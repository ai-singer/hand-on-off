# Phase 5.3 — Runtime Configuration Stabilization Audit

**Project:** Creator Agent Framework (creator-agent-template-v0.1.0)
**Repository:** https://github.com/ai-singer/hand-on-off
**Remote Baseline:** ed6a924
**Audit Date:** 2026-09-27
**Audit Scope:** Runtime Config, Bootstrap Flow, Artifact Validation, Version Governance, Test Coverage
**Audit Rule:** Audit only. No modifications to code, config, runtime, workflow, plugin, skill, or deployment packages.

---

## 1. Current Runtime Architecture

### 1.1 High-Level Chain

```
config/runtime/default.json
    ↓ load_runtime_config()
RuntimeConfig (dataclass with 5 sub-configs)
    ↓
┌─────────────────────────────────────────────────────┐
│  DistillationEngine(plugin, sources)                │
│  ┌───────────────────────────────────────────────┐  │
│  │ CommonExtractor.extract(sources)              │  │
│  │   → SourceClassifier.classify()               │  │
│  │   → 4 signal families: topic, structure,      │  │
│  │     knowledge, style                          │  │
│  └───────────────────────────────────────────────┘  │
│  ↓                                                │
│  plugin.enhance(sources, common_signals)            │
│  ↓                                                │
│  merged signals + domain extension                  │
│  ↓                                                │
│  evaluate_distillation_artifact()                   │
│  ↓                                                │
│  validate_unified_artifact(artifact, schema)        │
│  ↓                                                │
│  Returns: validated dict artifact                   │
└─────────────────────────────────────────────────────┘
    ↓
Lobster Workflow (content_distillation.lobster)
    → source_input → distill → plugin-check → gate → generation-handoff
```

### 1.2 Module Map

| Module | Path | Responsibility |
|--------|------|----------------|
| `config.runtime` | `config/runtime/` | Config loading + schema validation |
| `core` | `core/` | Data contracts, plugin loading, skill registry, schema validation |
| `distillation_core` | `distillation_core/` | Distillation engine, classifier, extractor |
| `plugin_interface` | `plugin_interface/` | Plugin ABC + dataclasses (stub) |
| `evaluation` | `evaluation/` | Artifact evaluation logic (stub) |
| `plugins.xiaolin_finance` | `plugins/xiaolin_finance/` | Finance domain plugin |
| `skills.openclaw` | `skills/openclaw/` | Skill adapter registry + 3 adapters |
| `workflows.lobster` | `workflows/lobster/` | Workflow definition + node contracts |

### 1.3 Runtime Init Chain

```
load_runtime_config(path?)
  → validates JSON schema (required fields, types, semver, skill names)
  → returns frozen RuntimeConfig dataclass

load_plugin(module_path)
  → importlib.import_module(module_path)
  → calls create_plugin() factory
  → validates CreatorDistillationPlugin ABC

discover_skills(skills_root)
  → scans */manifest.json files
  → validates required fields, entrypoint existence, duplicate names

discover_openclaw_skills(root)
  → scans */adapter.json files
  → validates required fields, name regex, semver, entrypoint, frontmatter

DistillationEngine(plugin, schema_path?, extractor?)
  → distill(sources)
  → orchestrates extraction → enhancement → evaluation → validation
```

**Gap:** There is no single bootstrap/initializer that wires `RuntimeConfig` → `DistillationEngine` → workflow execution. Each component loads independently.

---

## 2. Runtime Config Assessment

### 2.1 Config Inventory

| Field | Location | Description | Parsed? | Consumed? |
|-------|----------|-------------|---------|-----------|
| `instance.name` | `config/runtime/default.json` | Instance identifier string | ✅ | ❌ |
| `workflow.default` | `config/runtime/default.json` | Default Lobster workflow file path | ✅ | ❌ |
| `plugins.enabled` | `config/runtime/default.json` | List of enabled plugin module paths | ✅ | ❌ |
| `plugins.default` | `config/runtime/default.json` | Default plugin module path | ✅ | ❌ |
| `skills.enabled` | `config/runtime/default.json` | List of enabled skill names | ✅ | ❌ |
| `version` | `config/runtime/default.json` | Runtime version (semver) | ✅ | ❌ |

### 2.2 Config Loader Quality

**Loader:** `config/runtime/loader.py` — well-structured, dependency-free, uses frozen dataclasses.

**Validations present:**
- Required field presence (instance, workflow, plugins, skills)
- Type validation (mapping, string, non-empty string, string list)
- `plugins.default` must be present in `plugins.enabled`
- Version must match semver `X.Y.Z`
- Skill names must match `^[a-z0-9]+(?:-[a-z0-9]+)*$` (no underscores)
- No duplicate entries in list fields
- Normalization (strip whitespace)

**Validations absent:**
- No cross-reference between `skills.enabled` and actual discovered skills
- No cross-reference between `plugins.enabled` and actually loadable plugin modules
- No file existence check for `workflow.default` path
- No version compatibility check against schema versions
- No warning for unrecognized/extra fields
- No schema evolution / migration path
- No runtime overrides (e.g., environment variables, command-line args)
- No hot-reload or config validation against current state

### 2.3 Field-by-Field Consumption Audit

#### `instance.name`
- **Config value:** `"creator-agent-template"`
- **Consumed by:** Nowhere. The value is stored in `RuntimeConfig.instance.name` but no code reads it.
- **Expected uses:** Instance identity, work directory resolution, runtime state naming, log prefixing
- **Status:** ⚠️ **Parsed but not consumed**

#### `workflow.default`
- **Config value:** `"workflows/lobster/content_distillation.lobster"`
- **Consumed by:** Nowhere. The path is stored but no workflow loader or executor reads it.
- **Expected uses:** Workflow resolution, Lobster workflow loading, step execution
- **Status:** ⚠️ **Parsed but not consumed**

#### `plugins.enabled`
- **Config value:** `["plugins.xiaolin_finance"]`
- **Consumed by:** `load_plugin()` accepts a module path string directly — no awareness of `enabled` list.
- **Expected uses:** Plugin discovery, whitelist enforcement, loading only enabled plugins
- **Status:** ⚠️ **Parsed but not consumed**

#### `plugins.default`
- **Config value:** `"plugins.xiaolin_finance"`
- **Consumed by:** Nowhere. Only validated against `enabled` list during parsing.
- **Expected uses:** Default plugin selection when no plugin specified
- **Status:** ⚠️ **Parsed but not consumed**

#### `skills.enabled`
- **Config value:** `["source-ingestion", "unified-distillation", "quality-review"]`
- **Consumed by:** `discover_skills()` scans `*/manifest.json` — no awareness of `enabled` list. `discover_openclaw_skills()` scans `*/adapter.json` — also no awareness.
- **Expected uses:** Skill whitelist, selective loading, dependency resolution
- **Status:** ⚠️ **Parsed but not consumed**

#### `version`
- **Config value:** `"1.0.0"`
- **Consumed by:** Only validated against semver regex during parsing. Not compared to artifact version, schema version, or deployment metadata.
- **Expected uses:** Compatibility checks, deployment validation, rollback decisions
- **Status:** ⚠️ **Parsed but not consumed**

---

## 3. Bootstrap Assessment

### 3.1 Bootstrap Flow Analysis

**Current state: No unified bootstrap.**

The framework has four independent entry points, none of which coordinate:

```
Entry Point              Function                         Coordinates With
─────────────────────    ──────────────────────────       ────────────────
load_runtime_config()    Config loader                   None
load_plugin(module)      Plugin loader (by module path)  None
discover_skills(root)    Skill manifest scanner          None
discover_openclaw_skills(root)  Skill adapter scanner    None
```

### 3.2 Components Inventory

| Component | Exists? | Module | Notes |
|-----------|---------|--------|-------|
| Config loader | ✅ | `config.runtime.loader.load_runtime_config` | Solid, frozen dataclass |
| Runtime initializer | ❌ | — | No single bootstrap function |
| Component registry | ❌ | — | Plugin/skill registries load independently |
| Dependency resolver | ❌ | — | No dependency graph or ordering |
| State manager | ❌ | — | No runtime state tracking |

### 3.3 Bootstrap Gaps

| ID | Gap | Severity |
|----|-----|----------|
| B-01 | No `bootstrap()` function that wires config → plugin → skill → engine | **HIGH** |
| B-02 | `discover_skills()` expects `manifest.json` but none exist in the skills directory | **HIGH** |
| B-03 | `discover_openclaw_skills()` uses `adapter.json` (which does exist), but config's `skills.enabled` doesn't gate discovery | **MEDIUM** |
| B-04 | Plugin loading is by module path only; config's `plugins.enabled` list is never applied as a whitelist | **MEDIUM** |
| B-05 | No mechanism to load multiple plugins or switch between them at runtime | **LOW** |
| B-06 | No error recovery or graceful degradation on partial bootstrap failure (e.g., 1 of 3 skills fails) | **MEDIUM** |

### 3.4 Critical Gap: Missing manifest.json

`core/skill_registry.py::discover_skills()` scans `*/manifest.json` files:

```python
for path in sorted(root.glob("*/manifest.json")):
```

However, the skills directory contains only `adapter.json` files — **no `manifest.json` exists anywhere**. This means `discover_skills()` will always return an empty dict, even though `skills.enabled` lists three skills.

The `adapter.json` files are discovered by `discover_openclaw_skills()` instead. The two discovery systems are not unified.

---

## 4. Artifact Validation Assessment

### 4.1 Current Validation Layers

| Layer | Module | What it validates | Status |
|-------|--------|-------------------|--------|
| Config schema | `config.runtime.loader` | JSON structure, types, semver, name regex | ✅ Operational |
| Plugin interface | `core.plugin_loader._validate_plugin` | ABC conformance, identity completeness | ✅ Operational |
| Skill adapter | `skills.openclaw.adapter_registry` | adapter.json fields, entrypoint, frontmatter | ✅ Operational |
| Skill manifest | `core.skill_registry` | manifest.json fields, entrypoint | ⚠️ Non-functional (no manifests exist) |
| Artifact schema | `core.schema_validation` | JSON Schema draft 2020-12 subset | ✅ Operational |
| Distillation output | `distillation_core.engine` | Plugin enhancement fields, artifact validation | ✅ Operational |

### 4.2 Deployment Artifact Validation

**Current state: No deployment validation pipeline.**

| Check | Exists? | Notes |
|-------|---------|-------|
| File integrity (required files present) | ❌ | No deployment manifest or checklist |
| Skill dependency verification | ❌ | adapter.json declares dependencies but no validator checks them |
| Plugin runtime requirement verification | ❌ | No check for plugin dependencies before loading |
| Test declaration in deployment | ❌ | No deployment metadata mentioning tests |
| Schema version consistency | ❌ | Config version, artifact version, plugin version, schema version are all independent |
| Build → Artifact Manifest → Validation → Deploy pipeline | ❌ | No pipeline exists |

### 4.3 Artifact Validation Gaps

| ID | Gap | Severity |
|----|-----|----------|
| A-01 | No deployment artifact manifest listing required files | **HIGH** |
| A-02 | No file integrity verification (checksums, required files) | **HIGH** |
| A-03 | Skill adapter dependencies (`dependencies` array in adapter.json) are never validated at deploy time | **MEDIUM** |
| A-04 | Plugin runtime requirements (`runtime_requirements` in adapter.json) are never enforced | **MEDIUM** |
| A-05 | No build step producing versioned deployment artifacts | **HIGH** |
| A-06 | No `pyproject.toml`, `setup.py`, or `requirements.txt` — no Python packaging metadata | **MEDIUM** |

---

## 5. Findings

### 5.1 Runtime Config Findings

| ID | Severity | Description | Impact | Suggested Fix |
|----|----------|-------------|--------|---------------|
| S-03-01 | **HIGH** | `instance.name` is parsed but never consumed by any runtime component | Instance identity cannot be resolved at runtime; work directory and state naming have no source of truth | Wire `config.instance.name` to a runtime state object or instance resolver |
| S-03-02 | **HIGH** | `workflow.default` path is parsed but never resolved or loaded | The configured Lobster workflow file path is unused; workflow execution has no config-driven entry point | Create a workflow resolver that loads the configured `.lobster` file |
| S-03-03 | **HIGH** | `plugins.enabled` list is parsed but never applied as a whitelist | Any module path can be loaded via `load_plugin()` regardless of config; no runtime enforcement | Integrate `plugins.enabled` into the plugin loading path |
| S-03-04 | **HIGH** | `skills.enabled` list is parsed but `discover_skills()` has no awareness of it | Configured skills are not gated by the enabled list; discovery is blind to config | Merge `skills.enabled` into discovery or create a gated wrapper |
| S-03-05 | **MEDIUM** | `version` is validated but never compared to artifact/schema versions | No consistency check between runtime version 1.0.0 and artifact version 1.0.0 | Add version matrix validation at bootstrap |
| S-03-06 | **LOW** | No runtime config override mechanism (env vars, CLI, runtime patch) | Cannot adjust config without editing files | Add `os.environ` override layer |

### 5.2 Bootstrap Findings

| ID | Severity | Description | Impact | Suggested Fix |
|----|----------|-------------|--------|---------------|
| B-01 | **HIGH** | No unified bootstrap function wires config → components → engine | No guaranteed initialization order; each component loads in isolation | Author `bootstrap(RuntimeConfig)` that instantiates engine with loaded plugins/skills |
| B-02 | **HIGH** | `discover_skills()` expects `manifest.json` but none exist | Skill registry always returns empty; skills listed in config cannot be discovered via this path | Create `manifest.json` for each skill or unify with `discover_openclaw_skills()` |
| B-03 | **MEDIUM** | Two parallel skill discovery paths with no unification | `discover_skills()` and `discover_openclaw_skills()` are redundant but inconsistent | Consolidate to a single discovery mechanism |
| B-04 | **MEDIUM** | No dependency resolver between components | If skill A depends on skill B, there's no ordering guarantee | Build a topological dependency resolver |
| B-05 | **MEDIUM** | No graceful degradation on partial failure | One failed component blocks everything with no fallback | Implement partial bootstrap with failure reporting |
| B-06 | **LOW** | No mechanism to switch plugins at runtime | `plugins.default` exists but there's no runtime switching | Add plugin registry with `get_default()` and `get(name)` |

### 5.3 Artifact Validation Findings

| ID | Severity | Description | Impact | Suggested Fix |
|----|----------|-------------|--------|---------------|
| A-01 | **HIGH** | No deployment artifact manifest | Cannot verify a deployed package contains all required files | Create `DEPLOY_MANIFEST.json` or equivalent |
| A-02 | **HIGH** | No file integrity verification | Deployed artifacts cannot be verified for completeness | Add checksums + required-file checklist |
| A-03 | **MEDIUM** | Skill adapter dependencies unvalidated | A deployed skill might reference a missing dependency | Add `dependencies` validation at deploy time |
| A-04 | **MEDIUM** | Plugin runtime requirements unenforced | Plugin may run on incompatible Python/binary versions | Add `runtime_requirements` validation |
| A-05 | **HIGH** | No build step or versioned artifacts | No reproducible build pipeline | Add `Makefile` or build script producing versioned tarballs |
| A-06 | **MEDIUM** | No Python packaging metadata | Cannot install as pip package or verify dependencies | Add `pyproject.toml` with dependencies |

### 5.4 Test Coverage Findings

| Check | Status | Notes |
|-------|--------|-------|
| Runtime config tests | ⚠️ Partial | `RUNTIME_VALIDATION_REPORT.md` Test 4 covers semver and skill name validation; no tests for loader failure modes or missing fields |
| Bootstrap tests | ❌ None | No bootstrap function exists; no initialization tests |
| Deployment tests | ❌ None | `tests.deployment.test_skill_adapters` referenced in adapter.json `test` fields but no test files exist |
| Failure tests | ⚠️ Partial | Risk blocking test exists; no tests for config missing, plugin missing, skill missing |
| Schema validation tests | ⚠️ Partial | Covered indirectly via distillation tests; no unit tests for `core.schema_validation` |
| Plugin loader tests | ⚠️ Partial | Plugin loads in validation tests; no negative tests (invalid module, missing factory, ABC violation) |

---

## 6. Version Matrix

| Component | Version | Location | Consistent? |
|-----------|---------|----------|-------------|
| Runtime config `version` | `1.0.0` | `config/runtime/default.json` | — |
| Artifact `artifact_version` | `1.0.0` | Distillation engine (hardcoded), schema `$id` | ✅ Matches runtime config |
| Plugin `identity.version` | `1.0.0` | `plugins/xiaolin_finance/plugin.py` | ✅ Matches |
| Skill adapter versions | `1.0.0` | `skills/*/adapter.json` | ✅ Matches |
| Schema version (domain_extension) | `1.0.0` | `plugins/xiaolin_finance/plugin.py` | ✅ Matches |
| `pyproject.toml` | N/A | — | ❌ Missing |
| Deployment metadata | N/A | — | ❌ Missing |
| Git tag | `creator-agent-template-v0.1.0` | Git (remote) | ⚠️ Version mismatch: tag is v0.1.0, all internal versions are 1.0.0 |

**⚠️ Critical version inconsistency:** Git release tag is `v0.1.0` but all internal version references are `1.0.0`. This creates confusion about which version is authoritative.

---

## 7. Final Status

### Runtime Configuration Stabilization: **READY WITH ISSUES**

**Summary:**

- The runtime config loader is well-designed with thorough JSON schema validation, but **none of the parsed config fields are consumed by runtime behavior**. Config values are stored in frozen dataclasses but never wired to actual system components.
- The bootstrap chain is **fragmented** — four independent loaders with no coordinator, no dependency resolver, and no unified initialization.
- The **deployment artifact validation pipeline does not exist** — no build step, no manifest, no integrity checks, no packaging metadata.
- The **test infrastructure is incomplete** — test files referenced in adapter configs do not exist; failure mode tests are sparse.
- There is a **version inconsistency** between the Git release tag (`v0.1.0`) and all internal version references (`1.0.0`).

### Risk Summary

| Severity | Count | Key Items |
|----------|-------|-----------|
| HIGH | 9 | Config fields not consumed, no bootstrap, no deployment manifest, no integrity checks, no build step, missing manifests |
| MEDIUM | 7 | Version drift, no dependency resolver, no graceful degradation, unvalidated dependencies, no packaging metadata |
| LOW | 2 | No runtime config override, no runtime plugin switching |
| **Total** | **18** | |

---

## 8. Next Steps

1. **HIGH priority:** Wire `RuntimeConfig` fields to runtime components — create a bootstrap function that reads config and instantiates the distillation engine with the correct plugin, workflow, and skills.
2. **HIGH priority:** Create `manifest.json` files for each skill to make `discover_skills()` functional, or unify discovery with `discover_openclaw_skills()`.
3. **HIGH priority:** Create a deployment artifact manifest and build pipeline with file integrity verification.
4. **MEDIUM priority:** Resolve version inconsistency between Git tag (`v0.1.0`) and internal versions (`1.0.0`).
5. **MEDIUM priority:** Create missing test files (`tests/deployment/test_skill_adapters.py`, config loader failure tests, plugin loader negative tests).
6. **LOW priority:** Add runtime config override mechanism (env vars) and runtime plugin switching capability.
