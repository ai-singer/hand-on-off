#!/bin/bash
set -e
BASE="https://raw.githubusercontent.com/ai-singer/hand-on-off/creator-agent-template-v0.2.0-rc1/blank/workspace"
cd /home/node/.openclaw/workspace/blank/workspace

files=(
  "runtime/__init__.py"
  "runtime/bootstrap.py"
  "runtime/context.py"
  "runtime/errors.py"
  "workflows/lobster/runtime_adapter.py"
  "workflows/lobster/content_distillation.lobster"
  "workflows/lobster/node_contracts.json"
  "plugins/xiaolin_finance/plugin.py"
  "core/skill_registry.py"
  "core/plugin_loader.py"
  "core/models.py"
  "core/errors.py"
  "artifact/manifest.py"
  "artifact/validator.py"
  "artifact/schema.json"
  "evaluation/evaluator.py"
  "evaluation/quality_gate_controller.py"
  "distillation_core/engine.py"
  "distillation_core/classifier.py"
  "distillation_core/extractor.py"
  "config/runtime/default.json"
  "config/runtime/loader.py"
  "plugin_interface/base.py"
)

for f in "${files[@]}"; do
  curl -sL "${BASE}/${f}" -o "${f}"
  sz=$(wc -c < "${f}")
  echo "OK: ${f} (${sz} bytes)"
done

echo "=== ALL DOWNLOADED ==="
