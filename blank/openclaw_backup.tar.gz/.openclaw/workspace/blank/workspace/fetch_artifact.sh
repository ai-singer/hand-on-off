#!/bin/bash
set -e
cd /home/node/.openclaw/workspace/blank/workspace
mkdir -p artifact

for f in artifact/manifest.py artifact/validator.py; do
    encoded=$(curl -s "https://api.github.com/repos/ai-singer/hand-on-off/contents/${f}?ref=creator-agent-template-v0.2.0-rc1" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('content',''))")
    echo "$encoded" | python3 -c "import base64,sys; sys.stdout.buffer.write(base64.b64decode(sys.stdin.read()))" > "$f"
    echo "OK: $f"
done

echo "=== ARTIFACT DONE ==="
