#!/bin/bash
set -e
cd /home/node/.openclaw/workspace/blank/workspace

mkdir -p runtime workflows/lobster

# Fetch each file from GitHub API
fetch_file() {
    local path=$1
    local dest=$2
    local content
    content=$(curl -s "https://api.github.com/repos/ai-singer/hand-on-off/contents/${path}?ref=creator-agent-template-v0.2.0-rc1")
    local encoded
    encoded=$(echo "$content" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('content',''))")
    echo "$encoded" | python3 -c "import base64,sys; sys.stdout.buffer.write(base64.b64decode(sys.stdin.read()))" > "$dest"
    echo "OK: $dest"
}

fetch_file "runtime/__init__.py" "runtime/__init__.py"
fetch_file "runtime/bootstrap.py" "runtime/bootstrap.py"
fetch_file "runtime/context.py" "runtime/context.py"
fetch_file "runtime/errors.py" "runtime/errors.py"
fetch_file "workflows/lobster/runtime_adapter.py" "workflows/lobster/runtime_adapter.py"
fetch_file "workflows/lobster/content_distillation.lobster" "workflows/lobster/content_distillation.lobster"
fetch_file "workflows/lobster/node_contracts.json" "workflows/lobster/node_contracts.json"
fetch_file "plugins/xiaolin_finance/plugin.py" "plugins/xiaolin_finance/plugin.py"
fetch_file "core/skill_registry.py" "core/skill_registry.py"
fetch_file "core/plugin_loader.py" "core/plugin_loader.py"
fetch_file "core/models.py" "core/models.py"
fetch_file "core/errors.py" "core/errors.py"
fetch_file "artifact/manifest.py" "artifact/manifest.py"
fetch_file "artifact/validator.py" "artifact/validator.py"

echo "=== DONE ==="
