#!/bin/bash
set -e
BASE="https://raw.githubusercontent.com/ai-singer/hand-on-off/creator-agent-template-v0.2.0-rc1/blank/workspace"
cd /home/node/.openclaw/workspace/blank/workspace

files=(
  "skills/openclaw/source-ingestion/manifest.json"
  "skills/openclaw/unified-distillation/manifest.json"
  "skills/openclaw/quality-review/manifest.json"
)

for f in "${files[@]}"; do
  curl -sL "${BASE}/${f}" -o "${f}"
  sz=$(wc -c < "${f}")
  echo "OK: ${f} (${sz} bytes)"
done

echo "=== MANIFESTS DOWNLOADED ==="
