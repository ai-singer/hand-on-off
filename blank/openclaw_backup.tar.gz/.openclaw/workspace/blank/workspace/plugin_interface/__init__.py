"""Minimal stub for plugin_interface (external runtime dependency)."""
