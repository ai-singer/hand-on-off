"""Runtime schema validation."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def validate_runtime_schemas(
    schema_path: str | Path,
    data: dict[str, Any],
) -> bool:
    """Validate *data* against the JSON schema at *schema_path*.

    Returns ``True`` when the data is valid; raises ``ValueError`` on
    schema or validation failure.
    """

    path = Path(schema_path)
    if not path.is_file():
        raise FileNotFoundError(f"schema not found: {path}")

    schema = json.loads(path.read_text(encoding="utf-8"))

    # Minimal draft-07 style validation (sufficient for project needs).
    errors: list[str] = []

    def _validate(obj: Any, schema_node: dict, path_str: str = "$") -> None:
        if "type" in schema_node:
            expected = schema_node["type"]
            type_map = {
                "object": dict,
                "array": list,
                "string": str,
                "number": (int, float),
                "integer": int,
                "boolean": bool,
                "null": type(None),
            }
            if expected in type_map:
                if not isinstance(obj, type_map[expected]):
                    errors.append(f"{path_str}: expected {expected}, got {type(obj).__name__}")
                    return

        if "properties" in schema_node and isinstance(obj, dict):
            for prop, prop_schema in schema_node["properties"].items():
                if prop in obj:
                    _validate(obj[prop], prop_schema, f"{path_str}.{prop}")

        if "required" in schema_node and isinstance(obj, dict):
            for req in schema_node["required"]:
                if req not in obj:
                    errors.append(f"{path_str}: missing required field {req!r}")

    _validate(data, schema)

    if errors:
        raise ValueError("Schema validation failed:\n  " + "\n  ".join(errors))

    return True
