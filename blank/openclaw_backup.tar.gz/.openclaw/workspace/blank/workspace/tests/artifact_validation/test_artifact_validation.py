"""Artifact validation tests - Test D: Artifact validation."""

import sys
import json
import hashlib
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[2]))

from artifact.validator import validate_artifact, ValidationResult


def _setup_artifact_dir(tmpdir, extra_manifest=None):
    """Create a minimal artifact directory with all required files."""
    tmp = Path(tmpdir)
    # Create config
    config_dir = tmp / "config" / "runtime"
    config_dir.mkdir(parents=True)
    cfg_content = json.dumps({
        "instance": {"name": "test"},
        "workflow": {"default": "test"},
        "plugins": {"enabled": ["plugins.xiaolin_finance"], "default": "plugins.xiaolin_finance"},
        "skills": {"enabled": ["source-ingestion", "unified-distillation", "quality-review"]},
        "version": "1.0.0"
    })
    (config_dir / "default.json").write_text(cfg_content)
    # Create plugin
    (tmp / "plugins" / "xiaolin_finance").mkdir(parents=True)
    (tmp / "plugins" / "xiaolin_finance" / "__init__.py").write_text("")
    # Create skill manifests and SKILL.md
    for skill in ["source-ingestion", "unified-distillation", "quality-review"]:
        sdir = tmp / "skills" / "openclaw" / skill
        sdir.mkdir(parents=True)
        (sdir / "SKILL.md").write_text(f"# {skill}")
        manifest_data = {
            "name": skill, "version": "1.0.0", "entrypoint": "SKILL.md",
            "capabilities": ["test"], "test_command": "true"
        }
        (sdir / "manifest.json").write_text(json.dumps(manifest_data))
    # Create runtime file
    (tmp / "runtime").mkdir(parents=True)
    (tmp / "runtime" / "bootstrap.py").write_text("# bootstrap")
    # Collect files for manifest
    files = []
    for p in sorted(tmp.rglob("*")):
        if p.is_file() and p.name != "artifact-manifest.json":
            data = p.read_bytes()
            files.append({
                "path": str(p.relative_to(tmp)),
                "sha256": hashlib.sha256(data).hexdigest(),
                "size": len(data),
            })
    # Create manifest
    manifest = {
        "manifest_version": "1.0.0",
        "artifact_id": "test-artifact-001",
        "version": "0.2.0-rc1",
        "created_at": "2026-09-27T06:00:00Z",
        "runtime_version": "1.0.0",
        "config_version": "1.0.0",
        "enabled_plugins": ["plugins.xiaolin_finance"],
        "enabled_skills": ["source-ingestion", "unified-distillation", "quality-review"],
        "files": files,
    }
    if extra_manifest:
        manifest.update(extra_manifest)
    mpath = tmp / "artifact-manifest.json"
    mpath.write_text(json.dumps(manifest))
    return mpath


class TestArtifactValidation(unittest.TestCase):
    """Test artifact manifest and validator."""

    def test_valid_artifact(self):
        """Test 1: Valid artifact directory with matching manifest should pass."""
        with tempfile.TemporaryDirectory() as tmpdir:
            mpath = _setup_artifact_dir(tmpdir)
            result = validate_artifact(tmpdir, manifest_path=mpath)
            self.assertIsInstance(result, ValidationResult)
            self.assertEqual(len(result.findings), 0, f"Unexpected findings: {result.findings}")

    def test_invalid_hash(self):
        """Test D: Tampered manifest should be rejected."""
        with tempfile.TemporaryDirectory() as tmpdir:
            _setup_artifact_dir(tmpdir, {"artifact_id": "tampered-artifact"})
            mpath = Path(tmpdir) / "artifact-manifest.json"
            # Tamper the manifest after creation
            manifest = json.loads(mpath.read_text())
            manifest["files"][0]["sha256"] = "deadbeef" * 8
            mpath.write_text(json.dumps(manifest))
            result = validate_artifact(tmpdir, manifest_path=mpath)
            self.assertIsInstance(result, ValidationResult)
            self.assertGreater(len(result.findings), 0)

    def test_missing_artifact_dir(self):
        """Test D: Non-existent artifact directory should fail."""
        result = validate_artifact("/nonexistent/path/that/does/not/exist")
        self.assertIsInstance(result, ValidationResult)
        self.assertGreater(len(result.findings), 0)


if __name__ == "__main__":
    unittest.main()
