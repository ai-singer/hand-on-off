"""Quality gate test - Test 3: Risk input should be blocked."""

import sys
import unittest
import json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[2]))

from evaluation.quality_gate_controller import QualityGateController
from evaluation.quality_gate_controller import GateDecision


class TestQualityGate(unittest.TestCase):
    """Test quality gate risk blocking."""

    def test_risk_blocked(self):
        """Test 3: Quality Gate should BLOCK violating content."""
        qgc = QualityGateController()
        # Simulate content that violates quality rules
        risk_content = {
            "title": "Test",
            "body": "<script>alert('xss')</script>",
            "risk_level": "high",
            "can_continue": False,
        }
        result = qgc.decide(risk_content)
        self.assertEqual(result.decision, GateDecision.FAIL)
        self.assertIn("FAIL", result.quality_report.get("gate_decision", ""))


if __name__ == "__main__":
    unittest.main()
