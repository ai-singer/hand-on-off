"""Runtime config test - Test B & C: Missing plugin/skill should fail."""

import sys
import json
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[2]))

from runtime.bootstrap import bootstrap
from runtime.errors import RuntimeBootstrapError


class TestRuntimeConfig(unittest.TestCase):
    """Test runtime config validation for missing components."""

    def test_missing_plugin(self):
        """Test B: Non-existent plugin should cause startup failure."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            bad_config = tmp_path / "bad_config.json"
            bad_config.write_text(json.dumps({
                "instance": {"name": "test"},
                "workflow": {"default": "test"},
                "plugins": {"enabled": ["plugins.nonexistent"], "default": "plugins.nonexistent"},
                "skills": {"enabled": ["source-ingestion"]},
                "version": "1.0.0"
            }))
            with self.assertRaises(RuntimeBootstrapError):
                bootstrap(config_path=bad_config)

    def test_missing_skill(self):
        """Test C: Non-existent skill should cause startup failure."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            bad_config = tmp_path / "bad_config.json"
            bad_config.write_text(json.dumps({
                "instance": {"name": "test"},
                "workflow": {"default": "test"},
                "plugins": {"enabled": ["plugins.xiaolin_finance"], "default": "plugins.xiaolin_finance"},
                "skills": {"enabled": ["nonexistent-skill"]},
                "version": "1.0.0"
            }))
            with self.assertRaises(RuntimeBootstrapError) as ctx:
                bootstrap(config_path=bad_config)
            self.assertIn("no discoverable manifest", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
