"""Bootstrap validation tests."""

import os
import sys
import tempfile
import json
import unittest
from pathlib import Path

# Ensure workspace is on path
sys.path.insert(0, str(Path(__file__).parents[2]))

from runtime.bootstrap import bootstrap, SUPPORTED_CONFIG_VERSION
from runtime.errors import RuntimeBootstrapError
from config.runtime import load_runtime_config


class TestBootstrap(unittest.TestCase):
    """Test runtime bootstrap flow."""

    def setUp(self):
        """Load workspace path."""
        # Tests live in tests/runtime_bootstrap/ inside blank/workspace/
        self.workspace = Path(__file__).parents[2]
        self.config_path = self.workspace / "config" / "runtime" / "default.json"

    def test_bootstrap_success(self):
        """Test 1: Normal bootstrap should succeed."""
        ctx = bootstrap(config_path=self.config_path)
        self.assertEqual(ctx.instance, "creator-agent-template")
        self.assertEqual(ctx.version, "1.0.0")
        self.assertIn("plugins.xiaolin_finance", ctx.plugins)
        self.assertIn("source-ingestion", ctx.skills)
        self.assertIn("unified-distillation", ctx.skills)
        self.assertIn("quality-review", ctx.skills)
        self.assertEqual(ctx.workflow.name, "creator-agent-content-distillation")
        self.assertEqual(
            ctx.workflow.steps,
            ("source_input", "unified_distillation", "creator_plugin_enhancement", "quality_gate", "content_generation"),
        )

    def test_version_validation(self):
        """Test A: Incompatible version should raise RuntimeBootstrapError."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            bad_config = tmp_path / "bad_config.json"
            # Note: schema validation blocks empty skills before version validation,
            # so we provide a minimal valid skills array
            bad_config.write_text(json.dumps({
                "instance": {"name": "test"},
                "workflow": {"default": "test"},
                "plugins": {"enabled": ["none"], "default": "none"},
                "skills": {"enabled": ["dummy"]},
                "version": "2.0.0"
            }))
            with self.assertRaises(RuntimeBootstrapError) as ctx:
                bootstrap(config_path=bad_config)
            self.assertIn("not compatible", str(ctx.exception))

    def test_version_format_validation(self):
        """Test: Non-semantic version should raise RuntimeBootstrapError."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            bad_config = tmp_path / "bad_config.json"
            # Note: schema validation blocks empty skills before version validation,
            # so we provide a minimal valid skills array
            bad_config.write_text(json.dumps({
                "instance": {"name": "test"},
                "workflow": {"default": "test"},
                "plugins": {"enabled": ["none"], "default": "none"},
                "skills": {"enabled": ["dummy"]},
                "version": "invalid"
            }))
            with self.assertRaises(RuntimeBootstrapError) as ctx:
                bootstrap(config_path=bad_config)
            self.assertIn("semantic version", str(ctx.exception))


class TestPluginValidation(unittest.TestCase):
    """Test plugin loading."""

    def setUp(self):
        # Tests live in tests/runtime_bootstrap/ inside blank/workspace/
        self.workspace = Path(__file__).parents[2]
        self.config_path = self.workspace / "config" / "runtime" / "default.json"

    def test_plugin_loaded(self):
        """Test 2: xiaolin_finance plugin should be loaded."""
        ctx = bootstrap(config_path=self.config_path)
        self.assertIn("plugins.xiaolin_finance", ctx.plugins)
        plugin = ctx.plugins["plugins.xiaolin_finance"]
        self.assertEqual(plugin.__class__.__name__, "XiaolinFinancePlugin")


class TestSkillValidation(unittest.TestCase):
    """Test skill discovery."""

    def setUp(self):
        # Tests live in tests/runtime_bootstrap/ inside blank/workspace/
        self.workspace = Path(__file__).parents[2]
        self.config_path = self.workspace / "config" / "runtime" / "default.json"

    def test_skills_discovered(self):
        """Test 3: All configured skills should be discovered."""
        ctx = bootstrap(config_path=self.config_path)
        expected = {"source-ingestion", "unified-distillation", "quality-review"}
        self.assertEqual(set(ctx.skills.keys()), expected)


class TestWorkflowValidation(unittest.TestCase):
    """Test workflow binding."""

    def setUp(self):
        # Tests live in tests/runtime_bootstrap/ inside blank/workspace/
        self.workspace = Path(__file__).parents[2]
        self.config_path = self.workspace / "config" / "runtime" / "default.json"

    def test_workflow_bound(self):
        """Test 4: Workflow should be bound with correct steps."""
        ctx = bootstrap(config_path=self.config_path)
        self.assertEqual(ctx.workflow.name, "creator-agent-content-distillation")
        expected_steps = (
            "source_input",
            "unified_distillation",
            "creator_plugin_enhancement",
            "quality_gate",
            "content_generation",
        )
        self.assertEqual(ctx.workflow.steps, expected_steps)


if __name__ == "__main__":
    unittest.main()
