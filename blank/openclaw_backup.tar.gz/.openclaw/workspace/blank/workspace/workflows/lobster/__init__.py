"""OpenClaw Lobster deployment adapter."""
