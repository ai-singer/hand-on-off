---
name: creator_skill_library
version: 1.0.0
description: A shared skill library for building creator agents.
---

# creator_skill_library

A **skill library**, not a creator and not a runtime. Upload it once; from then on a domain request is answered by the library itself.

- version: `1.0.0`
- skills: 13 (10 universal, 3 meta)
- buildable domains: 3
- digests: `manifest.json` (`hashes`), and `checksums.json` per member

## How it is used

1. Upload this library to the Shared Skill Library.
2. A user asks for a creator in some domain.
3. `domain-plugin-builder` turns that request into a domain plugin.
4. `domain-plugin-validator` checks the plugin before anything uses it.
5. The agent is configured from the plugin and the universal skills.

Generated domain plugins are **not** in this archive. They are produced at run time and live with the creator they configure.

## Universal Creator Skills (10)

The same skills for every domain. Each carries no domain knowledge.

- `generation-interface` — Declare the interface a generation adapter must satisfy.
- `identity-rules` — Turn a declared domain identity into an instance identity block.
- `publishing-interface` — Declare the interface a publishing adapter must satisfy.
- `quality-review` — Evaluate an artifact against the shared quality contract.
- `risk-review` — Evaluate an artifact against the declared risk constraints.
- `source-discovery` — Find and enumerate the material a creator draws from.
- `source-normalization` — Normalize raw material into the shape the pipeline consumes.
- `template-extraction` — Extract reusable structure from finished material.
- `text-distillation` — Distill normalized material into the text rules an instance carries.
- `visual-distillation` — Distill visual references into the visual rules an instance carries.

## Meta Skills (3)

The skills that build and check the plugins.

- `domain-plugin-builder` — Turn a domain request into a domain plugin document.
- `domain-plugin-validator` — Check a domain plugin for protocol conformance, isolation and provenance.
- `skill-composer` — Assemble the set of universal skills a composed creator needs.

## Buildable Domains (3)

Domains this library can build a plugin for. Each is a registry entry, not a shipped skill set: adding a domain adds a row here, not a new library.

- `finance` → `domain_finance_plugin` (v1.0.0)
- `sports` → `domain_sports_plugin` (v1.0.0)
- `technology` → `domain_technology_plugin` (v1.0.0)

## Layout

```text
creator_skill_library/
├── LIBRARY.md
├── manifest.json
├── checksums.json
├── version.json
├── universal_skills/<skill>/{SKILL.md,manifest.json,skill.json}
├── meta_skills/<skill>/{SKILL.md,manifest.json,skill.json}
├── domain_plugins/registry.json
└── schemas/domain_plugin.schema.json
```

## What this library does not contain

- no runtime, no entry point, no executable code
- no prompt
- no credential, token or key
- no generated domain plugin
