---
name: domain-plugin-builder
version: 1.0.0
library_layer: meta
description: Turn a domain request into a domain plugin document.
---

# domain-plugin-builder

Turn a domain request into a domain plugin document.

## Layer

**Meta Skill.** This skill operates on domain plugin documents and on the library itself. A generated plugin is built and checked *by* the meta skills; it never runs them.

## Capability

- skill type: `builder`
- produces: a domain plugin
- accepts: `domain_request`

## Declaration

This skill is a **declaration**, not an implementation. It states what is possible and what it consumes. It carries no prompt to send to a model, no executable body and no credential of any kind; its machine-readable form is `skill.json` beside this file.

## Companions

The other skills released in this library version. A skill is selected alongside these, never instead of them.

- `domain-plugin-validator`
- `generation-interface`
- `identity-rules`
- `publishing-interface`
- `quality-review`
- `risk-review`
- `skill-composer`
- `source-discovery`
- `source-normalization`
- `template-extraction`
- `text-distillation`
- `visual-distillation`

## Provenance

- library version: `1.0.0`
- layer: `meta`
- manifest: `manifest.json`
