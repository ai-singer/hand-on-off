---
name: domain-plugin-validator
version: 1.0.0
library_layer: meta
description: Check a domain plugin for protocol conformance, isolation and provenance.
---

# domain-plugin-validator

Check a domain plugin for protocol conformance, isolation and provenance.

## Layer

**Meta Skill.** This skill operates on domain plugin documents and on the library itself. A generated plugin is built and checked *by* the meta skills; it never runs them.

## Capability

- skill type: `validator`
- produces: a validation report
- accepts: `domain_plugin`

## Declaration

This skill is a **declaration**, not an implementation. It states what is possible and what it consumes. It carries no prompt to send to a model, no executable body and no credential of any kind; its machine-readable form is `skill.json` beside this file.

## Companions

The other skills released in this library version. A skill is selected alongside these, never instead of them.

- `domain-plugin-builder`
- `generation-interface`
- `identity-rules`
- `publishing-interface`
- `quality-review`
- `risk-review`
- `skill-composer`
- `source-discovery`
- `source-normalization`
- `template-extraction`
- `text-distillation`
- `visual-distillation`

## Provenance

- library version: `1.0.0`
- layer: `meta`
- manifest: `manifest.json`
