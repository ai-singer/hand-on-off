---
name: publishing-interface
version: 1.0.0
library_layer: universal
description: Declare the interface a publishing adapter must satisfy.
---

# publishing-interface

Declare the interface a publishing adapter must satisfy.

## Layer

**Universal Creator Skill.** This skill is the same for every domain, and it carries no domain knowledge. If a domain fact is needed here, it belongs in a domain plugin instead.

## Capability

- skill type: `publishing`
- produces: a declared capability

## Declaration

This skill is a **declaration**, not an implementation. It states what is possible and what it consumes. It carries no prompt to send to a model, no executable body and no credential of any kind; its machine-readable form is `skill.json` beside this file.

## Companions

The other skills released in this library version. A skill is selected alongside these, never instead of them.

- `domain-plugin-builder`
- `domain-plugin-validator`
- `generation-interface`
- `identity-rules`
- `quality-review`
- `risk-review`
- `skill-composer`
- `source-discovery`
- `source-normalization`
- `template-extraction`
- `text-distillation`
- `visual-distillation`

## Provenance

- library version: `1.0.0`
- layer: `universal`
- manifest: `manifest.json`
