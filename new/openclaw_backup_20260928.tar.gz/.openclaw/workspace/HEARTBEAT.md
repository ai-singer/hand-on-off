# HEARTBEAT.md


# Proactive Task Scheduler


## Purpose

Define periodic checks and proactive actions.

Heartbeat does not define:

- Content strategy.
- Writing style.
- Visual generation rules.
- Publishing standards.

Related business logic belongs to:

agent_config/


---

# Scheduled Checks


## Content Production Check


Frequency:

Daily


Check:

- Whether there are pending content tasks.
- Whether source materials need processing.
- Whether generated content requires review.


Action:

If pending tasks exist:

Follow:

agent_config/operation.md



---


## Review Feedback Check


Frequency:

Daily


Check:

- New review results.
- Failed publications.
- User feedback.


Action:

Record issues and route them to the responsible review or improvement process.



---


## Operation Status Check


Frequency:

Daily


Check:

- Current production status.
- Published content status.
- Pending tasks.


Action:

Generate operation summary.



---


# Phanthy 私信轮询


Frequency:

每次心跳


Action:

1. GET https://cms.phanthy.com/api/v1/openclaw/messages
   Authorization: Bearer phanthy_22f3c1ab1db513c167b3446ce1f30c01

2. 如有消息（messages 数组非空）：
   - 以财叔人设生成回复（财经机制解释型，不提供投资建议，回复200字以内）
   - POST https://cms.phanthy.com/api/v1/openclaw/messages/<delivery_id>/reply
     body: {"content": "<回复内容>", "version": <version>, "leaseToken": "<leaseToken>"}
   - 如有 hasMore=true，继续取下一批

3. GET https://cms.phanthy.com/api/v1/openclaw/comments/unread
   如有评论，同样方式回复（回复限300字以内）

4. 无消息无评论：不输出任何内容，继续正常心跳判断


# Phanthy 发布 API 说明（2026-09-22 更新）

**正确端点：** `POST https://cms.phanthy.com/api/v1/openclaw/posts`（复数）
**已废弃：** `/api/v1/openclaw/post`（单数，legacy，返回 30001）

必须携带：
- `Idempotency-Key: <uuid>` header
- `cover_file_id`（文件 ID，非 URL）
- `media`: `[{"file_id": "..."}]`
- **正文字段名：`body`（不是 `content`）**

图片上传流程：
1. POST `/api/v1/openclaw/files/upload-authorizations` → 获取 signed URL
2. PUT 图片到 signed URL（不带 Authorization header）
3. POST `/api/v1/openclaw/files/<file_id>/complete` → 等待 status=READY
4. 在 posts 请求中引用 file_id


---


# Source Material Sync


Frequency:

每次心跳（Daily 亦可，视素材更新频率）


Steps:

1. 进入临时克隆目录，拉取最新内容：
   ```
   cd /home/node/.openclaw/workspace/ai-singer/hand-on-off && git pull
   ```

2. 将更新内容合并进本地工作目录（不覆盖已有文件）：
   ```
   cp -rn source_material/. /home/node/.openclaw/workspace/hand-on-off/source_material/
   ```

3. 合并完成后，`ai-singer/hand-on-off/` 仅作为 git 同步中转，不直接用于生产流程。

4. 生产流程读取素材路径：
   `/home/node/.openclaw/workspace/hand-on-off/source_material/`


Notes:

- 如有冲突（同名文件），保留本地版本（`cp -rn` 的 `-n` 保证不覆盖）。
- 如需强制用远端覆盖，需人工确认后执行 `cp -rf`。


---


# Heartbeat Rules

The Agent should:

- Perform lightweight checks.
- Avoid unnecessary actions.
- Follow operation workflow before external actions.

The Agent should not:

- Generate content without a production task.
- Publish content without review.
- Modify configuration without identifying the responsible process.

---

# 心跳自动化生产（每次心跳必须执行）

## 执行顺序

**Step A — 私信/评论轮询**（见上方 Phanthy 私信轮询章节）

**Step B — 检查发帖进度**
1. 读取当日日志（`memory/YYYY-MM-DD.md`，日期取当前UTC日期），统计已发篇数
2. 无每日上限，直接继续 Step C

**Step C — 检查话题库**
1. 读取 topic_pool.json（路径：`hand-on-off/source_material/xhs/creator_registry/topic_pool.json`）
2. 统计未发布话题数量
3. 如果未发布 < 5 条：先执行话题爬取补充（搜索小红书财经类S/A级内容追加到pool），再继续
4. 取第一条未发布 S/A 级话题开始生产

**Step D — 完整生产流程**
按以下顺序执行（每篇）：
1. 生成正文草稿（600-900字，财叔人设，机制解释型，冲突前置→机制深挖→金句收尾）
2. 生成5张配图（Gemini Image，按 Series Binding Protocol：先绑定系列→按角色顺序逐张生成→唯一性校验）
3. 上传图片（upload-authorizations → PUT signed URL → complete）
4. 发布到 `POST https://cms.phanthy.com/api/v1/openclaw/posts`（带 Idempotency-Key）
5. 记录 Post ID 到 `memory/YYYY-MM-DD.md`（当前UTC日期）
6. 标记话题为已发布
7. 检查剩余话题数，< 5 则触发爬取
8. 继续下一篇（回到 Step C），无篇数上限，直到话题耗尽或本次 session 超时


---

# 自动化发帖流程（每次心跳执行）

## 目标
持续发帖，无每日上限，不重复。每次心跳（30分钟）触发后尽量多发。

## 话题库补充规则（固化）
每次发帖后检查 topic_pool.json 中未发布话题数量：
- 如果未发布话题 **< 5 条**：立即触发话题爬取补充
- 爬取来源：小红书财经类内容（不限目标博主，S/A级即可入库）
- 爬取完成后更新 topic_pool.json

## 完整发帖流程（自动重复）

每篇执行以下步骤：

**Step 1 — 选题**
- 从 topic_pool.json 取第一条未发布 S/A 级话题
- 检查已发帖记录，跳过已发布选题

**Step 2 — 内容生成**
- 参考模板：`agent_config/distilled/content_templates_finance_xhs.md` 和 `content_templates_finance_xhs_external.md`
- 财叔人设：机制解释型，不提供投资建议
- 正文 600-900 字，结构：冲突前置→机制深挖→金句收尾

**Step 3 — 配图生成（Series Binding Protocol 强制执行）**

> ⚠️ 必须按以下顺序执行，不得跳过系列绑定步骤

**3a — 系列绑定（生图前执行一次）**
1. 根据本篇内容模板类型，从 `visual_prompt_templates_finance_xhs_external.md` → Series Binding Protocol Step 1 选定视觉模板和主题色
2. 生成并记录系列绑定参数：
   - `series_id` = 标题前6字 + Post UTC时间戳后4位
   - `visual_template` = 选定模板编号
   - `accent_color` = 本篇统一强调色（HEX）
   - `bg_color` = 本篇统一背景色（HEX）
   - `series_label` = 主题词系列（如「监管机制」系列）

**3b — 按角色分工生成5张图（顺序执行，不并行）**
| 图序 | 角色 | 核心要求 |
|---|---|---|
| 图1（封面） | Hook抛出 | 标题+核心冲突问题，**不出现答案文字** |
| 图2（机制图） | 原因拆解 | 必须有箭头或层级结构，**无重复文字块** |
| 图3（案例图） | 现实锚定 | 必须出现具体数字或机构名，**不得与图2重复信息** |
| 图4（数据/延伸图） | 深度支撑 | 必须包含数字对比或时间轴，**不得与图2/3重复** |
| 图5（金句收尾） | 认知升华 | 纯文字金句，≤2句话，**与前4张视觉差异最大** |

每张 prompt 开头携带系列标识块（格式见 Series Binding Protocol Step 3）

**3c — 生成后唯一性校验（5张全部生成后执行）**
按 Series Binding Protocol Step 4 逐条校验：
- ✅ 5张图角色各不相同（无重复角色）
- ✅ 图1封面未出现答案文字
- ✅ 图2包含箭头/层级结构描述
- ✅ 图3包含具体数字或机构名
- ✅ 图4包含数字对比或时间轴
- ✅ 图5文字≤2句话
- ✅ 全部5张 prompt 开头含 series_id 标识
- ✅ 全部5张强调色/背景色一致

任一不满足 → 单独补生成该张，不重置其他图，通过后继续

参考文件：`agent_config/distilled/visual_prompt_templates_finance_xhs_external.md`
使用 Gemini Image skill

**Step 4 — 上传 & 发布**
- 图片上传流程：POST upload-authorizations → PUT signed URL → POST complete
- **发布前确认图片数量：`len(media) >= 5`，不满足则返回 Step 3 补充生成，绝不允许上传单图**
- 发布端点：`POST https://cms.phanthy.com/api/v1/openclaw/posts`
- 必须携带 Idempotency-Key header
- 标签：科普

**Step 5 — 记录 & 循环**
- 将 Post ID、标题、状态写入 `memory/YYYY-MM-DD.md`（当前UTC日期）
- 将 topic_pool.json 中该条标记为已发布
- 检查剩余未发布话题数，如 < 5 则触发爬取
- 继续下一篇（Step 1），无篇数上限，直到话题耗尽或超时