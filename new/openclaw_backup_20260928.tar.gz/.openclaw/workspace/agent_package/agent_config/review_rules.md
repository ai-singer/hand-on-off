# Review Rules v2.1

# Platform

Platform:

小红书 (XHS)

------------------------------------------------------------------------

# Publishing Gate Principle

Review is the final quality gate before publishing.

A post can be published only when:

-   Content rules pass.
-   Source verification passes.
-   Identity consistency passes.
-   Visual requirements pass.
-   XHS platform compliance passes.

------------------------------------------------------------------------

# Review Pipeline

Review flow:

Draft Content

↓

Source Check

↓

Fact Check

↓

Content Quality Check

↓

Visual Series Review

↓

Cover Review

↓

Copy Review

↓

XHS Compliance Review

↓

Publish Decision

------------------------------------------------------------------------

# Source Check

Verify:

□ Source material exists.

□ Source origin is identifiable.

□ Important claims can be traced.

□ Content does not exceed available evidence.

Reject:

-   Unknown source.
-   Fake references.
-   Unsupported factual claims.

------------------------------------------------------------------------

# Fact Check

## Numeric Claims

Check:

-   Numbers.
-   Time periods.
-   Efficiency improvements.
-   Comparison results.

Requirement:

Claims must have:

-   Evidence.
-   Source.
-   Clear context.

If evidence is missing:

Reduce certainty or remove the claim.

------------------------------------------------------------------------

## Tool Capability Check

Check statements about:

-   Software functions.
-   Product capabilities.
-   Platform features.
-   AI model abilities.

Requirement:

Descriptions must be:

-   Source supported.
-   Accurate.
-   Not exaggerated.

Reject:

-   Invented features.
-   Unsupported capability claims.

------------------------------------------------------------------------

## Attribution Check

Check:

-   Quotes.
-   Opinions.
-   Personal statements.

Rules:

Do not write:

"Someone said..."

without source evidence.

------------------------------------------------------------------------

# Content Quality Check

Verify:

## Value

Content provides:

-   Useful information.
-   Practical methods.
-   Clear understanding.

## Structure

Check:

-   Hook present in first 2 lines.
-   Value Promise stated.
-   Core Information delivers the promise.
-   Interpretation Layer present (explains mechanism, not only phenomenon).
-   Interaction element present (max 1).

## Authenticity

Reject:

-   Fake personal experience.
-   Fabricated cases.
-   Empty AI-generated summaries.

------------------------------------------------------------------------

# Visual Series Review

## Series Completeness

Check:

□ Post contains 3–9 images.

□ **Image count hard gate (Phanthy platform rule):**
  - 知识笔记 / 财经科普 类：最少 **5 张**（含封面）
  - 好物分享 / 电子设备测评类：最少 3 张
  - 所有帖子：绝对最低 2 张（单图直接拒绝）
  - **发布前必须确认 `media` 数组长度 ≥ 5（财经科普帖）**

□ Images form a coherent series (not a random collection).

□ Image order follows a logical or narrative progression.

□ Removing any image would reduce the post's value.

## Image Role Assignment

Check:

□ Each image has a declared role (Hook / Context / Detail / Explanation / Result / CTA).

□ No two adjacent images share the same role.

□ A single post does not have more than 2 images with the same role.

## Information Progression

Check:

□ Information builds across images (each image adds a new point).

□ No information is repeated across images.

□ Final image provides conclusion or call-to-action.

## Non-Redundancy

Check:

□ No two images are visually similar (same scene, same angle, minor crop difference).

□ No data point or information is shown twice.

□ No filler images exist solely to reach a count target.

Reject criteria:

-   High visual similarity between any two images.
-   Same information conveyed by multiple images.
-   Images with no distinct contribution to the series.

------------------------------------------------------------------------

# Cover Review

The cover (Image 1) is the sole traffic entry point. Apply stricter review.

Check:

## Attention Capture

□ Cover communicates the post topic within 2 seconds.

□ Cover creates a clear reason to stop scrolling.

□ Cover does not require reading the title to understand the subject.

## Title Readability

□ Title text ≤ 15 characters (display text on cover image).

□ Title text is readable at thumbnail scale (375px wide).

□ Font size is dominant in the visual hierarchy.

□ Text contrast is sufficient against background.

## Visual Focus

□ Cover has a single clear visual focal point.

□ Cover is not cluttered with multiple competing elements.

□ Composition guides eye to the title and main subject.

## Click Motivation

□ Cover + title combination creates a reason to click.

□ Cover does not misrepresent the content.

□ Cover matches the emotional tone of the content.

------------------------------------------------------------------------

# Copy Review

## Title Check

□ Title ≤ 20 characters.

□ Title uses one of the four XHS title types:
  - Question Hook
  - Curiosity Gap
  - Number Hook
  - Contrast Hook

□ Title matches actual content (no clickbait).

## Hook Check

□ First 2 lines contain a Hook.

□ Hook triggers pain point, curiosity, or scene immersion.

□ Hook is not a generic opener ("今天来分享一下...").

## Copy Structure Check

□ Value Promise present after Hook.

□ Core Information structured in short paragraphs (≤ 4 lines each).

□ Interpretation Layer present before final section (explains mechanism, not only phenomenon).

□ Interaction element present at end (max 1).

## Rhythm Check

□ Paragraph count: 4–8 paragraphs for standard posts.

□ Total word count: 300–800 characters.

□ No single paragraph exceeds 4 lines.

□ Information segments and emotional segments alternate.

## Image-Copy Relationship

□ Copy does not repeat information already expressed in images.

□ Copy supplements images (adds background, reason, or emotion).

□ Image text (overlay) is independently readable.

Reject:

-   Copy that duplicates image content verbatim.
-   Copy that ignores the image sequence entirely.

------------------------------------------------------------------------

# XHS Compliance Review

## Tag Format

□ All tags use # format (e.g., #视频创作).

□ Tag count: 3–6 tags.

□ Tags match actual content topic.

□ No tags added solely for traffic without content relevance.

## Prohibited Content Risk

□ No absolute superlatives that violate advertising law
  (禁止："最好"、"第一"、"100%有效"、"绝对").

□ No medical, financial, or legal claims without qualification.

□ No false comparison claims.

## Over-Marketing Risk

□ No forced urgency language ("现在不看就晚了").

□ No coercive follow prompts ("不关注会后悔").

□ No exaggerated result promises without evidence.

## Off-Platform Traffic Risk

□ No external links in post body.

□ No mentions of competing platform names in a promotional context.

□ No QR codes or contact information designed to redirect users off-platform.

## Image Compliance

□ All images are 3:4 or 1:1 ratio.

□ No watermarks from competing platforms visible.

□ No prohibited symbols or content in images.

□ **Pre-publish image count hard block:**
  发布前验证 `len(media) >= 5`（财经科普帖）。
  如果 < 5，禁止发布，返回 Phase 4 补充生成缺失图片后重新审核。

------------------------------------------------------------------------

# Identity Check

Reference:

IDENTITY.md

SOUL.md

Verify:

-   Role consistency.
-   Expression consistency.
-   No false identity claims.

------------------------------------------------------------------------

# Decision Rules

PASS:

All required checks pass.

FAIL:

Any critical rule fails.

Failure should record:

-   Failure reason.
-   Responsible configuration file.
-   Improvement direction.

------------------------------------------------------------------------

# Failure Routing

Source problem:

→ source_strategy.md

Writing problem:

→ text_generation.md

Content direction problem:

→ content_strategy.md

Visual problem:

→ visual_strategy.md

Review rule problem:

→ review_rules.md

Operation problem:

→ operation.md

------------------------------------------------------------------------

# Responsibility Boundary

review_rules.md defines:

-   Publishing requirements.
-   Quality gates.
-   Validation standards.
-   XHS platform compliance checks.
-   Visual series review.
-   Cover review.
-   Copy review.

review_rules.md does not define:

-   Content topic.
-   Writing style.
-   Visual creativity.
-   Agent identity.

------------------------------------------------------------------------

# Version

v2.2

Changes from v2.1:

-   Visual Series Review: added image count hard gate for Phanthy platform.
    财经科普帖最少5张（含封面）；单图直接拒绝（对应平台拒稿原因“单图”）。
-   XHS Compliance Review: added pre-publish hard block, `len(media) >= 5`。

Changes from v2.0:

-   Copy structure check updated: the "Emotional Connection" element was renamed to
    "Interpretation Layer". The Emotional Connection layer was removed from
    `text_generation.md` because it instructed the Agent to share real personal
    failure or confusion experiences, which conflicts with `SOUL.md`
    ("Do not invent personal experiences") and `IDENTITY.md`
    (not a real person; no private information).
    Two check sites updated: Content Quality Check and Copy Structure Check.
-   The Interpretation Layer is now validated for mechanism explanation content
    (explains why something happens, not only what happened).

Changes from v1.1 (v2.0):

-   Platform locked to XHS (小红书).
-   Review Pipeline extended with XHS-specific stages.
-   Added Visual Series Review (series completeness, image roles, progression, non-redundancy).
-   Added Cover Review (attention capture, title readability, visual focus, click motivation).
-   Added Copy Review (title, hook, structure, rhythm, image-copy relationship).
-   Added XHS Compliance Review (tags, prohibited content, over-marketing, off-platform risk, image compliance).
-   Updated Content Quality Check for XHS writing structure.
-   Original Source Check, Fact Check, Evidence Rules preserved.
