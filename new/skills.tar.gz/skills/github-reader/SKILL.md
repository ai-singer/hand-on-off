---
name: github-reader
description: Read GitHub repositories, files, directory trees, and raw content via GitHub API without cloning. Use when: accessing GitHub repos, reading files from a repo, listing repo structure, downloading specific files, or when `git clone` fails due to network restrictions. Works via api.github.com and raw.githubusercontent.com which are reachable even when github.com direct access is blocked. Triggers on: "read github repo", "access github", "clone failed", "download from github", "read file from repo", "list repo files".
---

# GitHub Reader

Read GitHub repositories and files via API — no `git clone` required.

## Why This Skill

`git clone` requires a direct TCP connection to github.com port 443.
The GitHub REST API (`api.github.com`) and raw content CDN (`raw.githubusercontent.com`) are often reachable via different network paths even when direct cloning fails.

## Quick Reference

```
Repo metadata:    GET https://api.github.com/repos/{owner}/{repo}
Directory tree:   GET https://api.github.com/repos/{owner}/{repo}/git/trees/{branch}?recursive=1
File content:     GET https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{path}
File metadata:    GET https://api.github.com/repos/{owner}/{repo}/contents/{path}
Search code:      GET https://api.github.com/search/code?q={query}+repo:{owner}/{repo}
```

## Authentication

Public repos: no auth required.
Private repos or higher rate limits: use `Authorization: Bearer <GITHUB_TOKEN>`.

Token location (check in order):
1. Environment variable: `$GITHUB_TOKEN`
2. File: `~/.openclaw/workspace/.env` (key: `GITHUB_TOKEN`)
3. File: `~/.openclaw/workspace/credentials.json` (key: `github_token`)

Never log or expose the token value.

## Workflow

### 1. Explore Repo Structure

```bash
# Get repo metadata (name, description, default branch, size)
curl -s --max-time 15 \
  "https://api.github.com/repos/{owner}/{repo}" \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print('branch:', d.get('default_branch')); print('desc:', d.get('description')); print('size:', d.get('size'), 'KB')"

# List all files recursively
curl -s --max-time 15 \
  "https://api.github.com/repos/{owner}/{repo}/git/trees/{branch}?recursive=1" \
  | python3 -c "
import sys, json
d = json.load(sys.stdin)
for item in d.get('tree', []):
    print(item['type'], item['path'])
"
```

### 2. Read File Content

```bash
# Read a single file via raw CDN (fastest, no auth needed for public repos)
curl -s --max-time 15 \
  "https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{path/to/file}"

# Read multiple files in a loop
for FILE in path/file1.md path/file2.py; do
  echo "=== $FILE ==="
  curl -s --max-time 10 "https://raw.githubusercontent.com/{owner}/{repo}/{branch}/$FILE"
  echo ""
done
```

### 3. Download Files to Workspace

```bash
# Download a single file
curl -s --max-time 30 \
  "https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{path}" \
  -o /home/node/.openclaw/workspace/{local_filename}

# Download all files listed in tree (use scripts/download_repo.py for batch)
```

See `scripts/download_repo.py` for full repo download via API.

## Rate Limits

| Auth | Limit |
|---|---|
| No token | 60 req/hour |
| With token | 5,000 req/hour |

On 403/429: wait and retry. Check `X-RateLimit-Remaining` header.

## Troubleshooting

- `api.github.com` timeout → network blocked entirely; try a proxy
- `raw.githubusercontent.com` timeout → try `https://raw.fastgit.org/{owner}/{repo}/{branch}/{path}` as fallback
- 404 on tree → check branch name (main vs master): `curl -s https://api.github.com/repos/{owner}/{repo} | python3 -c "import sys,json; print(json.load(sys.stdin)['default_branch'])"`
- Private repo 401 → set `Authorization: Bearer $GITHUB_TOKEN` header
