#!/usr/bin/env python3
"""
Download an entire GitHub repo via API (no git clone required).
Usage: python3 download_repo.py <owner> <repo> [--branch main] [--out ./output] [--token TOKEN]
"""
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path


def api_get(url, token=None):
    headers = ["-H", "Accept: application/vnd.github+json"]
    if token:
        headers += ["-H", f"Authorization: Bearer {token}"]
    r = subprocess.run(
        ["curl", "-s", "--max-time", "15", url] + headers,
        capture_output=True, text=True
    )
    if not r.stdout:
        return None
    return json.loads(r.stdout)


def download_file(raw_url, dest_path, token=None):
    dest_path.parent.mkdir(parents=True, exist_ok=True)
    headers = []
    if token:
        headers = ["-H", f"Authorization: Bearer {token}"]
    r = subprocess.run(
        ["curl", "-s", "--max-time", "30", raw_url, "-o", str(dest_path)] + headers,
        capture_output=True
    )
    return r.returncode == 0


def get_token():
    # Check env
    t = os.environ.get("GITHUB_TOKEN")
    if t:
        return t
    # Check credentials.json
    creds_path = Path.home() / ".openclaw/workspace/credentials.json"
    if creds_path.exists():
        try:
            data = json.loads(creds_path.read_text())
            return data.get("github_token")
        except Exception:
            pass
    return None


def main():
    parser = argparse.ArgumentParser(description="Download GitHub repo via API")
    parser.add_argument("owner", help="GitHub owner/org")
    parser.add_argument("repo", help="GitHub repo name")
    parser.add_argument("--branch", default=None, help="Branch (default: repo default)")
    parser.add_argument("--out", default=None, help="Output directory")
    parser.add_argument("--token", default=None, help="GitHub token (overrides env/config)")
    args = parser.parse_args()

    token = args.token or get_token()

    # Get default branch if not specified
    if not args.branch:
        meta = api_get(f"https://api.github.com/repos/{args.owner}/{args.repo}", token)
        if not meta or "default_branch" not in meta:
            print(f"ERROR: Could not fetch repo metadata. Check owner/repo name.", file=sys.stderr)
            sys.exit(1)
        branch = meta["default_branch"]
        print(f"Default branch: {branch}")
    else:
        branch = args.branch

    out_dir = Path(args.out) if args.out else Path.cwd() / args.repo
    print(f"Output directory: {out_dir}")

    # Get file tree
    tree_data = api_get(
        f"https://api.github.com/repos/{args.owner}/{args.repo}/git/trees/{branch}?recursive=1",
        token
    )
    if not tree_data or "tree" not in tree_data:
        print("ERROR: Could not fetch repo tree.", file=sys.stderr)
        sys.exit(1)

    blobs = [item for item in tree_data["tree"] if item["type"] == "blob"]
    print(f"Files to download: {len(blobs)}")

    success, fail = 0, 0
    for item in blobs:
        path = item["path"]
        raw_url = f"https://raw.githubusercontent.com/{args.owner}/{args.repo}/{branch}/{path}"
        dest = out_dir / path
        ok = download_file(raw_url, dest, token)
        if ok:
            success += 1
            print(f"  ✅ {path}")
        else:
            fail += 1
            print(f"  ❌ {path}", file=sys.stderr)

    print(f"\nDone: {success} downloaded, {fail} failed → {out_dir}")


if __name__ == "__main__":
    main()
