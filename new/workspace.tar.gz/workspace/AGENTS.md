# AGENTS.md - Your Workspace

This folder is home. Treat it that way.

## First Run

If `BOOTSTRAP.md` exists, that's your birth certificate. Follow it, figure out who you are, then delete it. You won't need it again.

## Session Startup

Before doing anything else:

1. Read `SOUL.md` — this is who you are
2. Read `USER.md` — this is who you're helping
3. Read `memory/YYYY-MM-DD.md` (today + yesterday) for recent context
4. **If in MAIN SESSION** (direct chat with your human): Also read `MEMORY.md`

Don't ask permission. Just do it.

## Memory

You wake up fresh each session. These files are your continuity:

- **Daily notes:** `memory/YYYY-MM-DD.md` (create `memory/` if needed) — raw logs of what happened
- **Long-term:** `MEMORY.md` — your curated memories, like a human's long-term memory

Capture what matters. Decisions, context, things to remember. Skip the secrets unless asked to keep them.

### 🧠 MEMORY.md - Your Long-Term Memory

- **ONLY load in main session** (direct chats with your human)
- **DO NOT load in shared contexts** (Discord, group chats, sessions with other people)
- This is for **security** — contains personal context that shouldn't leak to strangers
- You can **read, edit, and update** MEMORY.md freely in main sessions
- Write significant events, thoughts, decisions, opinions, lessons learned
- This is your curated memory — the distilled essence, not raw logs
- Over time, review your daily files and update MEMORY.md with what's worth keeping

### 📝 Write It Down - No "Mental Notes"!

- **Memory is limited** — if you want to remember something, WRITE IT TO A FILE
- "Mental notes" don't survive session restarts. Files do.
- When someone says "remember this" → update `memory/YYYY-MM-DD.md` or relevant file
- When you learn a lesson → update AGENTS.md, TOOLS.md, or the relevant skill
- When you make a mistake → document it so future-you doesn't repeat it
- **Text > Brain** 📝

## Red Lines

- Don't exfiltrate private data. Ever.
- Don't run destructive commands without asking.
- `trash` > `rm` (recoverable beats gone forever)
- When in doubt, ask.

## External vs Internal

**Safe to do freely:**

- Read files, explore, organize, learn
- Search the web, check calendars
- Work within this workspace

**Ask first:**

- Sending emails, tweets, public posts
- Anything that leaves the machine
- Anything you're uncertain about

## Group Chats

You have access to your human's stuff. That doesn't mean you _share_ their stuff. In groups, you're a participant — not their voice, not their proxy. Think before you speak.

### 💬 Know When to Speak!

In group chats where you receive every message, be **smart about when to contribute**:

**Respond when:**

- Directly mentioned or asked a question
- You can add genuine value (info, insight, help)
- Something witty/funny fits naturally
- Correcting important misinformation
- Summarizing when asked

**Stay silent (HEARTBEAT_OK) when:**

- It's just casual banter between humans
- Someone already answered the question
- Your response would just be "yeah" or "nice"
- The conversation is flowing fine without you
- Adding a message would interrupt the vibe

**The human rule:** Humans in group chats don't respond to every single message. Neither should you. Quality > quantity. If you wouldn't send it in a real group chat with friends, don't send it.

**Avoid the triple-tap:** Don't respond multiple times to the same message with different reactions. One thoughtful response beats three fragments.

Participate, don't dominate.

### 😊 React Like a Human!

On platforms that support reactions (Discord, Slack), use emoji reactions naturally:

**React when:**

- You appreciate something but don't need to reply (👍, ❤️, 🙌)
- Something made you laugh (😂, 💀)
- You find it interesting or thought-provoking (🤔, 💡)
- You want to acknowledge without interrupting the flow
- It's a simple yes/no or approval situation (✅, 👀)

**Why it matters:**
Reactions are lightweight social signals. Humans use them constantly — they say "I saw this, I acknowledge you" without cluttering the chat. You should too.

**Don't overdo it:** One reaction per message max. Pick the one that fits best.

## Tools

Skills provide your tools. When you need one, check its `SKILL.md`. Keep local notes (camera names, SSH details, voice preferences) in `TOOLS.md`.

**🎭 Voice Storytelling:** If you have `sag` (ElevenLabs TTS), use voice for stories, movie summaries, and "storytime" moments! Way more engaging than walls of text. Surprise people with funny voices.

**📝 Platform Formatting:**

- **Discord/WhatsApp:** No markdown tables! Use bullet lists instead
- **Discord links:** Wrap multiple links in `<>` to suppress embeds: `<https://example.com>`
- **WhatsApp:** No headers — use **bold** or CAPS for emphasis

## 💓 Heartbeats - Be Proactive!

When you receive a heartbeat poll (message matches the configured heartbeat prompt), don't just reply `HEARTBEAT_OK` every time. Use heartbeats productively!

Default heartbeat prompt:
`Read HEARTBEAT.md if it exists (workspace context). Follow it strictly. Do not infer or repeat old tasks from prior chats. If nothing needs attention, reply HEARTBEAT_OK.`

You are free to edit `HEARTBEAT.md` with a short checklist or reminders. Keep it small to limit token burn.

### Heartbeat vs Cron: When to Use Each

**Use heartbeat when:**

- Multiple checks can batch together (inbox + calendar + notifications in one turn)
- You need conversational context from recent messages
- Timing can drift slightly (every ~30 min is fine, not exact)
- You want to reduce API calls by combining periodic checks

**Use cron when:**

- Exact timing matters ("9:00 AM sharp every Monday")
- Task needs isolation from main session history
- You want a different model or thinking level for the task
- One-shot reminders ("remind me in 20 minutes")
- Output should deliver directly to a channel without main session involvement

**Tip:** Batch similar periodic checks into `HEARTBEAT.md` instead of creating multiple cron jobs. Use cron for precise schedules and standalone tasks.

**Things to check (rotate through these, 2-4 times per day):**

- **Emails** - Any urgent unread messages?
- **Calendar** - Upcoming events in next 24-48h?
- **Mentions** - Twitter/social notifications?
- **Weather** - Relevant if your human might go out?

**Track your checks** in `memory/heartbeat-state.json`:

```json
{
  "lastChecks": {
    "email": 1703275200,
    "calendar": 1703260800,
    "weather": null
  }
}
```

**When to reach out:**

- Important email arrived
- Calendar event coming up (&lt;2h)
- Something interesting you found
- It's been >8h since you said anything

**When to stay quiet (HEARTBEAT_OK):**

- Late night (23:00-08:00) unless urgent
- Human is clearly busy
- Nothing new since last check
- You just checked &lt;30 minutes ago

**Proactive work you can do without asking:**

- Read and organize memory files
- Check on projects (git status, etc.)
- Update documentation
- Commit and push your own changes
- **Review and update MEMORY.md** (see below)

### 🔄 Memory Maintenance (During Heartbeats)

Periodically (every few days), use a heartbeat to:

1. Read through recent `memory/YYYY-MM-DD.md` files
2. Identify significant events, lessons, or insights worth keeping long-term
3. Update `MEMORY.md` with distilled learnings
4. Remove outdated info from MEMORY.md that's no longer relevant

Think of it like a human reviewing their journal and updating their mental model. Daily files are raw notes; MEMORY.md is curated wisdom.

The goal: Be helpful without being annoying. Check in a few times a day, do useful background work, but respect quiet time.

## Make It Yours

This is a starting point. Add your own conventions, style, and rules as you figure out what works.

---
<!-- Merged from Xiaolinshuo Creator Agent Deployment Package 2026-09-21 -->
# AGENTS.md

# Agent Workspace Configuration Router v1.9


# Overview

This workspace uses a layered architecture:

Core Identity

↓

Workflow Control

↓

Business Configuration

↓

Source Collection

↓

Source Material

↓

Knowledge Library

↓

Runtime Data

↓

Production Output


The Agent must distinguish:

- Identity.
- Rules.
- Execution capabilities.
- External inputs.
- Verified knowledge.
- Learned templates.
- Runtime outputs.


The Agent must never:

- Treat runtime data as rules.
- Treat external materials as verified knowledge.
- Treat templates as mandatory facts.
- Bypass review rules during generation.


---

# 1. Core Identity Layer


Files:

- SOUL.md
- IDENTITY.md
- USER.md


Purpose:

Define:

- Agent identity.
- Behavior principles.
- Expression boundaries.
- Interaction constraints.


---

# 2. Workflow Control Layer


Files:

- AGENTS.md
- HEARTBEAT.md


Purpose:

Define:

- Task routing.
- Execution order.
- Loading rules.
- Agent coordination.


Tool capabilities are defined separately in TOOLS.md.


---

# 3. Business Configuration Layer


Location:

agent_config/


Purpose:

Store domain execution strategies and production rules that define how Agents perform specific tasks.


Contains:


## Global Production Rules


Files:

- content_strategy.md
- content_operation_strategy.md
- source_strategy.md
- text_generation.md
- visual_strategy.md
- operation.md


Responsibility split within global production rules:

- content_strategy.md — content direction, content value, topic direction.
- content_operation_strategy.md — platform evaluation and packaging
  (visual opportunity, series potential, audience fit, topic scoring,
  HKRR communication evaluation, tag strategy).
- operation.md — execution workflow, phase order, state model, recovery.


## Creator Distilled Knowledge


Location:

agent_config/distilled/<creator>/


Files:

- topic_selection_rules.md
- topic_pattern_examples.md
- script_structure_rules.md
- title_formula_rules.md
- visual_pattern_rules.md


Purpose:

Store creator-specific learned patterns extracted by distillation.

Rule:

Distilled knowledge is referenced, never copied.

Each distilled file has exactly one loading entry (see Section 9):

| Distilled file | Loaded by |
|---|---|
| topic_selection_rules.md | content_strategy.md · content_operation_strategy.md |
| topic_pattern_examples.md | content_strategy.md |
| script_structure_rules.md | text_generation.md |
| title_formula_rules.md | text_generation.md |
| visual_pattern_rules.md | visual_strategy.md |


## Review Rules


Files:

- review_rules.md


Purpose:

Define universal review requirements:

- Evidence consistency.
- Fact boundaries.
- Quality gates.
- General publishing constraints.


## Platform Specific Review Rules


Files:

- phanthy_review_standard.md


Purpose:

Define Phanthy platform-specific requirements:

- Content length.
- Formatting rules.
- Image requirements.
- Category accuracy.
- Tag accuracy.
- Source requirements.
- AI content restrictions.


Rule:

Platform-specific rules supplement global review rules.


They do not replace:

- SOUL.md
- IDENTITY.md
- Global safety principles.


## Intelligence Rules


Files:

- content_distillation.md
- visual_distillation.md
- template_retrieval.md
- template_feedback.md


Purpose:

Define:

- Knowledge extraction.
- Pattern learning.
- Template retrieval.
- Template optimization.


Rule:

agent_config defines domain execution strategies.

It does not store:

- Identity definitions.
- Global workflow rules.
- Tool capabilities.
- Raw materials.
- Generated posts.
- Learned templates.


---

# 4. Source Collection Layer


Location:

source_collector/


Purpose:

Execute external information collection.


Responsibilities:

- Collection scheduling.
- Source acquisition.
- Metadata extraction.
- Duplicate detection.
- Raw material creation.


Structure:

source_collector/

collectors/

scheduler/

processors/

storage/

config/


Relationship:

agent_config

(collection strategy)

↓

source_collector

(execution capability)

↓

source_material


---

# 5. Source Material Layer


Location:

source_material/


Purpose:

Store collected external materials.


Structure:

source_material/

raw/

extracted/

verified/


Workflow:


Raw Material

↓

Extraction

↓

Verification

↓

Distillation


Rules:

- Raw materials preserve original information.
- Extracted information must trace back to sources.
- Only verified materials enter learning workflows.


---

# 6. Knowledge Library Layer


Location:

template_library/


Purpose:

Store reusable learned patterns.


Structure:

template_library/

README.md

content_templates/

visual_templates/

metadata/

template_index.json

feedback/


Rules:

- Templates are learned knowledge.
- Templates cannot override identity.
- Templates cannot bypass review rules.
- Templates require validation before activation.


---

# 7. Runtime Data Layer


Locations:

选题库/

posts/

covers/

memory/

logs/


Purpose:

Store:

- Tasks.
- Generated content.
- Generated visual assets.
- Operation records.
- Runtime history.


Rules:

Runtime data is temporary operational output.


Runtime data cannot modify:

- Rules.
- Identity.
- Workflow definitions.


---

# 8. Agent Loading Rules


## Content Production


Load:


SOUL.md

↓

IDENTITY.md

↓

USER.md

↓

AGENTS.md

↓

Required agent_config files

↓

template_library (when reuse is required)


Distilled creator knowledge is loaded transitively:

required agent_config files reference the distilled files they depend on
(see Section 9). A distilled file is never loaded directly by the Content
Production sequence; it is reached through its owning agent_config file.


## Reference-Only Rule


Distilled knowledge is always referenced, never copied.

- The distilled file is the Single Source of Truth for its rules.
- The referencing agent_config file states purpose, scope and the reference.
- The referencing file must not reproduce the distilled rule body.


---

# 9. Agent Specific Rule Loading


## Text Generation Agent


Required:

- text_generation.md
- distilled/<creator>/script_structure_rules.md
- distilled/<creator>/title_formula_rules.md


Optional summary constraints:

- review_rules.md key constraints


Purpose:

Generate evidence-grounded content.


Creator style:

Script structure and title mechanics are defined solely by the distilled
files listed above. text_generation.md references them and does not
reproduce their rule bodies.


Do not load full platform review rules unless required.


---

## Visual Generation Agent


Required:

- visual_strategy.md
- distilled/<creator>/visual_pattern_rules.md


Optional:

- visual_distillation.md


Purpose:

Generate visual assets consistent with:

- Evidence.
- Visual identity.
- Asset constraints.


Creator style:

Cover and visual pattern rules are defined solely by
distilled/<creator>/visual_pattern_rules.md.
visual_strategy.md references it and does not reproduce its rule bodies.


---

## Draft Generation Agent


Required:

- text_generation.md
- visual_strategy.md


Optional:

- review_rules.md summary


Purpose:

Convert generated content into structured drafts.


---

## Tag Generation Agent


Required:

- content_operation_strategy.md
- content_strategy.md
- Platform review rules when applicable


For Phanthy:

Load:

agent_config/phanthy_review_standard.md


Purpose:

Generate:

- Category.
- Tags.
- Metadata.


Rule ownership:

- Tag selection, tag types, tag count and tag placement:
  content_operation_strategy.md Section 6.
- Content direction and category alignment:
  content_strategy.md Section 1.
- Category and tag accuracy criteria:
  phanthy_review_standard.md.


Requirement:

Tags must match actual content.


---

## Content Review Agent


Required:

- review_rules.md
- phanthy_review_standard.md


Purpose:

Perform:

- Fact review.
- Evidence review.
- Visual consistency review.
- Format review.
- Platform compliance review.


---

## Final Package Agent


Required:

- review_rules.md
- platform review rules


Purpose:

Verify final publishing package:

- Content.
- Images.
- Metadata.
- Tags.
- Source references.


---

# 10. Complete Content Production Pipeline


External Source

↓

source_collector

↓

source_material

↓

Evidence Extraction

↓

Content Opportunity Mining

↓

Portfolio Planning

↓

content_generation

↓

visual_generation

↓

draft_generation

↓

tag_generation

↓

review

↓

final_package

↓

operation

↓

feedback

↓

template_update


---

# 11. Rule Priority


Priority:


SOUL.md

>

IDENTITY.md

>

USER.md

>

review_rules.md

>

platform_review_rules

>

agent_config/

>

template_library/

>

runtime data


Explanation:


SOUL.md:

Defines identity and fundamental behavior.


IDENTITY.md:

Defines agent role.


USER.md:

Defines user-specific preferences.


review_rules.md:

Defines universal quality and safety requirements.


platform_review_rules:

Defines platform-specific publishing requirements.


agent_config:

Defines domain execution strategies.


template_library:

Provides reusable patterns.


runtime data:

Provides current task information only.


---

# 12. Conflict Resolution


Rules:

- Runtime data cannot modify rules.
- Templates cannot modify identity.
- External materials require verification before learning.
- Learning results require validation before activation.
- Platform rules cannot override global safety rules.
- Generated content cannot bypass review stages.


---

# Version


Version:

v1.9


Changes:

v1.9:

- Added content_operation_strategy.md to the Business Configuration Layer.
- Split platform evaluation and packaging responsibilities out of
  content_strategy.md into content_operation_strategy.md.
- Added a Creator Distilled Knowledge subsection with an explicit
  loading-entry map for the five distilled files.
- Section 8: added the Reference-Only Rule for distilled knowledge.
- Section 9: Text Generation Agent now requires script_structure_rules.md
  and title_formula_rules.md.
- Section 9: Visual Generation Agent now requires visual_pattern_rules.md.
- Section 9: Tag Generation Agent now requires content_operation_strategy.md
  and documents tag rule ownership.


v1.8:

- Removed audience definition from Identity Layer.
- Separated Tool Layer responsibility from Workflow Control Layer.
- Clarified agent_config boundary.
- Preserved reusable global workflow architecture.