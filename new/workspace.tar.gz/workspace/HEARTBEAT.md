# HEARTBEAT.md


# Proactive Task Scheduler


## Purpose

Define periodic checks and proactive actions.

Heartbeat does not define:

- Content strategy.
- Writing style.
- Visual generation rules.
- Publishing standards.

Related business logic belongs to:

agent_config/


---

# Scheduled Checks


## Content Production Check


Frequency:

Daily


Check:

- Whether there are pending content tasks.
- Whether source materials need processing.
- Whether generated content requires review.


Action:

If pending tasks exist:

Follow:

agent_config/operation.md



---


## Review Feedback Check


Frequency:

Daily


Check:

- New review results.
- Failed publications.
- User feedback.


Action:

Record issues and route them to the responsible review or improvement process.



---


## Operation Status Check


Frequency:

Daily


Check:

- Current production status.
- Published content status.
- Pending tasks.


Action:

Generate operation summary.



---


# Phanthy 私信轮询


Frequency:

每次心跳


Action:

1. GET https://cms.phanthy.com/api/v1/openclaw/messages
   Authorization: Bearer phanthy_22f3c1ab1db513c167b3446ce1f30c01

2. 如有消息（messages 数组非空）：
   - 以财叔人设生成回复（财经机制解释型，不提供投资建议，回复200字以内）
   - POST https://cms.phanthy.com/api/v1/openclaw/messages/<delivery_id>/reply
     body: {"content": "<回复内容>", "version": <version>, "leaseToken": "<leaseToken>"}
   - 如有 hasMore=true，继续取下一批

3. GET https://cms.phanthy.com/api/v1/openclaw/comments/unread
   如有评论，同样方式回复（回复限300字以内）

4. 无消息无评论：不输出任何内容，继续正常心跳判断


# Phanthy 发布 API 说明（2026-09-22 更新）

**正确端点：** `POST https://cms.phanthy.com/api/v1/openclaw/posts`（复数）
**已废弃：** `/api/v1/openclaw/post`（单数，legacy，返回 30001）

必须携带：
- `Idempotency-Key: <uuid>` header
- `cover_file_id`（文件 ID，非 URL）
- `media`: `[{"file_id": "..."}]`

图片上传流程：
1. POST `/api/v1/openclaw/files/upload-authorizations` → 获取 signed URL
2. PUT 图片到 signed URL（不带 Authorization header）
3. POST `/api/v1/openclaw/files/<file_id>/complete` → 等待 status=READY
4. 在 posts 请求中引用 file_id


---


# Source Material Sync


Frequency:

每次心跳（Daily 亦可，视素材更新频率）


Steps:

1. 进入临时克隆目录，拉取最新内容：
   ```
   cd /home/node/.openclaw/workspace/ai-singer/hand-on-off && git pull
   ```

2. 将更新内容合并进本地工作目录（不覆盖已有文件）：
   ```
   cp -rn source_material/. /home/node/.openclaw/workspace/hand-on-off/source_material/
   ```

3. 合并完成后，`ai-singer/hand-on-off/` 仅作为 git 同步中转，不直接用于生产流程。

4. 生产流程读取素材路径：
   `/home/node/.openclaw/workspace/hand-on-off/source_material/`


Notes:

- 如有冲突（同名文件），保留本地版本（`cp -rn` 的 `-n` 保证不覆盖）。
- 如需强制用远端覆盖，需人工确认后执行 `cp -rf`。


---


# Heartbeat Rules


The Agent should:

- Perform lightweight checks.
- Avoid unnecessary actions.
- Follow operation workflow before external actions.


The Agent should not:

- Generate content without a production task.
- Publish content without review.
- Modify configuration without identifying the responsible process.


---

# 自动化发帖流程（每次心跳执行）

## 目标
每日发帖 10 篇，不重复。

## 话题库补充规则（固化）
每次发帖后检查 topic_pool.json 中未发布话题数量：
- 如果未发布话题 **< 5 条**：立即触发话题爬取补充
- 爬取来源：小红书财经类内容（不限目标博主，S/A级即可入库）
- 爬取完成后更新 topic_pool.json

## 完整发帖流程（自动重复）

每篇执行以下步骤：

**Step 1 — 选题**
- 从 topic_pool.json 取第一条未发布 S/A 级话题
- 检查已发帖记录，跳过已发布选题

**Step 2 — 内容生成**
- 参考模板：`agent_config/distilled/content_templates_finance_xhs.md` 和 `content_templates_finance_xhs_external.md`
- 财叔人设：机制解释型，不提供投资建议
- 正文 600-900 字，结构：冲突前置→机制深挖→金句收尾

**Step 3 — 配图生成**
- 生成 5 张配图（封面+4张内容图）
- 参考：`agent_config/distilled/visual_prompt_templates_finance_xhs_external.md`
- 使用 Gemini Image skill

**Step 4 — 上传 & 发布**
- 图片上传流程：POST upload-authorizations → PUT signed URL → POST complete
- 发布端点：`POST https://cms.phanthy.com/api/v1/openclaw/posts`
- 必须携带 Idempotency-Key header
- 标签：科普

**Step 5 — 记录 & 循环**
- 将 Post ID、标题、状态写入 `memory/2026-09-22.md`
- 将 topic_pool.json 中该条标记为已发布
- 检查剩余未发布话题数，如 < 5 则触发爬取
- 今日累计未满 10 篇则继续下一篇（Step 1）