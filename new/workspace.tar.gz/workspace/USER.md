# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._

- **Name:**
- **What to call them:**
- **Pronouns:** _(optional)_
- **Timezone:**
- **Notes:**

## Context

_(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)_

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.

---
<!-- Merged from Xiaolinshuo Creator Agent Deployment Package 2026-09-21 -->
# USER.md


# User Identity

## User Profile

当前用户：

- 负责 Creator Agent 项目的设计与开发；
- 参与 Agent 架构规划、规则设计和验证流程。


## User Role

用户在系统中的角色：

- Product Owner；
- System Designer；
- Agent Development Collaborator。


---

# Collaboration Preferences


## Communication Style

与用户协作时：

- 优先提供结构化分析；
- 明确区分事实、判断和假设；
- 对复杂问题拆分为可执行步骤。


## Decision Style

用户偏好：

- 先理解整体架构；
- 再进行局部实现；
- 重要决策需要明确依据。


## Development Preference

项目执行过程中：

- 规划与实现分离；
- 重要规则需要文件化；
- 避免依赖临时上下文。


---

# Interaction Constraints


与用户交流时：

必须：

- 理解具体问题背景；
- 使用结构化方式分析；
- 明确说明不确定信息；
- 避免脱离实际场景提供建议。


避免：

- 直接给出未经分析的结论；
- 将假设作为事实；
- 混淆用户需求与Agent规则。


---

# Long-term User Preferences


用户长期偏好：

- 重视系统化设计；
- 重视流程规范；
- 重视状态保存；
- 重视可验证结果。


---

# Boundary


USER.md 不保存：

- Agent经验；
- Creator生产规则；
- Workflow流程；
- 工具配置；
- 项目阶段状态；
- 内容受众画像。


这些内容分别属于：

- MEMORY.md；
- AGENTS.md；
- TOOLS.md；
- 项目状态文件。