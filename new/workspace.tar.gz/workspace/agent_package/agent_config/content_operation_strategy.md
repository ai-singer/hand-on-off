# Content Operation Strategy v1.0

# Platform

Platform:

小红书 (XHS)


---

# Scope

## What this file owns

Content Operation Strategy defines how content is **evaluated and packaged for the platform**
after topic direction has been set by `content_strategy.md`.

It owns:

- Visual Opportunity Assessment.
- Series Potential evaluation.
- XHS Audience Fit Assessment.
- Topic Scoring (the composite topic assessment output).
- Platform Communication Evaluation (HKRR).
- Tag Strategy.

## What this file does not own

- Content direction and topic direction → `agent_config/content_strategy.md`
- Creator identity, expression boundaries, persona limits → `IDENTITY.md`
- Execution workflow, phase order, state model, recovery → `agent_config/operation.md`
- Visual production mechanics, image roles, cover protocols → `agent_config/visual_strategy.md`
- Xiaolinshuo creator-specific learned rules → `agent_config/distilled/xiaolinshuo/`
- Publishing verdicts and quality gates → `agent_config/review_rules.md`
- Phanthy platform hard criteria → `agent_config/phanthy_review_standard.md`

## Disambiguation from `operation.md`

Two files carry "operation" in their name. They are not interchangeable:

| File | Answers | Nature |
|---|---|---|
| `agent_config/operation.md` | **How is the work executed over time?** Phase order, execution state, failure classification, context governance, recovery. | Process / workflow |
| `agent_config/content_operation_strategy.md`（本文件） | **How is content evaluated and packaged for the platform?** Topic scoring, visual feasibility, series potential, audience fit, communication metrics, tags. | Evaluation / packaging |

Rule of thumb: if the rule governs **when and in what order something runs**, it belongs to `operation.md`.
If the rule governs **how good content is judged to be, or what platform metadata it carries**, it belongs here.


---

# 1. Visual Opportunity Assessment

每个候选选题在进入生产流程前，必须完成视觉机会评估。

This assessment is mandatory before a topic is committed to production.

评估维度：

## 1.1 封面 Hook 强度

判断：

该主题是否能在封面上产生强烈的视觉停留冲击。

高分特征：

- 存在强对比或反直觉的视觉表达。
- 封面文字可以在 15 字内传达核心吸引力。
- 封面场景有清晰的视觉焦点。

## 1.2 图片系列适配性

判断：

该主题是否自然拆分为 3–9 张有序图片。

高分特征：

- 内容有天然的步骤或层次结构。
- 每个知识点可独立成一张图。
- 图片间有信息递进关系。

## 1.3 视觉记忆点

判断：

该主题是否存在可重复使用的视觉符号或场景。

高分特征：

- 有可抽象为图形的核心概念。
- 有可复用的视觉主体（地图、数据图表、关键场景、主体剪影）。
- 视觉元素与账号身份一致。

输出格式：

``` yaml
visual_opportunity:
  cover_hook_strength: HIGH / MEDIUM / LOW
  carousel_fit: HIGH / MEDIUM / LOW
  visual_memory_point: HIGH / MEDIUM / LOW
  notes:
```


---

# 2. Series Potential

每个候选选题必须评估系列化潜力。

## 2.1 Series Potential 等级

### HIGH

条件：

- 该主题可拆分为 3 篇以上独立但关联的内容。
- 系列内容之间有明确的知识递进关系。
- 用户完成系列阅读后获得系统性理解。

示例（结构性，非具体选题）：

同一机制在不同主体上的对比 → "同样是 [X 类型]，为什么 [A] 与 [B] 走向完全不同"

  Part 1: 主体 A 的机制
  Part 2: 主体 B 的机制
  Part 3: 两者差异的结构性原因

### MEDIUM

条件：

- 该主题可延伸为 2 篇关联内容。
- 关联性较强，但不构成完整系列。

### LOW

条件：

- 该主题适合作为独立单篇内容。
- 延伸空间有限。

输出格式：

``` yaml
series_potential:
  level: HIGH / MEDIUM / LOW
  series_title:        # 如果 HIGH 或 MEDIUM，定义系列名称
  planned_parts:       # 如果 HIGH，列出计划篇目
  notes:
```


---

# 3. XHS Audience Fit Assessment

每个候选选题在生产前评估小红书受众适配性。

## 3.1 用户兴趣匹配

判断：

目标受众是否在小红书上主动搜索或浏览此类内容。

检查：

- 小红书搜索框是否有相关关键词联想。
- 相关话题下是否有高互动内容。

## 3.2 搜索需求

判断：

该主题是否对应用户的主动搜索意图。

高搜索价值特征：

- 用户有明确问题需要解答（"为什么"、"发生了什么"、"意味着什么"）。
- 标题可自然包含搜索关键词。

## 3.3 分享动力

判断：

用户看完内容后是否有强烈的分享或保存动机。

高分享动力特征：

- 内容解决了用户长期存在的困惑。
- 内容有"原来如此"的认知增量。
- 内容有"我得让别人也看看"的转述价值。

输出格式：

``` yaml
xhs_audience_fit:
  interest_match: HIGH / MEDIUM / LOW
  search_demand: HIGH / MEDIUM / LOW
  share_motivation: HIGH / MEDIUM / LOW
  notes:
```


---

# 4. Topic Scoring Summary

每个候选选题输出完整评估：

``` yaml
topic_assessment:
  title:
  category:
  evidence_available: true / false
  hkrr:
    happiness:     HIGH / MEDIUM / LOW
    knowledge:     HIGH / MEDIUM / LOW
    resonance:     HIGH / MEDIUM / LOW
    rhythm:        HIGH / MEDIUM / LOW
  visual_opportunity:
    cover_hook_strength:
    carousel_fit:
    visual_memory_point:
  series_potential:
    level:
    series_title:
    planned_parts:
  xhs_audience_fit:
    interest_match:
    search_demand:
    share_motivation:
  creator_style_fit:
    mechanism_gap: HIGH / MEDIUM / LOW   # 认知差强度 — 判据见 §5.2
    source: agent_config/distilled/xiaolinshuo/topic_selection_rules.md
  recommendation: PROCEED / HOLD / REJECT
  rejection_reason:    # 如果 REJECT，说明原因
```

## 4.1 `creator_style_fit` 字段说明

该字段**不定义**判据。它只记录本次评估引用 `agent_config/distilled/xiaolinshuo/topic_selection_rules.md`
所得到的认知差判断结果，用于溯源。

判据的唯一权威来源是该蒸馏文件。本文件不得复制其规则正文。

作用：使"平台适配高但创作者风格不符"的选题不会因单一 `recommendation` 闸门而误判为 PROCEED。


---

# 5. Platform Communication Evaluation

Platform performance is evaluated separately from content identity.

## 5.1 HKRR Framework

用于判断内容是否具有小红书传播价值。

HKRR 四维度：

| 维度 | 含义 |
|---|---|
| **Happiness** | 视觉与标题层面的吸引力（含封面钩子效果） |
| **Knowledge** | 是否提供用户此前不知道或尚未清晰理解的知识 |
| **Resonance** | 是否触发目标用户的情绪反应 |
| **Rhythm** | 图文轮播是否具有持续翻页驱动力 |

### Happiness

检查：内容是否具有视觉和标题层面的吸引力。

XHS 适配：封面 + 标题组合是否在信息流中具有停留吸引力。

### Knowledge

检查：是否提供用户此前不知道或尚未清晰理解的知识。

XHS 适配：知识密度需与内容篇幅匹配，避免低信息量长文。

### Resonance

检查：是否触发目标用户的情绪反应。

XHS 适配：可接受情绪类型：

- 好奇感（"这我没想到"）
- 获得感（"学到了"）
- 共鸣感（"这说的就是我"）
- 被看见感（"终于有人说出来了"）

选题必须能回答：目标用户看到这个内容会产生什么情绪反应？
如果无法回答，降低选题优先级。

### Rhythm

检查：图文轮播是否具有持续翻页驱动力。

XHS 适配：用户从第 1 张图翻到最后一张图的动力是否持续存在。

## 5.2 Platform Weight vs Creator Style Overlay

**平台权重**（本文件声明，适用于小红书通用传播规律）：

```
Resonance > Happiness > Knowledge > Rhythm
```

**创作者风格叠加层**（不属于本文件的定义范围）：

本 Agent 的创作者风格要求认知差优先于情绪共鸣。
该优先级由 `agent_config/distilled/xiaolinshuo/topic_selection_rules.md` §3.1 定义，
并通过 §4 的 `creator_style_fit.mechanism_gap` 字段进入评分。

**两者关系：** 平台权重衡量"在小红书是否传得开"；风格叠加层衡量"是否符合本创作者的解释逻辑"。
二者是**不同轴**，不互相覆盖。任一维度得分高都不能替代另一维度的判定。

> **架构说明：** 此处不复制蒸馏规则正文，只声明两轴关系与引用位置。
> 依据 `phanthy_creator_configuration_placement_specification_v1.md` §5：
> "允许引用其他文件，禁止复制相同规则。核心原则：Single Source of Truth。"

## 5.3 HKRR 边界

HKRR is a communication evaluation framework.

It does not define:

- Creator identity.
- Content philosophy.
- Topic selection rules.


---

# 6. Tag Strategy

## 6.1 XHS Tag Rules

格式：

#话题名

示例（结构性示意）：

#<内容领域> #<主题关键词>

## 6.2 Tag Selection Rules

Primary Rule:

标签必须与内容核心主题一致。

禁止：

为了流量选择不匹配标签。

## 6.3 XHS Tag Types

### 内容标签（必选，1–2个）

直接描述内容主题。

示例（示意）：#商业分析 #经济科普

### 受众标签（必选，1–2个）

描述目标受众身份。

示例（示意）：#财经知识 #涨知识

### 热门话题标签（可选，1–2个）

与当前平台热门话题关联。

条件：

内容与热门话题有真实关联，不强行蹭热点。

## 6.4 Tag Count

建议：

3–6 个标签。

禁止：

超过 8 个标签（降低精准度）。

## 6.5 Tag Placement

标签放置在正文末尾。

不在正文段落中插入标签。

## 6.6 Category and Tag Accuracy

分类与标签的准确性由平台规则约束：

`agent_config/phanthy_review_standard.md`

本文件定义标签**选择与格式**规则；平台**审核标准**归该文件。


---

# 7. Responsibility Boundary

content_operation_strategy.md defines:

- Visual opportunity assessment.
- Series potential evaluation.
- XHS audience fit assessment.
- Topic scoring output schema.
- HKRR platform communication evaluation.
- Tag strategy.

content_operation_strategy.md does not define:

- Creator identity or persona.
- Content direction and topic direction.
- Visual production mechanics.
- Writing execution.
- Review standards and publishing verdicts.
- Execution workflow and phase order.
- Xiaolinshuo creator-specific learned rules.

## 7.1 Referenced (not owned) authorities

| Topic | Authority |
|---|---|
| Creator-specific topic selection logic, cognitive-gap priority | `agent_config/distilled/xiaolinshuo/topic_selection_rules.md` |
| Creator topic pattern examples | `agent_config/distilled/xiaolinshuo/topic_pattern_examples.md` |
| Creator visual pattern rules | `agent_config/distilled/xiaolinshuo/visual_pattern_rules.md` |
| Source reliability requirements | `agent_config/source_strategy.md` |
| Platform hard criteria (word count, sources, images, category accuracy) | `agent_config/phanthy_review_standard.md` |
| Audit gates | `agent_config/review_rules.md` |


---

# Version

v1.0

Origin:

Extracted from `agent_config/content_strategy.md` v2.0 (the platform-evaluation frameworks),
which had been removed from `content_strategy.md` during an earlier single-file rewrite.

Rationale:

`content_strategy.md` was carrying two distinct responsibilities — content direction
and platform evaluation/packaging. Splitting them gives each rule a single owner and
restores the platform frameworks that `operation.md`, `AGENTS.md` and `visual_strategy.md`
still reference.

Changes from the v2.0 source material:

- Restored Visual Opportunity Assessment, Series Potential, XHS Audience Fit Assessment,
  Topic Scoring Summary, HKRR Framework, Tag Strategy.
- Added Platform declaration.
- Removed creator-identity duplication (now referenced from `IDENTITY.md` / `SOUL.md`).
- Added `creator_style_fit` field with reference to the distilled style authority.
- Added explicit Platform Weight vs Creator Style Overlay separation.
- Replaced legacy vertical examples (video creation, equipment, editing) with
  domain-appropriate structural examples.
- Restored HKRR dimension `Happiness` (an earlier rewrite had renamed it `Hook`,
  which would have silently redefined the framework).
