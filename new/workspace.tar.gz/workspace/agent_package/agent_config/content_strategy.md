# Content Strategy v3.0

# Purpose

Define the strategic direction of Creator content production.

This file defines:

- Why create this content.
- What problems to solve.
- What content value is delivered, and to whom.
- What content opportunities should be considered.
- How the direction of content is evaluated.

This file does not define:

- Creator identity, persona, or expression boundaries.
- Personal background.
- Detailed script structure.
- Title formulas.
- Visual patterns.
- Platform evaluation and packaging rules.
- Execution workflow and phase order.

Those responsibilities belong to:

`IDENTITY.md` · `SOUL.md` · `agent_config/content_operation_strategy.md` ·
`agent_config/operation.md` · `agent_config/distilled/xiaolinshuo/`


---

# 1. Content Identity

> **Boundary note.** The Creator's identity, nature, role, creative philosophy and
> identity boundaries are defined solely by `IDENTITY.md` (and, for safety and
> ethical principles, `SOUL.md`).
> This section defines **what content direction follows from that identity**.
> It does not redefine the identity, and it must not be read as a second source
> for persona, philosophy, or behavioural boundaries.

## 1.1 Content Positioning

The Creator produces knowledge-oriented content that helps users understand complex topics.

Primary focus:

- Business mechanisms.
- Enterprise cases.
- Industry changes.
- Economic phenomena.
- Social and geopolitical outcomes behind observable events.

The goal is not simply to report information.

The goal is:

Transform complex information into understandable explanations.

## 1.2 Core Content Value

Content value is stated here at the **delivery level** — what users obtain.
The underlying creative philosophy that motivates these values is defined in
`IDENTITY.md` and is not restated here.

High-value content should provide:

### New Understanding

Help users understand:

- Why something happens.
- How systems operate.
- What hidden mechanisms exist.

### Reduced Complexity

Convert complex concepts into clear explanations and structured thinking.

### Decision Support

Help users build frameworks for analyzing problems.

## 1.3 Reference, Not Duplication

| Concept | Authority |
|---|---|
| Creator identity, nature, role | `IDENTITY.md` |
| Creative philosophy (Fact First, Mechanism Explanation First, Lower Cognitive Barrier, Rational Expression) | `IDENTITY.md` |
| Identity boundaries (not a real person, no private information, no impersonation) | `IDENTITY.md` |
| Truthfulness, source integrity, safety boundary | `SOUL.md` |


---

# 2. Target Problem Space

Content should focus on questions users naturally care about.

The problem space is:

- Structural outcomes that conflict with intuitive expectations.
- Mechanisms that popular narratives explain incompletely or incorrectly.
- Situations where an observable result has a non-obvious cause.

## 2.1 Illustrative Examples

The following are **illustrative only**. They are not a canonical formula list
and must not be treated as a topic template.

- Why did this company succeed or fail?
- Why did this industry change?
- What mechanism caused this phenomenon?
- What can we learn from this case?

> **Non-normative declaration.** The canonical question structures and topic
> selection logic are defined solely by
> `agent_config/distilled/xiaolinshuo/topic_selection_rules.md`.
> This section describes the problem *space*; it does not define topic formulas,
> selection criteria, or scoring rules. See §4.1.

## 2.2 Selection Starting Point

Avoid creating content only because information exists.

Content selection should start from:

User curiosity and understanding needs.


---

# 3. Audience Value Principle

The primary audience is:

People who want to understand complex topics through clear explanations.

Content should prioritize:

- Clarity.
- Insight.
- Evidence.
- Logical structure.

Avoid:

- Assuming professional background.
- Excessive unexplained terminology.
- Information dumping.

## 3.1 Boundary

This section defines the **audience value principle** — who the content serves and
what it owes them.

It does not define the operator profile. The user of this Agent (the person operating
it) is defined by `USER.md`, which describes operator identity and collaboration
preferences, not the content audience.


---

# 4. Topic Strategy

## 4.1 Topic Selection Responsibility

This file defines **strategic topic direction** — the domain within which topics
should fall.

Detailed topic selection rules are maintained separately and are the single source
of truth for how a topic is chosen.

### Distilled knowledge authorities

| Distilled file | Purpose | Loaded by |
|---|---|---|
| `agent_config/distilled/xiaolinshuo/topic_selection_rules.md` | Topic source patterns, question structures, value drivers, selection rules, anti-patterns | This file (§4.1) · `content_operation_strategy.md` (§4) |
| `agent_config/distilled/xiaolinshuo/topic_pattern_examples.md` | Abstracted topic pattern examples | This file (§4.1) |
| `agent_config/distilled/xiaolinshuo/script_structure_rules.md` | Opening structure, argument rhythm | `agent_config/text_generation.md` |
| `agent_config/distilled/xiaolinshuo/title_formula_rules.md` | Title mechanics | `agent_config/text_generation.md` |
| `agent_config/distilled/xiaolinshuo/visual_pattern_rules.md` | Cover and visual pattern rules | `agent_config/visual_strategy.md` |

### Single Source of Truth

For topic selection:

```
agent_config/distilled/xiaolinshuo/topic_selection_rules.md
```

This file must not duplicate:

- Topic formulas.
- Detailed selection criteria.
- Topic scoring rules.
- Example library.

Those are owned by the distilled files listed above. This file references them and
must not reproduce their rule bodies.

> **Status note.** The distilled files are `Status: DRAFT — based on public video
> corpus analysis`. Their source evaluation recorded that sample data was not
> collected in real time. Treat them as provisional until validated against
> recent live samples. See
> `validation/candidates/xiaolinshuo_evaluation_report.md` §8.

## 4.2 Topic Evaluation Principles

Potential topics should be evaluated by:

### User Interest

Does the topic solve a meaningful curiosity or problem?

### Explanation Value

Can the topic reveal:

- Hidden mechanisms.
- Useful frameworks.
- New perspectives?

### Evidence Availability

Can reliable information support the explanation?

Judged against `agent_config/source_strategy.md`.

### Long-term Value

Can the content remain meaningful beyond temporary attention?

> **Quantitative assessment** of a candidate topic — visual opportunity, series
> potential, audience fit, communication metrics and the composite score — is
> defined by `agent_config/content_operation_strategy.md`.
> This section states the strategic principles; it does not define the scoring schema.


---

# 5. Content Evaluation Framework

## 5.1 Knowledge Value

Evaluate:

- Whether the content provides useful understanding.
- Whether the explanation improves user cognition.

## 5.2 Evidence Quality

Evidence requirements are owned by:

- `SOUL.md` §3 Source Integrity — the distinction between source information and
  generated interpretation.
- `agent_config/source_strategy.md` — the Source Gate, extraction rules, and
  validation checklist.

This file does not restate those requirements. When evaluating a topic or draft for
evidence quality, apply `agent_config/source_strategy.md`.

## 5.3 Communication Value

Platform communication value — attention, structure for comprehension, HKRR
evaluation — is owned by `agent_config/content_operation_strategy.md` §5.

Rationale: platform performance is evaluated separately from content identity and
content direction. Keeping it out of this file prevents the two concerns from being
conflated. See `agent_config/content_operation_strategy.md` §5.2.


---

# 6. Content Boundaries

> **Boundary note.** Identity and safety boundaries are owned by `IDENTITY.md` and
> `SOUL.md`. They are **not** restated here.
> This section defines only the content-quality boundaries that follow from
> content strategy itself.

## 6.1 Owned by this file

### Produce Pure Information Summaries

Content should provide:

- Analysis.
- Structure.
- Explanation.

not only:

- News repetition.
- Fact listing.

### Deliver the Committed Value

Content should deliver the understanding its framing promises.
A title or opening that promises an explanation must be followed by an actual
mechanism explanation, not a restatement of the premise.

## 6.2 Referenced, not owned

| Boundary | Authority |
|---|---|
| Do not fabricate facts; do not invent personal experiences; clearly distinguish fact, assumption and inference | `SOUL.md` §1 Truthfulness |
| Do not pretend to be a real person; do not claim private knowledge; do not generate statements as confirmed personal opinions | `SOUL.md` §2 Identity Boundary · `IDENTITY.md` Identity Boundary |
| Do not present generated interpretation as original source material | `SOUL.md` §3 Source Integrity |
| Avoid unsupported claims, excessive emotional expression, and misleading conclusions | `IDENTITY.md` Creative Philosophy (Rational Expression) |
| Avoid content without practical value or substance | `SOUL.md` §4 User Value Priority |

> **Note on personal experience.** The prohibition is absolute and conditional-free:
> `SOUL.md` states "Do not invent personal experiences."
> If a source explicitly provides a first-hand account and it has passed
> `agent_config/source_strategy.md` verification, it may be **cited as source
> material with attribution** — it must never be narrated as the Creator's own
> experience. Any question of what counts as verified source material is resolved
> by `agent_config/source_strategy.md`, not by this file.


---

# 7. Relationship With Other Configuration Files

## SOUL.md

Defines:

- Core behaviour principles.
- Identity and safety boundaries.
- Rule priority and responsibility assignment.

## IDENTITY.md

Defines:

- Who the Creator is.
- Creative philosophy.
- Expression boundaries and persona limits.

## USER.md

Defines:

- The operator's identity and role in this project.
- Collaboration preferences and interaction constraints.
- What USER.md does not store.

Does **not** define the content audience. The content audience value principle is
defined by this file (§3).

## agent_config/content_operation_strategy.md

Defines:

- Visual opportunity assessment.
- Series potential.
- XHS audience fit assessment.
- Topic scoring schema.
- HKRR platform communication evaluation.
- Tag strategy.

## agent_config/operation.md

Defines:

- Execution workflow and phase order.
- Execution state model.
- Failure classification and recovery.
- Context governance.

## agent_config/text_generation.md

Defines:

- Writing execution process.
- XHS expression rules.
- Xiaolinshuo script generation flow.

## agent_config/visual_strategy.md

Defines:

- Visual production strategy.
- Image roles and cover protocols.

## agent_config/source_strategy.md

Defines:

- Source hierarchy and Source Gate.
- Extraction and validation requirements.

## agent_config/review_rules.md

Defines:

- Quality validation requirements.
- Publishing gate and failure routing.

## agent_config/phanthy_review_standard.md

Defines:

- Platform hard criteria.

## agent_config/distilled/xiaolinshuo/

Defines:

- Creator-specific learned patterns.

> Full responsibility assignment across these files:
> `validation/phanthy_creator_configuration_placement_specification_v1.md`


---

# 8. Single Source of Truth Rule

Each configuration file has one responsibility.

This file owns:

- Content direction.
- Content value.
- Strategic evaluation principles.

This file does not own:

- Identity.
- Platform evaluation and packaging.
- Detailed creation formulas.
- Execution instructions.
- Learned templates.
- Rule priority.

## 8.1 Rule Priority

The rule priority ladder is **not** defined here.

Authority: `AGENTS.md` §11 Rule Priority.

```
SOUL.md
>
IDENTITY.md
>
USER.md
>
review_rules.md
>
platform_review_rules
>
agent_config/
>
template_library/
>
runtime data
```

If this file appears to conflict with another configuration file, resolve the
conflict using the ladder above as defined in `AGENTS.md` §11.

## 8.2 Duplication Prohibition

Any rule, formula, boundary or criterion that has an owner elsewhere must be
**referenced**, never copied.

Reference is permitted. Duplication is prohibited.


---

# Version

v3.0

Changes from v2.0:

- **Architecture split.** Platform evaluation and packaging responsibilities were
  extracted into the new `agent_config/content_operation_strategy.md`
  (Visual Opportunity, Series Potential, XHS Audience Fit, Topic Scoring, HKRR, Tag Strategy).
- **Identity boundary restored.** Identity, philosophy and safety rules are now
  referenced from `IDENTITY.md` / `SOUL.md` instead of being restated here.
- **Removed conditional weakening.** The local `unless explicitly provided and verified`
  qualifier on personal experience was removed; the absolute `SOUL.md` rule now governs,
  with source verification routed to `source_strategy.md`.
- **Rule priority de-duplicated.** The local priority ladder was replaced with a
  reference to `AGENTS.md` §11. The previous local copy omitted three levels.
- **USER.md relationship corrected.** USER.md was previously described as defining the
  audience profile and user needs; USER.md explicitly excludes 内容受众画像.
  The audience value principle is owned by this file (§3).
- **Distilled knowledge wired.** All five `distilled/xiaolinshuo/` files are now named
  with explicit purpose and loading entry (§4.1), replacing a single ambiguous pointer.
- **Legacy vertical removed.** Video-creation categories, creator-community audience,
  equipment/parameter framing and the tag/visual/series examples of the previous
  vertical are gone.
- **Placement provenance.** The pre-rewrite v2.0 platform frameworks were restored from
  `validation/agent_config_full_handoff/content_strategy.md` (archived handoff copy).
