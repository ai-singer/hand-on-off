# Operation Strategy v3.1


# Platform

Platform:

小红书 (XHS)


------------------------------------------------------------------------


# Scope and Naming Note

This file owns **execution**: the daily workflow, phase order, execution state,
failure classification, context governance and recovery rules.

It answers: **when and in what order does work run?**

It does not own:

| Concern | Authority |
|---|---|
| Content direction, content value, topic direction | `agent_config/content_strategy.md` |
| Platform evaluation and packaging (visual opportunity, series potential, audience fit, topic scoring, HKRR, tags) | `agent_config/content_operation_strategy.md` |
| Creator-specific learned rules | `agent_config/distilled/xiaolinshuo/` |
| Writing execution | `agent_config/text_generation.md` |
| Visual production | `agent_config/visual_strategy.md` |
| Review verdicts | `agent_config/review_rules.md` · `agent_config/phanthy_review_standard.md` |

> **Disambiguation.** Two files carry "operation" in their name.
> `operation.md`（本文件）governs process order and state.
> `agent_config/content_operation_strategy.md` governs how content is evaluated
> and packaged for the platform. If a rule governs **when something runs**, it
> belongs here; if it governs **how good content is judged to be, or what platform
> metadata it carries**, it belongs there.


------------------------------------------------------------------------


# Operation Goal


The Agent operation goal:


- Produce stable high-quality XHS content.
- Improve content quality through feedback.
- Increase user engagement and retention.
- Build reusable production workflows.
- Maintain reliable execution under long-running tasks.
- Maintain observable, recoverable, and stable execution.
- Prevent execution failure caused by excessive conversation context.


------------------------------------------------------------------------


# Daily Workflow


## Phase 1: Material Collection


Purpose:


Prepare reliable content sources with XHS distribution potential.


Steps:


1. Search suitable reference materials.
2. Monitor XHS hot topics and search trends.
3. Filter materials according to source_strategy.md.
4. Extract useful topics and information.
5. Filter candidates against content direction: content_strategy.md.
6. Apply topic selection rules:
   agent_config/distilled/xiaolinshuo/topic_selection_rules.md
   (abstracted examples: agent_config/distilled/xiaolinshuo/topic_pattern_examples.md).
7. Run topic assessment according to agent_config/content_operation_strategy.md:
   - Visual Opportunity Assessment   (§1)
   - Series Potential                (§2)
   - XHS Audience Fit Assessment     (§3)
   - Platform Communication (HKRR)   (§5)
8. Produce the composite topic_assessment record
   (schema: agent_config/content_operation_strategy.md §4) and set recommendation.
9. Create pending content tasks with assessment scores.

XHS Hot Topic Sources:

- 小红书热榜话题
- 小红书话题广场
- 小红书搜索热词联想

Output:


Content task list with topic assessment scores
(schema: agent_config/content_operation_strategy.md §4).


------------------------------------------------------------------------


## Phase 2: Visual Opportunity Analysis


Purpose:


Evaluate visual feasibility before committing to content production.


Steps:


1. For each pending topic, complete visual_opportunity assessment.
2. Determine cover hook strength.
3. Determine carousel fit (can topic be split into 3–9 images).
4. Identify visual memory points.
5. Reject topics with LOW cover_hook_strength AND LOW carousel_fit.


Criteria:

agent_config/content_operation_strategy.md §1


Output:


Approved topic list with visual assessment attached.


------------------------------------------------------------------------


## Phase 3: Series Planning


Purpose:


Define the image sequence before generating any content.


Steps:


1. Define carousel count (3–9 images).
2. Assign image roles (Hook / Context / Detail / Explanation / Result / CTA).
3. Define information unit for each image.
4. Define emotional tone for each image.
5. Produce carousel_output YAML (reference: visual_strategy.md).


Criteria:

- Series potential level: agent_config/content_operation_strategy.md §2
- Carousel design and image roles: visual_strategy.md
- Creator cover and visual patterns:
  agent_config/distilled/xiaolinshuo/visual_pattern_rules.md


Output:


Carousel plan YAML per topic.


------------------------------------------------------------------------


## Phase 4: Visual Production


Purpose:


Generate images according to the carousel plan.


Steps:


1. Generate cover image (Image 1: Hook role).
2. Generate remaining carousel images in order.
3. Run Image Non-Redundancy check after generation.
4. Verify image ratio (3:4 or 1:1).
5. Verify text overlay readability.


Reference:

visual_strategy.md


Output:


Image set: cover + carousel images.


------------------------------------------------------------------------


## Phase 5: Copy Generation


Purpose:


Generate XHS-optimized copy after visual assets are confirmed.


Steps:


1. Run the Xiaolinshuo Script Generation Flow (text_generation.md §1):
   angle selection → opening construction → argument body → title → XHS adaptation.
2. Generate title per agent_config/distilled/xiaolinshuo/title_formula_rules.md
   (≤20 characters, real question, no rhetorical titles).
3. Generate body copy using the XHS writing flow
   (Hook → Value Promise → Core Information → Interpretation Layer → Interaction).
4. Generate image text overlays (cover title ≤15 chars, captions ≤30 chars).
5. Verify copy does not duplicate image content.
6. Generate tags per agent_config/content_operation_strategy.md §6
   (3–6 tags, #话题 format).


Reference:

- text_generation.md
- agent_config/distilled/xiaolinshuo/script_structure_rules.md
- agent_config/distilled/xiaolinshuo/title_formula_rules.md
- agent_config/content_operation_strategy.md (§6 Tag Strategy)


Output:


Title, body copy, image text overlays, tags.


------------------------------------------------------------------------


## Phase 6: Review


Purpose:


Ensure all content meets quality and compliance standards.


Steps:


1. Run full review pipeline from review_rules.md:
   - Source Check
   - Fact Check
   - Content Quality Check
   - Visual Series Review
   - Cover Review
   - Copy Review
   - XHS Compliance Review
2. Fix failed items.
3. Re-run failed checks after fix.


Output:


Review result (PASS / FAIL with failure log).


------------------------------------------------------------------------


## Phase 7: Preview Render


Purpose:


Simulate XHS user first-screen experience before human approval.


Steps:


1. Assemble final package:
   - Cover image
   - Carousel images (in order)
   - Title
   - Body copy
   - Tags
2. Render preview summary:
   - Cover + title combination review
   - First image + first 2 lines of copy review
   - Tag list review
3. Output preview package for human review.


Preview checks:

□ Cover + title creates click motivation.

□ First 2 lines of copy contain a Hook.

□ Image sequence order is logical.

□ Tag count and format correct.


Output:


Preview package ready for human approval.


------------------------------------------------------------------------


## Phase 8: Human Approval


Purpose:


Ensure a human reviews the final package before publishing.


Rule:


Forbidden:

Direct publishing from JSON package without human review.


Human review entry point:

Preview package from Phase 7.


Human can:

- Approve → proceed to Phase 9.
- Request changes → return to relevant phase.
- Reject → log rejection reason and archive task.


------------------------------------------------------------------------


## Phase 9: Publishing


Purpose:


Publish approved content and record publishing information.


Steps:


1. Submit final package to publishing system.
2. Verify publishing success.
3. Record publishing information.


Publishing Record:

``` yaml
publish_record:
  title:
  cover_image:
  image_count:
  tags:
  publish_time:
  review_status: PASS
  post_identifier:
  series_name:       # if part of a series
  series_part:       # e.g., "2/5"
  platform: XHS
```


------------------------------------------------------------------------


# Feedback Loop


Workflow:


Published Content

↓

Review Feedback

↓

Problem Analysis

↓

Update Responsible Configuration

↓

New Test


------------------------------------------------------------------------


# Operation Boundary


operation.md defines:


- Workflow.
- Iteration process.
- Publishing process.
- Runtime execution rules.
- Recovery rules.
- Context management rules.


operation.md does not define:


- Agent identity.
- Content style.
- Image generation details.
- Review standards.


------------------------------------------------------------------------


# Execution State Model


Agent execution contains four layers:


## Layer 1: Planning State


Includes:


- Understanding request.
- Designing execution steps.
- Selecting tools.
- Preparing inputs.


Planning does not equal execution.


------------------------------------------------------------------------


## Layer 2: Model Processing State


Includes:


- Loading context.
- Reasoning.
- Generating assistant response.
- Selecting tool actions.


Runtime evidence:


agent/embedded
stage=assistant


Entering Model Processing State means:


The Agent has started processing the request.


------------------------------------------------------------------------


## Layer 3: Execution State


Execution evidence includes:


- Tool call.
- exec execution.
- File creation.
- File modification.
- API request.
- Background Task execution.


Any execution evidence means:


The task has entered execution.


------------------------------------------------------------------------


## Layer 4: Completion State


A task is complete only when:


- Required outputs exist.
- Validation passes.
- Final report generated.


Intermediate steps are not completion.


------------------------------------------------------------------------


# OpenClaw Task Interpretation Rules


Tasks are tracking records.


Tasks are not universal execution indicators.


Rules:


1.

A running Task indicates tracked background execution.


2.

The absence of a Task does not indicate failure.


3.

Interactive Agent runs may execute without creating Tasks.


4.

Task state must be evaluated with:


- Runtime logs.
- Tool execution.
- File changes.
- Output artifacts.


Forbidden:


Using:


"No Task"


as the only failure signal.


------------------------------------------------------------------------


# Runtime Failure Classification


## MODEL_TIMEOUT


Indicators:


agent/embedded
stage=assistant
reason=timeout


Meaning:


Model generation failed before tool execution.


Action:


- Check provider status.
- Retry.
- Reduce context size.
- Split task.


Do not classify as execution failure.


------------------------------------------------------------------------


## EXECUTION_TIMEOUT


Indicators:


- Tool started.
- Task running.
- No completion.


Meaning:


Execution layer timeout.


Action:


Recover from checkpoint.


------------------------------------------------------------------------


## NOT_STARTED


Indicators:


All conditions:


- No model processing log.
- No tool execution.
- No artifact change.
- No runtime progress.


Meaning:


Execution trigger failure.


Action:


Re-trigger execution.


------------------------------------------------------------------------


# Context Management Rule


Long-running production workflows must not depend on unlimited conversation history.


When a conversation contains:


- Multiple failed attempts.
- Large logs.
- Large pasted documents.
- Multiple configuration versions.
- Large generated reports.


The Agent should consider starting a fresh execution session.


------------------------------------------------------------------------


# Fresh Session Recovery Rule


A new session must recover from workspace state, not conversation replay.


Recovery source priority:


1.

Checkpoint files.


2.

Generated artifacts.


3.

Runtime summaries.


4.

Configuration files.


Forbidden:


Requiring the entire previous conversation history to continue execution.


------------------------------------------------------------------------


# Context Overflow Prevention


Complex tasks must not combine:


- Large context loading.
- Complex reasoning.
- Large generation.
- Validation.
- Packaging.


into one model turn.


Preferred:


Preparation

↓

Execution

↓

Validation

↓

Packaging


------------------------------------------------------------------------


# Task Decomposition Rule


Large tasks must be divided into bounded units.


Incorrect:


Load everything
↓
Analyze everything
↓
Generate everything
↓
Validate everything


Correct:


Load bounded input
↓
Execute one unit
↓
Validate
↓
Continue next unit


------------------------------------------------------------------------


# Multi-Step Task Execution


For multi-stage tasks:


Examples:


- Validation.
- Generation.
- Repair.
- Review.
- Packaging.


Execution flow:


Preparation

↓

Validation

↓

Processing

↓

Generation

↓

Validation

↓

Final Report


The Agent must continue automatically.


Forbidden stopping points:


- Schema Probe completed.
- File loading completed.
- Environment check completed.
- Intermediate analysis completed.


------------------------------------------------------------------------


# Schema Probe Rule


Before processing structured data:


Perform Schema Probe.


Required:


1.

Load sample data.


2.

Verify:


- Data type.
- Fields.
- Required keys.
- Nested structure.


3.

Confirm compatibility.


Schema Probe PASS means:


Input structure is valid.


Schema Probe PASS does not mean:


Task completed.


------------------------------------------------------------------------


# Defensive Data Processing Rule


When processing structured data:


Forbidden:


- Assuming identical structures.
- Accessing unknown fields directly.
- Large batch processing before validation.


Required:


- Type checking.
- Field checking.
- Default handling.
- Node type distinction.


------------------------------------------------------------------------


# External Dependency Rule


Production tasks must validate dependencies before execution.


Forbidden:


Installing dependencies during production execution unless explicitly required.


------------------------------------------------------------------------


# External API Reliability Rule


API workflow:


Request

↓

Status Check

↓

Response Validation

↓

Parsing


Forbidden:


Parsing incomplete responses.


------------------------------------------------------------------------


# Recovery Rule


When execution is interrupted:


1.

Identify latest checkpoint.


2.

Preserve valid outputs.


3.

Skip completed stages.


4.

Resume unfinished stage.


Forbidden:


Restarting the entire pipeline unnecessarily.


------------------------------------------------------------------------


# Final Report Requirement


Every production task final report must include:


- Completed stages.
- Runtime status.
- Generated outputs.
- Validation result.
- Remaining issues.
- FINAL_STATUS.


------------------------------------------------------------------------


# Version


Version:


v3.1


Changes from v3.0:


- Added Scope and Naming Note, disambiguating this file (execution order and state)
  from agent_config/content_operation_strategy.md (platform evaluation and packaging).
- Phase 1: replaced the dangling reference to content_strategy.md for topic
  assessment. The three named frameworks (Visual Opportunity, Series Potential,
  XHS Audience Fit) had been removed from content_strategy.md during an earlier
  single-file rewrite; they now live in content_operation_strategy.md.
- Phase 1: added explicit topic selection step referencing
  distilled/xiaolinshuo/topic_selection_rules.md and topic_pattern_examples.md.
- Phase 1: added HKRR step and explicit topic_assessment schema reference.
- Phase 2: added criteria reference (content_operation_strategy.md §1).
- Phase 3: added criteria references (content_operation_strategy.md §2,
  visual_strategy.md, distilled/xiaolinshuo/visual_pattern_rules.md).
- Phase 5: replaced "Emotional Connection" in the writing flow with
  "Interpretation Layer" — the Emotional Connection layer was removed from
  text_generation.md because it instructed the Agent to share real personal
  failure experiences, conflicting with SOUL.md and IDENTITY.md.
- Phase 5: added Xiaolinshuo Script Generation Flow step and distilled file references.
- Phase 5: tag step now references content_operation_strategy.md §6 as the tag rule owner.


Changes from v2.1 (v3.0):


- Platform locked to XHS (小红书).
- Daily Workflow expanded from 3 phases to 9 phases.
- Added Phase 2: Visual Opportunity Analysis.
- Added Phase 3: Series Planning (carousel plan before production).
- Reordered Phase 4: Visual Production before Copy Generation.
- Added Phase 5: Copy Generation (Visual-first flow enforced).
- Updated Phase 6: Review with XHS-specific review pipeline.
- Added Phase 7: Preview Render.
- Added Phase 8: Human Approval gate (forbidden to publish without human review).
- Updated Phase 9: Publishing Record with XHS fields (title, cover, image_count, tags, series info).
- Phase 1 updated with XHS hot topic sources.
- All reliability rules preserved: Schema Probe, Defensive Data Processing, Context Overflow Prevention, Fresh Session Recovery, Task Decomposition, Multi-Step Execution, External API Reliability, Recovery Rule.
