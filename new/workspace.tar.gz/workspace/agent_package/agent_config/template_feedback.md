# Template Feedback Strategy

# Purpose

Template feedback collects production results and converts them into
optimization signals for the template library.

The goal:

    Template Usage

    ↓

    Output Evaluation

    ↓

    Feedback Collection

    ↓

    Template Optimization

    ↓

    Better Retrieval

------------------------------------------------------------------------

# Responsibility Boundary

template_feedback.md defines:

-   Feedback collection.
-   Template performance evaluation.
-   Template optimization signals.

template_feedback.md does not define:

-   Content generation.
-   Visual generation.
-   Review standards.
-   Publishing workflow.

------------------------------------------------------------------------

# Feedback Sources

Feedback can come from:

## Production Result

Record:

-   Template used.
-   Generated content.
-   Generated visual.
-   Production time.
-   Execution problems.

## Review Result

Collect:

-   PASS / FAIL status.
-   Review issues.
-   Required fixes.
-   Repeated failure patterns.

## User Feedback

Collect:

-   Audience response.
-   Engagement signals.
-   Quality evaluation.

------------------------------------------------------------------------

# Feedback Record

Each template usage should generate:

``` yaml
template_feedback:

template_id:

usage_time:

output_type:

review_status:

issues:

improvements:

performance_score:
```

------------------------------------------------------------------------

# Performance Evaluation

Evaluate templates by:

## Content Template

Check:

-   Topic relevance.
-   Hook effectiveness.
-   Structure quality.
-   Audience response.
-   Review pass rate.

## Visual Template

Check:

-   Visual consistency.
-   Content relevance.
-   Cover readability.
-   Generation success rate.
-   Audience response.

------------------------------------------------------------------------

# Template Update Rules

## Improve Template

Allowed when:

-   Same issue appears repeatedly.
-   Better pattern is identified.
-   Successful variations are confirmed.

## Keep Template

When:

-   Output quality is stable.
-   Review passes consistently.
-   Retrieval remains accurate.

## Deprecate Template

When:

-   Template causes repeated failures.
-   Pattern no longer matches audience needs.
-   Better replacement exists.

------------------------------------------------------------------------

# Feedback Loop

Complete learning loop:

    Template Retrieval

    ↓

    Production

    ↓

    Review

    ↓

    Feedback Collection

    ↓

    Template Update

    ↓

    Future Retrieval

------------------------------------------------------------------------

# Failure Analysis

When output fails:

Record:

## Failure Type

Examples:

-   Wrong topic direction.
-   Weak structure.
-   Poor visual match.
-   Audience mismatch.
-   Review failure.

## Root Cause

Determine:

-   Template problem.
-   Retrieval problem.
-   Generation problem.
-   Source problem.

## Action

Choose:

-   Update template.
-   Adjust retrieval rules.
-   Improve generation instructions.
-   Create new template.

------------------------------------------------------------------------

# Integration With Agent Architecture

Full intelligence loop:

    Creator Content

    ↓

    Content Distillation

    ↓

    Template Library


    Production Request

    ↓

    Template Retrieval

    ↓

    Generation

    ↓

    Review

    ↓

    Feedback

    ↓

    Template Optimization

------------------------------------------------------------------------

# Version

Version:

v1.0

Status:

Initial Template Feedback Module
