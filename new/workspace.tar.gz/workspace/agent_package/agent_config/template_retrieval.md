# Template Retrieval Strategy

# Purpose

Template retrieval selects the most suitable reusable templates from the
template library for a production task.

The goal:

    Production Request

    ↓

    Template Matching

    ↓

    Best Available Template

    ↓

    Content / Visual Generation

------------------------------------------------------------------------

# Responsibility Boundary

template_retrieval.md defines:

-   Template selection logic.
-   Matching criteria.
-   Template ranking.
-   Retrieval constraints.

template_retrieval.md does not define:

-   Template creation.
-   Content writing rules.
-   Visual generation rules.
-   Review rules.
-   Publishing workflow.

------------------------------------------------------------------------

# Input

Required:

Production request.

Example:

``` yaml
production_request:
  topic:
  content_type:
  platform:
  target_audience:
  goal:
```

Optional:

``` yaml
context:
  previous_templates:
  performance_feedback:
  failed_patterns:
```

------------------------------------------------------------------------

# Retrieval Pipeline

Process:

    Production Request

    ↓

    Requirement Analysis

    ↓

    Template Candidate Search

    ↓

    Template Ranking

    ↓

    Template Selection

    ↓

    Generation Workflow

------------------------------------------------------------------------

# Content Template Retrieval

Match based on:

## Topic Category

Compare:

-   Topic type.
-   Industry.
-   User problem.
-   Content purpose.

## Audience

Compare:

-   Target users.
-   Knowledge level.
-   Content expectation.

## Structure

Compare:

-   Required article format.
-   Hook style.
-   Information density.

Output:

``` yaml
selected_content_template:

template_id:

match_reason:

confidence:
```

------------------------------------------------------------------------

# Visual Template Retrieval

Match based on:

## Platform

Examples:

-   Xiaohongshu.
-   YouTube.
-   Blog.

## Aspect Ratio

Examples:

-   3:4.
-   16:9.
-   1:1.

## Content Theme

Compare:

-   Technology.
-   Education.
-   Review.
-   Storytelling.

## Visual Identity

Ensure:

-   Matches account positioning.
-   Maintains visual consistency.

Output:

``` yaml
selected_visual_template:

template_id:

match_reason:

confidence:
```

------------------------------------------------------------------------

# Template Ranking

Ranking factors:

## Relevance

Does the template match the current task?

## Historical Performance

Consider:

-   Usage count.
-   Feedback.
-   Successful outputs.

## Recency

Prefer updated templates when quality is similar.

## Stability

Avoid:

-   Experimental templates.
-   Deprecated templates.

Example:

``` yaml
template_score:

relevance:

performance:

stability:

final_score:
```

------------------------------------------------------------------------

# Template Status Rules

Only retrieve:

-   active
-   testing

Do not retrieve:

-   deprecated

------------------------------------------------------------------------

# Failure Handling

No matching template:

Action:

-   Use general production strategy.
-   Record missing pattern.
-   Consider future template creation.

Low confidence:

Action:

-   Select best available template.
-   Mark for review.

------------------------------------------------------------------------

# Integration With Production Workflow

Complete workflow:

    Creator Content

    ↓

    content_distillation.md

    ↓

    content_template

    ↓

    template_library


    Production Request

    ↓

    template_retrieval.md

    ↓

    Selected Template

    ↓

    text_generation.md

    ↓

    visual_strategy.md

    ↓

    review_rules.md

------------------------------------------------------------------------

# Learning Loop

After production:

Collect:

-   Template used.
-   Output quality.
-   Review results.
-   User feedback.

Update:

-   performance_feedback
-   usage_count
-   template status

Loop:

    Production

    ↓

    Feedback

    ↓

    Template Update

    ↓

    Better Retrieval

------------------------------------------------------------------------

# Version

Version:

v1.0

Status:

Initial Template Retrieval Module
