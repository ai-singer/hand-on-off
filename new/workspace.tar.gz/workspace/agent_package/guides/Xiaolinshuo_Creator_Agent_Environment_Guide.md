# Xiaolinshuo Creator Agent — Environment Guide

**文档版本：** v1.0
**生成日期：** 2026-09-21
**适用范围：** 将本 workspace 复制的 Xiaolinshuo Creator Agent 实例，部署到新运行环境
**扫描依据：** 对 workspace 全量代码/配置执行 `exec` / `shell` / `runtime` / `ffmpeg` / `path` / `external skill` 六类检查

---

## 0. 扫描结果总览

| 类别 | 检出的绑定项 | 阻塞级 |
|---|---|---|
| **Path** | `/home/node` 绝对路径 **34 处 / 18 文件** | 🔴 8 处硬阻塞 |
| **ffmpeg** | 二进制字面量路径 **10 处 / 5 文件**，其中 **6 处无回退** | 🔴 6 处硬阻塞 |
| **Runtime** | 宿主配置 `~/.openclaw/openclaw.json` 硬依赖（workspace 之外） | 🔴 1 处硬阻塞 |
| **Exec / Shell** | 7 个 shell 脚本 `cd /home/node/...`；1 个守护进程仅 Linux | 🔴 8 处硬阻塞 |
| **External Skill** | `mediastorm-text-generation`（已在配置层移除，但 Skill 仍存在于宿主） | 🟢 已解除绑定 |
| **依赖清单** | `requirements.txt` / `pyproject.toml` / `setup.py` / `Pipfile` / `environment.yml` / `package.json` **全部缺失** | 🟠 需新建 |

**结论：** 配置层（`agent_config/` + `AGENTS.md`）**已与环境解耦**；仍与环境绑定的是 `source_collector/` 的代码与 `scripts/` 的运维脚本。这些绑定**不影响 Agent 启动与配置加载**，但会在执行采集/抽帧/发布时失败。

---

## 1. Path — 绝对路径绑定

### 1.1 已知问题

`/home/node/.openclaw/workspace` 是源环境的容器路径。共 **34 处**，分布在 18 个文件：

| 文件 | 命中数 | 行号 | 阻塞级 |
|---|---|---|---|
| `source_collector/scripts/run_frame_extraction_prod.sh` | 5 | 7, 8, 9, 39, 40 | 🔴 硬阻塞 |
| `scripts/message_poller_minute.sh` | 5 | 6, 7, 13, 15, 29 | 🔴（且该目录不在迁移包内） |
| `source_collector/services/keyframe_dense_scan.py` | 4 | 48, 56, 86, 105 | 🔴 硬阻塞 |
| `scripts/message_poller.sh` | 3 | 3, 7, 9 | 🔴（同上） |
| `source_collector/services/keyframe_diversity.py` | 2 | 40, 305 | 🔴 硬阻塞 |
| `source_collector/scripts/wait_and_extract.sh` | 2 | 5, 16 | 🔴 |
| `creator_profiles/analysis/run_analysis.py` | 2 | 5, 274 | 🟡 |
| `source_collector/scripts/{run_asr_tests,run_extraction,run_frame_extraction,run_frame_tests,run_merge,run_tests}.sh` | 各 1 | 2 | 🔴 各 1 处 |
| `source_collector/scripts/run_audio_extraction.py` | 1 | 36 | 🟢 有回退 |
| `source_collector/services/{audio_extraction,frame_extraction}.py` | 各 1 | 78 / 90 | 🟢 有回退 |
| `source_collector/tests/test_audio_extraction.py` | 1 | 244 | 🟡 |
| `scripts/start_poller.sh` | 1 | 4 | 🔴（不在迁移包内） |

### 1.2 根因

源环境为 Linux 容器，workspace 挂载在 `/home/node/.openclaw/workspace`。
脚本以绝对路径 `cd` 与写入，未使用 `__file__` 或环境变量解析根目录。

### 1.3 修复步骤

**A. shell 脚本的 `cd`（7 处）** — 把硬编码的 `cd` 改为相对脚本自身定位：

```bash
# 修改前
cd /home/node/.openclaw/workspace/source_collector

# 修改后
cd "$(dirname "$0")/.."
```

| 文件 | 行 |
|---|---|
| `run_asr_tests.sh` | 2 |
| `run_extraction.sh` | 2 |
| `run_frame_extraction.sh` | 2 |
| `run_frame_tests.sh` | 2 |
| `run_merge.sh` | 2 |
| `run_tests.sh` | 2 |
| `wait_and_extract.sh` | 16 |

**B. `run_frame_extraction_prod.sh`（5 处）** — 引入 `WORKSPACE_ROOT` 环境变量：

```bash
# 修改前
SOURCE_ROOT="/home/node/.openclaw/workspace/source_collector/sources/bilibili/ysjf/space_camera_project"
FFMPEG=/home/node/.local/bin/ffmpeg
FFPROBE=/home/node/.local/bin/ffprobe

# 修改后
SOURCE_ROOT="${SOURCE_ROOT:?SOURCE_ROOT must be set}"
FFMPEG="$(command -v ffmpeg)"
FFPROBE="$(command -v ffprobe)"
```

并同步修改第 39、40 行的两个 Python 字面量，改为读取环境变量。
第 67 行的 `"source_id": "bilibili_av84178790"` 改为从 `source.json` 读取。

**C. `keyframe_dense_scan.py` / `keyframe_diversity.py`（6 处）** — 引入与同目录 `frame_extraction.py` 一致的候选列表 + `shutil.which` 回退：

```python
# 参考 frame_extraction.py:94 的既有正确写法
def _resolve_ffmpeg() -> str:
    found = shutil.which("ffmpeg")
    if found:
        return found
    for cand in ("/usr/bin/ffmpeg", "/usr/local/bin/ffmpeg", "/home/node/.local/bin/ffmpeg"):
        if os.path.isfile(cand):
            return cand
    raise FileNotFoundError("ffmpeg not found in PATH or candidate locations")
```

调用点：`keyframe_dense_scan.py:48, 86, 105`（ffmpeg）与 `:56`（ffprobe）；`keyframe_diversity.py:40, 305`（ffmpeg）。

**D. `run_analysis.py:5, 274`** — 绝对输入输出路径改为命令行参数或环境变量。

**E. `test_audio_extraction.py:244`** — 能力探测改为 `shutil.which("ffmpeg") is not None`。

### 1.4 验证方式

```bash
# 1) 全树复查：可执行代码中不应再有 /home/node
grep -rn "/home/node" --include=*.py --include=*.sh --include=*.yaml . | grep -v "/home/node/.openclaw/workspace/.*\.json"

# 2) shell 脚本可在任意工作目录执行
cd /tmp && bash <WORKSPACE>/source_collector/scripts/run_tests.sh

# 3) 关键帧模块的 ffmpeg 解析
python -c "import sys; sys.path.insert(0,'<WORKSPACE>/source_collector'); \
from services.keyframe_diversity import _resolve_ffmpeg; print(_resolve_ffmpeg())"
```

**通过标准：** 第 1 条输出为空；第 2 条在非 workspace 目录下成功执行；第 3 条打印出有效 ffmpeg 路径而非抛异常。

---

## 2. ffmpeg — 二进制依赖

### 2.1 已知问题

`ffmpeg` / `ffprobe` 是抽帧、音频抽取、关键帧处理的硬依赖。
**10 处**引用二进制路径，其中 **6 处无任何回退**：

| 文件 | 行 | 写法 | 回退 |
|---|---|---|---|
| `services/keyframe_dense_scan.py` | 48 | `["/home/node/.local/bin/ffmpeg"] + args,` | ❌ **无** |
| `services/keyframe_dense_scan.py` | 56 | `["/home/node/.local/bin/ffprobe", ...]` | ❌ **无** |
| `services/keyframe_dense_scan.py` | 86 | `["/home/node/.local/bin/ffmpeg", ...]` | ❌ **无** |
| `services/keyframe_dense_scan.py` | 105 | `["/home/node/.local/bin/ffmpeg", ...]` | ❌ **无** |
| `services/keyframe_diversity.py` | 40 | `["/home/node/.local/bin/ffmpeg", ...]` | ❌ **无** |
| `services/keyframe_diversity.py` | 305 | `["/home/node/.local/bin/ffmpeg", ...]` | ❌ **无** |
| `services/frame_extraction.py` | 90 | 候选列表 | ✅ `shutil.which` 优先 |
| `services/audio_extraction.py` | 78 | 候选列表 | ✅ `shutil.which` 优先 |
| `scripts/run_audio_extraction.py` | 36 | `shutil.which("ffmpeg") or "..."` | ✅ 有，且降级 MockBackend |
| `tests/test_audio_extraction.py` | 244 | 能力探测 | 🟡 探测逻辑本身不可移植 |

### 2.2 根因

关键帧模块把二进制路径当作 `subprocess` 的 `argv[0]` **字面量**传入，未经过任何解析。
同一代码库内 `frame_extraction.py` 与 `audio_extraction.py` 已采用 `shutil.which` 优先的正确写法——
因此这是**实现不一致**，而非设计缺陷。

### 2.3 修复步骤

1. 目标环境安装 ffmpeg/ffprobe，并确认二者在 `PATH` 中：
   ```bash
   ffmpeg -version && ffprobe -version
   ```
2. 按 §1.3 C 修复 `keyframe_dense_scan.py` 与 `keyframe_diversity.py` 的 6 处字面量。
3. `frame_extraction.py:90` 与 `audio_extraction.py:78` 的候选列表建议保留（作为二级回退），无需改动。

> **注意：** 仅把 ffmpeg 装进 `PATH` **不能**修复那 6 处——它们是字面量 argv，不查 `PATH`。
> 必须同时完成代码修改。

### 2.4 验证方式

```bash
# 1) PATH 可用性
command -v ffmpeg && command -v ffprobe

# 2) 关键帧模块实际可执行（不再抛 FileNotFoundError）
python -m pytest <WORKSPACE>/source_collector/tests/test_keyframe_v2_k2a.py -v

# 3) 抽帧端到端（需一个真实视频）
python -c "import sys; sys.path.insert(0,'<WORKSPACE>/source_collector'); \
from services.frame_extraction import extract_frames; print(extract_frames('<video>', interval_sec=10.0).__dict__)"
```

**通过标准：** 第 2 条不再出现 `FileNotFoundError`；如环境无 ffmpeg，应出现明确的降级提示而非崩溃。

---

## 3. Runtime — 宿主配置硬依赖

### 3.1 已知问题

`source_collector/services/image_generation.py` 硬依赖宿主配置文件：

| 行 | 内容 |
|---|---|
| 115 | `openclaw_config_path = os.path.expanduser("~/.openclaw/openclaw.json")` |
| 118 | `raise BackendMissingError(f"openclaw.json 不存在: {openclaw_config_path}")` |

该文件**位于 workspace 之外**，任何"复制 workspace"的部署都不会带上它。
缺失时图片生成直接抛 `BackendMissingError`，**无降级路径**。

### 3.2 根因

图片生成后端通过读取宿主 `openclaw.json` 发现 provider，而非读取 workspace 内的配置或环境变量。
设计前提是"workspace 总是运行在配好的 OpenClaw 宿主内"——该前提在迁移场景下不成立。

### 3.3 修复步骤

**方案 A（推荐，不改代码）：** 在目标环境的宿主配置中提供该文件，且满足发现条件：

- 存在一个 provider，其 `api` 字段为 `"google-generative-ai"`；
- 该 provider 下有一个接受 `image` 输入的模型；
- 该 provider 配置含有效 `apiKey` 与 `baseUrl`。

文件位置：`~/.openclaw/openclaw.json`

**方案 B（改代码，提高可移植性）：** 让路径可被环境变量覆盖：

```python
openclaw_config_path = os.environ.get(
    "OPENCLAW_CONFIG_PATH",
    os.path.expanduser("~/.openclaw/openclaw.json"),
)
```

> 该文件的第 344 行已有一个 `openclaw_config_path` 覆盖参数，说明设计上已预留可覆盖点，
> 只是未接到环境变量。

**方案 C：** 若目标环境不使用图片生成，需接受该能力不可用，并确保 `operation.md` Phase 4
不会因缺失后端而中断整个流程（当前会抛异常）。

### 3.4 验证方式

```bash
# 1) 宿主配置存在且可解析
python -c "import json,os; p=os.path.expanduser('~/.openclaw/openclaw.json'); \
print('FOUND' if os.path.isfile(p) else 'MISSING'); json.load(open(p))"

# 2) 后端发现逻辑可跑通
python -c "import sys; sys.path.insert(0,'<WORKSPACE>/source_collector'); \
from services.image_generation import discover_backend; print(discover_backend())"
```

**通过标准：** 第 2 条返回 `BackendConfig` 而非抛 `BackendMissingError`。

---

## 4. Exec / Shell — 执行环境绑定

### 4.1 已知问题

| 项 | 位置 | 问题 |
|---|---|---|
| shell 脚本 `cd` | `source_collector/scripts/` 7 个 `.sh` | 硬编码 `cd /home/node/.openclaw/workspace/source_collector`（详见 §1.1） |
| bash 依赖 | `source_collector/scripts/*.sh` | 需 POSIX shell；Windows 需 Git Bash / WSL |
| 仅 Linux 的守护进程 | `scripts/poller_daemon.py:17,18,32,37,41` | `os.fork()`、`os.setsid()`、`/tmp/poller_blueengineer.{pid,log}` — **Windows 无 `os.fork`** |
| 第三方调度库 | `scripts/message_poller.py:8` | `import schedule` — 未在任何清单中声明 |
| 无依赖清单 | workspace 全局 | `requirements.txt` / `pyproject.toml` / `setup.py` / `Pipfile` / `environment.yml` / `package.json` **全部缺失** |

**重要说明：** `scripts/` 整目录属 **DO-NOT-COPY**（与内容生产无关，且含明文凭证）。
上表关于 `scripts/` 的条目**仅作为源环境事实记录**，新实例不应携带该目录。

### 4.2 根因

- shell 脚本按"固定容器路径"编写，未假设可移植。
- `scripts/` 的轮询脚本是为 Linux 容器写的运维工具，从未设计为跨平台。
- `source_collector/` 依赖纯标准库（无 numpy/scipy/PIL/cv2/requests），因此**从未产出依赖清单**——
  这是有意的极简设计，但在新环境需要显式重建依赖声明。

### 4.3 修复步骤

1. **按 §1.3 A/B 修复 7 个 shell 脚本的 `cd`**，使其可在任意工作目录执行。
2. **产出依赖清单**（新实例的 `source_collector/`）：

   ```text
   # requirements.txt — 硬依赖
   pytest>=7.0

   # 可选依赖（缺失时自动降级到 MockBackend 或功能降级）
   # openai-whisper      ASR 后端之一（services/asr.py 懒加载）
   # faster-whisper      实际产出源数据所用的 ASR 引擎（代码未 import，但复现需它）
   # yt-dlp              字幕/视频获取（代码未调用，源数据由它产出）
   # Pillow              联系人清单合并图（缺失时降级，见源数据中的 "PIL not available"）
   ```

3. **Python 版本：** 要求 **3.10+**（`source_collector/collectors/bilibili/models.py:21`
   在运行时使用 `str | None`，且该文件无 `from __future__ import annotations`）。
4. **binfmt / exec 权限：** 目标环境的 `.sh` 需有执行位，或统一以 `bash <script>` 调用。
5. **`scripts/` 不迁移。** 若新实例确需消息基础设施，应作为独立项目重建，
   而非继承源环境的 Linux 专用实现。

### 4.4 验证方式

```bash
# 1) Python 版本
python -c "import sys; assert sys.version_info >= (3,10), sys.version; print('OK', sys.version)"

# 2) 关键模块可导入（暴露 3.10 语法依赖）
python -c "import sys; sys.path.insert(0,'<WORKSPACE>/source_collector'); \
import collectors.bilibili.models as m; print('models OK')"

# 3) 测试套件可被收集
python -m pytest <WORKSPACE>/source_collector/tests --collect-only -q | tail -5

# 4) shell 脚本可在任意目录执行
cd / && bash <WORKSPACE>/source_collector/scripts/run_tests.sh
```

**通过标准：** 4 条全部通过；第 3 条应收集到 30 个测试模块（其中约 19 个断言旧项目产物，
在未附带 `sources/` 时会失败或跳过——属预期，见 §6）。

---

## 5. External Skill — 外部技能依赖

### 5.1 已知问题（已解决）

源 workspace 的 `agent_config/text_generation.md` 曾强制要求：

```
When executing any text generation task ... MUST use the `mediastorm-text-generation` skill.
```

该 Skill：

1. 位于宿主 `~/.openclaw/skills/`，**不在 workspace 内**；
2. 蒸馏自影视飓风 / MediaStorm 的写作风格，与本 Creator 风格相悖。

**当前状态：✅ 已解除绑定。** `text_generation.md` v3.0 已移除该强制指令，
改为 `Xiaolinshuo Script Generation Flow`，依赖 workspace 内的
`distilled/xiaolinshuo/script_structure_rules.md` 与 `title_formula_rules.md`。

### 5.2 根因

配置层把"风格"委托给了一个 workspace 之外、且创作者不匹配的 Skill。
这既破坏可复制性（复制 workspace 不带上 Skill），又破坏身份一致性。

### 5.3 修复步骤（已完成 / 待确认）

1. ✅ 已从 `agent_config/text_generation.md` 移除 `## Skill Requirement` 段。
2. ✅ 已建立 `Xiaolinshuo Script Generation Flow`（`text_generation.md` §1），
   并把 STEP 2–5 的规则归属指向两个蒸馏文件。
3. ✅ `AGENTS.md` v1.9 §9 已把两个蒸馏文件列入 Text Generation Agent 的 Required 列表。
4. ⬜ **待确认：** 宿主 `~/.openclaw/skills/` 下若仍存在 `mediastorm-*`，应确认
   Agent 不会在无显式指令的情况下自动加载它们。这些 Skill 的完整定义目前**只存在于
   `memory/2026-09-15-skill-build.md` 与 `memory/2026-09-15-visual-prompt.md`**
   （因为源文件在 workspace 之外）。如需归档，应在源环境单独保存后再排除 `memory/`。

### 5.4 验证方式

```bash
# 1) 配置层不应再出现 mediastorm 强制指令（仅允许出现在变更记录里）
grep -rn "mediastorm" <WORKSPACE>/agent_config/ <WORKSPACE>/AGENTS.md

# 2) 宿主技能目录检查
ls -la ~/.openclaw/skills/ 2>/dev/null || echo "no skills dir"

# 3) 蒸馏依赖可达
grep -n "script_structure_rules\|title_formula_rules" <WORKSPACE>/agent_config/text_generation.md
grep -n "script_structure_rules\|title_formula_rules" <WORKSPACE>/AGENTS.md
```

**通过标准：** 第 1 条仅在 `text_generation.md` 的变更记录中出现；第 3 条在两处均有命中。

---

## 6. 部署前检查清单

| # | 检查项 | 通过标准 | 阻塞级 |
|---|---|---|---|
| E-1 | OpenClaw 运行时可用 | Agent 可启动 | 🔴 |
| E-2 | `~/.openclaw/openclaw.json` 存在且含可用 image provider | §3.4 第 2 条通过 | 🔴 |
| E-3 | Python ≥ 3.10 | `sys.version_info >= (3,10)` | 🔴 |
| E-4 | ffmpeg / ffprobe 在 PATH | `command -v` 均有输出 | 🔴 |
| E-5 | `keyframe_dense_scan.py` / `keyframe_diversity.py` 的 6 处字面量已修 | §2.4 第 2 条通过 | 🔴 |
| E-6 | 7 个 shell 脚本的 `cd` 已修 | §1.4 第 2 条通过 | 🔴 |
| E-7 | `requirements.txt` 已产出 | 文件存在且内容与 §4.3 一致 | 🟠 |
| E-8 | `pytest` 已安装 | `pytest --version` | 🟠 |
| E-9 | 采集凭证就绪 | `BILIBILI_COOKIE_PATH` 指向有效 Cookie 文件 | 🟠 |
| E-10 | Phanthy API 凭证就绪 | `/openclaw/status` 可达 | 🟠 |
| E-11 | 磁盘 ≥ 15 GB | 抽帧产物按项目累积 | 🟡 |
| E-12 | 外网可达 Bilibili / 小红书 / Phanthy | 连通性测试 | 🟠 |

### 6.1 关于 30 个测试模块的预期

`source_collector/tests/` 中约 **19 个模块**断言的是已归档项目
`bilibili/ysjf/space_camera_project` 的具体产物。由于迁移包不包含 `sources/`，
这些测试在目标环境**会失败或需跳过**——这是**预期行为**，不是环境问题。

处置（二选一）：

- 对这些模块加 `pytest.mark.skip(reason="depends on archived validation project")`；
- 或改为读取环境变量提供的项目根。

11 个使用 `MockBackend` + `tmp_path` 的模块应全部通过。

---

## 7. 本指南的不确定项

| # | 不确定项 |
|---|---|
| U-1 | `openclaw.json` 的 provider 发现条件是否只有"`api == google-generative-ai` 且模型接受 image 输入"这两条。`image_generation.py` 的发现逻辑未被完整逐行核验 |
| U-2 | 未在目标环境实跑任何测试。§1.4 / §2.4 / §4.4 的"通过标准"均为**设计判据**，需实际执行验证 |
| U-3 | `services/` 17 个模块中，除已定位的 5 个含路径/ffmpeg 绑定的模块外，是否还有未检出的环境绑定。已对全树 grep `/home/node`、`ffmpeg`、`ysjf`、`space_camera`，但未逐行通读约 200 KB 代码 |
| U-4 | `faster-whisper` 未出现在任何代码 import 中，但是源 ASR 数据的实际产出引擎。其是否为复现必需，取决于是否要重建源 ASR 结果 |
| U-5 | `scripts/` 内 4 个 poller 的实际调度方式。源 workspace 无 crontab / systemd unit / supervisor 配置，且其依赖的 `logs/` 目录不存在 |
| U-6 | 宿主 `~/.openclaw/skills/` 下是否仍有 `mediastorm-*`，以及 Agent 是否会自动加载它们。源环境不在本快照中，无法核验 |

---

*Xiaolinshuo_Creator_Agent_Environment_Guide.md v1.0 — Phase 5 输出*
