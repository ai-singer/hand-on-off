# Xiaolinshuo Creator Agent — Deployment Guide

**版本：** v2.0（架构治理后）
**日期：** 2026-09-21
**配套包：** `xiaolinshuo_creator_agent_package/`
**配套文档：** `Xiaolinshuo_Creator_Agent_Environment_Guide.md`（环境兼容性）· `xiaolinshuo_creator_migration_report.md`（迁移报告）

> **v2.0 说明：** 本指南取代 v1.0。v1.0 编写于 `content_strategy.md` 单文件改写之后、
> 架构治理之前，其中"必须重写 content_strategy.md / 必须移除 mediastorm 依赖"等前置项
> **已在本次治理中完成**。本版反映治理后的实际状态。

---

## 1. 部署目标

把 `xiaolinshuo_creator_agent_package/` 复制到新环境，得到一个：

- **身份一致** — 无身份规则冲突，Business Config 不重复定义身份
- **规则无冲突** — 每条规则只有一个主人
- **知识可达** — 5 个蒸馏文件各有唯一加载入口
- **环境可部署** — 环境绑定项已识别并给出修复路径

的 Xiaolinshuo Creator Agent。

---

## 2. 目标架构（部署后）

```
<WORKSPACE>/
│
├── SOUL.md                     ← Core Identity（不可修改）
├── IDENTITY.md                 ← Core Identity（不可修改）
├── USER.md                     ← Core Identity（不可修改）
│
├── AGENTS.md                   ← v1.9 工作流路由 + 加载规则
├── HEARTBEAT.md                ← 周期检查
├── TOOLS.md                    ← 工具能力
├── MEMORY.md                   ← Agent 经验（部署后应清空历史条目）
│
├── agent_config/               ← 业务配置层（14 项）
│   ├── content_strategy.md              v3.0  内容方向 / 内容价值 / Topic 方向
│   ├── content_operation_strategy.md    v1.0  平台评估与包装（★本次新增）
│   ├── source_strategy.md                     来源与 Source Gate
│   ├── text_generation.md               v3.0  写作执行 + Xiaolinshuo Script Flow
│   ├── visual_strategy.md               v3.0  视觉生产
│   ├── review_rules.md                  v2.1  审核门控
│   ├── operation.md                     v3.1  执行流程（9 阶段）
│   ├── phanthy_review_standard.md             平台硬指标
│   ├── content_distillation.md                蒸馏方法
│   ├── visual_distillation.md                 视觉蒸馏方法
│   ├── template_retrieval.md                  模板检索
│   ├── template_feedback.md                   模板反馈
│   ├── VERSION.md                       v1.2  版本记录
│   └── distilled/xiaolinshuo/          ← ★ 创作者知识（5 文件，保持 DRAFT）
│       ├── topic_selection_rules.md
│       ├── topic_pattern_examples.md
│       ├── script_structure_rules.md
│       ├── title_formula_rules.md
│       └── visual_pattern_rules.md
│
├── source_collector/           ← 采集执行层（代码与文档；sources/ 为空）
│   ├── README.md · collectors/ · config/ · contracts/ · doc/ · scripts/ · services/ · tests/
│   ├── processors/ · scheduler/ · storage/     ← 空占位
│   ├── secrets/                                ← 凭证，权限收紧
│   └── sources/                                ← 空
│
├── source_material/{raw,extracted,verified}/   ← 空
├── template_library/                           ← 知识库层
│   ├── README.md · metadata/template_index.json
│   └── content_templates/ · visual_templates/ · feedback/   ← 空
│
├── 选题库/topics.json          ← 空选题池（保留 config 段）
├── posts/ · covers/{pending,archive,samples}/ · logs/ · memory/ · validation/
└── （以上运行时目录均为空）
```

---

## 3. 部署步骤

### STEP 0 — 环境前置

按 `Xiaolinshuo_Creator_Agent_Environment_Guide.md` §6 检查清单执行。
**三项硬阻塞必须先解决：**

| # | 项 | 判据 |
|---|---|---|
| E-2 | `~/.openclaw/openclaw.json` 存在且含可用 image provider | Environment Guide §3.4 |
| E-3 | Python ≥ 3.10 | `sys.version_info >= (3,10)` |
| E-4 | ffmpeg / ffprobe 在 PATH | `command -v ffmpeg && command -v ffprobe` |

### STEP 1 — 复制包内容

```bash
cp -r xiaolinshuo_creator_agent_package/core/*            <WORKSPACE>/
cp -r xiaolinshuo_creator_agent_package/workflow/*        <WORKSPACE>/
cp -r xiaolinshuo_creator_agent_package/tools/*           <WORKSPACE>/
cp -r xiaolinshuo_creator_agent_package/agent_config      <WORKSPACE>/
cp -r xiaolinshuo_creator_agent_package/knowledge         <WORKSPACE>/template_library
cp -r xiaolinshuo_creator_agent_package/guides            <WORKSPACE>/
```

### STEP 2 — 创建运行时目录（空）

```bash
cd <WORKSPACE>
mkdir -p source_material/{raw,extracted,verified}
mkdir -p posts covers/{pending,archive,samples} logs memory validation 选题库
```

### STEP 3 — 配置环境相关项

见 §4「需要配置清单」。共 **7 项**。

### STEP 4 — 修复环境绑定（代码级）

见 `Xiaolinshuo_Creator_Agent_Environment_Guide.md` §1.3、§2.3。
**8 个 shell 脚本 + 2 个关键帧模块**必须修改，否则采集与抽帧会失败。

### STEP 5 — 产出依赖清单

`source_collector/` 无任何依赖清单。按 Environment Guide §4.3 产出 `requirements.txt`。

### STEP 6 — 验收

执行 §6 的 4 项测试。

---

## 4. 需要配置清单（7 项）

| # | 文件 | 必须改什么 | 优先级 |
|---|---|---|---|
| C-1 | `agent_config/distilled/xiaolinshuo/`（5 文件） | **不改内容。** 确认 `Status: DRAFT` 字段保留。这 5 个文件是 DRAFT 状态的知识资产，不得提升为 ACTIVE | 🔴 保持现状 |
| C-2 | `source_collector/config/source_targets.yaml` | 采集目标从 `ysjf_bilibili`（影视飓风）改为 Xiaolinshuo；`categories` 改为财经科普/商业机制/宏观与地缘经济。**UID 520819684 需实时核验** | 🔴 |
| C-3 | `MEMORY.md` | 清空 "Verified Experience" 段的历史条目（源环境宿主特有的会话信号经验）。保留文件结构与 Memory Boundary | 🟠 |
| C-4 | `选题库/topics.json` | `topics` → `[]`；`stats` 重置为全 0。保留 `config` 段（`daily_target: 5`、`min_word_count: 1500`、`cover_aspect_ratio: 3:4`、`cover_size: 2K`） | 🟠 |
| C-5 | `template_library/metadata/template_index.json` | 清空 2 条占位模板，或改名为 `SCHEMA_EXAMPLE_DO_NOT_USE`。**禁止**无内容改 `status: active` | 🟡 |
| C-6 | `source_collector/secrets/bilibili_cookies.txt` | 在目标环境新建；设 `BILIBILI_COOKIE_PATH` 指向它 | 🔴 |
| C-7 | 凭证（Phanthy API Key / Agent ID / 图片生成） | 全部在目标环境新建。`TOOLS.md` 只引用路径，不写凭证值 | 🔴 |

### 4.1 关于 `source_material/` 的落点偏离

`AGENTS.md` §5 声明 `source_material/{raw,extracted,verified}` 存储原材料，
但 `source_collector/` 的实际产物落在 `source_collector/sources/<platform>/<creator>/<project>/`。

**处置：** 建立空占位目录以保持声明一致（STEP 2），并在部署记录中写明：
> 采集产物实际落点为 `source_collector/sources/`；`source_material/` 为声明占位，暂未写入。

---

## 5. 禁止复制清单

迁移包**已排除**以下内容。请勿从源 workspace 手动补齐。

| 类别 | 对象 | 理由 |
|---|---|---|
| 🔴 凭证 | 任何 API Key / Token / credentials | 安全 |
| 运行时数据 | `memory/`（140 文件）、`source_collector/sources/`（242 文件 / 13.6 MB）、`选题库/` 现有内容 | 上一实例运行历史；含第三方视频抽帧（版权） |
| 历史 | `history/blue_engineer_baseline/`（9 文件） | 声明 `FROZEN_BASELINE` / `usage: comparison_only` / `modification: forbidden` |
| 过程证据 | `validation/`（174 文件） | 决策过程记录，非配置 |
| 基础设施 | `scripts/`（7 文件） | 与内容生产无关；**含同一把 Phanthy API Key 的 6 处明文字面量**；仅 Linux |
| 重复文件 | `指导文件/`（1 文件） | 与 `agent_config/phanthy_review_standard.md` SHA-256 完全相同 |
| 一次性/历史 | `manifest.md`、`BOOTSTRAP.md`、`ARCHITECTURE_MIGRATION.md`、`architecture_audit_report.md`、`ChatGPT运行规则.md` | 一次性产物 / 已过期 / Controller 侧规则 |
| 其他创作者 | `creator_agents/china_geography/`、`creator_profiles/` | 中国国家地理的实例数据，会污染 Xiaolinshuo 画像 |

---

## 6. 验收测试

### 6.1 Identity Test — 身份一致性

```bash
# 1) Business Config 不得重复定义身份
grep -rn "Not a Real Person\|不声称拥有真实\|Identity Boundary" <WORKSPACE>/agent_config/

# 2) 无身份冲突的垂类残留
grep -rn "视频制作\|剪辑\|up主\|影视飓风\|蓝厂\|工程角度" <WORKSPACE>/agent_config/ <WORKSPACE>/AGENTS.md

# 3) 无个人经历虚构指令
grep -rn "个人经验型\|真实失败\|第一人称视角的真实经历" <WORKSPACE>/agent_config/
```

**通过标准：** 三条均**仅命中变更记录/引用说明**，不命中任何生效规则。
（第 1 条若命中 `IDENTITY.md` 引用路径属正常。）

### 6.2 Reachability Test — 蒸馏知识可达

```bash
for f in topic_selection_rules topic_pattern_examples script_structure_rules title_formula_rules visual_pattern_rules; do
  echo "--- $f ---"
  grep -rln "$f" <WORKSPACE>/AGENTS.md <WORKSPACE>/agent_config/
done
```

**通过标准：** 5 个文件**各自至少 1 个加载入口**，且入口是 `AGENTS.md` §9 的加载列表或
`agent_config/` 中的明确引用节。预期映射：

| 蒸馏文件 | 加载入口 |
|---|---|
| `topic_selection_rules.md` | `content_strategy.md` §4.1 · `content_operation_strategy.md` §4 |
| `topic_pattern_examples.md` | `content_strategy.md` §4.1 |
| `script_structure_rules.md` | `text_generation.md` §1 · `AGENTS.md` §9 |
| `title_formula_rules.md` | `text_generation.md` §1 · `AGENTS.md` §9 |
| `visual_pattern_rules.md` | `visual_strategy.md` Creator Style Authority · `AGENTS.md` §9 |

### 6.3 Dependency Test — 外部依赖

```bash
# 1) 无外部 Skill 强依赖
grep -rn "MUST use the .* skill\|mediastorm" <WORKSPACE>/agent_config/ <WORKSPACE>/AGENTS.md

# 2) 无缺失路径引用
grep -rn "source_material\|credentials.json" <WORKSPACE>/AGENTS.md <WORKSPACE>/agent_config/ | head -20

# 3) 环境绑定已识别（应仅剩已知的 8+6+1 项）
grep -rn "/home/node" <WORKSPACE>/ --include=*.py --include=*.sh | wc -l
```

**通过标准：** 第 1 条仅命中变更记录；第 3 条的数量与 Environment Guide §0 一致或为 0（若已修复）。

### 6.4 Deployment Test — 新实例初始化模拟

按 §3 STEP 0–6 在干净目录执行一遍，确认：

- [ ] D-1 包内 110 个文件全部落地
- [ ] D-2 9 个运行时目录已创建且为空
- [ ] D-3 环境前置 3 项硬阻塞通过
- [ ] D-4 §4 的 7 项配置完成
- [ ] D-5 §6.1 / §6.2 / §6.3 三项测试通过
- [ ] D-6 冒烟测试：注入 1 条选题 → 走完 Phase 1–6 → 产出 1 个通过 review 的 draft（**不发布**）

---

## 7. 已知限制与风险

| # | 限制 | 影响 | 处置 |
|---|---|---|---|
| R-1 | `collectors/bilibili/client.py:24-35` **返回硬编码 mock 数据** | 复制包**不带来可用采集能力**。历史上真实数据是在管线之外获得的 | 部署记录必须写明；如需自动采集须自行实现 |
| R-2 | `source_collector/tests/` 约 19 个模块绑定已归档项目 | 因不附带 `sources/`，这些测试在目标环境会失败 | 加 `pytest.mark.skip` 或改读环境变量 |
| R-3 | 蒸馏规则均为 `Status: DRAFT`，上游评估自述"样本未实时采集" | 风格规则未经验证 | 保持 DRAFT；上线后补 ≥20 条实时样本验证 |
| R-4 | `source_collector/services/` 只覆盖**接触媒体的机械阶段** | 11 个阶段（机会挖掘、组合规划、文本生成、两轮审核、打包等）**无代码**，由 Agent 以 LLM-in-the-loop 执行 | 不要假设 `services/` 等价于完整管线 |
| R-5 | `scripts/` 中同一把 Phanthy API Key 的 6 处明文字面量仍在源 workspace | 密钥已进入交接快照，**应视为已泄露** | 在源环境轮换并清理 |
| R-6 | `~/.openclaw/openclaw.json` 为 workspace 外硬依赖 | 缺失时图片生成抛 `BackendMissingError`，无降级 | Environment Guide §3.3 方案 A/B/C |
| R-7 | 视频形态 → 图文形态的转换规则无文档 | 蒸馏规则中的时间约束（"30 秒"、"20 分钟"）需人工换算为轮播单位 | `text_generation.md` §1.5 已给出转换原则，但具体映射未定 |
| R-8 | `content_operation_strategy.md` 与 `operation.md` 命名相近 | 路由混淆风险 | 两文件均已加 Scope 消歧说明（`operation.md` §Scope and Naming Note） |

---

## 8. 部署记录模板

部署完成后，请填写并归档：

```yaml
deployment:
  date: <ISO-8601>
  environment:
    os: <>
    python: <>
    openclaw_runtime: <>
    ffmpeg: <>
  package_version: v1.0
  steps_completed: [0, 1, 2, 3, 4, 5, 6]
  environment_preconditions:
    E-2_openclaw_json: pass / fail
    E-3_python_310: pass / fail
    E-4_ffmpeg_path: pass / fail
  configuration_applied: [C-1, C-2, C-3, C-4, C-5, C-6, C-7]
  accepted_deviations:
    - source_material 落点偏离（见 §4.1）
    - collector 为 mock 骨架（见 R-1）
    - 19 个测试模块跳过（见 R-2）
  validation:
    identity_test: pass / fail
    reachability_test: pass / fail
    dependency_test: pass / fail
    deployment_test: pass / fail
    smoke_test: pass / fail
  open_risks: [R-1, R-2, R-3, R-4, R-5, R-6, R-7, R-8]
  final_status: <>
```

---

*xiaolinshuo_creator_deployment_guide.md v2.0*
