# Knowledge Map

**本目录：** `agent_package/knowledge/`
**对应架构层：** Knowledge Library Layer（`AGENTS.md` §6）

---

## 1. 本目录内容

| 条目 | 内容 |
|---|---|
| `README.md` | 知识库用途与规则（来自 `template_library/README.md`） |
| `metadata/template_index.json` | 模板索引（**需配置**：清空 2 条占位条目） |
| `content_templates/` | 空 — 内容模板存储 |
| `visual_templates/` | 空 — 视觉模板存储 |
| `feedback/` | 空 — 模板性能反馈 |

**部署映射：** `agent_package/knowledge/` → `<WORKSPACE>/template_library/`

---

## 2. 创作者蒸馏知识的实际位置

**任务要求"Knowledge 包含 distilled/xiaolinshuo/"，但蒸馏知识不在本目录，而位于：**

```
agent_package/agent_config/distilled/xiaolinshuo/
├── topic_selection_rules.md      6,879 B
├── topic_pattern_examples.md     5,021 B
├── script_structure_rules.md     9,503 B
├── title_formula_rules.md        8,857 B
└── visual_pattern_rules.md       8,147 B
```

### 为什么保持这个位置（而非移入 knowledge/）

| 原因 | 说明 |
|---|---|
| **1. 可达性硬要求** | 任务六要求"distilled 5/5 可达"。`AGENTS.md` §3 声明规范位置为 `agent_config/distilled/<creator>/`；§9 的加载列表、以及 `content_strategy.md` / `content_operation_strategy.md` / `text_generation.md` / `visual_strategy.md` / `operation.md` 中的**全部引用路径**都指向该位置 |
| **2. 移动会破坏引用** | 若移到 `knowledge/`，约 10 处引用需同步改写，且需重新验证加载顺序 —— 与"保持职责拆分"要求冲突 |
| **3. 单一事实来源** | 若两处各存一份，会产生重复副本，违反 Reference-Only Rule 与 SSOT |
| **4. 语义正确** | 蒸馏知识是**创作者专属规则**（Business Configuration 层的创作者变体），不是**可复用模板**（Knowledge Library 层）。二者层级不同 |

**结论：** 保持规范位置，`knowledge/` 承载 Knowledge Library Layer。
"Knowledge 包含 distilled"这一要求的**实质**（蒸馏知识随包交付且可达）已满足 —— 见下方可达性验证。

---

## 3. 蒸馏知识可达性验证（静态）

| 蒸馏文件 | 加载入口 | 入口数 |
|---|---|---|
| `topic_selection_rules.md` | `content_strategy.md` §4.1 · `content_operation_strategy.md` §4 · `operation.md` Phase 1 · `AGENTS.md` §3 映射表 | 4 |
| `topic_pattern_examples.md` | `content_strategy.md` §4.1 · `operation.md` Phase 1 · `AGENTS.md` §3 映射表 | 3 |
| `script_structure_rules.md` | `text_generation.md` §1 · `operation.md` Phase 5 · `AGENTS.md` §9 Text Agent | 3 |
| `title_formula_rules.md` | `text_generation.md` §1 · `operation.md` Phase 5 · `AGENTS.md` §9 Text Agent | 3 |
| `visual_pattern_rules.md` | `visual_strategy.md` Creator Style Authority · `operation.md` Phase 3 · `AGENTS.md` §9 Visual Agent | 3 |

**可达率 5 / 5。**

---

## 4. 关于 `template_index.json` 的配置要求

当前含 **2 条占位模板**（`content_template_example_001`、`visual_template_example_001`），
均为 `status: "testing"`，`target_audience` 与 `platform` 为空，`usage_count: 0`。

**部署时必须处置（二选一）：**

- 清空 `templates` 数组；
- 或将两条 `name` 改为 `SCHEMA_EXAMPLE_DO_NOT_USE` 以标明其为 schema 示例。

**🔴 严禁**把 `status` 从 `testing` 改为 `active` 而不填充真实模板内容 ——
这会让 `template_retrieval.md` 检索到空模板。

---

## 5. 关于 5 个蒸馏文件的状态

全部为：

```
Status: DRAFT — based on public video corpus analysis
```

**🔴 部署时必须原样保留 `Status: DRAFT`，不得提升为 ACTIVE。**

其上游评估（`validation/candidates/xiaolinshuo_evaluation_report.md` §8）自述：
样本未实时采集，存在截止日期偏差，正式使用前应补充 ≥20 条实时样本验证。

该评估报告**不在本包内**（属验证报告，禁止复制），其结论以引用形式记于
`agent_package/agent_config/content_strategy.md` §4.1 的状态注中。

---

*KNOWLEDGE_MAP.md — 知识位置说明与可达性验证*
