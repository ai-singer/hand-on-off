# Source Collector Module

# Purpose

`source_collector` is the automatic external information acquisition
layer of the Agent system.

Its responsibility is:

    External Sources

    ↓

    Automatic Collection

    ↓

    Raw Material Storage

    ↓

    Source Processing Pipeline

It provides the input capability for:

-   Content research.
-   Creator learning.
-   Content distillation.
-   Template generation.

------------------------------------------------------------------------

# Position in Architecture

Complete relationship:

    agent_config/

    Defines collection rules


            ↓


    source_collector/

    Executes collection capability


            ↓


    source_material/

    Stores collected data


            ↓


    content_distillation

    visual_distillation


            ↓


    template_library/

------------------------------------------------------------------------

# Responsibility Boundary

## source_collector is responsible for:

-   Source scheduling.
-   External content collection.
-   Metadata extraction.
-   Duplicate detection.
-   Raw material creation.

## source_collector is not responsible for:

-   Writing content.
-   Creating templates.
-   Reviewing posts.
-   Publishing content.

------------------------------------------------------------------------

# Internal Structure

Recommended structure:

    source_collector/

    ├── collectors/

    │   Source-specific collectors


    ├── scheduler/

    │   Collection task scheduling


    ├── processors/

    │   Data normalization and preprocessing


    ├── storage/

    │   Write collected data


    └── config/

        Collection target configuration

------------------------------------------------------------------------

# Collection Pipeline

## Step 1: Schedule

Scheduler determines:

-   Which sources to check.
-   When to execute.
-   Collection frequency.

Example:

    Nightly Collection

    02:00

    ↓

    Check subscribed creators

------------------------------------------------------------------------

## Step 2: Collect

Collector retrieves public information.

Output:

    source_material/raw/

Raw records should contain:

``` yaml
source_record:

source_id:

platform:

creator:

title:

url:

published_at:

collected_at:

content:

status:
```

------------------------------------------------------------------------

## Step 3: Normalize

Processor converts different sources into unified format.

Examples:

-   Video transcript.
-   Article text.
-   Metadata.
-   Tags.

Output:

    source_material/extracted/

------------------------------------------------------------------------

## Step 4: Continue Pipeline

After collection:

    source_material/extracted

    ↓

    verification

    ↓

    distillation

------------------------------------------------------------------------

# Error Handling

Collection failures should:

-   Record error information.
-   Retry temporary failures.
-   Continue other sources.
-   Avoid blocking the whole pipeline.

Example:

``` yaml
collection_error:

source:

error_type:

retry_count:

status:
```

------------------------------------------------------------------------

# Security Rules

Allowed:

-   Public sources.
-   Public information processing.

Forbidden:

-   Private data collection.
-   Credential storage.
-   Bypassing access restrictions.

------------------------------------------------------------------------

# Version

Version:

v1.0

Status:

Initial Source Collector Module Definition
