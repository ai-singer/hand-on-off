from .collector import BilibiliCollector


__all__ = [
    "BilibiliCollector",
]
