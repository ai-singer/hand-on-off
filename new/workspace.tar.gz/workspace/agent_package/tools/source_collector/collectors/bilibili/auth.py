"""
collectors/bilibili/auth.py

Bilibili Authentication Layer

职责：
- 从环境变量读取 Cookie 配置路径
- 验证 Cookie 文件是否可访问
- 提供认证路径给 Bilibili Client
- 未配置时返回明确错误，不抛出异常

配置方式（.env 或环境变量）：
  BILIBILI_COOKIE_PATH=/path/to/cookies.txt

禁止：
- 硬编码 cookie 内容
- 返回 cookie 内容本身
- 将 cookie 写入任何持久化存储
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional


# 环境变量名称
ENV_COOKIE_PATH = "BILIBILI_COOKIE_PATH"


@dataclass
class BilibiliAuthConfig:
    """
    认证配置结果。

    只暴露 cookie 文件路径，不暴露内容。
    """
    cookie_path: str

    def __repr__(self) -> str:
        # 避免日志中意外打印路径全文
        return f"BilibiliAuthConfig(cookie_path='<set>')"


class BilibiliAuthError(Exception):
    """认证配置错误，包含可读的错误原因。"""
    pass


def load_auth() -> BilibiliAuthConfig:
    """
    从环境变量加载认证配置。

    Returns:
        BilibiliAuthConfig — 包含 cookie_path

    Raises:
        BilibiliAuthError — 当环境变量未设置或文件不存在时
    """
    cookie_path = os.environ.get(ENV_COOKIE_PATH, "").strip()

    if not cookie_path:
        raise BilibiliAuthError(
            f"Bilibili Cookie 未配置。"
            f"请设置环境变量 {ENV_COOKIE_PATH}=/path/to/cookies.txt"
        )

    if not os.path.isfile(cookie_path):
        raise BilibiliAuthError(
            f"Bilibili Cookie 文件不存在: {cookie_path}  "
            f"(来自环境变量 {ENV_COOKIE_PATH})"
        )

    return BilibiliAuthConfig(cookie_path=cookie_path)


def try_load_auth() -> tuple[Optional[BilibiliAuthConfig], Optional[str]]:
    """
    尝试加载认证配置，不抛出异常。

    Returns:
        (BilibiliAuthConfig, None)  — 成功
        (None, error_message)       — 失败，附带可读错误信息
    """
    try:
        return load_auth(), None
    except BilibiliAuthError as e:
        return None, str(e)
