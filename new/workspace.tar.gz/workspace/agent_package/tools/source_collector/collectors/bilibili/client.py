class BilibiliClient:
    """
    Bilibili platform access layer.

    This layer isolates platform-specific communication.
    The first version uses mock data to verify the collector
    architecture before implementing real data acquisition.
    """

    def fetch_creator_content(self, url: str) -> list[dict]:
        """
        Fetch public creator content.

        Current implementation:
        - mock response
        - no network request

        Future implementation:
        - connect to Bilibili data source
        - parse platform response
        - return normalized raw items
        """

        return [
            {
                "source_id": "mock_bv001",
                "title": "Mock Bilibili Content",
                "url": url,
                "published_at": None,
                "content": None,
                "metadata": {
                    "mock": True
                },
            }
        ]
