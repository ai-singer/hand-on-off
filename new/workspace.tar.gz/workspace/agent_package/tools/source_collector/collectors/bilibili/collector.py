from .client import BilibiliClient


class BilibiliCollector:
    """
    Bilibili Collector implementation.

    Responsibility:
    - receive source target
    - call Bilibili client
    - return unified collection_result

    It does not handle:
    - storage
    - extraction
    - verification
    - distillation
    """

    def __init__(self, client=None):
        self.client = client or BilibiliClient()

    def collect(self, source_target: dict) -> dict:
        """
        Execute Bilibili collection workflow.

        Input:
            source_target configuration

        Output:
            collection_result
        """

        try:
            items = self.client.fetch_creator_content(
                source_target["url"]
            )

            return {
                "status": "success",
                "platform": "bilibili",
                "items": items,
                "errors": [],
            }

        except Exception as exc:
            return {
                "status": "failed",
                "platform": "bilibili",
                "items": [],
                "errors": [
                    {
                        "type": type(exc).__name__,
                        "message": str(exc),
                    }
                ],
            }
