from dataclasses import dataclass, field
from typing import Any


@dataclass
class BilibiliItem:
    """
    Bilibili platform-specific content model.

    This model represents the raw data structure
    collected from Bilibili before conversion into
    the common collection format.
    """

    source_id: str

    title: str

    url: str

    published_at: str | None = None

    content: str | None = None

    metadata: dict[str, Any] = field(default_factory=dict)



def to_collection_item(item: BilibiliItem) -> dict:
    """
    Convert Bilibili-specific model into
    common Collection Item format.

    The output should be compatible with
    Source Collector Interface.
    """

    return {
        "source_id": item.source_id,
        "title": item.title,
        "url": item.url,
        "published_at": item.published_at,
        "content": item.content,
        "metadata": item.metadata,
    }
