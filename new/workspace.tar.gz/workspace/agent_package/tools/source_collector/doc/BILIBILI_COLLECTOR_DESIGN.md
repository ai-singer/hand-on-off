# Bilibili Collector Design v1.0

# Purpose

Define the platform-specific collector design for Bilibili public
content acquisition.

The collector converts Bilibili content into the unified Source Record
format defined by Source Collector Interface.

------------------------------------------------------------------------

# Position

    source_targets.yaml

    ↓

    Bilibili Collector

    ↓

    Processor

    ↓

    source_material/raw

------------------------------------------------------------------------

# Responsibility Boundary

Bilibili Collector is responsible for:

-   Reading Bilibili source targets.
-   Discovering new public content.
-   Collecting available metadata.
-   Obtaining public content data.
-   Producing source records.

Bilibili Collector is not responsible for:

-   Writing articles.
-   Evaluating content quality.
-   Creating templates.
-   Publishing content.

------------------------------------------------------------------------

# Input

From:

    source_collector/config/source_targets.yaml

Example:

``` yaml
platform:
  bilibili

creator:
  target_creator

url:
  creator_space_url
```

------------------------------------------------------------------------

# Output

Unified record:

``` yaml
source_record:

  source_id:

  platform:

  creator:

  title:

  url:

  published_at:

  collected_at:

  content:

  metadata:

  status:
```

------------------------------------------------------------------------

# Collection Process

## Step 1: Load Target

Read enabled Bilibili targets.

Check:

-   Platform.
-   Creator.
-   Collection status.

------------------------------------------------------------------------

## Step 2: Discover Content

Find:

-   New videos.
-   Updated information.
-   Metadata changes.

Duplicate detection:

-   Video ID.
-   URL.
-   Content hash.

------------------------------------------------------------------------

## Step 3: Collect Data

Collect available public information:

-   Title.
-   Description.
-   Publish time.
-   Video URL.
-   Transcript/subtitle when available.
-   Public metadata.

------------------------------------------------------------------------

## Step 4: Create Source Record

Convert collected data into unified format.

Send to:

    processors/

------------------------------------------------------------------------

# Error Handling

Possible errors:

## Collection Failure

Examples:

-   Network failure.
-   Platform response failure.

Action:

-   Retry.
-   Record failure.

## Missing Content

Examples:

-   No transcript available.

Action:

-   Preserve metadata.
-   Mark missing fields.

------------------------------------------------------------------------

# Platform Boundary

Rules:

-   Only collect public information.
-   Respect platform restrictions.
-   Do not bypass access controls.
-   Preserve source attribution.

------------------------------------------------------------------------

# Version

Version:

v1.0

Status:

Bilibili Collector Design
