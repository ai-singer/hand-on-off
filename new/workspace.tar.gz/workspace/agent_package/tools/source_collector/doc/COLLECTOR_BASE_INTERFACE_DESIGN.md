# Collector Base Interface Design v1.0

# Purpose

Define the common interface contract for all source collectors.

The interface allows different platforms to provide content acquisition
capability while sharing the same processing pipeline.

------------------------------------------------------------------------

# Position

Complete flow:

    source_targets.yaml

    ↓

    Collector Interface

    ↓

    Platform Collector

    ↓

    collection_result

    ↓

    Processor

    ↓

    source_record

    ↓

    source_material/raw

------------------------------------------------------------------------

# Responsibility Boundary

## Collector Interface is responsible for:

-   Defining collector contract.
-   Standardizing input and output.
-   Managing collector lifecycle.

## Collector Interface is not responsible for:

-   Platform-specific implementation.
-   Content normalization.
-   Storage.
-   Verification.

------------------------------------------------------------------------

# Collector Lifecycle

    Initialize

    ↓

    Load Target

    ↓

    Collect

    ↓

    Return Result

    ↓

    Close

------------------------------------------------------------------------

# Input Contract

Input:

``` yaml
collector_request:

  source_target:

    platform:

    creator:

    url:

    collection_type:
```

The collector receives configuration only.

It should not contain hard-coded source targets.

------------------------------------------------------------------------

# Output Contract

Output:

``` yaml
collection_result:

  status:

  platform:

  items:

  errors:
```

Status:

    success

    partial

    failed

------------------------------------------------------------------------

# Item Contract

Each collected item should contain enough information for Processor:

``` yaml
collection_item:

  source_id:

  title:

  url:

  published_at:

  content:

  metadata:
```

------------------------------------------------------------------------

# Platform Collector Example

Bilibili implementation:

    CollectorInterface

            ↓

    BilibiliCollector

            ↓

    collection_result

Other platforms can follow:

    YouTubeCollector

    RSSCollector

    ArticleCollector

------------------------------------------------------------------------

# Error Handling

Collector errors:

``` yaml
collector_error:

  source:

  error_type:

  message:

  retryable:
```

Rules:

-   Collector failures must be observable.
-   Temporary failures may retry.
-   Failed collection must not corrupt stored data.

------------------------------------------------------------------------

# Implementation Rules

Collectors should:

-   Depend on interface.
-   Return unified result.
-   Keep platform logic isolated.

Collectors should not:

-   Write directly to template library.
-   Generate content.
-   Modify business rules.

------------------------------------------------------------------------

# Version

Version:

v1.0

Status:

Collector Base Interface Design
