# Distillation Integration Design v1.0

# Purpose

Define how verified source materials enter the content and visual
distillation pipeline.

The integration connects:

    source_material/verified

    ↓

    Distillation Layer

    ↓

    template_library

------------------------------------------------------------------------

# Position

Complete learning flow:

    source_collector

    ↓

    source_material/raw

    ↓

    Extraction

    ↓

    source_material/extracted

    ↓

    Verification

    ↓

    source_material/verified

    ↓

    content_distillation

    +

    visual_distillation

    ↓

    template_library

------------------------------------------------------------------------

# Responsibility Boundary

## Distillation Integration is responsible for:

-   Selecting verified materials.
-   Routing materials to the correct distillation process.
-   Creating reusable knowledge candidates.
-   Sending results to template validation.

## Distillation Integration is not responsible for:

-   Source collection.
-   Source verification.
-   Final content generation.
-   Publishing.

------------------------------------------------------------------------

# Input

Source:

    source_material/verified/

Input example:

``` yaml
verified_material:

source_id:

verification_status:

verified_items:

limitations:
```

------------------------------------------------------------------------

# Routing Rules

## Content Distillation

Use when:

-   Learning writing structure.
-   Learning topic patterns.
-   Learning argument methods.
-   Learning audience adaptation.

Flow:

    verified_material

    ↓

    content_distillation.md

    ↓

    content_template candidate

    ↓

    template_library/content_templates

------------------------------------------------------------------------

## Visual Distillation

Use when:

-   Learning cover composition.
-   Learning visual style.
-   Learning prompt patterns.
-   Learning image structure.

Flow:

    verified_material

    ↓

    visual_distillation.md

    ↓

    visual_template candidate

    ↓

    template_library/visual_templates

------------------------------------------------------------------------

# Template Candidate Lifecycle

New distilled knowledge should not immediately become active.

Lifecycle:

    Candidate

    ↓

    Testing

    ↓

    Validated

    ↓

    Active Template

------------------------------------------------------------------------

# Metadata Requirements

Every generated template candidate should record:

``` yaml
template_metadata:

source_id:

created_time:

template_type:

distillation_method:

validation_status:
```

------------------------------------------------------------------------

# Feedback Connection

After template usage:

    Production

    ↓

    Review

    ↓

    template_feedback

    ↓

    template_library update

------------------------------------------------------------------------

# Complete Learning Loop

    External Content

    ↓

    Collection

    ↓

    Verification

    ↓

    Distillation

    ↓

    Template Candidate

    ↓

    Validation

    ↓

    Active Template

    ↓

    Production

    ↓

    Feedback

    ↓

    Optimization

------------------------------------------------------------------------

# Version

Version:

v1.0

Status:

Distillation Integration Design
