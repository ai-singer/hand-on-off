# Source Collector Interface Design v1.0

# Purpose

Define the implementation boundary between:

    Collection Logic

    ↓

    Normalization

    ↓

    Storage

    ↓

    Source Material Pipeline

The interface allows different platforms to share the same collection
workflow.

------------------------------------------------------------------------

# Architecture

    source_collector/


    ├── collectors/

    │   Platform-specific acquisition


    ├── processors/

    │   Data normalization


    ├── storage/

    │   Raw material persistence


    └── scheduler/

        Task triggering

------------------------------------------------------------------------

# Core Interface

## Collector Interface

Responsibility:

Acquire public external content.

Input:

``` yaml
source_target:

  platform:

  creator:

  url:

  collection_type:
```

Output:

``` yaml
collection_result:

  status:

  items:

  errors:
```

------------------------------------------------------------------------

# Source Record Schema

Every collected item must be converted into:

``` yaml
source_record:

  source_id:

  platform:

  creator:

  title:

  url:

  published_at:

  collected_at:

  content:

  metadata:

  status:
```

Field responsibility:

  Field          Purpose
  -------------- ------------------------
  source_id      Unique identifier
  platform       Source platform
  creator        Content creator
  title          Original title
  url            Original location
  published_at   Original publish time
  collected_at   Collection time
  content        Raw content
  metadata       Additional information
  status         Collection state

------------------------------------------------------------------------

# Processor Interface

Purpose:

Convert different platform formats into unified records.

Input:

    raw collection result

Output:

    normalized source_record

Responsibilities:

-   Clean metadata.
-   Normalize fields.
-   Extract basic structure.
-   Preserve source traceability.

------------------------------------------------------------------------

# Storage Interface

Purpose:

Save collected materials.

Input:

    source_record

Output:

    source_material/raw/

Rules:

-   Never overwrite existing source records.
-   Detect duplicates before saving.
-   Preserve original content.

------------------------------------------------------------------------

# Scheduler Interface

Purpose:

Trigger collection tasks.

Example:

``` yaml
schedule_task:

name:

nightly_source_collection


time:

02:00


targets:

- creator_a

- creator_b
```

Scheduler should only trigger collection.

It does not process content.

------------------------------------------------------------------------

# Error Handling

Collection failures:

``` yaml
collection_error:

source:

error_type:

message:

retry_count:

status:
```

Rules:

-   Temporary errors may retry.
-   Permanent errors must be recorded.
-   One failed source must not stop other tasks.

------------------------------------------------------------------------

# Complete Flow

    Scheduler

    ↓

    Collector

    ↓

    Processor

    ↓

    Storage

    ↓

    source_material/raw

    ↓

    Extraction Pipeline

------------------------------------------------------------------------

# Version

Version:

v1.0

Status:

Source Collector Interface Definition
