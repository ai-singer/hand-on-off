# Source Extraction Pipeline Design v1.0

# Purpose

Define how collected raw materials are transformed into structured
extraction results.

The extraction pipeline connects:

    source_material/raw

    ↓

    Extraction Pipeline

    ↓

    source_material/extracted

    ↓

    Verification Pipeline

------------------------------------------------------------------------

# Position

Complete flow:

    Source Collector

    ↓

    source_material/raw

    ↓

    Extraction

    ↓

    source_material/extracted

    ↓

    Verification

    ↓

    Distillation

    ↓

    template_library

------------------------------------------------------------------------

# Responsibility Boundary

## Extraction Pipeline is responsible for:

-   Reading raw source materials.
-   Extracting structured information.
-   Identifying content structure.
-   Preparing material for verification and distillation.

## Extraction Pipeline is not responsible for:

-   Deciding content quality.
-   Creating final articles.
-   Creating templates.
-   Publishing content.

------------------------------------------------------------------------

# Input

Location:

    source_material/raw/

Input examples:

-   Video transcript.
-   Article content.
-   Creator post.
-   Metadata records.

------------------------------------------------------------------------

# Output

Location:

    source_material/extracted/

Output schema:

``` yaml
extracted_material:

  source_id:

  title:

  creator:

  platform:

  topic:

  timeline:

  key_events:

  technical_points:

  content_structure:

  audience:

  emotional_points:

  possible_angles:
```

------------------------------------------------------------------------

# Extraction Steps

## Step 1: Load Raw Material

Read:

-   Original content.
-   Metadata.
-   Source information.

------------------------------------------------------------------------

## Step 2: Content Structure Extraction

Extract:

-   Opening hook.
-   Main sections.
-   Argument flow.
-   Story structure.

------------------------------------------------------------------------

## Step 3: Fact Element Extraction

Identify:

-   Events.
-   Dates.
-   Technical details.
-   Project information.

Important:

Extraction preserves information.

It does not determine truth.

------------------------------------------------------------------------

## Step 4: Narrative Element Extraction

For story-based content:

Extract:

-   Conflict.
-   Challenge.
-   Solution.
-   Result.
-   Emotional transition.

------------------------------------------------------------------------

# Traceability Rules

Every extracted item must keep:

-   Source ID.
-   Original location reference.
-   Extraction timestamp.

------------------------------------------------------------------------

# Error Handling

Extraction failure:

Record:

``` yaml
extraction_error:

  source_id:

  error_type:

  message:

  status:
```

Rules:

-   Failed extraction does not delete raw material.
-   Failed records can be retried.
-   Original sources remain unchanged.

------------------------------------------------------------------------

# Complete Flow

    source_material/raw

    ↓

    Extraction Pipeline

    ↓

    source_material/extracted

    ↓

    Verification Pipeline

    ↓

    content_distillation

------------------------------------------------------------------------

# Version

Version:

v1.0

Status:

Source Extraction Pipeline Design
