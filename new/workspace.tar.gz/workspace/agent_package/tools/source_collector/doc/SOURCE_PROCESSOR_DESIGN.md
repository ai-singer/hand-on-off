# Source Processor Design v1.0

# Purpose

Define the normalization and preprocessing layer between platform
collectors and source material storage.

The processor converts platform-specific collection results into unified
source records.

------------------------------------------------------------------------

# Position

    Platform Collector

    ↓

    Processor

    ↓

    Storage

    ↓

    source_material/raw

------------------------------------------------------------------------

# Responsibility Boundary

## Processor is responsible for:

-   Data normalization.
-   Field mapping.
-   Metadata cleanup.
-   Basic content preprocessing.
-   Source traceability preservation.

## Processor is not responsible for:

-   Content judgment.
-   Template extraction.
-   Article generation.
-   Final verification decisions.

------------------------------------------------------------------------

# Input

Input:

    collection_result

From:

    source_collector/collectors/

Example:

``` yaml
collection_result:

  platform:

  items:

  errors:
```

------------------------------------------------------------------------

# Output

Output:

``` yaml
source_record:

  source_id:

  platform:

  creator:

  title:

  url:

  published_at:

  collected_at:

  content:

  metadata:

  status:
```

------------------------------------------------------------------------

# Processing Pipeline

## Step 1: Validate Input

Check:

-   Required fields exist.
-   Source platform is known.
-   Content identity is available.

------------------------------------------------------------------------

## Step 2: Normalize Fields

Convert platform-specific fields:

Example:

    video_name

    ↓

    title

    author_name

    ↓

    creator

------------------------------------------------------------------------

## Step 3: Clean Content

Operations:

-   Remove unnecessary formatting.
-   Preserve original meaning.
-   Keep source references.

Rules:

Original content should not be rewritten during this stage.

------------------------------------------------------------------------

## Step 4: Generate Metadata

Possible metadata:

``` yaml
metadata:

  content_type:

  language:

  tags:

  source_version:
```

------------------------------------------------------------------------

# Traceability Rules

Every processed record must keep:

-   Original URL.
-   Source ID.
-   Creator identity.
-   Collection timestamp.

------------------------------------------------------------------------

# Error Handling

Processor errors:

``` yaml
processor_error:

  source_id:

  error_type:

  message:

  status:
```

Rules:

-   Invalid records are rejected.
-   Processing failures are logged.
-   Other records continue processing.

------------------------------------------------------------------------

# Complete Flow

    source_targets.yaml

    ↓

    Collector

    ↓

    collection_result

    ↓

    Processor

    ↓

    source_record

    ↓

    source_material/raw

------------------------------------------------------------------------

# Version

Version:

v1.0

Status:

Source Processor Design
