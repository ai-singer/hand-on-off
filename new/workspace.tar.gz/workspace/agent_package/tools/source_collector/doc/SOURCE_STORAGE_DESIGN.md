# Source Storage Design v1.0

# Purpose

Define how normalized source records are persisted into the source
material layer.

The storage layer connects:

    Processor

    ↓

    Storage

    ↓

    source_material/raw

------------------------------------------------------------------------

# Position

Complete flow:

    External Source

    ↓

    Collector

    ↓

    Processor

    ↓

    Storage

    ↓

    source_material/raw

    ↓

    Extraction Pipeline

------------------------------------------------------------------------

# Responsibility Boundary

## Storage is responsible for:

-   Saving source records.
-   File organization.
-   Duplicate protection.
-   Record version management.
-   Storage metadata management.

## Storage is not responsible for:

-   Data collection.
-   Content interpretation.
-   Verification.
-   Template generation.

------------------------------------------------------------------------

# Storage Location

Output:

    source_material/raw/

Structure:

    source_material/

    └── raw/

        └── {platform}/

            └── {creator}/

                └── {year}/

                    └── {source_id}/

Example:

    source_material/raw/

    └── bilibili/

        └── ysjf/

            └── 2026/

                └── BVxxxx/

------------------------------------------------------------------------

# File Format

Recommended storage:

    metadata.json

    content.md

Purpose:

## metadata.json

Stores structured information.

Example fields:

``` yaml
source_id:

platform:

creator:

title:

url:

published_at:

collected_at:

content_hash:

status:
```

## content.md

Stores original collected content.

Rules:

-   Preserve source information.
-   Do not rewrite original meaning.
-   Keep traceability.

------------------------------------------------------------------------

# Duplicate Detection

Before saving:

Check:

-   source_id.
-   URL.
-   Content hash.

If duplicate:

    skip storage

    ↓

    record duplicate event

------------------------------------------------------------------------

# Version Management

When source changes:

Create a new version.

Example:

    BVxxxx/

    ├── v1/

    │   ├── metadata.json

    │   └── content.md


    └── v2/

        ├── metadata.json

        └── content.md

------------------------------------------------------------------------

# Storage Status

Records may have:

    collected

    stored

    failed

    duplicate

    archived

------------------------------------------------------------------------

# Error Handling

Storage errors:

Record:

-   source_id.
-   error type.
-   timestamp.
-   retry status.

Rules:

-   Storage failure should not lose collection information.
-   Failed records should be recoverable.

------------------------------------------------------------------------

# Complete Flow

    source_targets.yaml

    ↓

    Scheduler

    ↓

    Collector

    ↓

    Processor

    ↓

    Storage

    ↓

    source_material/raw

    ↓

    Extraction

------------------------------------------------------------------------

# Version

Version:

v1.0

Status:

Source Storage Design
