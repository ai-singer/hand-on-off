# Source Verification Pipeline Design v1.0

# Purpose

Define how extracted materials are verified before entering distillation
and template learning.

The verification pipeline connects:

    source_material/extracted

    ↓

    Verification Pipeline

    ↓

    source_material/verified

    ↓

    Distillation

------------------------------------------------------------------------

# Position

Complete flow:

    External Source

    ↓

    source_collector

    ↓

    source_material/raw

    ↓

    Extraction

    ↓

    source_material/extracted

    ↓

    Verification

    ↓

    source_material/verified

    ↓

    content_distillation

    ↓

    template_library

------------------------------------------------------------------------

# Responsibility Boundary

## Verification Pipeline is responsible for:

-   Checking extracted material consistency.
-   Recording verification status.
-   Identifying uncertainty.
-   Preventing unverified information from entering learning.

## Verification Pipeline is not responsible for:

-   Writing content.
-   Creating templates.
-   Making subjective quality judgments.
-   Replacing original sources.

------------------------------------------------------------------------

# Input

Location:

    source_material/extracted/

Input:

``` yaml
extracted_material:

  source_id:

  extracted_items:

  source_reference:
```

------------------------------------------------------------------------

# Output

Location:

    source_material/verified/

Output:

``` yaml
verified_material:

  source_id:

  verification_status:

  verified_items:

  uncertain_items:

  rejected_items:

  limitations:

  verification_notes:
```

------------------------------------------------------------------------

# Verification Process

## Step 1: Source Trace Check

Verify:

-   Source ID exists.
-   Original URL exists.
-   Extracted information maps to original material.

------------------------------------------------------------------------

## Step 2: Content Consistency Check

Check:

-   Extraction matches source.
-   Important context is preserved.
-   No unsupported additions are introduced.

------------------------------------------------------------------------

## Step 3: Claim Classification

Classify extracted information:

    verified

    ↓

    uncertain

    ↓

    unsupported

Rules:

-   Verified information can enter distillation.
-   Uncertain information must carry limitations.
-   Unsupported information must not become learning material.

------------------------------------------------------------------------

# Verification Status

Possible states:

``` yaml
status:

  verified

  partial

  rejected
```

------------------------------------------------------------------------

# Error Handling

Verification failure:

Record:

``` yaml
verification_error:

  source_id:

  error_type:

  message:

  status:
```

Rules:

-   Never delete raw or extracted data.
-   Preserve failed verification records.
-   Allow later re-verification.

------------------------------------------------------------------------

# Integration With Distillation

Only:

    source_material/verified/

can enter:

    content_distillation

    visual_distillation

This prevents:

-   Incorrect facts.
-   Unsupported claims.
-   Low-quality patterns.

------------------------------------------------------------------------

# Version

Version:

v1.0

Status:

Source Verification Pipeline Design
