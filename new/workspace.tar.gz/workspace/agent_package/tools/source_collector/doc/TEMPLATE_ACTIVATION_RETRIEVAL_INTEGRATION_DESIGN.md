# Template Activation & Retrieval Integration Design v1.0

# Purpose

Define how validated templates become usable production knowledge and
how generation workflows retrieve them.

The integration connects:

    active_template

    ↓

    template_retrieval

    ↓

    content_generation / visual_generation

------------------------------------------------------------------------

# Position

Complete flow:

    source_material/verified

    ↓

    Distillation

    ↓

    Template Candidate

    ↓

    Validation

    ↓

    Active Template

    ↓

    Retrieval

    ↓

    Production

    ↓

    Feedback

------------------------------------------------------------------------

# Responsibility Boundary

## Template Activation & Retrieval is responsible for:

-   Activating validated templates.
-   Indexing available templates.
-   Matching templates to production tasks.
-   Providing reusable patterns.

## Template Activation & Retrieval is not responsible for:

-   Creating templates.
-   Validating source materials.
-   Replacing content strategy.
-   Bypassing review rules.

------------------------------------------------------------------------

# Activation Flow

    validated_template

    ↓

    activation_check

    ↓

    active_template

    ↓

    template_library

Activation requirements:

-   Validation status is complete.
-   Source trace exists.
-   Usage conditions exist.
-   Limitations exist.

------------------------------------------------------------------------

# Template Storage

Active templates:

    template_library/

    ├── content_templates/

    ├── visual_templates/

    └── metadata/

------------------------------------------------------------------------

# Retrieval Flow

Input:

``` yaml
retrieval_request:

  task_type:

  content_category:

  target_audience:

  style_requirement:
```

Process:

    Production Task

    ↓

    Retrieve Matching Templates

    ↓

    Apply Template Constraints

    ↓

    Generate Output

------------------------------------------------------------------------

# Retrieval Rules

Templates should be selected by:

-   Template type.
-   Applicable scenario.
-   Audience match.
-   Historical performance.
-   Known limitations.

Templates should not:

-   Override identity rules.
-   Override review rules.
-   Replace source verification.

------------------------------------------------------------------------

# Feedback Integration

After production:

    Generated Content

    ↓

    Review

    ↓

    Feedback

    ↓

    Template Performance Update

    ↓

    Retrieval Optimization

------------------------------------------------------------------------

# Complete Knowledge Runtime Loop

    Collection

    ↓

    Verification

    ↓

    Distillation

    ↓

    Validation

    ↓

    Activation

    ↓

    Retrieval

    ↓

    Production

    ↓

    Feedback

    ↓

    Optimization

------------------------------------------------------------------------

# Version

Version:

v1.0

Status:

Template Activation & Retrieval Integration Design
