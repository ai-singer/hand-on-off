# Template Candidate Schema Design v1.0

# Purpose

Define the unified structure of knowledge candidates generated from
distillation.

The schema connects:

    Distillation

    ↓

    Template Candidate

    ↓

    Validation

    ↓

    template_library

------------------------------------------------------------------------

# Position

Complete flow:

    source_material/verified

    ↓

    content_distillation

    +

    visual_distillation

    ↓

    template_candidate

    ↓

    validation

    ↓

    active_template

------------------------------------------------------------------------

# Responsibility Boundary

## Template Candidate Schema is responsible for:

-   Defining reusable knowledge structure.
-   Preserving source traceability.
-   Recording validation status.
-   Preparing candidates for template activation.

## Template Candidate Schema is not responsible for:

-   Creating final content.
-   Deciding whether a template is useful.
-   Replacing review rules.
-   Directly modifying active templates.

------------------------------------------------------------------------

# Candidate Types

Supported types:

## Content Template Candidate

Used for:

-   Writing structures.
-   Story patterns.
-   Argument frameworks.
-   Audience adaptation patterns.

Location after validation:

    template_library/content_templates/

------------------------------------------------------------------------

## Visual Template Candidate

Used for:

-   Cover composition.
-   Visual style.
-   Prompt patterns.
-   Image generation structures.

Location after validation:

    template_library/visual_templates/

------------------------------------------------------------------------

# Schema

Example:

``` yaml
template_candidate:

  candidate_id:

  template_type:

  title:

  description:

  source_reference:

  extracted_pattern:

  usage_condition:

  limitations:

  validation_status:

  created_at:
```

------------------------------------------------------------------------

# Field Definition

  Field               Purpose
  ------------------- -----------------------------
  candidate_id        Unique candidate identifier
  template_type       Content or visual template
  title               Candidate name
  description         Pattern explanation
  source_reference    Original verified source
  extracted_pattern   Reusable knowledge
  usage_condition     When to apply
  limitations         When not to apply
  validation_status   Candidate lifecycle state
  created_at          Creation timestamp

------------------------------------------------------------------------

# Validation Status

Lifecycle:

    candidate

    ↓

    testing

    ↓

    validated

    ↓

    active

States:

-   candidate: Newly generated.
-   testing: Under evaluation.
-   validated: Approved for use.
-   active: Available in template retrieval.

------------------------------------------------------------------------

# Traceability Rules

Every candidate must preserve:

-   Original source ID.
-   Distillation source.
-   Creation time.
-   Validation history.

------------------------------------------------------------------------

# Activation Rules

A candidate can become active only when:

-   Source is verified.
-   Pattern is reproducible.
-   Validation is completed.
-   Limitations are recorded.

------------------------------------------------------------------------

# Complete Knowledge Loop

    External Source

    ↓

    Collection

    ↓

    Verification

    ↓

    Distillation

    ↓

    Template Candidate

    ↓

    Validation

    ↓

    Template Library

    ↓

    Production

    ↓

    Feedback

------------------------------------------------------------------------

# Version

Version:

v1.0

Status:

Template Candidate Schema Design
