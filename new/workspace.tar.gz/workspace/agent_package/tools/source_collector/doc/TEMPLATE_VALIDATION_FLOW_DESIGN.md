# Template Validation Flow Design v1.0

# Purpose

Define how template candidates are tested, validated, and activated
before entering the active template library.

The validation flow connects:

    template_candidate

    ↓

    Testing

    ↓

    Validation

    ↓

    template_library

------------------------------------------------------------------------

# Position

Complete flow:

    source_material/verified

    ↓

    Distillation

    ↓

    template_candidate

    ↓

    Validation Flow

    ↓

    active_template

    ↓

    Production

    ↓

    Feedback

------------------------------------------------------------------------

# Responsibility Boundary

## Validation Flow is responsible for:

-   Testing template candidates.
-   Recording validation results.
-   Controlling activation status.
-   Preserving validation history.

## Validation Flow is not responsible for:

-   Creating candidates.
-   Collecting sources.
-   Rewriting templates.
-   Replacing review rules.

------------------------------------------------------------------------

# Validation Lifecycle

    candidate

    ↓

    testing

    ↓

    validated

    ↓

    active

------------------------------------------------------------------------

# Stage 1: Candidate

Status:

    candidate

Meaning:

-   Generated from verified source.
-   Not available for production use.
-   Waiting for validation.

Required information:

-   Source reference.
-   Pattern description.
-   Usage conditions.
-   Limitations.

------------------------------------------------------------------------

# Stage 2: Testing

Status:

    testing

Purpose:

Evaluate whether the pattern can be reused.

Checks:

-   Pattern reproducibility.
-   Output consistency.
-   Usage boundary.
-   Failure cases.

Testing record:

``` yaml
validation_record:

  candidate_id:

  test_case:

  result:

  issues:

  timestamp:
```

------------------------------------------------------------------------

# Stage 3: Validated

Status:

    validated

Requirements:

-   Testing completed.
-   Failure conditions understood.
-   Usage rules documented.

Validated templates can enter activation queue.

------------------------------------------------------------------------

# Stage 4: Active

Status:

    active

Meaning:

-   Available for template retrieval.
-   Can influence generation workflow.
-   Must continue receiving feedback.

------------------------------------------------------------------------

# Failure Handling

Possible results:

## Validation Failed

Action:

    candidate

    ↓

    rejected

Rules:

-   Keep validation history.
-   Do not activate.
-   Allow future revision.

------------------------------------------------------------------------

# Template Feedback Loop

After production:

    Active Template

    ↓

    Production Result

    ↓

    Review Feedback

    ↓

    Template Update

    ↓

    New Validation

------------------------------------------------------------------------

# Activation Rules

A template can become active only when:

-   Source trace exists.
-   Validation completed.
-   Limitations recorded.
-   Failure cases documented.

------------------------------------------------------------------------

# Complete Knowledge Governance Loop

    Collection

    ↓

    Verification

    ↓

    Distillation

    ↓

    Candidate

    ↓

    Validation

    ↓

    Active Template

    ↓

    Production

    ↓

    Feedback

    ↓

    Optimization

------------------------------------------------------------------------

# Version

Version:

v1.0

Status:

Template Validation Flow Design
