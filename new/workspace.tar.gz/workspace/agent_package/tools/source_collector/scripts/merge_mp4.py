"""
scripts/merge_mp4.py

纯 Python DASH MP4 合并工具

将视频流 (video-only DASH MP4) 和音频流 (audio-only DASH MP4/m4a) 合并为
单个包含视频 + 音频两个 track 的 MP4 文件。

不依赖 ffmpeg / ffprobe / 任何第三方库。

原理：
  1. 从视频文件提取 ftyp、moov（含视频 trak）
  2. 从音频文件提取 moov（含音频 trak）
  3. 将音频 trak 注入视频 moov，更新 mvhd.next_track_id
  4. 将视频 + 音频的所有 moof/mdat segment 按原始顺序交错写入

限制：
  - 不对 edit list (elst) 做偏移修正
  - 不修改 tfhd base_data_offset（因为 moof/mdat 是自描述的）
  - 适用于 Bilibili DASH fragmented MP4（ftyp+moov+sidx+moof/mdat...）
"""

from __future__ import annotations

import struct
import sys
import os


# ---------------------------------------------------------------------------
# 基础 box 读取
# ---------------------------------------------------------------------------

def iter_boxes(data: bytes, start: int = 0, end: int = -1):
    """迭代 box（name, offset, size, payload_offset）"""
    if end < 0:
        end = len(data)
    pos = start
    while pos < end:
        if pos + 8 > end:
            break
        size = struct.unpack_from('>I', data, pos)[0]
        name = data[pos+4:pos+8].decode('latin-1')
        if size == 0:
            size = end - pos  # 延伸到文件末尾
        if size < 8:
            break
        yield name, pos, size, pos + 8
        pos += size


def find_box(data: bytes, name: str, start: int = 0, end: int = -1):
    for n, off, size, pay in iter_boxes(data, start, end):
        if n == name:
            return off, size, pay
    return None, None, None


# ---------------------------------------------------------------------------
# 读取整个文件
# ---------------------------------------------------------------------------

def read_file(path: str) -> bytes:
    with open(path, 'rb') as f:
        return f.read()


# ---------------------------------------------------------------------------
# moov 操作
# ---------------------------------------------------------------------------

def get_box(data: bytes, name: str, parent_start: int = 0, parent_size: int = -1) -> bytes | None:
    """提取指定名称的 box 字节（含 box 头）"""
    end = (parent_start + parent_size) if parent_size > 0 else len(data)
    off, size, _ = find_box(data, name, parent_start, end)
    if off is None:
        return None
    return data[off: off + size]


def patch_box_size(box: bytes) -> bytes:
    """用实际长度更新 box 头部 4 字节 size"""
    return struct.pack('>I', len(box)) + box[4:]


def extract_trak(moov_data: bytes) -> bytes | None:
    """从 moov 字节中提取第一个 trak box"""
    # moov_data 包含完整 moov box（含 8 字节头）
    moov_inner_start = 8
    moov_inner_end = len(moov_data)
    off, size, _ = find_box(moov_data, 'trak', moov_inner_start, moov_inner_end)
    if off is None:
        return None
    return moov_data[off: off + size]


def patch_tkhd_track_id(trak: bytes, new_id: int) -> bytes:
    """将 trak 内 tkhd 的 track_id 改为 new_id"""
    off, size, pay = find_box(trak, 'tkhd')
    if off is None:
        return trak
    version = trak[pay]
    if version == 1:
        # creation_time(8) + modification_time(8) + track_id(4)
        tid_off = pay + 1 + 3 + 8 + 8
    else:
        # creation_time(4) + modification_time(4) + track_id(4)
        tid_off = pay + 1 + 3 + 4 + 4
    return trak[:tid_off] + struct.pack('>I', new_id) + trak[tid_off+4:]


def get_mvhd_next_track_id(moov: bytes) -> int:
    """读取 mvhd.next_track_id"""
    off, size, pay = find_box(moov, 'mvhd', 8)
    if off is None:
        return 3
    version = moov[pay]
    if version == 1:
        # 8+8+4+8+8 = 36 bytes before next_track_id
        ntid_off = pay + 1 + 3 + 8 + 8 + 4 + 8 + 8 + 4 + 2 + 2 + 4*9
    else:
        # 4+4+4+4+4 = 20 bytes, then rate(4)+vol(2)+reserv(10)+matrix(36)+pre(24)+next_track_id(4)
        ntid_off = pay + 1 + 3 + 4 + 4 + 4 + 4 + 4 + 2 + 10 + 36 + 24
    return struct.unpack_from('>I', moov, ntid_off)[0]


def patch_mvhd_next_track_id(moov: bytes, new_val: int) -> bytes:
    """更新 mvhd.next_track_id"""
    off, size, pay = find_box(moov, 'mvhd', 8)
    if off is None:
        return moov
    version = moov[pay]
    if version == 1:
        ntid_off = pay + 1 + 3 + 8 + 8 + 4 + 8 + 8 + 4 + 2 + 2 + 4*9
    else:
        ntid_off = pay + 1 + 3 + 4 + 4 + 4 + 4 + 4 + 2 + 10 + 36 + 24
    return moov[:ntid_off] + struct.pack('>I', new_val) + moov[ntid_off+4:]


def merge_moov(video_moov: bytes, audio_trak: bytes) -> bytes:
    """
    将 audio_trak 插入 video_moov，返回新的 moov bytes。
    audio trak 的 track_id 设为 2，mvhd.next_track_id 设为 3。
    """
    # 修正音频 trak 的 track_id 为 2
    audio_trak_patched = patch_tkhd_track_id(audio_trak, 2)

    # 在 video_moov 末尾（去掉最后 0 字节前）插入 audio_trak
    # moov = [size(4)][moov(4)][...children...]
    moov_inner = video_moov[8:]  # 去掉 moov box 头
    new_inner = moov_inner + audio_trak_patched
    new_moov = b'xxxx' + b'moov' + new_inner
    new_moov = patch_box_size(new_moov)

    # 更新 mvhd.next_track_id = 3
    new_moov = patch_mvhd_next_track_id(new_moov, 3)

    return new_moov


# ---------------------------------------------------------------------------
# 提取 moof/mdat segments
# ---------------------------------------------------------------------------

def extract_segments(data: bytes) -> bytes:
    """提取文件中所有 moof 和 mdat box 的原始字节（按顺序）"""
    result = bytearray()
    for name, off, size, _ in iter_boxes(data):
        if name in ('moof', 'mdat'):
            result += data[off: off + size]
    return bytes(result)


# ---------------------------------------------------------------------------
# 主合并函数
# ---------------------------------------------------------------------------

def merge(video_path: str, audio_path: str, output_path: str) -> None:
    print(f"读取视频: {video_path} ({os.path.getsize(video_path):,} bytes)")
    video_data = read_file(video_path)

    print(f"读取音频: {audio_path} ({os.path.getsize(audio_path):,} bytes)")
    audio_data = read_file(audio_path)

    # 提取 ftyp（来自视频）
    ftyp = get_box(video_data, 'ftyp')
    if ftyp is None:
        raise ValueError("视频文件缺少 ftyp box")
    print(f"ftyp: {len(ftyp)} bytes")

    # 提取 video moov
    v_moov = get_box(video_data, 'moov')
    if v_moov is None:
        raise ValueError("视频文件缺少 moov box")
    print(f"video moov: {len(v_moov)} bytes")

    # 提取 audio trak（从 audio moov 中）
    a_moov = get_box(audio_data, 'moov')
    if a_moov is None:
        raise ValueError("音频文件缺少 moov box")
    a_trak = extract_trak(a_moov)
    if a_trak is None:
        raise ValueError("音频 moov 中找不到 trak box")
    print(f"audio trak: {len(a_trak)} bytes")

    # 合并 moov
    merged_moov = merge_moov(v_moov, a_trak)
    print(f"merged moov: {len(merged_moov)} bytes")

    # 提取 segments
    v_segs = extract_segments(video_data)
    a_segs = extract_segments(audio_data)
    print(f"video segments: {len(v_segs):,} bytes")
    print(f"audio segments: {len(a_segs):,} bytes")

    # 写入输出
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    with open(output_path, 'wb') as f:
        f.write(ftyp)
        f.write(merged_moov)
        f.write(v_segs)
        f.write(a_segs)

    out_size = os.path.getsize(output_path)
    print(f"\n✅ 合并完成: {output_path}")
    print(f"   输出大小: {out_size:,} bytes ({out_size/1024/1024:.1f} MB)")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == '__main__':
    if len(sys.argv) != 4:
        print("用法: python3 merge_mp4.py <video.mp4> <audio.m4a> <output.mp4>")
        sys.exit(1)
    merge(sys.argv[1], sys.argv[2], sys.argv[3])
