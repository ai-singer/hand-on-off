#!/usr/bin/env python3
"""
scripts/run_audio_extraction.py

Article 005 Audio Extraction — Production Path

用法:
    python3 scripts/run_audio_extraction.py

输入:  sources/bilibili/ysjf/space_camera_project/
输出:  sources/bilibili/ysjf/space_camera_project/extracted/audio/audio.wav
       sources/bilibili/ysjf/space_camera_project/extracted/audio_metadata.json
"""

import os
import sys
import shutil

# 确保 source_collector 根目录在 sys.path
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from services.audio_extraction import extract_audio, FfmpegBackend, MockBackend

SOURCE_ROOT = os.path.join(
    ROOT,
    "sources", "bilibili", "ysjf", "space_camera_project"
)

def main():
    print("=" * 60)
    print("Article 005 — Audio Extraction Layer")
    print("=" * 60)

    # Step 1: 检查 ffmpeg 状态
    ffmpeg_path = shutil.which("ffmpeg") or "/home/node/.local/bin/ffmpeg"
    ffmpeg_available = os.path.isfile(ffmpeg_path) and os.access(ffmpeg_path, os.X_OK)

    if ffmpeg_available:
        print(f"[ffmpeg] AVAILABLE: {ffmpeg_path}")
        backend = FfmpegBackend()
        backend_name = "FfmpegBackend"
    else:
        print(f"[ffmpeg] FFMPEG_UNAVAILABLE — using MockBackend")
        backend = MockBackend()
        backend_name = "MockBackend"

    print(f"[backend] {backend_name}")
    print(f"[source_root] {SOURCE_ROOT}")
    print()

    # Step 2: 执行提取
    try:
        result = extract_audio(SOURCE_ROOT, backend=backend)
    except Exception as e:
        print(f"[ERROR] Audio extraction failed: {e}")
        sys.exit(1)

    # Step 3: 验证输出
    wav_abs = os.path.join(SOURCE_ROOT, result.output_audio)
    meta_abs = os.path.join(SOURCE_ROOT, "extracted", "audio_metadata.json")

    wav_ok = os.path.isfile(wav_abs)
    meta_ok = os.path.isfile(meta_abs)

    print("[results]")
    print(f"  source_id:        {result.source_id}")
    print(f"  input_audio:      {result.input_audio}")
    print(f"  output_audio:     {result.output_audio}")
    print(f"  duration_seconds: {result.duration_seconds}")
    print(f"  sample_rate:      {result.sample_rate} Hz")
    print(f"  backend_used:     {result.backend_used}")
    print()
    print("[output files]")
    print(f"  audio.wav:            {'✅' if wav_ok else '❌'} {wav_abs}")
    print(f"  audio_metadata.json:  {'✅' if meta_ok else '❌'} {meta_abs}")

    if wav_ok:
        wav_size = os.path.getsize(wav_abs)
        print(f"  audio.wav size:       {wav_size:,} bytes ({wav_size/1024:.1f} KB)")

    if not wav_ok or not meta_ok:
        print("\n[ERROR] Output files missing")
        sys.exit(1)

    print()
    print("✅ Audio Extraction COMPLETE")
    print()
    print("[next dependency]")
    print("  ASR Layer — transcript extraction from audio.wav")
    print("  MISSING: extracted/transcript.json")

if __name__ == "__main__":
    main()
