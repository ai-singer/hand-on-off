#!/bin/bash
cd /home/node/.openclaw/workspace/source_collector
python3 scripts/run_audio_extraction.py
