#!/usr/bin/env python3
"""
scripts/run_frame_analysis_openclaw.py

OpenClaw 原生视觉分析生产脚本

职责：
- 逐帧读取 extracted/frames/*.jpg
- 通过 read tool（模型原生图片理解）分析每一帧
- 收集所有帧的观察结果
- 调用 frame_analysis.build_result_from_dicts() 持久化

本脚本不是自动化 CLI，而是给 Agent 执行的生产流程描述。
实际执行时由 Agent 调用 read tool 读取图片，再解析 JSON 输出。

执行方式：
  Agent 直接运行此脚本，逐帧分析并收集结果。

输出：
  extracted/frame_observations.json
  - backend_used: "openclaw_vision"
"""

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.frame_analysis import build_result_from_dicts

SOURCE_ROOT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "sources", "bilibili", "ysjf", "space_camera_project"
)

FRAME_META_PATH = os.path.join(SOURCE_ROOT, "extracted", "frame_metadata.json")

VISION_PROMPT = """请分析这张图片。
不要读取文件名中的任何信息。
只根据图片内容分析。

严格输出以下 JSON，不要添加任何其他文字：

{
  "objects": [],
  "scene": "",
  "observable_facts": [],
  "uncertain_points": []
}

要求：
- objects：图片中实际可见的物体列表
- scene：当前视觉场景的简短描述
- observable_facts：图片直接证明的信息（不允许推测）
- uncertain_points：无法从单张图片确定的信息
"""


def load_frame_metadata():
    with open(FRAME_META_PATH, encoding="utf-8") as f:
        return json.load(f)


def parse_vision_output(raw_output: str) -> dict:
    """
    从模型输出中提取 JSON。
    支持 ```json ... ``` 或裸 JSON 格式。
    """
    import re
    # 尝试提取 ```json ... ``` 块
    match = re.search(r"```(?:json)?\s*([\s\S]+?)\s*```", raw_output)
    if match:
        return json.loads(match.group(1))
    # 尝试直接解析
    return json.loads(raw_output.strip())


def build_observation_entry(frame_record: dict, vision_result: dict) -> dict:
    return {
        "frame_id": frame_record["index"],
        "timestamp_sec": frame_record["timestamp_sec"],
        "filename": frame_record["filename"],
        "filepath": frame_record["filepath"],
        "objects": vision_result.get("objects", []),
        "scene": vision_result.get("scene", ""),
        "observable_facts": vision_result.get("observable_facts", []),
        "uncertain_points": vision_result.get("uncertain_points", []),
    }


if __name__ == "__main__":
    meta = load_frame_metadata()
    frames = meta["frames"]

    print(f"[Frame Analysis] source_root: {SOURCE_ROOT}")
    print(f"[Frame Analysis] total frames: {len(frames)}")
    print(f"[Frame Analysis] backend: openclaw_vision")
    print()

    # 此处由 Agent 逐帧读取图片并填充 observations_list
    # 示例：Agent 应对每一帧执行：
    #   1. read(frame_path)  → 获取图片
    #   2. 按 VISION_PROMPT 分析
    #   3. parse_vision_output(output) → vision_result
    #   4. build_observation_entry(frame_record, vision_result)

    # 以下为占位，实际由 Agent 执行时替换
    print("[Frame Analysis] 请由 Agent 逐帧执行视觉分析后调用 build_result_from_dicts()")
    print(f"[Frame Analysis] VISION_PROMPT:\n{VISION_PROMPT}")
