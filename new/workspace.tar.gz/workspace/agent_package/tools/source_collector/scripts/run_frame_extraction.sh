#!/bin/bash
cd /home/node/.openclaw/workspace/source_collector
python3 -c "
import sys, os
sys.path.insert(0, '.')
from services.frame_extraction import extract_frames

SOURCE_ROOT = 'sources/bilibili/ysjf/space_camera_project'
result = extract_frames(SOURCE_ROOT, interval_sec=10.0)

print('=' * 60)
print('Article 005 — Frame Extraction Layer')
print('=' * 60)
print(f'backend_used:     {result.backend_used}')
print(f'input_video:      {result.input_video}')
print(f'interval_sec:     {result.interval_sec}')
print(f'duration_seconds: {result.duration_seconds}')
print(f'total_frames:     {result.total_frames}')
print()
print('Sample frames (first 3 / last 3):')
for fr in result.frames[:3]:
    print(f'  [{fr.index:04d}] t={fr.timestamp_sec:7.1f}s  {fr.filename}')
if len(result.frames) > 6:
    print('  ...')
for fr in result.frames[-3:]:
    print(f'  [{fr.index:04d}] t={fr.timestamp_sec:7.1f}s  {fr.filename}')
print()

meta_path = os.path.join(SOURCE_ROOT, 'extracted', 'frame_metadata.json')
print(f'frame_metadata.json: {\"EXISTS\" if os.path.isfile(meta_path) else \"MISSING\"}')
frames_dir = os.path.join(SOURCE_ROOT, 'extracted', 'frames')
jpg_count = len([f for f in os.listdir(frames_dir) if f.endswith('.jpg')])
print(f'frames/*.jpg count:  {jpg_count}')
print()
print('✅ Frame Extraction COMPLETE')
print()
print('[next dependency]')
print('  Content Extraction Layer')
print('  INPUTS READY: audio_metadata.json + frame_metadata.json')
print('  OPTIONAL:     transcript.json (ASR = OPTIONAL_DEPENDENCY)')
"
