#!/bin/bash
# Frame Extraction — Production Path
# 输入: raw/camera_to_space.f30077.mp4 (video-only stream, H.265, 867s)
# 输出: extracted/frames/frame_*.jpg + extracted/frame_metadata.json
# 间隔: 10 秒一帧 → ~87 帧

FFMPEG="/home/node/.local/bin/ffmpeg"
FFPROBE="/home/node/.local/bin/ffprobe"
SOURCE_ROOT="/home/node/.openclaw/workspace/source_collector/sources/bilibili/ysjf/space_camera_project"
VIDEO="$SOURCE_ROOT/raw/camera_to_space.f30077.mp4"
FRAMES_DIR="$SOURCE_ROOT/extracted/frames"
INTERVAL=10

echo "[$(date -u '+%H:%M:%S')] Frame Extraction — START"
echo "  input:    $VIDEO"
echo "  output:   $FRAMES_DIR"
echo "  interval: ${INTERVAL}s"

mkdir -p "$FRAMES_DIR"

# 获取时长
DURATION=$($FFPROBE -v quiet -print_format json -show_format "$VIDEO" 2>/dev/null | python3 -c "import sys,json; d=json.load(sys.stdin); print(d['format']['duration'])")
echo "  duration: ${DURATION}s"

# 抽帧：每 10 秒一帧，输出 JPEG
$FFMPEG -y \
  -i "$VIDEO" \
  -vf "select='not(mod(t,${INTERVAL}))',setpts=N/FRAME_RATE/TB" \
  -vsync vfr \
  -q:v 2 \
  "$FRAMES_DIR/frame_%06d.jpg" 2>&1 | grep -E "(frame=|fps=|Error|error)" | tail -5

echo "[$(date -u '+%H:%M:%S')] ffmpeg done"

# 重命名为含时间戳格式，生成 metadata
python3 - <<'PYEOF'
import os, json, re

frames_dir = "/home/node/.openclaw/workspace/source_collector/sources/bilibili/ysjf/space_camera_project/extracted/frames"
source_root = "/home/node/.openclaw/workspace/source_collector/sources/bilibili/ysjf/space_camera_project"
interval_sec = 10.0

files = sorted(f for f in os.listdir(frames_dir) if re.match(r'^frame_\d+\.jpg$', f))
print(f"  raw frames: {len(files)}")

frame_records = []
for i, fname in enumerate(files):
    ts = round(i * interval_sec, 3)
    ts_ms = int(ts * 1000)
    new_name = f"frame_{i+1:06d}_{ts_ms:08d}ms.jpg"
    src = os.path.join(frames_dir, fname)
    dst = os.path.join(frames_dir, new_name)
    if src != dst:
        os.rename(src, dst)
    frame_records.append({
        "index": i + 1,
        "timestamp_sec": ts,
        "filename": new_name,
        "filepath": f"extracted/frames/{new_name}",
    })

# 读取时长
with open(os.path.join(source_root, "extracted", "audio_metadata.json")) as f:
    duration = json.load(f).get("duration_seconds", 867.136)

meta = {
    "source_id": "bilibili_av84178790",
    "input_video": "raw/camera_to_space.f30077.mp4",
    "output_dir": "extracted/frames",
    "interval_sec": interval_sec,
    "total_frames": len(frame_records),
    "duration_seconds": duration,
    "backend_used": "ffmpeg",
    "frames": frame_records,
}
meta_path = os.path.join(source_root, "extracted", "frame_metadata.json")
with open(meta_path, "w", encoding="utf-8") as f:
    json.dump(meta, f, ensure_ascii=False, indent=2)

print(f"  total_frames: {len(frame_records)}")
print(f"  frame_metadata.json: {meta_path}")
print(f"  first: {frame_records[0]['filename'] if frame_records else 'N/A'}")
print(f"  last:  {frame_records[-1]['filename'] if frame_records else 'N/A'}")
print("✅ Frame Extraction COMPLETE")
PYEOF
