#!/bin/bash
cd /home/node/.openclaw/workspace/source_collector
python3 -m pytest tests/test_frame_extraction.py -v
