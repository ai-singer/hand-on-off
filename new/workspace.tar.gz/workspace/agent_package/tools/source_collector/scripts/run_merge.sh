#!/bin/bash
cd /home/node/.openclaw/workspace/source_collector
python3 scripts/merge_mp4.py \
  sources/bilibili/ysjf/space_camera_project/raw/camera_to_space.f30077.mp4 \
  sources/bilibili/ysjf/space_camera_project/raw/camera_to_space.f30280.m4a \
  sources/bilibili/ysjf/space_camera_project/raw/camera_to_space_merged.mp4
