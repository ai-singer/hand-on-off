#!/bin/bash
cd /home/node/.openclaw/workspace/source_collector
python3 -m pytest tests/test_audio_extraction.py -v
