#!/bin/bash
# 等待 ffmpeg 安装完成，然后运行真实 Audio Extraction
# 每 60 秒检查一次，最多等待 30 分钟

FFMPEG_PATH="/home/node/.local/bin/ffmpeg"
MAX_WAIT=1800  # 30 minutes
INTERVAL=60
ELAPSED=0

echo "[$(date -u '+%H:%M:%S')] Waiting for ffmpeg at $FFMPEG_PATH..."

while [ $ELAPSED -lt $MAX_WAIT ]; do
    if [ -x "$FFMPEG_PATH" ]; then
        echo "[$(date -u '+%H:%M:%S')] ffmpeg FOUND — running production extraction..."
        $FFMPEG_PATH -version 2>&1 | head -1
        cd /home/node/.openclaw/workspace/source_collector
        python3 scripts/run_audio_extraction.py
        echo "[$(date -u '+%H:%M:%S')] DONE"
        exit 0
    fi
    sleep $INTERVAL
    ELAPSED=$((ELAPSED + INTERVAL))
    echo "[$(date -u '+%H:%M:%S')] still waiting... (${ELAPSED}s elapsed)"
done

echo "[$(date -u '+%H:%M:%S')] TIMEOUT — ffmpeg not available after ${MAX_WAIT}s"
exit 1
