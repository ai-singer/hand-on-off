"""
services/article_generation_contract.py

Article Generation Contract Layer

职责：
- 读取 post_plan.json + content_facts.json + frame_observations.json
- 为每篇帖子生成生产合约（结构规范、事实引用、图片引用）
- 输出 extracted/article_generation_contract.json

不生成正文。
不添加新事实。
不修改 post_plan。
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import List


# ---------------------------------------------------------------------------
# 异常
# ---------------------------------------------------------------------------

class ArticleContractError(Exception):
    pass


# ---------------------------------------------------------------------------
# 数据类
# ---------------------------------------------------------------------------

@dataclass
class ImageReference:
    frame_id: int
    timestamp_sec: float
    scene: str
    theme_note: str   # 说明这张图在帖子中代表什么主题


@dataclass
class PostContract:
    post_id: str
    title: str
    target_length: str
    required_sections: List[str]
    fact_references: List[dict]   # {fact_id, fact_summary, confidence}
    image_references: List[dict]  # {frame_id, timestamp_sec, scene, theme_note}


@dataclass
class ArticleContract:
    source_id: str
    posts: List[PostContract]


# ---------------------------------------------------------------------------
# 主服务
# ---------------------------------------------------------------------------

def build_contract(source_root: str) -> ArticleContract:
    """
    从 post_plan.json + content_facts.json + frame_observations.json
    生成 article_generation_contract.json。

    Args:
        source_root: source 目录路径

    Returns:
        ArticleContract

    Raises:
        ArticleContractError: 输入缺失或引用无效
    """
    # 1. 验证依赖
    paths = {
        "source.json":              os.path.join(source_root, "metadata", "source.json"),
        "content_facts.json":       os.path.join(source_root, "extracted", "content_facts.json"),
        "key_points.json":          os.path.join(source_root, "extracted", "key_points.json"),
        "post_plan.json":           os.path.join(source_root, "extracted", "post_plan.json"),
        "frame_observations.json":  os.path.join(source_root, "extracted", "frame_observations.json"),
    }
    for label, path in paths.items():
        if not os.path.isfile(path):
            raise ArticleContractError(f"MISSING_DEPENDENCY: {label} 不存在: {path}")

    with open(paths["source.json"],             encoding="utf-8") as f: meta  = json.load(f)
    with open(paths["content_facts.json"],      encoding="utf-8") as f: cf    = json.load(f)
    with open(paths["post_plan.json"],          encoding="utf-8") as f: pp    = json.load(f)
    with open(paths["frame_observations.json"], encoding="utf-8") as f: obs   = json.load(f)

    source_id = meta.get("source_id", "unknown")
    facts     = cf.get("facts", [])
    posts     = pp.get("posts", [])

    # 索引
    fact_map  = {f"fact_{i}": f for i, f in enumerate(facts)}
    obs_map   = {o["frame_id"]: o for o in obs.get("observations", [])}

    # 2. 构建每个帖子的合约
    post_contracts = []
    for post in posts:
        post_id = post["post_id"]
        title   = post["title"]
        target  = post.get("target_length", "800-1200")

        # --- 事实引用 ---
        fact_refs = []
        for fid in post.get("fact_ids", []):
            if fid not in fact_map:
                raise ArticleContractError(
                    f"post {post_id!r} 引用了不存在的 fact_id: {fid!r}"
                )
            f = fact_map[fid]
            fact_refs.append({
                "fact_id":      fid,
                "fact_summary": f["fact"][:80],
                "confidence":   f["confidence"],
                "evidence_frames": f["evidence_frames"],
            })

        # --- 图片引用 ---
        img_refs = []
        for frame_id in post.get("image_frames", []):
            if frame_id not in obs_map:
                raise ArticleContractError(
                    f"post {post_id!r} 引用了不存在的 frame_id: {frame_id}"
                )
            o = obs_map[frame_id]
            img_refs.append({
                "frame_id":     frame_id,
                "timestamp_sec": o["timestamp_sec"],
                "scene":        o["scene"],
                "theme_note":   _theme_note_for_post(post_id, o),
            })

        # --- 文章结构 ---
        sections = _required_sections_for_post(post_id, post)

        post_contracts.append(PostContract(
            post_id=post_id,
            title=title,
            target_length=target,
            required_sections=sections,
            fact_references=fact_refs,
            image_references=img_refs,
        ))

    contract = ArticleContract(source_id=source_id, posts=post_contracts)

    # 3. 写入文件
    out_path = os.path.join(source_root, "extracted", "article_generation_contract.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump({
            "source_id": contract.source_id,
            "posts": [
                {
                    "post_id":          p.post_id,
                    "title":            p.title,
                    "target_length":    p.target_length,
                    "required_sections": p.required_sections,
                    "fact_references":  p.fact_references,
                    "image_references": p.image_references,
                }
                for p in contract.posts
            ],
        }, f, ensure_ascii=False, indent=2)

    return contract


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------

def _required_sections_for_post(post_id: str, post: dict) -> List[str]:
    """为每篇帖子定义必须包含的段落结构。"""
    base = [
        "标题",
        "开场引入",
        "核心过程",
        "关键事实",
        "总结",
    ]
    # 根据主题微调
    theme = post.get("theme", "")
    if "准备" in theme or "起点" in theme:
        return ["标题", "开场引入", "项目背景", "现场环境描述", "关键事实", "总结"]
    if "升空" in theme or "太空" in theme:
        return ["标题", "开场引入", "上升过程", "视觉变化描述", "关键事实", "总结"]
    if "回收" in theme or "下降" in theme or "收尾" in theme:
        return ["标题", "开场引入", "下降过程", "回收现场描述", "关键事实", "总结"]
    return base


def _theme_note_for_post(post_id: str, obs: dict) -> str:
    """为图片生成主题说明（说明这张图在该帖子中起什么作用）。"""
    scene = obs.get("scene", "")
    ts = obs.get("timestamp_sec", 0)

    if "发射" in scene or "准备" in scene or ts < 160:
        return "用于展示发射现场环境和准备状态"
    if "太空" in scene or "黑" in scene or "曲率" in scene or 300 <= ts <= 560:
        return "用于展示高空/近太空视觉效果"
    if "下降" in scene or "回收" in scene or ts > 560:
        return "用于展示下降过程或回收现场"
    if "片头" in scene or "片尾" in scene:
        return "用于展示视频标题或总结画面"
    return "用于展示对应阶段的画面内容"
