"""
services/asr.py

ASR (Automatic Speech Recognition) Service

职责：
- 读取 audio.wav
- 转录语音为文本
- 输出 extracted/transcript.json 和 extracted/transcript.txt

不实现：内容分析、关键词提取、LLM 处理

后端策略：
  WhisperBackend  — 有 whisper 时使用（真实转录）
  MockBackend     — 无 whisper 时使用（生成占位 transcript，用于测试/CI）
"""

from __future__ import annotations

import json
import os
import wave
from dataclasses import dataclass, field
from typing import List, Optional


# ---------------------------------------------------------------------------
# 异常
# ---------------------------------------------------------------------------

class ASRError(Exception):
    """ASR 转录失败。"""
    pass


# ---------------------------------------------------------------------------
# 数据类
# ---------------------------------------------------------------------------

@dataclass
class ASRSegment:
    start: float    # 秒
    end: float      # 秒
    text: str


@dataclass
class ASRResult:
    source_id: str
    audio_file: str         # 相对于 source root 的路径
    language: str
    duration_seconds: float
    segments: List[ASRSegment]
    backend_used: str       # "whisper" | "mock"

    @property
    def full_text(self) -> str:
        return " ".join(s.text.strip() for s in self.segments if s.text.strip())


# ---------------------------------------------------------------------------
# Backend 接口
# ---------------------------------------------------------------------------

class ASRBackend:
    """ASR 后端基类。"""

    def transcribe(self, audio_path: str, source_id: str) -> ASRResult:
        """
        转录 audio_path（wav 文件）。

        Returns:
            ASRResult
        """
        raise NotImplementedError


class MockBackend(ASRBackend):
    """
    无 whisper 时使用的 mock 后端。

    生成结构合法的占位 transcript，使测试可以在无 GPU/网络环境下运行。
    占位文本基于 source_id，可追溯。
    """

    LANGUAGE = "zh"

    def transcribe(self, audio_path: str, source_id: str) -> ASRResult:
        if not os.path.isfile(audio_path):
            raise ASRError(f"音频文件不存在: {audio_path}")

        # 从 wav 文件读取实际时长
        try:
            with wave.open(audio_path, "rb") as wf:
                frames = wf.getnframes()
                rate = wf.getframerate()
                duration = frames / rate if rate > 0 else 0.0
        except Exception as e:
            raise ASRError(f"无法读取 wav 文件: {audio_path}: {e}")

        # 生成占位 segments（每 30 秒一段）
        segment_duration = 30.0
        segments = []
        t = 0.0
        idx = 1
        while t < duration:
            end = min(t + segment_duration, duration)
            segments.append(ASRSegment(
                start=round(t, 3),
                end=round(end, 3),
                text=f"[MockASR segment {idx}: {t:.0f}s-{end:.0f}s | source={source_id}]"
            ))
            t = end
            idx += 1

        return ASRResult(
            source_id=source_id,
            audio_file=audio_path,
            language=self.LANGUAGE,
            duration_seconds=round(duration, 3),
            segments=segments,
            backend_used="mock",
        )


class WhisperBackend(ASRBackend):
    """
    使用 openai-whisper 进行本地转录。

    安装：pip3 install openai-whisper
    """

    def __init__(self, model: str = "medium"):
        self.model_name = model
        self._model = None

    def _load_model(self):
        if self._model is None:
            try:
                import whisper
                self._model = whisper.load_model(self.model_name)
            except ImportError:
                raise ASRError(
                    "openai-whisper 未安装，请运行: pip3 install openai-whisper"
                )

    def transcribe(self, audio_path: str, source_id: str) -> ASRResult:
        if not os.path.isfile(audio_path):
            raise ASRError(f"音频文件不存在: {audio_path}")

        self._load_model()

        import whisper
        result = self._model.transcribe(audio_path, language="zh")

        segments = [
            ASRSegment(
                start=round(seg["start"], 3),
                end=round(seg["end"], 3),
                text=seg["text"].strip(),
            )
            for seg in result.get("segments", [])
        ]

        duration = result.get("duration", 0.0)
        if duration == 0.0 and segments:
            duration = segments[-1].end

        return ASRResult(
            source_id=source_id,
            audio_file=audio_path,
            language=result.get("language", "zh"),
            duration_seconds=round(duration, 3),
            segments=segments,
            backend_used="whisper",
        )


def _select_backend() -> ASRBackend:
    """自动选择可用的后端。"""
    try:
        import whisper  # noqa: F401
        return WhisperBackend()
    except ImportError:
        return MockBackend()


# ---------------------------------------------------------------------------
# 主服务
# ---------------------------------------------------------------------------

def run_asr(
    source_root: str,
    backend: Optional[ASRBackend] = None,
) -> ASRResult:
    """
    对 source_root/extracted/audio/audio.wav 执行 ASR。

    Args:
        source_root: source 目录路径（包含 metadata/ 和 extracted/）
        backend:     可选后端（默认自动选择）

    Returns:
        ASRResult

    Raises:
        ASRError: 输入缺失或转录失败
    """
    # 1. 读取 source.json 获取 source_id
    metadata_path = os.path.join(source_root, "metadata", "source.json")
    if not os.path.isfile(metadata_path):
        raise ASRError(f"source.json 不存在: {metadata_path}")

    with open(metadata_path, "r", encoding="utf-8") as f:
        meta = json.load(f)

    source_id = meta.get("source_id", "unknown")

    # 2. 读取 audio_metadata.json 确认 Audio Extraction 已完成
    audio_meta_path = os.path.join(source_root, "extracted", "audio_metadata.json")
    if not os.path.isfile(audio_meta_path):
        raise ASRError(
            f"audio_metadata.json 不存在: {audio_meta_path}\n"
            "请先运行 Audio Extraction Layer。"
        )

    with open(audio_meta_path, "r", encoding="utf-8") as f:
        audio_meta = json.load(f)

    # 3. 定位 wav 文件
    audio_output_rel = audio_meta.get("output_audio", "extracted/audio/audio.wav")
    wav_abs = os.path.join(source_root, audio_output_rel)

    if not os.path.isfile(wav_abs):
        raise ASRError(f"wav 文件不存在: {wav_abs}")

    # 4. 执行转录
    if backend is None:
        backend = _select_backend()

    result = backend.transcribe(wav_abs, source_id)

    # 5. 写入 extracted/transcript.json
    transcript_json_path = os.path.join(source_root, "extracted", "transcript.json")
    transcript_data = {
        "source_id": result.source_id,
        "audio_file": audio_output_rel,
        "language": result.language,
        "duration_seconds": result.duration_seconds,
        "segments": [
            {"start": s.start, "end": s.end, "text": s.text}
            for s in result.segments
        ],
        "backend_used": result.backend_used,
    }
    with open(transcript_json_path, "w", encoding="utf-8") as f:
        json.dump(transcript_data, f, ensure_ascii=False, indent=2)

    # 6. 写入 extracted/transcript.txt（纯文本，ASR 后续处理友好）
    transcript_txt_path = os.path.join(source_root, "extracted", "transcript.txt")
    with open(transcript_txt_path, "w", encoding="utf-8") as f:
        for seg in result.segments:
            f.write(f"[{seg.start:.1f}s - {seg.end:.1f}s] {seg.text}\n")

    return result
