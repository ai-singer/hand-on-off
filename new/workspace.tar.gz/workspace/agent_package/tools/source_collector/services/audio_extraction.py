"""
services/audio_extraction.py

Audio Extraction Service

职责：
- 读取 source.json
- 定位 audio asset（m4a）
- 转换 m4a -> wav（有 ffmpeg 时真实转换，无则 mock）
- 生成 extracted/audio_metadata.json

不实现：ASR、LLM、内容分析

后端策略（Backend）：
  FfmpegBackend  — 有 ffmpeg 时使用（真实转换）
  MockBackend    — 无 ffmpeg 时使用（生成合法空 wav，用于测试/CI）
"""

from __future__ import annotations

import json
import os
import shutil
import struct
import wave
from dataclasses import dataclass
from typing import Optional


# ---------------------------------------------------------------------------
# 异常
# ---------------------------------------------------------------------------

class AudioExtractionError(Exception):
    """音频提取失败。"""
    pass


# ---------------------------------------------------------------------------
# 数据类
# ---------------------------------------------------------------------------

@dataclass
class AudioExtractionResult:
    source_id: str
    input_audio: str       # 相对于 source root 的路径
    output_audio: str      # 相对于 source root 的路径
    duration_seconds: float
    sample_rate: int
    backend_used: str      # "ffmpeg" | "mock"


# ---------------------------------------------------------------------------
# Backend 接口
# ---------------------------------------------------------------------------

class AudioBackend:
    """音频转换后端基类。"""

    def convert_to_wav(self, input_path: str, output_path: str) -> dict:
        """
        转换 input_path 为 wav 格式写入 output_path。

        Returns:
            dict with keys: duration_seconds, sample_rate
        """
        raise NotImplementedError


class FfmpegBackend(AudioBackend):
    """使用 ffmpeg 进行真实音频转换。"""

    @staticmethod
    def find_ffmpeg() -> str:
        """查找 ffmpeg 可执行路径，优先用户目录。"""
        import shutil
        candidates = [
            "/home/node/.local/bin/ffmpeg",
            "/usr/local/bin/ffmpeg",
            "/usr/bin/ffmpeg",
        ]
        # shutil.which 先找 PATH
        found = shutil.which("ffmpeg")
        if found:
            return found
        for c in candidates:
            if os.path.isfile(c) and os.access(c, os.X_OK):
                return c
        return "ffmpeg"  # 最后回退，让 subprocess 报错

    def convert_to_wav(self, input_path: str, output_path: str) -> dict:
        import subprocess

        ffmpeg_bin = self.find_ffmpeg()
        cmd = [
            ffmpeg_bin, "-y",
            "-i", input_path,
            "-ar", "16000",      # 16kHz — ASR 友好
            "-ac", "1",          # 单声道
            "-f", "wav",
            output_path
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            raise AudioExtractionError(
                f"ffmpeg 转换失败 (exit {result.returncode}):\n{result.stderr}"
            )

        # 读取生成的 wav 获取元数据
        with wave.open(output_path, "rb") as wf:
            frames = wf.getnframes()
            rate = wf.getframerate()
            duration = frames / rate if rate > 0 else 0.0

        return {"duration_seconds": round(duration, 3), "sample_rate": rate}


class MockBackend(AudioBackend):
    """
    无 ffmpeg 时使用的 mock 后端。

    生成一个合法的空 wav 文件（1 秒静音，16kHz mono），
    使测试可以在 CI/无 ffmpeg 环境下完整运行。
    """

    SAMPLE_RATE = 16000
    DURATION_SEC = 1.0

    def convert_to_wav(self, input_path: str, output_path: str) -> dict:
        if not os.path.isfile(input_path):
            raise AudioExtractionError(
                f"输入音频文件不存在: {input_path}"
            )

        num_frames = int(self.SAMPLE_RATE * self.DURATION_SEC)
        os.makedirs(os.path.dirname(output_path), exist_ok=True)

        with wave.open(output_path, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)          # 16-bit
            wf.setframerate(self.SAMPLE_RATE)
            wf.writeframes(b"\x00\x00" * num_frames)   # 静音帧

        return {
            "duration_seconds": self.DURATION_SEC,
            "sample_rate": self.SAMPLE_RATE,
        }


def _select_backend() -> AudioBackend:
    """自动选择可用的后端。"""
    ffmpeg_bin = FfmpegBackend.find_ffmpeg()
    if ffmpeg_bin != "ffmpeg" or shutil.which("ffmpeg"):
        return FfmpegBackend()
    return MockBackend()


# ---------------------------------------------------------------------------
# 主服务
# ---------------------------------------------------------------------------

def extract_audio(
    source_root: str,
    backend: Optional[AudioBackend] = None,
) -> AudioExtractionResult:
    """
    从 source_root 读取 source.json，提取音频并转换为 wav。

    Args:
        source_root: source 目录路径（包含 metadata/ 和 raw/）
        backend:     可选后端（默认自动选择）

    Returns:
        AudioExtractionResult

    Raises:
        AudioExtractionError: 输入缺失或转换失败
    """
    # 1. 读取 source.json
    metadata_path = os.path.join(source_root, "metadata", "source.json")
    if not os.path.isfile(metadata_path):
        raise AudioExtractionError(
            f"source.json 不存在: {metadata_path}"
        )

    with open(metadata_path, "r", encoding="utf-8") as f:
        meta = json.load(f)

    source_id = meta.get("source_id", "unknown")

    # 2. 定位音频文件
    # 优先级：audio_file > merged_file > raw_file
    # 注意：merged_file 是手工 mux 的文件，moov 结构可能不完整，
    #       音频提取优先使用原始 audio_file（纯音频流，结构完整）
    audio_rel = meta.get("audio_file")

    if not audio_rel:
        # 尝试 metadata.merged_file
        merged_rel = None
        if "metadata" in meta and isinstance(meta["metadata"], dict):
            merged_rel = meta["metadata"].get("merged_file")
        if not merged_rel:
            merged_rel = meta.get("merged_file")
        audio_rel = merged_rel or meta.get("raw_file")

    if not audio_rel:
        raise AudioExtractionError(
            "source.json 中缺少 audio_file / merged_file / raw_file 字段"
        )

    input_audio_abs = os.path.join(source_root, audio_rel)
    if not os.path.isfile(input_audio_abs):
        raise AudioExtractionError(
            f"音频文件不存在: {input_audio_abs}  (字段值: {audio_rel!r})"
        )

    # 3. 确定输出路径
    output_rel = "extracted/audio/audio.wav"
    output_abs = os.path.join(source_root, output_rel)
    os.makedirs(os.path.dirname(output_abs), exist_ok=True)

    # 4. 执行转换
    if backend is None:
        backend = _select_backend()

    backend_name = type(backend).__name__.replace("Backend", "").lower()
    wav_meta = backend.convert_to_wav(input_audio_abs, output_abs)

    result = AudioExtractionResult(
        source_id=source_id,
        input_audio=audio_rel,
        output_audio=output_rel,
        duration_seconds=wav_meta["duration_seconds"],
        sample_rate=wav_meta["sample_rate"],
        backend_used=backend_name,
    )

    # 5. 写入 extracted/audio_metadata.json
    audio_meta_path = os.path.join(source_root, "extracted", "audio_metadata.json")
    os.makedirs(os.path.dirname(audio_meta_path), exist_ok=True)
    with open(audio_meta_path, "w", encoding="utf-8") as f:
        json.dump({
            "source_id": result.source_id,
            "input_audio": result.input_audio,
            "output_audio": result.output_audio,
            "duration_seconds": result.duration_seconds,
            "sample_rate": result.sample_rate,
            "backend_used": result.backend_used,
        }, f, ensure_ascii=False, indent=2)

    return result
