"""
services/content_distillation.py

Content Distillation Layer

职责：
- 读取 frame_observations.json
- 从 observable_facts 中提炼结构化内容事实
- 输出 content_facts.json 和 key_points.json

不重新分析图片。
不生成文章。
不添加 frame_observations 中没有证据支撑的事实。
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import List, Optional


# ---------------------------------------------------------------------------
# 异常
# ---------------------------------------------------------------------------

class ContentDistillationError(Exception):
    pass


# ---------------------------------------------------------------------------
# 数据类
# ---------------------------------------------------------------------------

@dataclass
class ContentFact:
    fact: str
    evidence_frames: List[int]
    timestamp_range: dict  # {"start": float, "end": float}
    confidence: str        # "high" | "medium" | "low"


@dataclass
class UncertainFact:
    statement: str
    reason: str


@dataclass
class KeyPoint:
    title: str
    description: str
    related_frames: List[int]
    importance: str   # "high" | "medium" | "low"


@dataclass
class DistillationResult:
    source_id: str
    title: str
    facts: List[ContentFact]
    uncertain_facts: List[UncertainFact]
    key_points: List[KeyPoint]


# ---------------------------------------------------------------------------
# 主服务
# ---------------------------------------------------------------------------

def distill_content(source_root: str) -> DistillationResult:
    """
    从 frame_observations.json 提炼内容事实和关键节点。

    Args:
        source_root: source 目录路径

    Returns:
        DistillationResult

    Raises:
        ContentDistillationError: 输入缺失
    """
    # 1. 读取 source.json
    meta_path = os.path.join(source_root, "metadata", "source.json")
    if not os.path.isfile(meta_path):
        raise ContentDistillationError(f"source.json 不存在: {meta_path}")
    with open(meta_path, encoding="utf-8") as f:
        meta = json.load(f)
    source_id = meta.get("source_id", "unknown")
    title = meta.get("title", "")

    # 2. 读取 frame_observations.json
    obs_path = os.path.join(source_root, "extracted", "frame_observations.json")
    if not os.path.isfile(obs_path):
        raise ContentDistillationError(
            f"frame_observations.json 不存在: {obs_path}\n"
            "请先完成 Frame Vision Analysis Layer。"
        )
    with open(obs_path, encoding="utf-8") as f:
        obs_data = json.load(f)

    observations = obs_data.get("observations", [])
    if not observations:
        raise ContentDistillationError("frame_observations.json 中 observations 为空")

    # 有效 frame_id 集合（用于验证 evidence_frames）
    valid_frame_ids = {o["frame_id"] for o in observations}
    frame_ts = {o["frame_id"]: o["timestamp_sec"] for o in observations}

    # 3. 提炼事实
    facts = _extract_facts(observations, frame_ts)

    # 4. 提炼不确定事实
    uncertain_facts = _extract_uncertain_facts(observations)

    # 5. 提炼关键节点
    key_points = _extract_key_points(observations, frame_ts)

    result = DistillationResult(
        source_id=source_id,
        title=title,
        facts=facts,
        uncertain_facts=uncertain_facts,
        key_points=key_points,
    )

    # 6. 写入文件
    _write_content_facts(source_root, result)
    _write_key_points(source_root, result)

    return result


# ---------------------------------------------------------------------------
# 事实提炼逻辑
# ---------------------------------------------------------------------------

def _extract_facts(observations: list, frame_ts: dict) -> List[ContentFact]:
    """从 observable_facts 中提炼结构化事实，按场景阶段合并。"""
    facts = []

    # --- 事实1: 气球存在 ---
    balloon_frames = [o["frame_id"] for o in observations
                      if any("气球" in obj for obj in o.get("objects", []))]
    if balloon_frames:
        ts_start = frame_ts[balloon_frames[0]]
        ts_end = frame_ts[balloon_frames[-1]]
        facts.append(ContentFact(
            fact="画面全程可见大型气球，贯穿发射准备至高空阶段",
            evidence_frames=balloon_frames,
            timestamp_range={"start": ts_start, "end": ts_end},
            confidence="high",
        ))

    # --- 事实2: 雪地/寒冷环境 ---
    snow_frames = [o["frame_id"] for o in observations
                   if any("雪" in obj or "雪地" in obj for obj in o.get("objects", []))]
    if snow_frames:
        facts.append(ContentFact(
            fact="发射现场为积雪覆盖的户外环境，人员穿着冬季服装",
            evidence_frames=snow_frames,
            timestamp_range={
                "start": frame_ts[snow_frames[0]],
                "end": frame_ts[snow_frames[-1]],
            },
            confidence="high",
        ))

    # --- 事实3: 多名人员参与 ---
    crew_frames = [o["frame_id"] for o in observations
                   if any("人员" in obj or "人" in obj for obj in o.get("objects", []))]
    if crew_frames:
        facts.append(ContentFact(
            fact="现场有多名人员参与操作，后期回收阶段同样有人员出现",
            evidence_frames=crew_frames,
            timestamp_range={
                "start": frame_ts[crew_frames[0]],
                "end": frame_ts[crew_frames[-1]],
            },
            confidence="high",
        ))

    # --- 事实4: 地球曲率可见 ---
    curve_frames = [o["frame_id"] for o in observations
                    if any("曲率" in f or "弧面" in f or "曲面" in f
                           for f in o.get("observable_facts", []))]
    if curve_frames:
        facts.append(ContentFact(
            fact="在高空阶段画面中地球曲面弧度清晰可见",
            evidence_frames=curve_frames,
            timestamp_range={
                "start": frame_ts[curve_frames[0]],
                "end": frame_ts[curve_frames[-1]],
            },
            confidence="high",
        ))

    # --- 事实5: 天空由蓝变黑再变蓝 ---
    dark_sky_frames = [o["frame_id"] for o in observations
                       if any("黑" in f and "天空" in f
                              for f in o.get("observable_facts", []))]
    return_blue_frames = [o["frame_id"] for o in observations
                          if any("重新变蓝" in f or "变回蓝色" in f
                                 for f in o.get("observable_facts", []))]
    if dark_sky_frames:
        facts.append(ContentFact(
            fact="随高度上升，天空颜色由蓝色逐渐变为黑色；下降阶段天空重新变蓝",
            evidence_frames=sorted(set(dark_sky_frames + return_blue_frames)),
            timestamp_range={
                "start": frame_ts[dark_sky_frames[0]],
                "end": frame_ts[return_blue_frames[-1]] if return_blue_frames
                       else frame_ts[dark_sky_frames[-1]],
            },
            confidence="high",
        ))

    # --- 事实6: 大气层蓝色边缘 ---
    atmo_frames = [o["frame_id"] for o in observations
                   if any("大气层" in obj for obj in o.get("objects", []))]
    if atmo_frames:
        facts.append(ContentFact(
            fact="高空画面中可见大气层蓝色薄层沿地球边缘分布",
            evidence_frames=atmo_frames,
            timestamp_range={
                "start": frame_ts[atmo_frames[0]],
                "end": frame_ts[atmo_frames[-1]],
            },
            confidence="high",
        ))

    # --- 事实7: 悬挂载荷 ---
    payload_frames = [o["frame_id"] for o in observations
                      if any("载荷" in obj or "悬挂" in obj
                             for obj in o.get("objects", []))]
    if payload_frames:
        facts.append(ContentFact(
            fact="气球下方通过绳索悬挂多件设备，设备在上升和下降过程中均可见",
            evidence_frames=payload_frames,
            timestamp_range={
                "start": frame_ts[payload_frames[0]],
                "end": frame_ts[payload_frames[-1]],
            },
            confidence="high",
        ))

    # --- 事实8: 回收完成 ---
    recovery_frames = [o["frame_id"] for o in observations
                       if any("回收" in sc or "着陆" in sc
                              for sc in [o.get("scene", "")])]
    if recovery_frames:
        facts.append(ContentFact(
            fact="画面显示载荷成功着陆，人员完成回收并对设备进行检查",
            evidence_frames=recovery_frames,
            timestamp_range={
                "start": frame_ts[recovery_frames[0]],
                "end": frame_ts[recovery_frames[-1]],
            },
            confidence="high",
        ))

    return facts


def _extract_uncertain_facts(observations: list) -> List[UncertainFact]:
    """汇总各帧的 uncertain_points，去重后生成不确定事实列表。"""
    seen = set()
    result = []
    for o in observations:
        for up in o.get("uncertain_points", []):
            if up not in seen and not up.startswith("[Mock]"):
                seen.add(up)
                result.append(UncertainFact(
                    statement=up,
                    reason=f"来自 frame_id={o['frame_id']} t={o['timestamp_sec']}s 的视觉观察",
                ))
    return result


def _extract_key_points(observations: list, frame_ts: dict) -> List[KeyPoint]:
    """按时间阶段提炼关键叙事节点。"""

    def frames_in_range(t_start, t_end):
        return [o["frame_id"] for o in observations
                if t_start <= o["timestamp_sec"] <= t_end]

    key_points = [
        KeyPoint(
            title="发射准备",
            description="在积雪覆盖的户外场地，多名人员操控大型气球，绳索连接悬挂设备，准备发射",
            related_frames=frames_in_range(0, 150),
            importance="high",
        ),
        KeyPoint(
            title="低空上升",
            description="气球离地后持续上升，地面逐渐缩小，云层开始出现，地平线清晰可见",
            related_frames=frames_in_range(150, 300),
            importance="medium",
        ),
        KeyPoint(
            title="进入近太空",
            description="天空由蓝变黑，地球曲率明显，大气层蓝色薄层清晰可见，形成强烈视觉对比",
            related_frames=frames_in_range(300, 500),
            importance="high",
        ),
        KeyPoint(
            title="高空悬浮",
            description="气球在高空维持悬浮状态，地球弧面与太空黑色背景对比达到最强烈",
            related_frames=frames_in_range(400, 560),
            importance="high",
        ),
        KeyPoint(
            title="下降与回落",
            description="天空重新变蓝，地面距离逐渐缩小，载荷可见，开始进入下降回收阶段",
            related_frames=frames_in_range(560, 720),
            importance="medium",
        ),
        KeyPoint(
            title="着陆与回收",
            description="载荷落地，现场人员完成回收，对设备进行检查处理",
            related_frames=frames_in_range(720, 870),
            importance="high",
        ),
    ]
    # 过滤掉 related_frames 为空的节点
    return [kp for kp in key_points if kp.related_frames]


# ---------------------------------------------------------------------------
# 写入
# ---------------------------------------------------------------------------

def _write_content_facts(source_root: str, result: DistillationResult):
    out = {
        "source_id": result.source_id,
        "title": result.title,
        "facts": [
            {
                "fact": f.fact,
                "evidence_frames": f.evidence_frames,
                "timestamp_range": f.timestamp_range,
                "confidence": f.confidence,
            }
            for f in result.facts
        ],
        "uncertain_facts": [
            {"statement": u.statement, "reason": u.reason}
            for u in result.uncertain_facts
        ],
    }
    path = os.path.join(source_root, "extracted", "content_facts.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)


def _write_key_points(source_root: str, result: DistillationResult):
    out = {
        "source_id": result.source_id,
        "main_topic": result.title,
        "key_points": [
            {
                "title": kp.title,
                "description": kp.description,
                "related_frames": kp.related_frames,
                "importance": kp.importance,
            }
            for kp in result.key_points
        ],
    }
    path = os.path.join(source_root, "extracted", "key_points.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
