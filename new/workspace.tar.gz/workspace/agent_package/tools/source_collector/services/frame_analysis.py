"""
services/frame_analysis.py

Frame Analysis Service

职责：
- 读取 frame_metadata.json
- 对每一帧进行视觉分析
- 输出 extracted/frame_observations.json

不实现：文章生成、LLM 写作、内容摘要

后端策略：
  VisionAPIBackend  — 接入真实 Vision Model（预留接口，未实现）
  MockVisionBackend — 生成结构合法的占位观察结果，用于测试/CI

frame_observations.json schema:
{
  "source_id": str,
  "total_frames": int,
  "backend_used": str,
  "observations": [
    {
      "frame_id": int,
      "filename": str,
      "timestamp_sec": float,
      "filepath": str,
      "objects": [str],           # 画面中实际可见的物体
      "scene": str,               # 视觉场景描述
      "observable_facts": [str],  # 图片直接证明的信息
      "uncertain_points": [str],  # 无法从单张图片确定的信息
      # legacy 兼容字段
      "observations": [str],      # 同 observable_facts（MockBackend 使用）
      "confidence": float,        # 0.0-1.0
    }
  ]
}
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import List, Optional


# ---------------------------------------------------------------------------
# 异常
# ---------------------------------------------------------------------------

class FrameAnalysisError(Exception):
    """帧分析失败。"""
    pass


# ---------------------------------------------------------------------------
# 数据类
# ---------------------------------------------------------------------------

@dataclass
class FrameObservation:
    frame_id: int
    filename: str
    timestamp_sec: float
    filepath: str
    objects: List[str]
    scene: str
    uncertain_points: List[str]
    # 新字段
    observable_facts: List[str] = field(default_factory=list)
    # legacy 兼容字段（MockBackend 使用，OpenClawVisionBackend 可留空）
    observations: List[str] = field(default_factory=list)
    confidence: float = 0.0


@dataclass
class FrameAnalysisResult:
    source_id: str
    total_frames: int
    backend_used: str
    observations: List[FrameObservation]


# ---------------------------------------------------------------------------
# Backend 接口
# ---------------------------------------------------------------------------

class VisionBackend:
    """视觉分析后端基类。"""

    def analyze_frame(
        self,
        frame_path: str,
        frame_id: int,
        timestamp_sec: float,
        filename: str,
        filepath: str,
    ) -> FrameObservation:
        """
        分析单帧图像。

        Args:
            frame_path:   帧文件绝对路径
            frame_id:     帧序号（1-based）
            timestamp_sec: 时间戳（秒）
            filename:     帧文件名
            filepath:     相对于 source root 的路径

        Returns:
            FrameObservation
        """
        raise NotImplementedError


class MockVisionBackend(VisionBackend):
    """
    Mock 视觉后端。

    生成结构合法的占位观察结果，每帧基于时间戳生成差异化描述。
    使测试可以在无 GPU/Vision API 环境下完整运行。
    """

    # 预设场景库（按时间区间轮换，模拟视频内容变化）
    _SCENES = [
        "outdoor_ground_preparation",
        "equipment_setup",
        "balloon_inflation",
        "launch_sequence",
        "low_altitude_ascent",
        "mid_altitude_ascent",
        "high_altitude_ascent",
        "near_space_float",
        "descent",
        "landing",
    ]

    _OBJECTS_BY_SCENE = {
        "outdoor_ground_preparation": ["人员", "设备箱", "气球材料", "地面"],
        "equipment_setup": ["相机", "传感器", "气象仪器", "固定装置"],
        "balloon_inflation": ["气球", "氦气罐", "充气管", "操作人员"],
        "launch_sequence": ["气球", "有效载荷", "绳索", "操作人员"],
        "low_altitude_ascent": ["气球", "地面", "建筑物", "道路"],
        "mid_altitude_ascent": ["气球", "云层", "地面", "地平线"],
        "high_altitude_ascent": ["气球", "云层", "大气层", "地球曲率"],
        "near_space_float": ["气球", "太空黑暗背景", "地球", "大气层边界"],
        "descent": ["降落伞", "有效载荷", "云层", "地面"],
        "landing": ["有效载荷", "降落区域", "地面", "回收人员"],
    }

    def analyze_frame(
        self,
        frame_path: str,
        frame_id: int,
        timestamp_sec: float,
        filename: str,
        filepath: str,
    ) -> FrameObservation:
        if not os.path.isfile(frame_path):
            raise FrameAnalysisError(f"帧文件不存在: {frame_path}")

        # 根据时间戳选择场景（867s 分 10 段）
        scene_idx = min(int(timestamp_sec / 87), len(self._SCENES) - 1)
        scene = self._SCENES[scene_idx]
        objects = self._OBJECTS_BY_SCENE.get(scene, ["未知物体"])

        observations = [
            f"[MockVision t={timestamp_sec:.1f}s] 画面显示{scene}阶段",
            f"画面中可见 {len(objects)} 类主要元素",
            f"帧序号 {frame_id}，时间戳 {timestamp_sec:.1f}s",
        ]

        uncertain_points = [
            f"[Mock] 真实视觉分析需要 Vision Model，当前为占位结果",
        ]

        return FrameObservation(
            frame_id=frame_id,
            filename=filename,
            timestamp_sec=timestamp_sec,
            filepath=filepath,
            observations=observations,
            objects=objects,
            scene=scene,
            confidence=0.0,   # mock 不提供置信度
            uncertain_points=uncertain_points,
        )


class VisionAPIBackend(VisionBackend):
    """
    真实 Vision API 后端（接口预留，未实现）。

    接入方式：
      1. OpenAI GPT-4o Vision: POST /chat/completions with image_url
      2. Google Gemini Vision: generateContent with inlineData
      3. 本地 LLaVA/InternVL: local inference server

    实现时需覆盖 analyze_frame()，返回 FrameObservation。
    """

    def __init__(self, api_key: str = None, model: str = "gpt-4o"):
        self.api_key = api_key
        self.model = model

    def analyze_frame(
        self,
        frame_path: str,
        frame_id: int,
        timestamp_sec: float,
        filename: str,
        filepath: str,
    ) -> FrameObservation:
        raise NotImplementedError(
            "VisionAPIBackend.analyze_frame() 未实现。"
            "请实现具体 Vision API 调用逻辑。"
        )


class OpenClawVisionBackend(VisionBackend):
    """
    OpenClaw 原生图片理解后端。

    使用模型原生图片理解能力分析每一帧：
    - 读取 JPEG 文件
    - 输出 objects / scene / observable_facts / uncertain_points
    - 不依赖外部 API，不依赖文件名或元数据推断内容
    - 仅报告图片中直接可观察到的事实
    """

    def analyze_frame(
        self,
        frame_path: str,
        frame_id: int,
        timestamp_sec: float,
        filename: str,
        filepath: str,
    ) -> FrameObservation:
        if not os.path.isfile(frame_path):
            raise FrameAnalysisError(f"帧文件不存在: {frame_path}")

        # 读取图片内容（base64 供模型消费）
        import base64
        with open(frame_path, "rb") as f:
            img_b64 = base64.b64encode(f.read()).decode("utf-8")

        # 调用 OpenClaw 原生视觉理解
        result = self._call_vision(img_b64, frame_id, timestamp_sec)
        return result

    def _call_vision(
        self,
        img_b64: str,
        frame_id: int,
        timestamp_sec: float,
    ) -> FrameObservation:
        """
        内部方法：调用模型视觉分析并解析结果。

        注意：此方法在 service 层被调用，但实际视觉推理
        通过 run_frame_analysis_production.py 脚本逐帧传入模型完成。
        service 层不直接调用 LLM API，而是期望调用者注入观察结果。
        """
        raise NotImplementedError(
            "OpenClawVisionBackend._call_vision() 需要通过生产脚本驱动，"
            "不支持在 service 层直接调用。"
            "请使用 scripts/run_frame_analysis_openclaw.py"
        )

    @classmethod
    def from_observation_dict(cls, obs_dict: dict, filename: str, filepath: str) -> FrameObservation:
        """
        从外部传入的观察字典构建 FrameObservation。
        供生产脚本在完成模型推理后调用。
        """
        return FrameObservation(
            frame_id=obs_dict["frame_id"],
            filename=filename,
            timestamp_sec=obs_dict["timestamp_sec"],
            filepath=filepath,
            objects=obs_dict.get("objects", []),
            scene=obs_dict.get("scene", ""),
            observable_facts=obs_dict.get("observable_facts", []),
            uncertain_points=obs_dict.get("uncertain_points", []),
            observations=obs_dict.get("observable_facts", []),  # legacy 兼容
            confidence=obs_dict.get("confidence", 0.0),
        )


def _select_backend() -> VisionBackend:
    """自动选择可用的后端（当前默认 Mock）。"""
    return MockVisionBackend()


def build_result_from_dicts(
    source_root: str,
    observations_list: list,
) -> FrameAnalysisResult:
    """
    从外部传入的观察字典列表构建 FrameAnalysisResult 并写入 frame_observations.json。

    供 OpenClaw 原生视觉生产脚本使用：
    脚本逐帧完成模型推理后，将所有结果以列表形式传入此函数持久化。

    Args:
        source_root:       source 目录路径
        observations_list: 观察字典列表，每项包含
                           frame_id / timestamp_sec / filename / filepath /
                           objects / scene / observable_facts / uncertain_points

    Returns:
        FrameAnalysisResult
    """
    import json as _json

    metadata_path = os.path.join(source_root, "metadata", "source.json")
    if not os.path.isfile(metadata_path):
        raise FrameAnalysisError(f"source.json 不存在: {metadata_path}")
    with open(metadata_path, "r", encoding="utf-8") as f:
        meta = _json.load(f)
    source_id = meta.get("source_id", "unknown")

    observations = [
        OpenClawVisionBackend.from_observation_dict(
            obs,
            filename=obs.get("filename", ""),
            filepath=obs.get("filepath", ""),
        )
        for obs in observations_list
    ]

    result = FrameAnalysisResult(
        source_id=source_id,
        total_frames=len(observations),
        backend_used="openclaw_vision",
        observations=observations,
    )

    out_path = os.path.join(source_root, "extracted", "frame_observations.json")
    with open(out_path, "w", encoding="utf-8") as f:
        _json.dump({
            "source_id": result.source_id,
            "total_frames": result.total_frames,
            "backend_used": result.backend_used,
            "observations": [
                {
                    "frame_id": o.frame_id,
                    "filename": o.filename,
                    "timestamp_sec": o.timestamp_sec,
                    "filepath": o.filepath,
                    "objects": o.objects,
                    "scene": o.scene,
                    "observable_facts": o.observable_facts,
                    "uncertain_points": o.uncertain_points,
                }
                for o in result.observations
            ],
        }, f, ensure_ascii=False, indent=2)

    return result


# ---------------------------------------------------------------------------
# 主服务
# ---------------------------------------------------------------------------

def analyze_frames(
    source_root: str,
    backend: Optional[VisionBackend] = None,
    max_frames: Optional[int] = None,
) -> FrameAnalysisResult:
    """
    对 extracted/frames/ 中的帧进行视觉分析。

    Args:
        source_root: source 目录路径
        backend:     可选后端（默认 MockVisionBackend）
        max_frames:  最多分析帧数（None = 全部）

    Returns:
        FrameAnalysisResult

    Raises:
        FrameAnalysisError: 输入缺失或分析失败
    """
    # 1. 读取 source.json
    metadata_path = os.path.join(source_root, "metadata", "source.json")
    if not os.path.isfile(metadata_path):
        raise FrameAnalysisError(f"source.json 不存在: {metadata_path}")

    with open(metadata_path, "r", encoding="utf-8") as f:
        meta = json.load(f)
    source_id = meta.get("source_id", "unknown")

    # 2. 读取 frame_metadata.json
    frame_meta_path = os.path.join(source_root, "extracted", "frame_metadata.json")
    if not os.path.isfile(frame_meta_path):
        raise FrameAnalysisError(
            f"frame_metadata.json 不存在: {frame_meta_path}\n"
            "请先运行 Frame Extraction Layer。"
        )

    with open(frame_meta_path, "r", encoding="utf-8") as f:
        frame_meta = json.load(f)

    frames_list = frame_meta.get("frames", [])
    if not frames_list:
        raise FrameAnalysisError("frame_metadata.json 中 frames 列表为空")

    frames_dir = os.path.join(source_root, "extracted", "frames")

    # 3. 选择后端
    if backend is None:
        backend = _select_backend()

    backend_name = type(backend).__name__.replace("Backend", "").lower()

    # 4. 分析每一帧
    if max_frames is not None:
        frames_list = frames_list[:max_frames]

    observations: List[FrameObservation] = []
    for fr in frames_list:
        frame_path = os.path.join(frames_dir, fr["filename"])
        obs = backend.analyze_frame(
            frame_path=frame_path,
            frame_id=fr["index"],
            timestamp_sec=fr["timestamp_sec"],
            filename=fr["filename"],
            filepath=fr["filepath"],
        )
        observations.append(obs)

    result = FrameAnalysisResult(
        source_id=source_id,
        total_frames=len(observations),
        backend_used=backend_name,
        observations=observations,
    )

    # 5. 写入 frame_observations.json
    out_path = os.path.join(source_root, "extracted", "frame_observations.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump({
            "source_id": result.source_id,
            "total_frames": result.total_frames,
            "backend_used": result.backend_used,
            "observations": [
                {
                    "frame_id": o.frame_id,
                    "filename": o.filename,
                    "timestamp_sec": o.timestamp_sec,
                    "filepath": o.filepath,
                    "objects": o.objects,
                    "scene": o.scene,
                    "observable_facts": o.observable_facts,
                    "observations": o.observations,  # legacy 兼容
                    "confidence": o.confidence,
                    "uncertain_points": o.uncertain_points,
                }
                for o in result.observations
            ],
        }, f, ensure_ascii=False, indent=2)

    return result
