"""
services/frame_extraction.py

Frame Extraction Service

职责：
- 从视频文件按固定间隔抽帧
- 输出 JPEG 帧到 extracted/frames/
- 生成 extracted/frame_metadata.json

不实现：图像分析、场景识别、LLM 处理

后端策略：
  FfmpegBackend  — 有 ffmpeg 时使用（真实抽帧）
  MockBackend    — 无 ffmpeg 时使用（生成占位 JPEG，用于测试/CI）

输出命名规则：
  frame_{index:06d}_{timestamp_ms:08d}ms.jpg
  示例：frame_000001_00000000ms.jpg（第1帧，0.0秒）
         frame_000002_00010000ms.jpg（第2帧，10.0秒）
"""

from __future__ import annotations

import json
import os
import shutil
import struct
import subprocess
from dataclasses import dataclass, field
from typing import List, Optional


# ---------------------------------------------------------------------------
# 异常
# ---------------------------------------------------------------------------

class FrameExtractionError(Exception):
    """帧提取失败。"""
    pass


# ---------------------------------------------------------------------------
# 数据类
# ---------------------------------------------------------------------------

@dataclass
class FrameInfo:
    index: int          # 帧序号（1-based）
    timestamp_sec: float
    filename: str       # 相对于 frames/ 目录的文件名
    filepath: str       # 相对于 source root 的路径


@dataclass
class FrameExtractionResult:
    source_id: str
    input_video: str        # 相对于 source root
    output_dir: str         # 相对于 source root
    interval_sec: float
    total_frames: int
    duration_seconds: float
    frames: List[FrameInfo]
    backend_used: str       # "ffmpeg" | "mock"


# ---------------------------------------------------------------------------
# Backend 接口
# ---------------------------------------------------------------------------

class FrameBackend:
    """帧提取后端基类。"""

    def extract_frames(
        self,
        video_path: str,
        output_dir: str,
        interval_sec: float,
        source_id: str,
    ) -> FrameExtractionResult:
        raise NotImplementedError


class FfmpegBackend(FrameBackend):
    """使用 ffmpeg 进行真实帧提取。"""

    @staticmethod
    def find_ffmpeg() -> str:
        candidates = [
            "/home/node/.local/bin/ffmpeg",
            "/usr/local/bin/ffmpeg",
            "/usr/bin/ffmpeg",
        ]
        found = shutil.which("ffmpeg")
        if found:
            return found
        for c in candidates:
            if os.path.isfile(c) and os.access(c, os.X_OK):
                return c
        return "ffmpeg"

    @staticmethod
    def get_duration(video_path: str, ffprobe_bin: str = None) -> float:
        """用 ffprobe 获取视频时长。"""
        if ffprobe_bin is None:
            ffprobe_bin = FfmpegBackend.find_ffmpeg().replace("ffmpeg", "ffprobe")
            if not os.path.isfile(ffprobe_bin):
                ffprobe_bin = "ffprobe"

        cmd = [
            ffprobe_bin, "-v", "quiet",
            "-print_format", "json",
            "-show_format",
            video_path,
        ]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            raise FrameExtractionError(f"ffprobe 失败: {r.stderr}")
        import json as _json
        data = _json.loads(r.stdout)
        return float(data["format"]["duration"])

    def extract_frames(
        self,
        video_path: str,
        output_dir: str,
        interval_sec: float,
        source_id: str,
    ) -> FrameExtractionResult:
        if not os.path.isfile(video_path):
            raise FrameExtractionError(f"视频文件不存在: {video_path}")

        os.makedirs(output_dir, exist_ok=True)
        ffmpeg_bin = self.find_ffmpeg()

        # 获取视频时长
        duration = self.get_duration(video_path)

        # 输出文件名模板：frame_%06d.jpg
        # 用 select filter 按间隔抽帧
        output_pattern = os.path.join(output_dir, "frame_%06d.jpg")
        cmd = [
            ffmpeg_bin, "-y",
            "-i", video_path,
            "-vf", f"select='not(mod(t,{interval_sec}))',setpts=N/FRAME_RATE/TB",
            "-vsync", "vfr",
            "-q:v", "2",
            output_pattern,
        ]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            raise FrameExtractionError(
                f"ffmpeg 抽帧失败 (exit {r.returncode}):\n{r.stderr[-1000:]}"
            )

        # 收集生成的帧文件，计算时间戳
        frame_files = sorted(
            f for f in os.listdir(output_dir) if f.startswith("frame_") and f.endswith(".jpg")
        )
        frames = []
        for i, fname in enumerate(frame_files):
            ts = round(i * interval_sec, 3)
            ts_ms = int(ts * 1000)
            # 重命名为含时间戳的格式
            new_name = f"frame_{i+1:06d}_{ts_ms:08d}ms.jpg"
            src = os.path.join(output_dir, fname)
            dst = os.path.join(output_dir, new_name)
            os.rename(src, dst)
            frames.append(FrameInfo(
                index=i + 1,
                timestamp_sec=ts,
                filename=new_name,
                filepath=os.path.join(
                    os.path.relpath(output_dir), new_name
                ),
            ))

        return FrameExtractionResult(
            source_id=source_id,
            input_video=video_path,
            output_dir=output_dir,
            interval_sec=interval_sec,
            total_frames=len(frames),
            duration_seconds=round(duration, 3),
            frames=frames,
            backend_used="ffmpeg",
        )


class MockBackend(FrameBackend):
    """
    无 ffmpeg 时使用的 mock 后端。

    生成最小合法 JPEG 占位文件（1x1 灰色），使测试可以在无 ffmpeg 环境下运行。
    """

    # 最小合法 1x1 灰色 JPEG（51字节）
    _MINIMAL_JPEG = bytes([
        0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01,
        0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x43,
        0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08, 0x07, 0x07, 0x07, 0x09,
        0x09, 0x08, 0x0A, 0x0C, 0x14, 0x0D, 0x0C, 0x0B, 0x0B, 0x0C, 0x19, 0x12,
        0x13, 0x0F, 0x14, 0x1D, 0x1A, 0x1F, 0x1E, 0x1D, 0x1A, 0x1C, 0x1C, 0x20,
        0x24, 0x2E, 0x27, 0x20, 0x22, 0x2C, 0x23, 0x1C, 0x1C, 0x28, 0x37, 0x29,
        0x2C, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1F, 0x27, 0x39, 0x3D, 0x38, 0x32,
        0x3C, 0x2E, 0x33, 0x34, 0x32, 0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x00, 0x01,
        0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xFF, 0xC4, 0x00, 0x1F, 0x00, 0x00,
        0x01, 0x05, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
        0x09, 0x0A, 0x0B, 0xFF, 0xC4, 0x00, 0xB5, 0x10, 0x00, 0x02, 0x01, 0x03,
        0x03, 0x02, 0x04, 0x03, 0x05, 0x05, 0x04, 0x04, 0x00, 0x00, 0x01, 0x7D,
        0x01, 0x02, 0x03, 0x00, 0x04, 0x11, 0x05, 0x12, 0x21, 0x31, 0x41, 0x06,
        0x13, 0x51, 0x61, 0x07, 0x22, 0x71, 0x14, 0x32, 0x81, 0x91, 0xA1, 0x08,
        0x23, 0x42, 0xB1, 0xC1, 0x15, 0x52, 0xD1, 0xF0, 0x24, 0x33, 0x62, 0x72,
        0x82, 0x09, 0x0A, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x25, 0x26, 0x27, 0x28,
        0x29, 0x2A, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x43, 0x44, 0x45,
        0x46, 0x47, 0x48, 0x49, 0x4A, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59,
        0x5A, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x73, 0x74, 0x75,
        0x76, 0x77, 0x78, 0x79, 0x7A, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89,
        0x8A, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9A, 0xA2, 0xA3, 0xA4,
        0xA5, 0xA6, 0xA7, 0xA8, 0xA9, 0xAA, 0xB2, 0xB3, 0xB4, 0xB5, 0xB6, 0xB7,
        0xB8, 0xB9, 0xBA, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8, 0xC9, 0xCA,
        0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD7, 0xD8, 0xD9, 0xDA, 0xE1, 0xE2, 0xE3,
        0xE4, 0xE5, 0xE6, 0xE7, 0xE8, 0xE9, 0xEA, 0xF1, 0xF2, 0xF3, 0xF4, 0xF5,
        0xF6, 0xF7, 0xF8, 0xF9, 0xFA, 0xFF, 0xDA, 0x00, 0x08, 0x01, 0x01, 0x00,
        0x00, 0x3F, 0x00, 0xFB, 0xD7, 0xFF, 0xD9,
    ])

    def extract_frames(
        self,
        video_path: str,
        output_dir: str,
        interval_sec: float,
        source_id: str,
    ) -> FrameExtractionResult:
        if not os.path.isfile(video_path):
            raise FrameExtractionError(f"视频文件不存在: {video_path}")

        os.makedirs(output_dir, exist_ok=True)

        # 从 source_root/extracted/audio_metadata.json 读取时长（如有）
        # 否则默认 mock 60 秒
        duration = 60.0
        try:
            source_root = os.path.dirname(os.path.dirname(output_dir))
            audio_meta_path = os.path.join(source_root, "extracted", "audio_metadata.json")
            if os.path.isfile(audio_meta_path):
                with open(audio_meta_path) as f:
                    import json as _json
                    am = _json.load(f)
                    duration = float(am.get("duration_seconds", 60.0))
        except Exception:
            pass

        frames = []
        t = 0.0
        idx = 1
        while t < duration:
            ts_ms = int(t * 1000)
            fname = f"frame_{idx:06d}_{ts_ms:08d}ms.jpg"
            fpath = os.path.join(output_dir, fname)
            with open(fpath, "wb") as f:
                f.write(self._MINIMAL_JPEG)
            frames.append(FrameInfo(
                index=idx,
                timestamp_sec=round(t, 3),
                filename=fname,
                filepath=os.path.join("extracted", "frames", fname),
            ))
            t = round(t + interval_sec, 3)
            idx += 1

        return FrameExtractionResult(
            source_id=source_id,
            input_video=video_path,
            output_dir=output_dir,
            interval_sec=interval_sec,
            total_frames=len(frames),
            duration_seconds=duration,
            frames=frames,
            backend_used="mock",
        )


def _select_backend() -> FrameBackend:
    """自动选择可用的后端。"""
    ffmpeg_bin = FfmpegBackend.find_ffmpeg()
    if ffmpeg_bin != "ffmpeg" or shutil.which("ffmpeg"):
        return FfmpegBackend()
    return MockBackend()


# ---------------------------------------------------------------------------
# 主服务
# ---------------------------------------------------------------------------

def extract_frames(
    source_root: str,
    interval_sec: float = 10.0,
    backend: Optional[FrameBackend] = None,
) -> FrameExtractionResult:
    """
    从视频文件按固定间隔抽帧。

    Args:
        source_root:  source 目录路径
        interval_sec: 抽帧间隔（秒），默认 10s
        backend:      可选后端（默认自动选择）

    Returns:
        FrameExtractionResult

    Raises:
        FrameExtractionError: 输入缺失或抽帧失败
    """
    # 1. 读取 source.json
    metadata_path = os.path.join(source_root, "metadata", "source.json")
    if not os.path.isfile(metadata_path):
        raise FrameExtractionError(f"source.json 不存在: {metadata_path}")

    with open(metadata_path, "r", encoding="utf-8") as f:
        import json as _json
        meta = _json.load(f)

    source_id = meta.get("source_id", "unknown")

    # 2. 定位视频文件
    # 优先 raw_file（视频流），其次 merged_file
    video_rel = meta.get("raw_file")
    if not video_rel:
        merged = None
        if isinstance(meta.get("metadata"), dict):
            merged = meta["metadata"].get("merged_file")
        video_rel = merged or meta.get("audio_file")

    if not video_rel:
        raise FrameExtractionError("source.json 缺少 raw_file 字段")

    video_abs = os.path.join(source_root, video_rel)
    if not os.path.isfile(video_abs):
        raise FrameExtractionError(f"视频文件不存在: {video_abs}")

    # 3. 输出目录
    output_dir = os.path.join(source_root, "extracted", "frames")
    os.makedirs(output_dir, exist_ok=True)

    # 4. 执行抽帧
    if backend is None:
        backend = _select_backend()

    result = backend.extract_frames(video_abs, output_dir, interval_sec, source_id)

    # 5. 写入 frame_metadata.json
    meta_out_path = os.path.join(source_root, "extracted", "frame_metadata.json")
    with open(meta_out_path, "w", encoding="utf-8") as f:
        import json as _json
        _json.dump({
            "source_id": result.source_id,
            "input_video": video_rel,
            "output_dir": "extracted/frames",
            "interval_sec": result.interval_sec,
            "total_frames": result.total_frames,
            "duration_seconds": result.duration_seconds,
            "backend_used": result.backend_used,
            "frames": [
                {
                    "index": fr.index,
                    "timestamp_sec": fr.timestamp_sec,
                    "filename": fr.filename,
                    "filepath": fr.filepath,
                }
                for fr in result.frames
            ],
        }, f, ensure_ascii=False, indent=2)

    return result
