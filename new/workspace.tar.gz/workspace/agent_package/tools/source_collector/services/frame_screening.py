"""
services/frame_screening.py

Frame Screening Layer

职责：
- 基于确定性规则从全量帧中筛选候选帧
- 保证时间覆盖（起始/中段/结尾均有代表帧）
- 不调用任何 Vision API
- 输出 extracted/candidate_frames.json

筛选规则：
  1. 均匀采样：每 N 帧取一帧，覆盖全时间轴
  2. 强制包含端点：第一帧 + 最后一帧
  3. 强制包含关键时间节点：可配置的时间窗口（如 0%, 25%, 50%, 75%, 100%）
  4. 去重：多规则命中同一帧时只保留一次

candidate_frames.json schema:
{
  "source_id": str,
  "total_frames": int,           # 原始全量帧数
  "candidate_count": int,        # 筛选后候选帧数
  "selection_strategy": str,     # 筛选策略描述
  "candidates": [
    {
      "frame_id": int,
      "filename": str,
      "timestamp_sec": float,
      "filepath": str,
      "selection_reason": [str]  # 命中的规则列表
    }
  ]
}
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import List, Optional


# ---------------------------------------------------------------------------
# 异常
# ---------------------------------------------------------------------------

class FrameScreeningError(Exception):
    """帧筛选失败。"""
    pass


# ---------------------------------------------------------------------------
# 数据类
# ---------------------------------------------------------------------------

@dataclass
class CandidateFrame:
    frame_id: int
    filename: str
    timestamp_sec: float
    filepath: str
    selection_reason: List[str]


@dataclass
class FrameScreeningResult:
    source_id: str
    total_frames: int
    candidate_count: int
    selection_strategy: str
    candidates: List[CandidateFrame]


# ---------------------------------------------------------------------------
# 筛选规则
# ---------------------------------------------------------------------------

def _select_uniform(frames: list, step: int) -> dict:
    """均匀采样：每 step 帧取一帧，返回 {frame_id: reason}。"""
    selected = {}
    for i, fr in enumerate(frames):
        if i % step == 0:
            fid = fr["index"]
            selected[fid] = selected.get(fid, []) + [f"uniform_sample(step={step})"]
    return selected


def _select_endpoints(frames: list) -> dict:
    """强制包含第一帧和最后一帧。"""
    selected = {}
    if frames:
        selected[frames[0]["index"]] = ["endpoint_first"]
        selected[frames[-1]["index"]] = ["endpoint_last"]
    return selected


def _select_time_percentiles(frames: list, percentiles: list) -> dict:
    """
    按时间百分位选帧。
    percentiles: [0.0, 0.25, 0.5, 0.75, 1.0]
    对每个百分位找距离最近的帧。
    """
    if not frames:
        return {}
    duration = frames[-1]["timestamp_sec"]
    if duration <= 0:
        return {}

    selected = {}
    for pct in percentiles:
        target_ts = duration * pct
        # 找最近帧
        closest = min(frames, key=lambda f: abs(f["timestamp_sec"] - target_ts))
        fid = closest["index"]
        reason = f"time_percentile({int(pct*100)}%)"
        if fid in selected:
            selected[fid] = selected[fid] + [reason]
        else:
            selected[fid] = [reason]
    return selected


def _merge_selections(*dicts) -> dict:
    """合并多个 {frame_id: [reasons]} 字典，同一 frame_id 的 reasons 合并去重。"""
    merged = {}
    for d in dicts:
        for fid, reasons in d.items():
            if fid in merged:
                existing = set(merged[fid])
                merged[fid] = merged[fid] + [r for r in reasons if r not in existing]
            else:
                merged[fid] = list(reasons)
    return merged


# ---------------------------------------------------------------------------
# 主服务
# ---------------------------------------------------------------------------

def screen_frames(
    source_root: str,
    uniform_step: int = 5,
    time_percentiles: Optional[List[float]] = None,
    min_candidates: int = 10,
    max_candidates: int = 30,
) -> FrameScreeningResult:
    """
    基于确定性规则筛选候选帧。

    Args:
        source_root:       source 目录路径
        uniform_step:      均匀采样步长（每 N 帧取一帧）
        time_percentiles:  时间百分位列表，默认 [0, 0.1, 0.25, 0.5, 0.75, 0.9, 1.0]
        min_candidates:    最少候选帧数（不足时减小 step）
        max_candidates:    最多候选帧数（超出时增大 step）

    Returns:
        FrameScreeningResult

    Raises:
        FrameScreeningError: 输入缺失或筛选失败
    """
    # 1. 读取 source.json
    metadata_path = os.path.join(source_root, "metadata", "source.json")
    if not os.path.isfile(metadata_path):
        raise FrameScreeningError(f"source.json 不存在: {metadata_path}")
    with open(metadata_path, "r", encoding="utf-8") as f:
        meta = json.load(f)
    source_id = meta.get("source_id", "unknown")

    # 2. 读取 frame_metadata.json
    frame_meta_path = os.path.join(source_root, "extracted", "frame_metadata.json")
    if not os.path.isfile(frame_meta_path):
        raise FrameScreeningError(
            f"frame_metadata.json 不存在: {frame_meta_path}\n"
            "请先运行 Frame Extraction Layer。"
        )
    with open(frame_meta_path, "r", encoding="utf-8") as f:
        frame_meta = json.load(f)

    frames = frame_meta.get("frames", [])
    if not frames:
        raise FrameScreeningError("frame_metadata.json 中 frames 列表为空")

    total_frames = len(frames)

    # 3. 默认百分位
    if time_percentiles is None:
        time_percentiles = [0.0, 0.1, 0.25, 0.5, 0.75, 0.9, 1.0]

    # 4. 自动调整 uniform_step 以满足 min/max 约束
    step = uniform_step
    while True:
        uniform = _select_uniform(frames, step)
        endpoints = _select_endpoints(frames)
        percentiles = _select_time_percentiles(frames, time_percentiles)
        merged = _merge_selections(uniform, endpoints, percentiles)
        count = len(merged)
        if count < min_candidates and step > 1:
            step = max(1, step - 1)
        elif count > max_candidates and step < total_frames:
            step += 1
        else:
            break
        # 防止死循环
        if step >= total_frames:
            break

    # 5. 构建候选列表（按 frame_id 排序）
    frame_map = {fr["index"]: fr for fr in frames}
    candidates = []
    for fid in sorted(merged.keys()):
        fr = frame_map[fid]
        candidates.append(CandidateFrame(
            frame_id=fid,
            filename=fr["filename"],
            timestamp_sec=fr["timestamp_sec"],
            filepath=fr["filepath"],
            selection_reason=merged[fid],
        ))

    strategy = (
        f"uniform_step={step}, "
        f"time_percentiles={time_percentiles}, "
        f"endpoints=True"
    )

    result = FrameScreeningResult(
        source_id=source_id,
        total_frames=total_frames,
        candidate_count=len(candidates),
        selection_strategy=strategy,
        candidates=candidates,
    )

    # 6. 写入 candidate_frames.json
    out_path = os.path.join(source_root, "extracted", "candidate_frames.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump({
            "source_id": result.source_id,
            "total_frames": result.total_frames,
            "candidate_count": result.candidate_count,
            "selection_strategy": result.selection_strategy,
            "candidates": [
                {
                    "frame_id": c.frame_id,
                    "filename": c.filename,
                    "timestamp_sec": c.timestamp_sec,
                    "filepath": c.filepath,
                    "selection_reason": c.selection_reason,
                }
                for c in result.candidates
            ],
        }, f, ensure_ascii=False, indent=2)

    return result
