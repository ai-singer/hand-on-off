"""
Global generation context — all 9 prompts built from shared anchors + global plan.
REFERENCE_CONDITIONING_AVAILABLE = false (text-to-image only backend)
"""

SHARED_ANCHOR_BLOCK = """
SHARED ENTITY ANCHORS (must be respected across all images in this project):

PAYLOAD: plain white or light-colored foam/styrofoam rectangular box, simple rope attachment, no markings or labels. In early phases: clean. In recovery: may show dirt/wear.

BALLOON: large white spherical balloon. Connected to payload via flexible braided rope/tether. NOT a hot air balloon. NOT a rigid pole or metal mast.

TEAM: crew wearing olive green insulated parkas, fur-trimmed hoods, black work gloves. No logos, no badges, no orange uniforms, no reflective strips, no national flags.

ENVIRONMENT: snowy winter outdoor terrain throughout all phases. No warm-season green farmland. No tropical environment.

RULES: No text, no labels, no watermarks, no timestamps, no platform UI, no subtitles, no invented names, no organizational insignia. Photorealistic documentary style.
"""

SLOTS = [
    {
        "image_id": "global_img_001",
        "assigned_post": "post_001",
        "event_state": "STATE_001",
        "keyframe_state": "title_card_or_early_preparation",
        "timestamp": 0.0,
        "camera": "ground_level",
        "transition_role": "state_entry",
        "prompt": f"""{SHARED_ANCHOR_BLOCK}

EVENT STATE: STATE_001 — Launch preparation, ground level, early phase.
KEYFRAME STATE: title_card_or_early_preparation
CAMERA: ground-level handheld or tripod, wide shot of launch site.
REQUIRED: snowy open field, crew in olive green winter parkas beginning preparation, large white balloon visible but not yet fully inflated, cold winter daylight.
FORBIDDEN: fully inflated balloon ready for release, balloon already airborne, earth curvature, black sky, orange uniforms.

Generate: Documentary wide-angle shot of a scientific balloon launch preparation site in winter. Snowy open field. A large white balloon is partially visible on the ground, not yet fully inflated. Several people in heavy olive green insulated parkas with fur-trimmed hoods and black work gloves are working around the equipment. Cold winter daylight. Low rolling hills in background. Photorealistic documentary style."""
    },
    {
        "image_id": "global_img_002",
        "assigned_post": "post_001",
        "event_state": "STATE_001",
        "keyframe_state": "balloon_fully_inflated_pre_release",
        "timestamp": 90.0,
        "camera": "ground_level",
        "transition_role": "state_progression",
        "prompt": f"""{SHARED_ANCHOR_BLOCK}

EVENT STATE: STATE_001 — Launch preparation, balloon fully inflated.
KEYFRAME STATE: balloon_fully_inflated_pre_release
CAMERA: ground-level wide shot, balloon dominates upper frame.
REQUIRED: large white fully inflated spherical balloon, plain foam payload box with multiple equipment boxes strung on rope below balloon, crew in olive green parkas gathering below, orange-pink dusk or dawn sky, snowy ground.
FORBIDDEN: partially deflated balloon, balloon airborne, earth curvature, black sky.

Generate: Documentary photograph of a fully inflated large white spherical scientific balloon on the ground at dusk or dawn. Multiple plain foam equipment boxes are strung on a rope below the balloon. Crew in heavy olive green insulated parkas with fur-trimmed hoods and black gloves are gathered around the base. Orange-pink gradient sky contrasts with cold white snow below. Photorealistic documentary style."""
    },
    {
        "image_id": "global_img_003",
        "assigned_post": "post_001",
        "event_state": "STATE_001",
        "keyframe_state": "release_preparation_upward_angle",
        "timestamp": 100.0,
        "camera": "ground_level_upward_angle",
        "transition_role": "state_exit",
        "prompt": f"""{SHARED_ANCHOR_BLOCK}

EVENT STATE: STATE_001 — Release preparation, upward-looking angle.
KEYFRAME STATE: release_preparation_upward_angle
CAMERA: ground-level looking upward at balloon, balloon dominates frame.
REQUIRED: fully inflated white balloon filling upper frame viewed from below, flexible tether rope visible connecting downward, crew in olive green parkas visible at ground level, blue or gradient sky background.
FORBIDDEN: balloon already airborne far away, earth curvature, black sky, no crew at base.

Generate: Upward-looking documentary photograph from ground level. A large fully inflated white spherical scientific balloon fills the upper portion of the frame. The flexible rope tether hangs down toward the camera. Crew members in olive green parkas with fur-trimmed hoods and black gloves are visible at the base. Blue sky background. Photorealistic documentary style."""
    },
    {
        "image_id": "global_img_004",
        "assigned_post": "post_002",
        "event_state": "STATE_002",
        "keyframe_state": "initial_ascent",
        "timestamp": 200.0,
        "camera": "balloon_payload_camera",
        "transition_role": "state_entry",
        "prompt": f"""{SHARED_ANCHOR_BLOCK}

EVENT STATE: STATE_002 — High altitude ascent, low phase.
KEYFRAME STATE: initial_ascent
CAMERA: payload-mounted camera looking outward/downward. First-person perspective — NOT external view of balloon.
REQUIRED: snow-covered ground visible far below from payload camera, scattered clouds between camera and ground, slightly curved horizon, deep blue sky above, rope or payload edge visible at frame edge, no crew visible.
FORBIDDEN: completely black sky, Earth curvature as dominant arc, external observer view of balloon, hot air balloon gondola, text or timestamp.

Generate: First-person perspective documentary photograph from a camera mounted on a scientific payload looking downward during ascent. Snow-covered ground far below, shrinking as altitude increases. Clouds appearing between camera and ground. Deep blue sky above. A simple rope is faintly visible at the top edge of frame. No external view of balloon. Photorealistic high-altitude documentary style."""
    },
    {
        "image_id": "global_img_005",
        "assigned_post": "post_002",
        "event_state": "STATE_002",
        "keyframe_state": "atmospheric_boundary_sky_turning_black",
        "timestamp": 350.0,
        "camera": "balloon_payload_camera",
        "transition_role": "state_progression",
        "prompt": f"""{SHARED_ANCHOR_BLOCK}

EVENT STATE: STATE_002 — High altitude ascent, sky transition phase.
KEYFRAME STATE: atmospheric_boundary_sky_turning_black
CAMERA: payload-mounted camera looking outward. First-person perspective.
REQUIRED: sky transitioning from deep blue to near-black at top of frame, Earth curvature clearly visible as arc below, thin glowing blue atmosphere layer at Earth edge, cloud formations below, rope or payload element visible at frame edge.
FORBIDDEN: bright blue sky (too early), external observer view of balloon, full star field.

Generate: First-person perspective documentary photograph from balloon payload camera at approximately 25km altitude. Sky above is near-black. Earth curvature spans across the lower portion of frame. Thin glowing blue atmosphere layer at Earth edge. Cloud formations below. Rope visible at frame edge. Photorealistic near-space documentary style."""
    },
    {
        "image_id": "global_img_006",
        "assigned_post": "post_002",
        "event_state": "STATE_002",
        "keyframe_state": "maximum_altitude",
        "timestamp": 430.0,
        "camera": "balloon_payload_camera_upward",
        "transition_role": "state_exit",
        "prompt": f"""{SHARED_ANCHOR_BLOCK}

EVENT STATE: STATE_002 — Near-space peak altitude.
KEYFRAME STATE: maximum_altitude
CAMERA: payload-mounted camera looking upward at balloon above. First-person perspective.
REQUIRED: large white spherical balloon above, connected to camera by flexible tether rope visible in frame, Earth arc and thin atmosphere layer visible below/around, near-black sky. This is the payload camera looking UP at its own balloon.
FORBIDDEN: external observer view, full Earth disk as complete sphere, star field as primary background, complete absence of atmosphere layer.

Generate: First-person perspective documentary photograph from a balloon payload looking upward. A large white spherical balloon fills the upper portion of the frame, connected by a flexible tether rope. Earth curvature and thin blue atmosphere layer visible below. Near-black sky background. Photorealistic near-space documentary style."""
    },
    {
        "image_id": "global_img_007",
        "assigned_post": "post_003",
        "event_state": "STATE_003",
        "keyframe_state": "descent",
        "timestamp": 600.0,
        "camera": "balloon_payload_camera",
        "transition_role": "state_entry",
        "prompt": f"""{SHARED_ANCHOR_BLOCK}

EVENT STATE: STATE_003 — Descent phase, sky returning to blue.
KEYFRAME STATE: descent
CAMERA: payload-mounted camera looking outward/downward during descent.
REQUIRED: blue sky (returned from black — altitude decreasing), snowy ground visible below growing closer, clouds between camera and ground, rope or payload edge visible, no crew visible.
FORBIDDEN: black sky, Earth curvature arc (altitude too low), atmosphere layer at Earth edge, crew on ground, payload already landed, text or timestamp overlay, hot air balloon gondola.

Generate: First-person perspective documentary photograph from payload camera during descent. Blue sky has returned. Snowy ground visible below at distance, growing closer. White clouds around the descending payload. Simple rope visible at top edge. Plain foam payload enclosure edge visible. No text, no timestamp. Photorealistic descent documentary style."""
    },
    {
        "image_id": "global_img_008",
        "assigned_post": "post_003",
        "event_state": "STATE_003",
        "keyframe_state": "landing_or_recovery",
        "timestamp": 650.0,
        "camera": "ground_level_recovery_site",
        "transition_role": "state_progression",
        "prompt": f"""{SHARED_ANCHOR_BLOCK}

EVENT STATE: STATE_003 — Landing and recovery.
KEYFRAME STATE: landing_or_recovery
CAMERA: ground-level at recovery site.
REQUIRED: plain foam/styrofoam payload box on snow-covered ground, two or more crew in olive green insulated parkas with fur-trimmed hoods and black gloves kneeling or standing beside it, snowy open terrain, blue sky, simple rope attached to box.
FORBIDDEN: black sky, earth curvature from high altitude, balloon ascending, orange uniforms, reflective strips, logos, badges, text.

Generate: Documentary photograph of a scientific payload recovery in winter. A plain white foam box has landed on snow-covered ground. Crew members wearing heavy olive green insulated parkas with fur-trimmed hoods and black work gloves are at the recovery site examining the payload. Snowy winter terrain. Blue sky above. Simple rope attached to the foam box. Photorealistic winter recovery documentary style."""
    },
    {
        "image_id": "global_img_009",
        "assigned_post": "post_003",
        "event_state": "STATE_003",
        "keyframe_state": "post_recovery_handling",
        "timestamp": 800.0,
        "camera": "ground_level_recovery_site",
        "transition_role": "state_exit",
        "prompt": f"""{SHARED_ANCHOR_BLOCK}

EVENT STATE: STATE_003 — Post-recovery handling.
KEYFRAME STATE: post_recovery_handling
CAMERA: ground-level close-up at recovery site.
REQUIRED: crew member in olive green insulated parka with fur-trimmed hood and black work gloves holding or carrying the plain foam payload box. Snowy outdoor background. Natural cold winter light. The payload box may show wear/dirt from flight and landing.
FORBIDDEN: balloon ascending, payload airborne, black sky, orange uniforms, logos, badges, text, timestamps.

Generate: Documentary close-up photograph of a crew member in a heavy olive green insulated winter parka with fur-trimmed hood and black work gloves carrying a worn foam payload box in a snowy outdoor environment. Natural cold winter daylight. Snowy wilderness background. The box shows some weathering/dirt. Simple rope still attached. Mission completion mood. Photorealistic winter documentary style."""
    },
]

if __name__ == "__main__":
    import json
    print(json.dumps([{"image_id": s["image_id"], "assigned_post": s["assigned_post"], "state": s["event_state"], "t": s["timestamp"]} for s in SLOTS], indent=2))
    print(f"\nTotal slots: {len(SLOTS)}")
