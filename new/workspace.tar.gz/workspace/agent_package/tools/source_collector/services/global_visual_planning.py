"""
services/global_visual_planning.py

Global Visual Planning Layer — generates global_visual_plan.json and
shared_visual_anchors.json from project-wide inputs.

Responsibilities:
  - Aggregate all image slots across posts with full context
  - Identify entities that recur across posts and freeze shared anchors
  - Provide per-slot metadata: event_state, frame_refs, camera_origin,
    transition_role, visual_purpose, required_anchor_ids
  - Output cross_post_visual_validation.json schema

This service is READ-ONLY w.r.t. existing frozen artifacts.
It does not generate images.
"""

import json
import os
from typing import Any

# ---------------------------------------------------------------------------
# Entity detection helpers
# ---------------------------------------------------------------------------

ENTITY_KEYWORDS = {
    "team": [
        "人员", "操作员", "工作人员", "crew", "person", "people",
        "winter clothing", "冬季服装", "parka",
    ],
    "equipment": [
        "载荷", "设备箱", "payload", "foam box", "equipment",
        "绳索", "tether rope", "rope", "系绳", "缆绳",
    ],
    "capture_platform": [
        "气球", "balloon", "大型气球", "白色气球",
    ],
    "environment": [
        "雪地", "积雪", "snowy", "snow", "winter",
        "丘陵", "荒野", "terrain",
    ],
}


def detect_entity_type(text: str) -> list:
    """Return list of entity types matching the text."""
    found = []
    tl = text.lower()
    for etype, keywords in ENTITY_KEYWORDS.items():
        if any(kw.lower() in tl for kw in keywords):
            found.append(etype)
    return found


def is_cross_post_entity(entity_type: str, observations_by_post: dict) -> bool:
    """Return True if the entity type appears in more than one post."""
    count = sum(
        1 for obs_list in observations_by_post.values()
        if any(entity_type in detect_entity_type(o) for o in obs_list)
    )
    return count > 1


# ---------------------------------------------------------------------------
# Camera origin resolver
# ---------------------------------------------------------------------------

def resolve_camera_origin(event_state: str, keyframe_state: str) -> str:
    """
    Resolve the camera origin description for a given state.
    """
    if event_state == "STATE_001":
        return "ground_level_handheld_or_tripod"
    if event_state == "STATE_002":
        return "balloon_payload_camera"
    if event_state == "STATE_003":
        if keyframe_state in ("descent",):
            return "balloon_payload_camera"
        return "ground_level_at_recovery_site"
    return "unknown"


# ---------------------------------------------------------------------------
# Transition role classifier
# ---------------------------------------------------------------------------

def classify_transition_role(image_order: int, total_images: int) -> str:
    if image_order == 1:
        return "state_entry"
    if image_order == total_images:
        return "state_exit"
    return "state_progression"


# ---------------------------------------------------------------------------
# Main planning function
# ---------------------------------------------------------------------------

def build_global_visual_plan(
    post_plan: dict,
    keyframe_anchor: dict,
    keyframe_deltas: dict,
    capture_system: dict,
) -> dict:
    """
    Build the global visual plan from project inputs.
    Returns the global_visual_plan dict.
    """
    project_id = capture_system.get("source_id", "unknown")
    image_slots = []
    post_summaries = []
    shared_anchor_refs = []

    anchor_by_post = {p["post_id"]: p for p in keyframe_anchor["posts"]}
    deltas_by_post = {p["post_id"]: p for p in keyframe_deltas["posts"]}

    for post in post_plan["posts"]:
        pid = post["post_id"]
        a = anchor_by_post.get(pid, {})
        d = deltas_by_post.get(pid, {})
        timeline = a.get("timeline", [])
        event_state = d.get("event_state", "UNKNOWN")

        post_summaries.append({
            "post_id": pid,
            "title": post.get("title", ""),
            "event_state": event_state,
            "image_count": len(timeline),
        })

        for item in timeline:
            order = item["image_order"]
            ks = item["expected_state"]
            cam_origin = resolve_camera_origin(event_state, ks)
            role = classify_transition_role(order, len(timeline))

            # Determine required anchors for this slot
            req_anchors = []
            if event_state in ("STATE_001", "STATE_003"):
                req_anchors.append("team_anchor")
            if event_state == "STATE_001":
                req_anchors.append("balloon_anchor")
            req_anchors.append("environment_anchor")

            slot = {
                "image_id": f"{pid}_img_{order:02d}",
                "assigned_post": pid,
                "event_state": event_state,
                "keyframe_state": ks,
                "timeline_range": {
                    "representative_timestamp_sec": item["representative_timestamp_sec"],
                    "source_frame_refs": item["source_frame_refs"],
                },
                "camera_origin": cam_origin,
                "required_anchor_ids": req_anchors,
                "transition_role": role,
                "visual_purpose": item.get("expected_state_description", ks),
                "required_visual_elements": item.get("required_visual_elements", []),
                "forbidden_visual_elements": item.get("forbidden_visual_elements", []),
            }
            image_slots.append(slot)

            # Register anchors referenced
            for aid in req_anchors:
                if aid not in shared_anchor_refs:
                    shared_anchor_refs.append(aid)

    return {
        "schema_version": "GLOBAL_VISUAL_PLAN_V1.0",
        "project_id": project_id,
        "posts": post_summaries,
        "shared_anchor_refs": shared_anchor_refs,
        "image_slots": image_slots,
    }


# ---------------------------------------------------------------------------
# Shared anchor builder
# ---------------------------------------------------------------------------

def build_shared_visual_anchors(
    capture_system: dict,
    team_anchor_hint: str = "",
) -> dict:
    """
    Build the shared visual anchors for a project.
    """
    project_id = capture_system.get("source_id", "unknown")
    cs = capture_system.get("capture_system", {})
    platform_type = cs.get("platform_type", "unknown")

    anchors = {
        "team_anchor": {
            "entity_type": "team",
            "stable_attributes": [
                "olive green insulated parkas",
                "fur-trimmed hoods",
                "black work gloves",
                "6-8 people group size",
            ],
            "variable_attributes": [
                "number of visible crew members (varies by frame)",
                "specific pose and activity",
            ],
            "forbidden_variants": [
                "orange high-visibility industrial uniforms",
                "reflective strips on clothing",
                "logos or badges on clothing",
                "national flags or organizational insignia",
                "named individuals or identifiable faces",
                "military-style uniforms",
                "lab coats",
            ],
            "appears_in_posts": ["post_001", "post_003"],
            "note": "Crew in winter outdoor gear. Consistent appearance required across all posts where crew is visible."
        },
        "balloon_anchor": {
            "entity_type": "capture_platform",
            "stable_attributes": [
                "large white spherical balloon",
                "flexible tether rope connecting to payload below",
                "payload box suspended at bottom of tether",
            ],
            "variable_attributes": [
                "apparent size in frame (varies with altitude and camera angle)",
                "inflation state (partially inflated → fully inflated → deflated on recovery)",
            ],
            "forbidden_variants": [
                "rigid metal pole instead of flexible rope",
                "hot air balloon gondola basket",
                "colored or decorated balloon",
                "multiple balloons",
            ],
            "appears_in_posts": ["post_001", "post_002"],
            "note": "The balloon is a large white scientific weather/research balloon. Equipment is attached via flexible rope, not rigid structure."
        },
        "payload_anchor": {
            "entity_type": "equipment",
            "stable_attributes": [
                "plain foam or styrofoam rectangular box",
                "no markings or labels on exterior",
                "simple rope attachment point",
            ],
            "variable_attributes": [
                "may show wear/weathering in post_003 recovery images",
                "visible from different angles depending on phase",
            ],
            "forbidden_variants": [
                "metal casing with visible branding",
                "complex scientific instrument chassis",
                "labeled equipment boxes with text",
            ],
            "appears_in_posts": ["post_001", "post_002", "post_003"],
            "note": "DIY-style plain foam payload box. No logos, no labels, no text."
        },
        "environment_anchor": {
            "entity_type": "environment",
            "stable_attributes": [
                "snowy outdoor terrain",
                "winter season",
                "low rolling hills or sparse wilderness in distance",
                "cold natural light (daylight or dusk/dawn)",
            ],
            "variable_attributes": [
                "sky color changes across posts: blue (STATE_001) → near-black (STATE_002 peak) → blue again (STATE_003)",
                "ground visibility varies from full (STATE_001/003) to partial/distant (STATE_002 ascent)",
            ],
            "forbidden_variants": [
                "warm-season green farmland",
                "tropical environment",
                "urban cityscape as primary background",
                "summer terrain",
            ],
            "appears_in_posts": ["post_001", "post_002", "post_003"],
            "note": "Project took place in a winter/snow environment. All ground-level imagery must reflect winter conditions."
        },
    }

    return {
        "schema_version": "SHARED_VISUAL_ANCHORS_V1.0",
        "project_id": project_id,
        "anchors": anchors,
    }


# ---------------------------------------------------------------------------
# Cross-post validation schema builder
# ---------------------------------------------------------------------------

def build_cross_post_validation_schema(project_id: str) -> dict:
    return {
        "schema_version": "CROSS_POST_VISUAL_VALIDATION_V1.0",
        "project_id": project_id,
        "checks": {
            "same_entity_consistency": {
                "description": "Entities that appear across multiple posts must maintain stable attributes as defined in shared_visual_anchors.json",
                "check_field": "same_entity_consistency",
                "scope": "cross_post_group",
                "violation_blocks_pass": True,
            },
            "equipment_continuity": {
                "description": "The same piece of equipment (payload, balloon, rope) must be visually consistent across all posts where it appears",
                "check_field": "equipment_continuity",
                "scope": "cross_post_group",
                "violation_blocks_pass": True,
            },
            "cross_post_temporal_consistency": {
                "description": "Posts must appear in source timeline order: STATE_001 → STATE_002 → STATE_003. No post may depict a state that precedes a prior post's state.",
                "check_field": "cross_post_temporal_consistency",
                "scope": "cross_post_group",
                "violation_blocks_pass": True,
            },
            "same_event_identity": {
                "description": "All posts from the same source event must feel like they document the same event. Environment, team, equipment, and seasonal context must be consistent.",
                "check_field": "same_event_identity",
                "scope": "cross_post_group",
                "violation_blocks_pass": True,
            },
        },
    }


# ---------------------------------------------------------------------------
# CLI entry point (for direct execution)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys

    SOURCE_ROOT = os.path.join(
        os.path.dirname(__file__),
        "..", "sources", "bilibili", "ysjf", "space_camera_project"
    )

    post_plan = json.load(open(os.path.join(SOURCE_ROOT, "extracted", "post_plan.json")))
    kf_anchor = json.load(open(os.path.join(SOURCE_ROOT, "posts", "keyframe_transition_anchor.json")))
    kf_deltas = json.load(open(os.path.join(SOURCE_ROOT, "extracted", "keyframe_state_deltas.json")))
    cap_sys   = json.load(open(os.path.join(SOURCE_ROOT, "capture_system.json")))

    plan    = build_global_visual_plan(post_plan, kf_anchor, kf_deltas, cap_sys)
    anchors = build_shared_visual_anchors(cap_sys)
    xval    = build_cross_post_validation_schema(cap_sys["source_id"])

    out_plan    = os.path.join(SOURCE_ROOT, "posts", "global_visual_plan.json")
    out_anchors = os.path.join(SOURCE_ROOT, "posts", "shared_visual_anchors.json")
    out_xval    = os.path.join(SOURCE_ROOT, "validation", "cross_post_visual_validation.json")

    os.makedirs(os.path.dirname(out_xval), exist_ok=True)

    json.dump(plan,    open(out_plan,    "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(anchors, open(out_anchors, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    json.dump(xval,    open(out_xval,    "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    print(f"global_visual_plan:   {out_plan}")
    print(f"shared_visual_anchors: {out_anchors}")
    print(f"cross_post_validation: {out_xval}")
    print(f"image_slots: {len(plan['image_slots'])}")
    print(f"anchors: {list(anchors['anchors'].keys())}")
    print("Done.")
