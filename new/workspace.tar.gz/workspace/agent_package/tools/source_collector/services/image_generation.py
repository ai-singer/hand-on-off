#!/usr/bin/env python3
"""
services/image_generation.py

Image Generation Service

职责：
- 读取 visual_output.json 中的 image plan
- 调用 Gemini 图像生成 API（phanrouter-g backend）
- 保存生成的图片文件
- 输出 image_generation.json（provenance + metadata）

约束：
- 不修改任何已冻结上游 artifact
- 不使用 mock backend 作为最终 acceptance
- source frames 只作为 factual reference，不直接复制为输出
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import struct
import time
import urllib.error
import urllib.request
import zlib
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

# ---------------------------------------------------------------------------
# 错误分类
# ---------------------------------------------------------------------------

class ImageGenerationError(Exception):
    pass

class BackendMissingError(ImageGenerationError):
    error_code = "IMAGE_GENERATION_BACKEND_MISSING"

class AuthError(ImageGenerationError):
    error_code = "IMAGE_GENERATION_AUTH_ERROR"

class ProviderError(ImageGenerationError):
    error_code = "IMAGE_GENERATION_PROVIDER_ERROR"

class TimeoutError(ImageGenerationError):
    error_code = "IMAGE_GENERATION_TIMEOUT"

class InvalidResponseError(ImageGenerationError):
    error_code = "IMAGE_GENERATION_INVALID_RESPONSE"

class FileWriteError(ImageGenerationError):
    error_code = "IMAGE_GENERATION_FILE_WRITE_ERROR"

class ValidationFailedError(ImageGenerationError):
    error_code = "IMAGE_GENERATION_VALIDATION_FAILED"

class VisualPlanContractMismatchError(ImageGenerationError):
    error_code = "VISUAL_PLAN_CONTRACT_MISMATCH"


# ---------------------------------------------------------------------------
# 数据类
# ---------------------------------------------------------------------------

@dataclass
class BackendConfig:
    provider: str
    api_key: str
    base_url: str
    model_id: str
    generation_mode: str = "text_to_image"
    real_backend: bool = True


@dataclass
class ImageResult:
    visual_id: str
    output_path: str
    source_frame_refs: List[int]
    fact_refs: List[str]
    generation_prompt: str
    generation_mode: str
    width: int
    height: int
    format: str
    file_size_bytes: int
    generation_success: bool
    attempts: int
    direct_source_frame_reuse: bool = False
    auto_vision_result: Optional[str] = None
    auto_vision_notes: Optional[str] = None
    error: Optional[str] = None


@dataclass
class GenerationReport:
    post_id: str
    status: str
    backend: BackendConfig
    visual_count: int
    images: List[ImageResult]


# ---------------------------------------------------------------------------
# Backend 发现
# ---------------------------------------------------------------------------

def discover_backend(openclaw_config_path: str = None) -> BackendConfig:
    """从 openclaw.json 发现 Gemini image generation backend。"""
    if openclaw_config_path is None:
        openclaw_config_path = os.path.expanduser("~/.openclaw/openclaw.json")

    if not os.path.isfile(openclaw_config_path):
        raise BackendMissingError(f"openclaw.json 不存在: {openclaw_config_path}")

    with open(openclaw_config_path, encoding="utf-8") as f:
        config = json.load(f)

    import re
    providers = config.get("models", {}).get("providers", {})
    candidates = []
    for pname, pcfg in providers.items():
        if pcfg.get("api") != "google-generative-ai":
            continue
        for m in pcfg.get("models", []):
            mid = m.get("id", "")
            inputs = m.get("input", [])
            if "image" in inputs or re.search(r"image", mid, re.IGNORECASE):
                candidates.append(BackendConfig(
                    provider=pname,
                    api_key=pcfg["apiKey"],
                    base_url=pcfg["baseUrl"],
                    model_id=mid,
                    generation_mode="text_to_image",
                    real_backend=True,
                ))

    if not candidates:
        raise BackendMissingError("未发现任何 Gemini image generation backend")

    return candidates[0]


# ---------------------------------------------------------------------------
# 图像生成 API 调用
# ---------------------------------------------------------------------------

def _call_generate(backend: BackendConfig, prompt: str, aspect_ratio: str = "3:4",
                   timeout: int = 120) -> bytes:
    """调用 Gemini generateContent API，返回图片原始字节。"""
    body = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "responseModalities": ["TEXT", "IMAGE"],
        }
    }

    url = f"{backend.base_url}/models/{backend.model_id}:generateContent"
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode(),
        headers={
            "x-goog-api-key": backend.api_key,
            "Content-Type": "application/json",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        err_body = e.read().decode(errors="replace")[:400]
        if e.code in (401, 403):
            raise AuthError(f"Auth failed ({e.code}): {err_body}")
        raise ProviderError(f"HTTP {e.code}: {err_body}")
    except OSError as e:
        raise TimeoutError(f"Request timeout/network error: {e}")

    parts = data.get("candidates", [{}])[0].get("content", {}).get("parts", [])
    for part in parts:
        inline = part.get("inlineData") or part.get("inline_data")
        if inline and inline.get("data"):
            return base64.b64decode(inline["data"]), inline.get("mimeType", "image/jpeg")

    raise InvalidResponseError(f"API 未返回图片数据: {json.dumps(data)[:300]}")


# ---------------------------------------------------------------------------
# 图片尺寸解析
# ---------------------------------------------------------------------------

def _get_image_dimensions(data: bytes, mime: str) -> Tuple[int, int]:
    """从图片字节中提取宽高，支持 JPEG 和 PNG。"""
    try:
        if mime == "image/png" or data[:4] == b"\x89PNG":
            w = struct.unpack(">I", data[16:20])[0]
            h = struct.unpack(">I", data[20:24])[0]
            return w, h
        elif mime in ("image/jpeg", "image/jpg") or data[:2] == b"\xff\xd8":
            i = 2
            while i < len(data):
                if data[i] != 0xff:
                    break
                marker = data[i + 1]
                if marker in (0xC0, 0xC1, 0xC2):
                    h = struct.unpack(">H", data[i + 5:i + 7])[0]
                    w = struct.unpack(">H", data[i + 7:i + 9])[0]
                    return w, h
                seg_len = struct.unpack(">H", data[i + 2:i + 4])[0]
                i += 2 + seg_len
    except Exception:
        pass
    return 0, 0


# ---------------------------------------------------------------------------
# Hash 对比（防止直接复用原帧）
# ---------------------------------------------------------------------------

def _file_sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _check_not_source_frame(output_path: str, source_root: str,
                             frame_refs: List[int]) -> bool:
    """验证输出文件不是原始帧文件的直接副本。返回 True 表示安全（不同）。"""
    out_hash = _file_sha256(output_path)
    frames_dir = os.path.join(source_root, "extracted", "frames")
    if not os.path.isdir(frames_dir):
        return True
    for frame_id in frame_refs:
        # 匹配 frame_XXXXXX_*.jpg 格式
        pattern = f"frame_{frame_id:06d}"
        for fname in os.listdir(frames_dir):
            if fname.startswith(pattern):
                src_hash = _file_sha256(os.path.join(frames_dir, fname))
                if src_hash == out_hash:
                    return False
    return True


# ---------------------------------------------------------------------------
# 单张图片生成（含重试）
# ---------------------------------------------------------------------------

def _generate_one(
    backend: BackendConfig,
    visual_id: str,
    prompt: str,
    source_frame_refs: List[int],
    fact_refs: List[str],
    output_path: str,
    source_root: str,
    max_attempts: int = 3,
) -> ImageResult:
    """生成单张图片，最多重试 max_attempts 次。"""
    current_prompt = prompt
    last_error = None

    for attempt in range(1, max_attempts + 1):
        try:
            img_bytes, mime = _call_generate(backend, current_prompt)
            ext = "jpg" if "jpeg" in mime else "png"
            # 确保扩展名与实际格式一致
            base, _ = os.path.splitext(output_path)
            final_path = f"{base}.{ext}"

            os.makedirs(os.path.dirname(final_path), exist_ok=True)
            with open(final_path, "wb") as f:
                f.write(img_bytes)

            w, h = _get_image_dimensions(img_bytes, mime)
            is_safe = _check_not_source_frame(final_path, source_root, source_frame_refs)

            return ImageResult(
                visual_id=visual_id,
                output_path=final_path,
                source_frame_refs=source_frame_refs,
                fact_refs=fact_refs,
                generation_prompt=current_prompt,
                generation_mode=backend.generation_mode,
                width=w,
                height=h,
                format=ext,
                file_size_bytes=len(img_bytes),
                generation_success=True,
                attempts=attempt,
                direct_source_frame_reuse=not is_safe,
            )

        except (ProviderError, InvalidResponseError, TimeoutError) as e:
            last_error = str(e)
            # 重试时加强约束
            current_prompt = prompt + (
                " Important: absolutely no text, no watermark, no logo, "
                "no subtitles, no UI elements. Photorealistic only."
            )
            time.sleep(2)
        except (AuthError, BackendMissingError, FileWriteError):
            raise

    return ImageResult(
        visual_id=visual_id,
        output_path="",
        source_frame_refs=source_frame_refs,
        fact_refs=fact_refs,
        generation_prompt=current_prompt,
        generation_mode=backend.generation_mode,
        width=0, height=0, format="", file_size_bytes=0,
        generation_success=False,
        attempts=max_attempts,
        error=f"GENERATION_FAILED_AFTER_RETRIES: {last_error}",
    )


# ---------------------------------------------------------------------------
# 主服务：为 post_001 生成 3 张图片
# ---------------------------------------------------------------------------

def generate_post_images(
    source_root: str,
    post_id: str,
    expected_visual_count: int = 3,
    aspect_ratio: str = "3:4",
    openclaw_config_path: str = None,
) -> GenerationReport:
    """
    读取 posts/{post_id}_visual_output.json，生成全部图片。

    Args:
        source_root: project source 目录
        post_id: 帖子 ID（如 post_001）
        expected_visual_count: 期望的图片数量
        aspect_ratio: 目标宽高比（验证用，记录在 metadata）
        openclaw_config_path: 覆盖默认 openclaw.json 路径

    Returns:
        GenerationReport
    """
    # 1. 读取 visual plan
    visual_plan_path = os.path.join(source_root, "posts", f"{post_id}_visual_output.json")
    if not os.path.isfile(visual_plan_path):
        raise ValidationFailedError(f"visual_output.json 不存在: {visual_plan_path}")

    with open(visual_plan_path, encoding="utf-8") as f:
        plan = json.load(f)

    images_plan = plan.get("images", [])
    if len(images_plan) != expected_visual_count:
        raise VisualPlanContractMismatchError(
            f"VISUAL_PLAN_CONTRACT_MISMATCH: "
            f"期望 {expected_visual_count} 个 visual item，实际 {len(images_plan)}"
        )

    # 2. 发现 backend
    backend = discover_backend(openclaw_config_path)

    # 3. 准备输出目录
    output_dir = os.path.join(source_root, "posts", "images", post_id)
    os.makedirs(output_dir, exist_ok=True)

    # 4. 逐张生成
    results = []
    for idx, item in enumerate(images_plan, start=1):
        visual_id = item.get("image_id", f"{post_id}_img_{idx:02d}")
        prompt = item.get("prompt", "")
        frame_refs = item.get("based_on_frames", [])
        # 从 preserved_facts 提取 fact_refs（只有文字描述，不含 fact_id）
        # 我们从 metadata 中查不到 fact_id，所以记录 visual_goal 作为 fact ref 描述
        fact_refs = item.get("preserved_facts", [])

        # 输出路径（先用 .jpg 占位，实际格式由生成结果决定）
        output_path = os.path.join(output_dir, f"{post_id}_{idx:02d}.jpg")

        result = _generate_one(
            backend=backend,
            visual_id=visual_id,
            prompt=prompt,
            source_frame_refs=frame_refs,
            fact_refs=fact_refs,
            output_path=output_path,
            source_root=source_root,
        )
        results.append(result)

    # 5. 确定整体状态
    all_success = all(r.generation_success for r in results)
    any_reuse = any(r.direct_source_frame_reuse for r in results)
    status = "PASS_PENDING_HUMAN_REVIEW" if (all_success and not any_reuse) else "NEEDS_REPAIR"

    report = GenerationReport(
        post_id=post_id,
        status=status,
        backend=backend,
        visual_count=len(results),
        images=results,
    )

    # 6. 写入 generation metadata
    meta_path = os.path.join(source_root, "posts", f"{post_id}_image_generation.json")
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump({
            "post_id": post_id,
            "status": status,
            "backend": {
                "provider": backend.provider,
                "model": backend.model_id,
                "mode": backend.generation_mode,
                "real_backend": backend.real_backend,
            },
            "requested_aspect_ratio": aspect_ratio,
            "visual_count": len(results),
            "images": [
                {
                    "visual_id": r.visual_id,
                    "output_path": r.output_path,
                    "source_frame_refs": r.source_frame_refs,
                    "fact_refs": r.fact_refs,
                    "generation_prompt": r.generation_prompt,
                    "generation_mode": r.generation_mode,
                    "width": r.width,
                    "height": r.height,
                    "format": r.format,
                    "file_size_bytes": r.file_size_bytes,
                    "generation_success": r.generation_success,
                    "attempts": r.attempts,
                    "direct_source_frame_reuse": r.direct_source_frame_reuse,
                    "auto_vision_result": r.auto_vision_result,
                    "auto_vision_notes": r.auto_vision_notes,
                    "error": r.error,
                    "provenance": {
                        "article": "005",
                        "post_id": post_id,
                        "visual_plan_path": visual_plan_path,
                        "backend_provider": backend.provider,
                        "backend_model": backend.model_id,
                    }
                }
                for r in results
            ]
        }, f, ensure_ascii=False, indent=2)

    return report
