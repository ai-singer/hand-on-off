"""
services/keyframe_candidate_selection.py

K2A: Segment-local candidate generation + Top-K selection.

For each source segment:
  1. Identify candidate frames by multiple signals
  2. Merge candidates from same scan point
  3. Apply segment-local QuickSelect Top-K (dynamic k)
  4. Protect transition_candidate_region frames

NO expensive Vision LLM calls.
NO cross-segment diversity (that is K2B).
NO semantic classification.
"""

from __future__ import annotations

import json
import os
import time
from typing import Optional

from services.keyframe_dense_scan import select_top_k


# ---------------------------------------------------------------------------
# Config defaults (all configurable — no project-specific values hardcoded)
# ---------------------------------------------------------------------------

# Composite score weights
DEFAULT_WEIGHTS = {
    "visual_change": 0.30,
    "novelty":       0.25,
    "scene_cut":     0.20,
    "motion":        0.10,
    "quality":       0.15,
}

TRANSITION_BONUS = 0.25          # added to composite score for transition-region frames

# Dynamic local_k allocation
BASE_LOCAL_K = 1                 # minimum candidates per segment
DENSITY_SCALE = 4.0              # multiplier: high-density segment gets more candidates
MAX_LOCAL_K = 6                  # cap per segment (prevents long-segment domination)
MAX_SEGMENT_SHARE = 0.10         # single segment cannot exceed this fraction of total budget
GLOBAL_BUDGET_TARGET = 150       # target max candidates after local Top-K

# Transition window
TRANSITION_WINDOW_SEC = 2.0      # seconds before/after transition peak to find neighbour candidates


# ---------------------------------------------------------------------------
# Composite score
# ---------------------------------------------------------------------------

def composite_score(pt: dict, weights: dict = DEFAULT_WEIGHTS,
                    transition_bonus: float = 0.0) -> tuple[float, dict]:
    """Return (total_score, components_dict)."""
    components = {
        "visual_change": round(pt["visual_change_score"] * weights["visual_change"], 5),
        "novelty":       round(pt["novelty_score"]       * weights["novelty"],       5),
        "scene_cut":     round(pt["scene_cut_score"]     * weights["scene_cut"],     5),
        "motion":        round(pt["motion_score"]        * weights["motion"],        5),
        "quality":       round(pt["quality_score"]       * weights["quality"],       5),
        "transition_bonus": round(transition_bonus, 5),
    }
    total = sum(components.values())
    return round(total, 5), components


# ---------------------------------------------------------------------------
# Dynamic local_k
# ---------------------------------------------------------------------------

def dynamic_local_k(seg: dict,
                    has_transition: bool,
                    base_k: int = BASE_LOCAL_K,
                    density_scale: float = DENSITY_SCALE,
                    max_k: int = MAX_LOCAL_K) -> int:
    """
    Assign local_k to a segment based on information density and transition presence.
    Duration alone does NOT increase k.
    """
    info_density = seg.get("information_density", 0.0)
    # Scale k by density, not by duration
    k = base_k + int(info_density * density_scale)
    if has_transition:
        k += 1
    return min(k, max_k)


# ---------------------------------------------------------------------------
# Transition lookup
# ---------------------------------------------------------------------------

def build_transition_index(transition_regions: list) -> list:
    """Return list of (start, end, region_dict) sorted by start for fast lookup."""
    return sorted(
        [(r["start_sec"], r["end_sec"], r) for r in transition_regions],
        key=lambda x: x[0]
    )


def find_transition_regions_for_ts(ts: float, transition_index: list,
                                    window: float = TRANSITION_WINDOW_SEC) -> list:
    """Return list of transition region dicts that cover or are near ts."""
    result = []
    for start, end, region in transition_index:
        if (start - window) <= ts <= (end + window):
            result.append(region)
    return result


def segment_has_transition(seg: dict, transition_index: list) -> bool:
    """Check if any transition region overlaps this segment."""
    seg_start = seg["source_start_sec"]
    seg_end = seg["source_end_sec"]
    for start, end, _ in transition_index:
        if start < seg_end and end > seg_start:
            return True
    return False


# ---------------------------------------------------------------------------
# Candidate generation per segment
# ---------------------------------------------------------------------------

def generate_segment_candidates(seg: dict, seg_points: list,
                                  transition_index: list,
                                  weights: dict = DEFAULT_WEIGHTS) -> list[dict]:
    """
    Generate raw candidates for one segment from its scan points.
    Each candidate has reasons, score_components, composite score.
    Same scan point may satisfy multiple reasons — deduplicated by frame_ref.
    """
    if not seg_points:
        return []

    seg_id = seg["segment_id"]
    by_ref: dict[str, dict] = {}

    def upsert(pt: dict, reason: str):
        ref = pt["frame_ref"]
        ts = pt["source_video_timestamp_sec"]
        tc_regions = find_transition_regions_for_ts(ts, transition_index)
        is_tc = len(tc_regions) > 0
        t_bonus = TRANSITION_BONUS if is_tc else 0.0
        score, comps = composite_score(pt, weights, transition_bonus=t_bonus)

        if ref not in by_ref:
            by_ref[ref] = {
                "source_frame_ref": ref,
                "source_video_timestamp_sec": ts,
                "source_segment_id": seg_id,
                "candidate_reasons": [reason],
                "score_components": comps,
                "candidate_score": score,
                "transition_candidate": is_tc,
                "transition_region_refs": [r.get("start_sec") for r in tc_regions],
            }
        else:
            if reason not in by_ref[ref]["candidate_reasons"]:
                by_ref[ref]["candidate_reasons"].append(reason)
            # Update transition info if newly discovered
            if is_tc and not by_ref[ref]["transition_candidate"]:
                by_ref[ref]["transition_candidate"] = True
                by_ref[ref]["transition_region_refs"] = [r.get("start_sec") for r in tc_regions]
                # Recompute score with bonus
                score2, comps2 = composite_score(pt, weights, transition_bonus=t_bonus)
                by_ref[ref]["score_components"] = comps2
                by_ref[ref]["candidate_score"] = score2

    # 1. Representative: highest quality frame
    rep = max(seg_points, key=lambda p: p["quality_score"])
    upsert(rep, "representative")

    # 2. Strongest visual_change
    best_vc = max(seg_points, key=lambda p: p["visual_change_score"])
    upsert(best_vc, "visual_change_peak")

    # 3. Strongest novelty
    best_nov = max(seg_points, key=lambda p: p["novelty_score"])
    upsert(best_nov, "novelty_peak")

    # 4. Strongest scene_cut
    best_sc = max(seg_points, key=lambda p: p["scene_cut_score"])
    upsert(best_sc, "scene_cut_peak")

    # 5. Strongest motion
    best_mo = max(seg_points, key=lambda p: p["motion_score"])
    upsert(best_mo, "motion_peak")

    # 6. Transition-nearby frames: before / peak / after
    seg_start = seg["source_start_sec"]
    seg_end = seg["source_end_sec"]
    for t_start, t_end, tc_region in transition_index:
        # Check if this transition overlaps the segment
        if not (t_start < seg_end and t_end > seg_start):
            continue
        peak_ts = (t_start + t_end) / 2.0
        # before: closest scan point just before t_start
        before_pts = [p for p in seg_points if p["source_video_timestamp_sec"] < t_start]
        if before_pts:
            before_pt = max(before_pts, key=lambda p: p["source_video_timestamp_sec"])
            upsert(before_pt, "transition_before")
        # peak: closest to peak_ts
        peak_pt = min(seg_points, key=lambda p: abs(p["source_video_timestamp_sec"] - peak_ts))
        upsert(peak_pt, "transition_peak")
        # after: closest scan point just after t_end
        after_pts = [p for p in seg_points if p["source_video_timestamp_sec"] > t_end]
        if after_pts:
            after_pt = min(after_pts, key=lambda p: p["source_video_timestamp_sec"])
            upsert(after_pt, "transition_after")

    return list(by_ref.values())


# ---------------------------------------------------------------------------
# Segment-local Top-K
# ---------------------------------------------------------------------------

def local_topk(candidates: list[dict], k: int) -> list[dict]:
    """Select top-k candidates by composite score using QuickSelect."""
    return select_top_k(candidates, k=k, key=lambda c: c["candidate_score"],
                        mode="batch_quickselect")


# ---------------------------------------------------------------------------
# Main K2A pipeline
# ---------------------------------------------------------------------------

class CandidateSelector:

    def __init__(self,
                 weights: dict = None,
                 base_local_k: int = BASE_LOCAL_K,
                 density_scale: float = DENSITY_SCALE,
                 max_local_k: int = MAX_LOCAL_K,
                 max_segment_share: float = MAX_SEGMENT_SHARE,
                 global_budget: int = GLOBAL_BUDGET_TARGET):
        self.weights = weights or DEFAULT_WEIGHTS
        self.base_local_k = base_local_k
        self.density_scale = density_scale
        self.max_local_k = max_local_k
        self.max_segment_share = max_segment_share
        self.global_budget = global_budget

    def select(self, scan_result: dict, segmentation: dict) -> dict:
        """
        Run K2A: candidate generation + segment-local Top-K.
        Returns candidates dict ready for JSON output.
        """
        t_start = time.time()
        scan_points = scan_result["scan_points"]
        segments = segmentation["segments"]
        transition_regions = segmentation.get("transition_candidate_regions", [])

        # Build lookup: timestamp -> scan point
        ts_to_pt = {p["source_video_timestamp_sec"]: p for p in scan_points}

        # Build transition index
        trans_idx = build_transition_index(transition_regions)

        # Build lookup: segment -> its scan points
        seg_point_map: dict[str, list] = {s["segment_id"]: [] for s in segments}
        for pt in scan_points:
            ts = pt["source_video_timestamp_sec"]
            # Assign to segment
            for seg in segments:
                if seg["source_start_sec"] <= ts < seg["source_end_sec"]:
                    seg_point_map[seg["segment_id"]].append(pt)
                    break
            else:
                # Assign last point to last segment
                if segments:
                    seg_point_map[segments[-1]["segment_id"]].append(pt)

        # --- Phase 1: Generate raw candidates per segment ---
        all_raw: list[dict] = []
        for seg in segments:
            seg_pts = seg_point_map[seg["segment_id"]]
            raw = generate_segment_candidates(seg, seg_pts, trans_idx, self.weights)
            all_raw.extend(raw)

        raw_count = len(all_raw)

        # --- Phase 2: Segment-local Top-K (dynamic k) ---
        # Group by segment
        by_seg: dict[str, list] = {}
        for c in all_raw:
            seg_id = c["source_segment_id"]
            by_seg.setdefault(seg_id, []).append(c)

        # Compute max candidates this segment can contribute
        max_per_seg = max(1, int(self.global_budget * self.max_segment_share))

        topk_candidates: list[dict] = []
        for seg in segments:
            seg_id = seg["segment_id"]
            seg_cands = by_seg.get(seg_id, [])
            if not seg_cands:
                continue
            has_tc = segment_has_transition(seg, trans_idx)
            k = dynamic_local_k(seg, has_tc, self.base_local_k,
                                  self.density_scale, self.max_local_k)
            # Apply max_segment_share cap
            k = min(k, max_per_seg)
            selected = local_topk(seg_cands, k=k)
            topk_candidates.extend(selected)

        topk_count = len(topk_candidates)

        # --- Phase 3: Ensure transition coverage (protection pass) ---
        # Find transition regions with no coverage yet
        covered_ts = {c["source_video_timestamp_sec"] for c in topk_candidates}
        for tc_region in transition_regions:
            t_start_r = tc_region["start_sec"]
            t_end_r = tc_region["end_sec"]
            # Check if any candidate falls within this region
            region_covered = any(
                t_start_r - TRANSITION_WINDOW_SEC <= ts <= t_end_r + TRANSITION_WINDOW_SEC
                for ts in covered_ts
            )
            if not region_covered:
                # Find nearest scan point and force-add it
                peak_ts = (t_start_r + t_end_r) / 2.0
                if scan_points:
                    pt = min(scan_points, key=lambda p: abs(p["source_video_timestamp_sec"] - peak_ts))
                    # Find its segment
                    seg_id = None
                    for seg in segments:
                        if seg["source_start_sec"] <= pt["source_video_timestamp_sec"] < seg["source_end_sec"]:
                            seg_id = seg["segment_id"]
                            break
                    if seg_id is None and segments:
                        seg_id = segments[-1]["segment_id"]
                    tc_regions = find_transition_regions_for_ts(pt["source_video_timestamp_sec"], trans_idx)
                    score, comps = composite_score(pt, self.weights, TRANSITION_BONUS)
                    forced = {
                        "source_frame_ref": pt["frame_ref"],
                        "source_video_timestamp_sec": pt["source_video_timestamp_sec"],
                        "source_segment_id": seg_id,
                        "candidate_reasons": ["transition_forced_coverage"],
                        "score_components": comps,
                        "candidate_score": score,
                        "transition_candidate": True,
                        "transition_region_refs": [r.get("start_sec") for r in tc_regions],
                    }
                    topk_candidates.append(forced)
                    covered_ts.add(pt["source_video_timestamp_sec"])

        # Deduplicate by source_frame_ref (merge reasons)
        deduped: dict[str, dict] = {}
        for c in topk_candidates:
            ref = c["source_frame_ref"]
            if ref not in deduped:
                deduped[ref] = c
            else:
                for reason in c["candidate_reasons"]:
                    if reason not in deduped[ref]["candidate_reasons"]:
                        deduped[ref]["candidate_reasons"].append(reason)
                if c["transition_candidate"] and not deduped[ref]["transition_candidate"]:
                    deduped[ref]["transition_candidate"] = True
                    deduped[ref]["transition_region_refs"] = c["transition_region_refs"]
                    # Boost score
                    deduped[ref]["score_components"]["transition_bonus"] = TRANSITION_BONUS
                    deduped[ref]["candidate_score"] = round(
                        deduped[ref]["candidate_score"] + TRANSITION_BONUS, 5)

        final_candidates = list(deduped.values())
        # Sort by timestamp for readability
        final_candidates.sort(key=lambda c: c["source_video_timestamp_sec"])

        elapsed = round(time.time() - t_start, 2)

        # Transition coverage stats
        trans_covered = 0
        trans_uncovered = 0
        covered_ts_final = {c["source_video_timestamp_sec"] for c in final_candidates}
        for tc_region in transition_regions:
            t_start_r = tc_region["start_sec"]
            t_end_r = tc_region["end_sec"]
            if any(t_start_r - TRANSITION_WINDOW_SEC <= ts <= t_end_r + TRANSITION_WINDOW_SEC
                   for ts in covered_ts_final):
                trans_covered += 1
            else:
                trans_uncovered += 1

        return {
            "schema_version": "KEYFRAME_V2_K2A",
            "summary": {
                "scan_points": len(scan_points),
                "source_segments": len(segments),
                "transition_regions": len(transition_regions),
                "raw_candidates": raw_count,
                "after_local_topk": topk_count,
                "after_dedup": len(final_candidates),
                "transition_regions_covered": trans_covered,
                "transition_regions_uncovered": trans_uncovered,
            },
            "config": {
                "weights": self.weights,
                "transition_bonus": TRANSITION_BONUS,
                "base_local_k": self.base_local_k,
                "density_scale": self.density_scale,
                "max_local_k": self.max_local_k,
                "max_segment_share": self.max_segment_share,
                "global_budget_target": self.global_budget,
            },
            "performance": {
                "processing_time_sec": elapsed,
                "full_video_global_topk_used": False,
                "batch_local_topk_mode": "quickselect",
                "expensive_vision_calls": 0,
            },
            "candidates": final_candidates,
        }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    source_root = sys.argv[1] if len(sys.argv) > 1 else "."
    scan_path = os.path.join(source_root, "extracted/keyframe_v2/dense_scan.json")
    seg_path = os.path.join(source_root, "extracted/keyframe_v2/source_segments.json")
    out_path = os.path.join(source_root, "extracted/keyframe_v2/candidates_k2a.json")

    scan_result = json.load(open(scan_path, encoding="utf-8"))
    segmentation = json.load(open(seg_path, encoding="utf-8"))

    selector = CandidateSelector()
    result = selector.select(scan_result, segmentation)

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    s = result["summary"]
    print(f"Raw candidates:    {s['raw_candidates']}")
    print(f"After local Top-K: {s['after_local_topk']}")
    print(f"After dedup:       {s['after_dedup']}")
    print(f"Transition covered: {s['transition_regions_covered']}/{s['transition_regions']}")
    print(f"Output: {out_path}")
