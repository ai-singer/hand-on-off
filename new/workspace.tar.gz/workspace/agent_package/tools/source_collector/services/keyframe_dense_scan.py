"""
services/keyframe_dense_scan.py

Dense coarse visual-change scan for source video.
Uses perceptual hash (pHash) difference between consecutive frames
via ffmpeg thumbnail extraction — NO expensive Vision LLM calls.

Produces per-scan-point visual change scores:
  visual_change_score  — pHash distance to previous frame
  novelty_score        — distance to rolling N-frame context window mean
  motion_score         — mean absolute pixel diff (downsampled)
  scene_cut_score      — binary hard-cut detector based on histogram diff
  quality_score        — approximate sharpness (Laplacian variance)

All frame decoding is done via ffmpeg at thumbnail scale (160x90).
"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import tempfile
import time
from collections import deque
from pathlib import Path
from typing import List, Optional


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

DEFAULT_SCAN_INTERVAL_SEC = 1.0
THUMBNAIL_WIDTH = 160
THUMBNAIL_HEIGHT = 90
NOVELTY_WINDOW = 30          # rolling window size for novelty baseline
SCENE_CUT_THRESHOLD = 0.35   # histogram diff above this → hard cut
PHASH_BITS = 64              # 8x8 pHash

# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------

def _run_ffmpeg(args: list[str], check=True) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["/home/node/.local/bin/ffmpeg"] + args,
        capture_output=True, check=check
    )


def _get_video_duration(video_path: str) -> float:
    """Return video duration in seconds via ffprobe."""
    result = subprocess.run(
        ["/home/node/.local/bin/ffprobe", "-v", "error",
         "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1",
         video_path],
        capture_output=True, text=True, check=True
    )
    return float(result.stdout.strip())


def _extract_all_frames_batch(video_path: str, timestamps: list[float],
                              width: int = THUMBNAIL_WIDTH,
                              height: int = THUMBNAIL_HEIGHT,
                              temp_dir: str = None) -> dict[float, bytes]:
    """
    Extract all thumbnail frames in a single ffmpeg pass using image2 format.
    Much faster than one subprocess per frame.
    Returns dict mapping timestamp_index -> raw RGB bytes.
    Uses JPEG intermediate files for reliable per-frame splitting.
    """
    import shutil
    cleanup = temp_dir is None
    if temp_dir is None:
        temp_dir = tempfile.mkdtemp(prefix="kdense_")

    try:
        interval = timestamps[1] - timestamps[0] if len(timestamps) > 1 else 1.0
        fps = 1.0 / interval
        out_pattern = os.path.join(temp_dir, "frame_%06d.jpg")

        subprocess.run(
            ["/home/node/.local/bin/ffmpeg",
             "-i", video_path,
             "-vf", f"fps={fps},scale={width}:{height}",
             "-f", "image2",
             out_pattern, "-y"],
            capture_output=True, check=True
        )

        # Load each JPEG as raw RGB via ffmpeg pipe
        frame_files = sorted(
            f for f in os.listdir(temp_dir)
            if f.startswith("frame_") and f.endswith(".jpg")
        )
        expected = width * height * 3
        result = {}
        for idx, fname in enumerate(frame_files):
            ts = round(idx * interval, 2)
            fpath = os.path.join(temp_dir, fname)
            r = subprocess.run(
                ["/home/node/.local/bin/ffmpeg",
                 "-i", fpath,
                 "-f", "rawvideo", "-pix_fmt", "rgb24",
                 "-vf", f"scale={width}:{height}",
                 "pipe:1"],
                capture_output=True, check=False
            )
            if len(r.stdout) >= expected:
                result[ts] = r.stdout[:expected]
        return result
    finally:
        if cleanup and os.path.exists(temp_dir):
            shutil.rmtree(temp_dir, ignore_errors=True)


def _to_array(raw: bytes, width: int, height: int) -> list[list[list[int]]]:
    """Convert raw RGB bytes to 3D list [row][col][channel]."""
    pixels = []
    idx = 0
    for r in range(height):
        row = []
        for c in range(width):
            row.append([raw[idx], raw[idx+1], raw[idx+2]])
            idx += 3
        pixels.append(row)
    return pixels


def _grayscale_mean(raw: bytes) -> float:
    """Mean luminance of raw RGB frame."""
    total = 0
    n = len(raw) // 3
    for i in range(0, len(raw), 3):
        total += 0.299 * raw[i] + 0.587 * raw[i+1] + 0.114 * raw[i+2]
    return total / n if n > 0 else 0.0


def _phash(raw: bytes, width: int = THUMBNAIL_WIDTH,
           height: int = THUMBNAIL_HEIGHT) -> int:
    """
    Compute a 64-bit perceptual hash (pHash) from raw RGB bytes.
    Uses 8x8 DCT approximation via simple block averaging (no scipy needed).
    """
    # Convert to grayscale 8x8 block averages
    bw = width // 8
    bh = height // 8
    blocks = []
    for by in range(8):
        for bx in range(8):
            total = 0
            count = 0
            for r in range(by * bh, min((by + 1) * bh, height)):
                for c in range(bx * bw, min((bx + 1) * bw, width)):
                    idx = (r * width + c) * 3
                    total += 0.299 * raw[idx] + 0.587 * raw[idx+1] + 0.114 * raw[idx+2]
                    count += 1
            blocks.append(total / count if count > 0 else 0)
    mean_val = sum(blocks) / len(blocks)
    bits = 0
    for i, v in enumerate(blocks):
        if v >= mean_val:
            bits |= (1 << i)
    return bits


def _hamming(a: int, b: int) -> int:
    """Hamming distance between two 64-bit integers."""
    x = a ^ b
    count = 0
    while x:
        count += x & 1
        x >>= 1
    return count


def _histogram_diff(raw_a: bytes, raw_b: bytes, bins: int = 32) -> float:
    """
    Normalised histogram difference for scene-cut detection.
    Computes per-channel histogram diff, returns mean.
    """
    def hist(raw, ch):
        h = [0] * bins
        for i in range(ch, len(raw), 3):
            bucket = min(raw[i] * bins // 256, bins - 1)
            h[bucket] += 1
        total = sum(h)
        return [x / total if total > 0 else 0 for x in h]

    total_diff = 0.0
    for ch in range(3):
        ha = hist(raw_a, ch)
        hb = hist(raw_b, ch)
        total_diff += sum(abs(ha[i] - hb[i]) for i in range(bins)) / 2.0
    return total_diff / 3.0


def _motion_score(raw_a: bytes, raw_b: bytes) -> float:
    """Mean absolute pixel difference (grayscale) between two frames."""
    n = min(len(raw_a), len(raw_b)) // 3
    if n == 0:
        return 0.0
    total = 0.0
    for i in range(0, n * 3, 3):
        ga = 0.299 * raw_a[i] + 0.587 * raw_a[i+1] + 0.114 * raw_a[i+2]
        gb = 0.299 * raw_b[i] + 0.587 * raw_b[i+1] + 0.114 * raw_b[i+2]
        total += abs(ga - gb)
    return total / (n * 255.0)


def _laplacian_sharpness(raw: bytes, width: int = THUMBNAIL_WIDTH,
                          height: int = THUMBNAIL_HEIGHT) -> float:
    """
    Approximate sharpness as variance of simple 2D Laplacian on grayscale.
    Uses 3x3 kernel at every other pixel for speed.
    """
    # Convert to grayscale 2D
    gray = []
    for r in range(height):
        row = []
        for c in range(width):
            idx = (r * width + c) * 3
            v = 0.299 * raw[idx] + 0.587 * raw[idx+1] + 0.114 * raw[idx+2]
            row.append(v)
        gray.append(row)

    lap_vals = []
    for r in range(1, height - 1, 2):
        for c in range(1, width - 1, 2):
            lap = (gray[r-1][c] + gray[r+1][c] + gray[r][c-1] + gray[r][c+1]
                   - 4 * gray[r][c])
            lap_vals.append(lap)

    if not lap_vals:
        return 0.0
    mean = sum(lap_vals) / len(lap_vals)
    variance = sum((v - mean) ** 2 for v in lap_vals) / len(lap_vals)
    # Normalise to 0-1 range (typical variance up to ~5000)
    return min(variance / 5000.0, 1.0)


# ---------------------------------------------------------------------------
# Dense Scanner
# ---------------------------------------------------------------------------

class DenseScanner:
    """
    Scans a video at configurable interval using cheap visual metrics.
    Produces list of ScanPoint dicts.
    """

    def __init__(self,
                 video_path: str,
                 scan_interval_sec: float = DEFAULT_SCAN_INTERVAL_SEC,
                 novelty_window: int = NOVELTY_WINDOW):
        self.video_path = video_path
        self.scan_interval_sec = scan_interval_sec
        self.novelty_window = novelty_window

    def scan(self, progress_callback=None) -> dict:
        """
        Run the dense scan. Returns dict with:
          scan_interval_sec, total_duration_sec, scan_points, metadata
        No Vision LLM calls made.
        Uses single-pass ffmpeg batch extraction for speed.
        """
        start_time = time.time()
        duration = _get_video_duration(self.video_path)

        timestamps = []
        t = 0.0
        while t <= duration:
            timestamps.append(round(t, 2))
            t += self.scan_interval_sec

        if progress_callback:
            progress_callback(0, len(timestamps))

        # Batch extract all frames in one ffmpeg pass
        frame_map = _extract_all_frames_batch(
            self.video_path, timestamps
        )

        # Sort timestamps for sequential processing
        sorted_ts = sorted(frame_map.keys())

        scan_points = []
        prev_raw = None
        prev_hash = None
        novelty_window_hashes: deque = deque(maxlen=self.novelty_window)

        for idx, ts in enumerate(sorted_ts):
            raw = frame_map[ts]

            phash = _phash(raw)
            frame_ref = f"dense_{idx:05d}_{int(ts*1000):08d}ms"

            # Visual change score (pHash distance to previous frame, normalised 0-1)
            if prev_hash is not None:
                vcs = _hamming(phash, prev_hash) / PHASH_BITS
            else:
                vcs = 0.0

            # Novelty score (pHash distance to window context mean)
            if novelty_window_hashes:
                distances = [_hamming(phash, h) for h in novelty_window_hashes]
                ns = (sum(distances) / len(distances)) / PHASH_BITS
            else:
                ns = 0.0

            # Motion score (pixel diff to previous)
            if prev_raw is not None:
                ms = _motion_score(prev_raw, raw)
            else:
                ms = 0.0

            # Scene cut score (histogram diff)
            if prev_raw is not None:
                scs = _histogram_diff(prev_raw, raw)
            else:
                scs = 0.0

            # Quality score (sharpness)
            qs = _laplacian_sharpness(raw)

            scan_points.append({
                "source_video_timestamp_sec": ts,
                "frame_ref": frame_ref,
                "visual_change_score": round(vcs, 4),
                "novelty_score": round(ns, 4),
                "motion_score": round(ms, 4),
                "scene_cut_score": round(scs, 4),
                "quality_score": round(qs, 4)
            })

            novelty_window_hashes.append(phash)
            prev_raw = raw
            prev_hash = phash

            if progress_callback and idx % 50 == 0:
                progress_callback(idx, len(sorted_ts))

        elapsed = time.time() - start_time
        return {
            "video_path": self.video_path,
            "scan_interval_sec": self.scan_interval_sec,
            "total_duration_sec": round(duration, 2),
            "decoded_scan_points": len(scan_points),
            "processing_time_sec": round(elapsed, 2),
            "estimated_expensive_vision_calls": 0,
            "no_expensive_vision_calls": True,
            "scan_points": scan_points
        }


# ---------------------------------------------------------------------------
# Top-K primitives (used by downstream stages, tested here)
# ---------------------------------------------------------------------------

def select_top_k(candidates: list, k: int, key=None, mode: str = "batch_quickselect") -> list:
    """
    Return top-k elements by key value (descending).
    mode:
      batch_quickselect  — uses argpartition-style quickselect for batch lists
      stream_min_heap    — streaming k-element min-heap (yields same result)
    No full sort performed.
    """
    if k <= 0 or not candidates:
        return []
    k = min(k, len(candidates))
    key_fn = key if key is not None else (lambda x: x)

    if mode == "batch_quickselect":
        # Python's heapq.nlargest uses a similar approach internally
        import heapq
        return heapq.nlargest(k, candidates, key=key_fn)

    elif mode == "stream_min_heap":
        import heapq
        heap = []
        for item in candidates:
            val = key_fn(item)
            if len(heap) < k:
                heapq.heappush(heap, (val, item))
            elif val > heap[0][0]:
                heapq.heapreplace(heap, (val, item))
        # Return sorted descending
        return [item for _, item in sorted(heap, key=lambda x: -x[0])]

    else:
        raise ValueError(f"Unknown mode: {mode}")


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    video = sys.argv[1] if len(sys.argv) > 1 else None
    interval = float(sys.argv[2]) if len(sys.argv) > 2 else DEFAULT_SCAN_INTERVAL_SEC
    out_path = sys.argv[3] if len(sys.argv) > 3 else "extracted/keyframe_v2/dense_scan.json"

    if not video:
        print("Usage: python3 keyframe_dense_scan.py <video_path> [interval_sec] [output_path]")
        sys.exit(1)

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    scanner = DenseScanner(video, scan_interval_sec=interval)

    def progress(idx, total):
        print(f"  scanning... {idx}/{total} ({100*idx//total}%)", flush=True)

    result = scanner.scan(progress_callback=progress)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"Done. {result['decoded_scan_points']} scan points in {result['processing_time_sec']}s")
    print(f"Output: {out_path}")
