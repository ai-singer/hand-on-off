"""
services/keyframe_diversity.py

K2B1: Diversity signature extraction for K2A candidates.

Computes cheap visual signatures for each candidate thumbnail:
  - perceptual_hash (pHash, 64-bit)
  - color_histogram (normalized per-channel, 32 bins each → 96 floats)
  - edge_layout (Sobel-approximation variance grid, 4x4 blocks → 16 floats)

NO Vision LLM calls.
NO pairwise matrix generation (that is K2B2).
NO candidate suppression (that is K2B2).
"""

from __future__ import annotations

import json
import math
import os
import subprocess
import tempfile
import time
from typing import Optional

# Thumbnail spec for diversity (cheap, just needs to express visual structure)
THUMB_WIDTH = 64
THUMB_HEIGHT = 36
HIST_BINS = 32
EDGE_GRID = 4   # 4x4 = 16 edge blocks


# ---------------------------------------------------------------------------
# Thumbnail decode (single frame from JPEG file via ffmpeg pipe)
# ---------------------------------------------------------------------------

def _decode_rgb(jpeg_path: str, width: int = THUMB_WIDTH, height: int = THUMB_HEIGHT) -> Optional[bytes]:
    """Decode JPEG to raw RGB bytes at thumbnail scale."""
    r = subprocess.run(
        ["/home/node/.local/bin/ffmpeg",
         "-i", jpeg_path,
         "-f", "rawvideo", "-pix_fmt", "rgb24",
         "-vf", f"scale={width}:{height}",
         "pipe:1"],
        capture_output=True, check=False
    )
    expected = width * height * 3
    return r.stdout[:expected] if len(r.stdout) >= expected else None


# ---------------------------------------------------------------------------
# Signature components
# ---------------------------------------------------------------------------

def _phash_64(raw: bytes, width: int = THUMB_WIDTH, height: int = THUMB_HEIGHT) -> str:
    """64-bit perceptual hash as hex string. Uses 8x8 DCT block averaging."""
    bw = width // 8
    bh = height // 8
    blocks = []
    for by in range(8):
        for bx in range(8):
            total = 0.0
            count = 0
            for r in range(by * bh, min((by + 1) * bh, height)):
                for c in range(bx * bw, min((bx + 1) * bw, width)):
                    idx = (r * width + c) * 3
                    lum = 0.299 * raw[idx] + 0.587 * raw[idx + 1] + 0.114 * raw[idx + 2]
                    total += lum
                    count += 1
            blocks.append(total / count if count > 0 else 0.0)
    mean_val = sum(blocks) / len(blocks)
    bits = 0
    for i, v in enumerate(blocks):
        if v >= mean_val:
            bits |= (1 << i)
    return format(bits, '016x')


def _color_histogram(raw: bytes, bins: int = HIST_BINS) -> list[float]:
    """
    Normalised colour histogram: bins per channel (R, G, B) → list of 3*bins floats.
    Each value is fraction of pixels in that bin.
    """
    n_pixels = len(raw) // 3
    hist = [[0] * bins for _ in range(3)]
    for i in range(0, len(raw), 3):
        for ch in range(3):
            bucket = min(raw[i + ch] * bins // 256, bins - 1)
            hist[ch][bucket] += 1
    result = []
    for ch in range(3):
        total = sum(hist[ch])
        result.extend(round(v / total, 6) if total > 0 else 0.0 for v in hist[ch])
    return result


def _edge_layout(raw: bytes, width: int = THUMB_WIDTH, height: int = THUMB_HEIGHT,
                  grid: int = EDGE_GRID) -> list[float]:
    """
    Approximation of edge energy per grid block using variance of luminance differences.
    Returns grid*grid floats normalised to 0-1.
    """
    # Build grayscale
    gray = []
    for r in range(height):
        row = []
        for c in range(width):
            idx = (r * width + c) * 3
            row.append(0.299 * raw[idx] + 0.587 * raw[idx + 1] + 0.114 * raw[idx + 2])
        gray.append(row)

    # Compute horizontal + vertical gradient magnitude at each pixel
    edges = [[0.0] * width for _ in range(height)]
    for r in range(1, height - 1):
        for c in range(1, width - 1):
            gx = gray[r][c + 1] - gray[r][c - 1]
            gy = gray[r + 1][c] - gray[r - 1][c]
            edges[r][c] = math.sqrt(gx * gx + gy * gy)

    # Compute mean edge energy per grid block
    bw = width // grid
    bh = height // grid
    result = []
    max_energy = 360.0  # approximate max sqrt(255^2 + 255^2) normalisation
    for by in range(grid):
        for bx in range(grid):
            total = 0.0
            count = 0
            for r in range(by * bh, min((by + 1) * bh, height)):
                for c in range(bx * bw, min((bx + 1) * bw, width)):
                    total += edges[r][c]
                    count += 1
            mean_energy = (total / count) if count > 0 else 0.0
            result.append(round(min(mean_energy / max_energy, 1.0), 6))
    return result


def hamming_distance(hash_a: str, hash_b: str) -> int:
    """Hamming distance between two hex pHash strings."""
    a = int(hash_a, 16)
    b = int(hash_b, 16)
    x = a ^ b
    count = 0
    while x:
        count += x & 1
        x >>= 1
    return count


def phash_similarity(hash_a: str, hash_b: str, bits: int = 64) -> float:
    """
    Perceptual hash similarity: 0.0 = maximally different, 1.0 = identical.
    Computed as 1 - (hamming_distance / bits).
    """
    return round(1.0 - hamming_distance(hash_a, hash_b) / bits, 6)


def per_channel_histogram_similarity(hist_a: list[float], hist_b: list[float],
                                      bins: int = HIST_BINS,
                                      channel_weights: tuple = (1.0, 1.0, 1.0)) -> float:
    """
    Per-channel histogram similarity: 0.0 = maximally different, 1.0 = identical.

    Computes Bhattacharyya coefficient INDEPENDENTLY for each colour channel
    (R, G, B), then returns a weighted average.

    This correctly distinguishes images that differ only in which channel
    carries a distribution — e.g. a red gradient vs. a blue gradient both
    have the same luminance profile but in different channels, and will
    return low similarity here.

    Input: concatenated per-channel histogram of length 3*bins (same format
    as _color_histogram output).
    """
    assert len(hist_a) == 3 * bins, f"Expected {3*bins} values, got {len(hist_a)}"
    assert len(hist_b) == 3 * bins, f"Expected {3*bins} values, got {len(hist_b)}"

    channel_sims = []
    total_weight = sum(channel_weights)
    for ch in range(3):
        start = ch * bins
        end = start + bins
        ha = hist_a[start:end]
        hb = hist_b[start:end]
        bc = sum(math.sqrt(a * b) for a, b in zip(ha, hb))
        channel_sims.append(min(bc, 1.0))

    weighted = sum(s * w for s, w in zip(channel_sims, channel_weights))
    return round(weighted / total_weight, 6)


def histogram_similarity(hist_a: list[float], hist_b: list[float],
                          bins: int = HIST_BINS) -> float:
    """
    DEPRECATED for K2B2 use. Use per_channel_histogram_similarity() instead.

    Global Bhattacharyya coefficient over the full concatenated histogram.
    Returns 1.0 for images that share the same per-channel distribution shape
    even if channels are different (e.g. red vs blue gradient → returns 1.0).
    Retained for backward compatibility with existing tests only.
    """
    bc = sum(math.sqrt(a * b) for a, b in zip(hist_a, hist_b))
    return round(min(bc, 1.0), 6)


def edge_similarity(edge_a: list[float], edge_b: list[float]) -> float:
    """
    Edge layout cosine similarity: 0.0 = maximally different, 1.0 = identical.
    Both-zero vectors (featureless frames) return 1.0 by convention.
    """
    dot = sum(a * b for a, b in zip(edge_a, edge_b))
    mag_a = math.sqrt(sum(a * a for a in edge_a))
    mag_b = math.sqrt(sum(b * b for b in edge_b))
    if mag_a < 1e-9 or mag_b < 1e-9:
        return 1.0 if mag_a < 1e-9 and mag_b < 1e-9 else 0.0
    return round(dot / (mag_a * mag_b), 6)


# Default composite weights for visual_similarity
DEFAULT_COMPOSITE_WEIGHTS = {
    "phash":     0.45,
    "histogram": 0.30,
    "edge":      0.25,
}


def visual_similarity(sig_a: dict, sig_b: dict,
                       weights: dict = None,
                       hist_bins: int = HIST_BINS) -> dict:
    """
    Composite visual similarity between two diversity signature dicts.

    Similarity contract:
      0.0 = maximally different
      1.0 = identical

    Uses:
      - phash_similarity             (structural/perceptual)
      - per_channel_histogram_similarity  (colour distribution per channel)
      - edge_similarity              (spatial layout / edge energy)

    Returns a dict with individual components and composite score.
    Weights are configurable; defaults in DEFAULT_COMPOSITE_WEIGHTS.
    Single-feature duplicate detection is NOT supported by design:
    composite_similarity must be used for suppression decisions.
    """
    w = weights or DEFAULT_COMPOSITE_WEIGHTS
    total_w = sum(w.values())

    ph_sim = phash_similarity(
        sig_a["perceptual_hash"], sig_b["perceptual_hash"]
    )
    hist_sim = per_channel_histogram_similarity(
        sig_a["color_histogram"], sig_b["color_histogram"],
        bins=hist_bins
    )
    edge_sim = edge_similarity(
        sig_a["edge_layout"], sig_b["edge_layout"]
    )

    composite = round(
        (ph_sim * w["phash"] + hist_sim * w["histogram"] + edge_sim * w["edge"]) / total_w,
        6
    )

    return {
        "phash_similarity":     ph_sim,
        "histogram_similarity": hist_sim,
        "edge_layout_similarity": edge_sim,
        "composite_similarity": composite,
        "weights_used": w,
    }


# ---------------------------------------------------------------------------
# Batch materialization
# ---------------------------------------------------------------------------

def materialize_candidates_batch(
        candidates: list[dict],
        video_path: str,
        thumbnail_dir: str,
        scan_interval_sec: float = 1.0,
        thumb_width: int = THUMB_WIDTH,
        thumb_height: int = THUMB_HEIGHT) -> dict[str, str]:
    """
    Materialise candidate thumbnails via a single ffmpeg pass at 1fps,
    then copy/link the needed frames.

    Returns dict: source_video_timestamp_sec (as str) -> thumbnail_path
    Does NOT spawn one ffmpeg per candidate.
    """
    os.makedirs(thumbnail_dir, exist_ok=True)

    # Extract needed timestamps
    needed_ts = sorted({c["source_video_timestamp_sec"] for c in candidates})
    if not needed_ts:
        return {}

    # Single batch extraction at scan_interval fps
    fps = 1.0 / scan_interval_sec
    tmp_dir = tempfile.mkdtemp(prefix="k2b1_mat_")
    try:
        subprocess.run(
            ["/home/node/.local/bin/ffmpeg",
             "-i", video_path,
             "-vf", f"fps={fps},scale={thumb_width}:{thumb_height}",
             "-f", "image2",
             os.path.join(tmp_dir, "frame_%06d.jpg"),
             "-y"],
            capture_output=True, check=True
        )

        # Map frame index → timestamp
        frame_files = sorted(
            f for f in os.listdir(tmp_dir) if f.startswith("frame_") and f.endswith(".jpg")
        )
        ts_to_file = {
            round(idx * scan_interval_sec, 2): os.path.join(tmp_dir, fname)
            for idx, fname in enumerate(frame_files)
        }

        # Copy needed frames to thumbnail_dir
        import shutil
        result = {}
        for ts in needed_ts:
            src = ts_to_file.get(ts)
            if src and os.path.exists(src):
                cand_id = f"cand_{int(ts*1000):09d}ms"
                dst = os.path.join(thumbnail_dir, f"{cand_id}.jpg")
                shutil.copy2(src, dst)
                result[str(ts)] = dst
        return result

    finally:
        import shutil as _shutil
        _shutil.rmtree(tmp_dir, ignore_errors=True)


# ---------------------------------------------------------------------------
# Signature extractor
# ---------------------------------------------------------------------------

class DiversitySignatureExtractor:

    def __init__(self,
                 thumb_width: int = THUMB_WIDTH,
                 thumb_height: int = THUMB_HEIGHT):
        self.thumb_width = thumb_width
        self.thumb_height = thumb_height

    def extract_from_file(self, jpeg_path: str) -> Optional[dict]:
        """Extract all diversity signatures from a JPEG thumbnail file."""
        raw = _decode_rgb(jpeg_path, self.thumb_width, self.thumb_height)
        if raw is None:
            return None
        return {
            "perceptual_hash": _phash_64(raw, self.thumb_width, self.thumb_height),
            "color_histogram": _color_histogram(raw),
            "edge_layout": _edge_layout(raw, self.thumb_width, self.thumb_height),
        }

    def extract_from_raw(self, raw: bytes) -> dict:
        """Extract signatures from raw RGB bytes."""
        return {
            "perceptual_hash": _phash_64(raw, self.thumb_width, self.thumb_height),
            "color_histogram": _color_histogram(raw),
            "edge_layout": _edge_layout(raw, self.thumb_width, self.thumb_height),
        }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    source_root = sys.argv[1] if len(sys.argv) > 1 else "."
    k2a_path = os.path.join(source_root, "extracted/keyframe_v2/candidates_k2a.json")
    out_path = os.path.join(source_root, "extracted/keyframe_v2/candidate_diversity_signatures_k2b1.json")
    thumb_dir = os.path.join(source_root, "extracted/keyframe_v2/candidate_thumbnails")
    video_path = os.path.join(source_root, "raw/camera_to_space.f30077.mp4")

    k2a = json.load(open(k2a_path, encoding="utf-8"))
    candidates = k2a["candidates"]
    print(f"Candidates: {len(candidates)}")

    print("Materializing thumbnails (batch ffmpeg)...")
    t0 = time.time()
    ts_to_thumb = materialize_candidates_batch(candidates, video_path, thumb_dir)
    mat_time = round(time.time() - t0, 2)
    print(f"Materialized {len(ts_to_thumb)} thumbnails in {mat_time}s")

    extractor = DiversitySignatureExtractor()
    sig_records = []
    failed = 0
    t0 = time.time()
    for c in candidates:
        ts_key = str(c["source_video_timestamp_sec"])
        thumb_path = ts_to_thumb.get(ts_key)
        cand_id = f"cand_{int(c['source_video_timestamp_sec']*1000):09d}ms"
        if thumb_path and os.path.exists(thumb_path):
            sig = extractor.extract_from_file(thumb_path)
        else:
            sig = None
            failed += 1

        sig_records.append({
            "candidate_id": cand_id,
            "source_video_timestamp_sec": c["source_video_timestamp_sec"],
            "source_segment_id": c["source_segment_id"],
            "thumbnail_ref": os.path.basename(thumb_path) if thumb_path else None,
            "transition_candidate": c.get("transition_candidate", False),
            "transition_region_refs": c.get("transition_region_refs", []),
            "diversity_signature": sig or {"perceptual_hash": None, "color_histogram": [], "edge_layout": []},
        })

    sig_time = round(time.time() - t0, 2)
    result = {
        "schema_version": "KEYFRAME_V2_K2B1",
        "summary": {
            "candidate_count": len(candidates),
            "materialized_count": len(ts_to_thumb),
            "signature_count": len(candidates) - failed,
            "failed_count": failed,
            "materialization_time_sec": mat_time,
            "signature_extraction_time_sec": sig_time,
            "per_candidate_ffmpeg_spawn": False,
            "full_pairwise_matrix_created": False,
            "expensive_vision_calls": 0,
        },
        "candidates": sig_records,
    }

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"Signatures: {len(candidates)-failed}/{len(candidates)} (failed={failed})")
    print(f"Sig extraction time: {sig_time}s")
    print(f"Output: {out_path}")
