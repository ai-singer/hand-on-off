"""
services/keyframe_diversity_selection.py

K2B2: Cross-segment diversity selection (greedy MMR-like).

Reduces K2A candidate set by suppressing visually redundant frames
while protecting transition coverage and source segment representation.

NO expensive Vision LLM calls.
NO full pairwise matrix artifact.
NO semantic classification (that is K3).
Uses visual_similarity() with per_channel_histogram_similarity (not deprecated histogram_similarity).
"""

from __future__ import annotations

import json
import os
import time
from typing import Optional

from services.keyframe_diversity import visual_similarity, DEFAULT_COMPOSITE_WEIGHTS


# ---------------------------------------------------------------------------
# Config defaults (all configurable — no project-specific values hardcoded)
# ---------------------------------------------------------------------------

# Similarity thresholds
DUPLICATE_THRESHOLD = 0.92          # composite >= this → treat as duplicate
NEAR_DUPLICATE_THRESHOLD = 0.80     # composite >= this → near-duplicate (role-aware)

# Global budget
GLOBAL_BUDGET = 300                 # soft ceiling; may be exceeded to preserve coverage

# Transition role keywords (detected from candidate_reasons)
TRANSITION_ROLES = {"transition_before", "transition_peak", "transition_after",
                    "transition_forced_coverage"}


# ---------------------------------------------------------------------------
# Priority scorer
# ---------------------------------------------------------------------------

def candidate_priority(cand: dict, seg_density_map: dict) -> float:
    """
    Compute selection priority for a candidate.
    Higher = more valuable.
    NOT a semantic score — purely visual/structural.
    """
    score = cand.get("candidate_score", 0.0)

    # Boost for transition candidates
    if cand.get("transition_candidate", False):
        score += 0.15

    # Boost for multiple candidate reasons (multi-signal value)
    reasons = cand.get("candidate_reasons", [])
    score += min(len(reasons) - 1, 3) * 0.03

    # Boost for high-density segment (information-rich region)
    seg_id = cand.get("source_segment_id", "")
    density = seg_density_map.get(seg_id, 0.0)
    score += min(density, 1.0) * 0.05

    return round(score, 5)


# ---------------------------------------------------------------------------
# Transition role detection
# ---------------------------------------------------------------------------

def detect_transition_role(cand: dict) -> str:
    """Detect the transition role of a candidate from its reasons."""
    reasons = set(cand.get("candidate_reasons", []))
    if "transition_peak" in reasons or "transition_forced_coverage" in reasons:
        return "PEAK"
    if "transition_before" in reasons:
        return "BEFORE"
    if "transition_after" in reasons:
        return "AFTER"
    return "UNKNOWN"


# ---------------------------------------------------------------------------
# Greedy MMR-like diversity selection
# ---------------------------------------------------------------------------

class DiversitySelector:

    def __init__(self,
                 duplicate_threshold: float = DUPLICATE_THRESHOLD,
                 near_duplicate_threshold: float = NEAR_DUPLICATE_THRESHOLD,
                 global_budget: int = GLOBAL_BUDGET,
                 composite_weights: dict = None):
        self.dup_thresh = duplicate_threshold
        self.near_dup_thresh = near_duplicate_threshold
        self.global_budget = global_budget
        self.weights = composite_weights or DEFAULT_COMPOSITE_WEIGHTS

    def select(self, candidates: list[dict], signatures: dict[str, dict],
               segmentation: dict) -> dict:
        """
        Run K2B2 greedy diversity selection.

        candidates: list of K2A candidate dicts
        signatures: dict of candidate_id -> diversity_signature dict
        segmentation: source_segments.json dict (for density info)

        Returns selection result dict.
        """
        t0 = time.time()

        # Build segment density map
        seg_density_map = {
            s["segment_id"]: s.get("information_density", 0.0)
            for s in segmentation.get("segments", [])
        }

        # Build signature lookup by timestamp (K2B1 uses timestamp-based IDs)
        ts_to_sig = {
            c["source_video_timestamp_sec"]: c["diversity_signature"]
            for c in signatures
        }

        # Assign priorities and sort descending
        for c in candidates:
            c["_priority"] = candidate_priority(c, seg_density_map)
        sorted_cands = sorted(candidates, key=lambda c: c["_priority"], reverse=True)

        selected: list[dict] = []
        suppressed: list[dict] = []
        selected_sigs: list[dict] = []  # parallel list of sigs for selected

        # Track transition region coverage: region_start_sec -> set of roles covered
        tc_coverage: dict[float, set] = {}
        for c in candidates:
            for ts in c.get("transition_region_refs", []):
                if ts not in tc_coverage:
                    tc_coverage[float(ts)] = set()

        similarity_comparisons = 0

        for cand in sorted_cands:
            cand_ts = cand["source_video_timestamp_sec"]
            cand_sig = ts_to_sig.get(cand_ts)
            if cand_sig is None:
                # No signature — keep without comparison
                selected.append(cand)
                selected_sigs.append({})
                continue

            # Compare against already-selected candidates
            max_sim = 0.0
            most_similar_id = None
            most_similar_detail = {}

            for sel, sel_sig in zip(selected, selected_sigs):
                if not sel_sig:
                    continue
                vs = visual_similarity(cand_sig, sel_sig, weights=self.weights)
                similarity_comparisons += 1
                comp = vs["composite_similarity"]
                if comp > max_sim:
                    max_sim = comp
                    most_similar_id = f"cand_{int(sel['source_video_timestamp_sec']*1000):09d}ms"
                    most_similar_detail = vs

            cand_id = f"cand_{int(cand_ts*1000):09d}ms"
            cand_role = detect_transition_role(cand)
            is_tc = cand.get("transition_candidate", False)

            # --- Duplicate decision ---
            if max_sim >= self.dup_thresh:
                # Check transition protection before suppressing
                suppress_allowed = True

                if is_tc:
                    # Check if suppressing would lose transition role coverage
                    for tc_ts in cand.get("transition_region_refs", []):
                        tc_ts_f = float(tc_ts)
                        covered_roles = tc_coverage.get(tc_ts_f, set())
                        if cand_role not in covered_roles:
                            # This role is not yet covered for this transition region
                            # Only suppress if another selected candidate covers it
                            # (It won't be in covered_roles yet since we haven't added this one)
                            suppress_allowed = False
                            break

                if suppress_allowed:
                    suppressed.append({
                        "candidate_id": cand_id,
                        "source_video_timestamp_sec": cand_ts,
                        "source_segment_id": cand.get("source_segment_id"),
                        "suppressed_by": most_similar_id,
                        "reason": "VISUAL_DUPLICATE",
                        "composite_similarity": round(max_sim, 5),
                        "similarities": most_similar_detail,
                        "transition_candidate": is_tc,
                        "transition_role": cand_role,
                        "transition_coverage_preserved": True,
                    })
                    continue

            elif max_sim >= self.near_dup_thresh:
                # Near duplicate: only suppress non-transition, non-representative candidates
                # when budget pressure exists
                is_representative = "representative" in cand.get("candidate_reasons", [])
                if not is_tc and not is_representative and len(selected) >= self.global_budget:
                    suppressed.append({
                        "candidate_id": cand_id,
                        "source_video_timestamp_sec": cand_ts,
                        "source_segment_id": cand.get("source_segment_id"),
                        "suppressed_by": most_similar_id,
                        "reason": "NEAR_DUPLICATE_BUDGET",
                        "composite_similarity": round(max_sim, 5),
                        "similarities": most_similar_detail,
                        "transition_candidate": is_tc,
                        "transition_role": cand_role,
                        "transition_coverage_preserved": True,
                    })
                    continue

            # Select this candidate
            selected.append(cand)
            selected_sigs.append(cand_sig)

            # Update transition coverage
            if is_tc and cand_role != "UNKNOWN":
                for tc_ts in cand.get("transition_region_refs", []):
                    tc_ts_f = float(tc_ts)
                    if tc_ts_f not in tc_coverage:
                        tc_coverage[tc_ts_f] = set()
                    tc_coverage[tc_ts_f].add(cand_role)

        elapsed = round(time.time() - t0, 2)

        # --- Transition coverage validation ---
        # Rebuild from selected
        sel_ts_set = {c["source_video_timestamp_sec"] for c in selected}
        tc_fully = 0
        tc_partial = 0
        tc_lost = 0

        # Group selected candidates by transition region
        from collections import defaultdict
        tc_sel_roles: dict[float, set] = defaultdict(set)
        for c in selected:
            if c.get("transition_candidate"):
                role = detect_transition_role(c)
                for tc_ts in c.get("transition_region_refs", []):
                    tc_sel_roles[float(tc_ts)].add(role)

        # Get all transition region start_secs from candidates
        all_tc_starts = set()
        for c in candidates:
            for tc_ts in c.get("transition_region_refs", []):
                all_tc_starts.add(float(tc_ts))

        for tc_start in all_tc_starts:
            roles = tc_sel_roles.get(tc_start, set())
            if not roles:
                tc_lost += 1
            elif "PEAK" in roles or len(roles) >= 2:
                tc_fully += 1
            else:
                tc_partial += 1

        # Cross-segment vs same-segment suppression counts
        same_seg = sum(
            1 for sup in suppressed
            if any(s.get("source_segment_id") == sup["source_segment_id"]
                   for s in selected
                   if f"cand_{int(s['source_video_timestamp_sec']*1000):09d}ms" == sup["suppressed_by"])
        )
        cross_seg = len(suppressed) - same_seg

        # K1 density diagnostic
        redundancy_rate = len(suppressed) / max(len(candidates), 1)
        k1_review = redundancy_rate > 0.40

        return {
            "schema_version": "KEYFRAME_V2_K2B2",
            "summary": {
                "input_candidates": len(candidates),
                "selected_candidates": len(selected),
                "suppressed_candidates": len(suppressed),
                "suppression_rate": round(redundancy_rate, 4),
                "same_segment_suppressions": same_seg,
                "cross_segment_suppressions": cross_seg,
                "transition_regions_fully_covered": tc_fully,
                "transition_regions_partially_covered": tc_partial,
                "transition_regions_lost": tc_lost,
                "transition_regions_total": len(all_tc_starts),
                "k1_threshold_review_candidate": k1_review,
            },
            "config": {
                "duplicate_threshold": self.dup_thresh,
                "near_duplicate_threshold": self.near_dup_thresh,
                "global_budget": self.global_budget,
                "composite_weights": self.weights,
                "deprecated_histogram_similarity_used": False,
            },
            "performance": {
                "selection_runtime_sec": elapsed,
                "similarity_comparisons": similarity_comparisons,
                "full_pairwise_matrix_created": False,
                "expensive_vision_calls": 0,
            },
            "selected": selected,
            "suppressed": suppressed,
        }
