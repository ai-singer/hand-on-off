"""
services/post_planning.py

Post Planning Layer

职责：
- 读取 content_facts.json + key_points.json
- 将视频内容规划为多个独立但连续的帖子
- 输出 extracted/post_plan.json

不生成正文。
不创建新事实。
不重新分析图片。
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import List


# ---------------------------------------------------------------------------
# 异常
# ---------------------------------------------------------------------------

class PostPlanningError(Exception):
    pass


# ---------------------------------------------------------------------------
# 数据类
# ---------------------------------------------------------------------------

@dataclass
class PostPlan:
    post_id: str
    title: str
    theme: str
    summary: str
    key_points: List[str]    # key_point titles
    fact_ids: List[str]      # fact_0, fact_1, ...
    image_frames: List[int]
    target_length: str = "800-1000"


@dataclass
class SeriesPlan:
    source_id: str
    series_title: str
    posts: List[PostPlan]


# ---------------------------------------------------------------------------
# 主服务
# ---------------------------------------------------------------------------

def plan_posts(source_root: str) -> SeriesPlan:
    """
    从 content_facts.json + key_points.json 规划帖子系列。

    Args:
        source_root: source 目录路径

    Returns:
        SeriesPlan

    Raises:
        PostPlanningError: 输入缺失
    """
    # 1. 验证依赖
    meta_path  = os.path.join(source_root, "metadata", "source.json")
    facts_path = os.path.join(source_root, "extracted", "content_facts.json")
    kp_path    = os.path.join(source_root, "extracted", "key_points.json")
    obs_path   = os.path.join(source_root, "extracted", "frame_observations.json")

    for path, label in [
        (meta_path,  "source.json"),
        (facts_path, "content_facts.json"),
        (kp_path,    "key_points.json"),
        (obs_path,   "frame_observations.json"),
    ]:
        if not os.path.isfile(path):
            raise PostPlanningError(f"MISSING_DEPENDENCY: {label} 不存在: {path}")

    with open(meta_path,  encoding="utf-8") as f: meta  = json.load(f)
    with open(facts_path, encoding="utf-8") as f: cf    = json.load(f)
    with open(kp_path,    encoding="utf-8") as f: kp    = json.load(f)
    with open(obs_path,   encoding="utf-8") as f: obs   = json.load(f)

    source_id   = meta.get("source_id", "unknown")
    video_title = meta.get("title", "")
    facts       = cf.get("facts", [])
    key_points  = kp.get("key_points", [])
    valid_frames = {o["frame_id"] for o in obs.get("observations", [])}

    # fact_id → index 映射
    fact_id = lambda i: f"fact_{i}"

    # key_point title 索引
    kp_titles = {k["title"]: k for k in key_points}

    # ---------------------------------------------------------------------------
    # 帖子规划：动态派生，基于实际输入的 facts 和 key_points
    # Post 1 — 项目起点：环境与准备
    # Post 2 — 升空过程：从地面到太空边缘
    # Post 3 — 任务收尾：回落与回收
    # ---------------------------------------------------------------------------

    def pick_frames(candidates: List[int], n: int) -> List[int]:
        """从候选帧中选 n 帧，均匀分布，只取 valid_frames 中存在的。"""
        valid = [f for f in candidates if f in valid_frames]
        if len(valid) <= n:
            return valid
        step = len(valid) / n
        return [valid[int(i * step)] for i in range(n)]

    def facts_matching(keywords: List[str]) -> List[str]:
        """返回 fact 文本中包含任意关键词的 fact_id 列表。"""
        result = []
        for i, f in enumerate(facts):
            if any(kw in f["fact"] for kw in keywords):
                result.append(fact_id(i))
        return result or [fact_id(0)]  # 至少保留 fact_0

    def kps_present(titles: List[str]) -> List[str]:
        """返回实际存在于 key_points.json 中的 key_point 标题列表。"""
        return [t for t in titles if t in kp_titles]

    def frames_in_range(t_start: float, t_end: float, n: int) -> List[int]:
        """从 frame_observations 中按时间范围选帧。"""
        candidates = [
            o["frame_id"] for o in obs.get("observations", [])
            if t_start <= o["timestamp_sec"] <= t_end
        ]
        return pick_frames(candidates, n)

    posts = [
        PostPlan(
            post_id="post_001",
            title="把相机送上天：从一片雪地开始",
            theme="项目起点与发射准备",
            summary=(
                "介绍项目背景环境，展示发射准备阶段的实际操作场景："
                "积雪场地、大型气球充气、绳索连接悬挂设备，以及参与人员的现场工作状态。"
            ),
            key_points=kps_present(["发射准备"]),
            fact_ids=facts_matching(["雪", "人员", "悬挂", "绳索"]),
            image_frames=frames_in_range(0, 160, 4),
            target_length="800-1000",
        ),
        PostPlan(
            post_id="post_002",
            title="天空变黑的那一刻：气球带我们到了大气层边缘",
            theme="升空过程与近太空视觉",
            summary=(
                "记录气球从低空到高空的上升过程：地面逐渐缩小，云层出现又消失，"
                "天空颜色由蓝转黑，地球曲面与大气层蓝色薄层在画面中清晰呈现。"
            ),
            key_points=kps_present(["低空上升", "进入近太空", "高空悬浮"]),
            fact_ids=facts_matching(["气球", "曲率", "曲面", "弧", "天空", "大气层"]),
            image_frames=frames_in_range(160, 560, 5),
            target_length="800-1000",
        ),
        PostPlan(
            post_id="post_003",
            title="从30000米落回地面：回收一台经历过太空边缘的设备",
            theme="下降、着陆与回收",
            summary=(
                "天空重新变蓝，载荷开始回落。"
                "记录从高空下降到着陆的视觉变化，以及人员找回设备、完成回收的现场过程。"
            ),
            key_points=kps_present(["下降与回落", "着陆与回收"]),
            fact_ids=facts_matching(["着陆", "回收", "悬挂", "设备"]),
            image_frames=frames_in_range(560, 870, 4),
            target_length="800-1000",
        ),
    ]
    # 过滤掉 image_frames 为空的帖子（测试场景帧稀少时）
    # 保证每帖至少 2 帧；不足时从 valid_frames 补充
    for post in posts:
        if len(post.image_frames) < 2:
            post.image_frames = pick_frames(sorted(valid_frames), 2)

    series = SeriesPlan(
        source_id=source_id,
        series_title=video_title,
        posts=posts,
    )

    # 写入 post_plan.json
    out_path = os.path.join(source_root, "extracted", "post_plan.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump({
            "source_id": series.source_id,
            "series_title": series.series_title,
            "posts": [
                {
                    "post_id": p.post_id,
                    "title": p.title,
                    "theme": p.theme,
                    "summary": p.summary,
                    "key_points": p.key_points,
                    "fact_ids": p.fact_ids,
                    "image_frames": p.image_frames,
                    "target_length": p.target_length,
                }
                for p in series.posts
            ],
        }, f, ensure_ascii=False, indent=2)

    return series
