"""
services/temporal_segmentation.py

Temporal segmentation of source video from dense scan output.

Groups scan points into SOURCE VIDEO SEGMENTS based on:
  - scene cut scores (hard cuts)
  - novelty peaks (visual regime change)
  - sustained low-change periods (stable regions)
  - motion regime changes

This is purely structural video segmentation — NOT semantic classification.
It does NOT classify content as interview / operation / etc.

Outputs:
  - list of segments with density metrics
  - transition_candidate_regions for adaptive local resampling
"""

from __future__ import annotations

import json
import math
from typing import List, Optional


# ---------------------------------------------------------------------------
# Config defaults
# ---------------------------------------------------------------------------

SCENE_CUT_HARD_THRESHOLD = 0.30      # scene_cut_score above this → hard cut
CHANGE_PEAK_THRESHOLD = 0.25         # visual_change_score above this → change peak
NOVELTY_PEAK_THRESHOLD = 0.20        # novelty_score above this → novelty peak
MIN_SEGMENT_DURATION_SEC = 2.0       # merge segments shorter than this
TRANSITION_CANDIDATE_MERGE_GAP = 2.0 # merge transition candidates within this window


# ---------------------------------------------------------------------------
# Segmenter
# ---------------------------------------------------------------------------

class TemporalSegmenter:
    """
    Segments source video into temporal regions based on visual change signals.
    Input: dense_scan result dict (from DenseScanner.scan()).
    Output: segmentation dict with segments + transition_candidate_regions.
    """

    def __init__(self,
                 scene_cut_threshold: float = SCENE_CUT_HARD_THRESHOLD,
                 change_peak_threshold: float = CHANGE_PEAK_THRESHOLD,
                 novelty_peak_threshold: float = NOVELTY_PEAK_THRESHOLD,
                 min_segment_duration: float = MIN_SEGMENT_DURATION_SEC,
                 transition_merge_gap: float = TRANSITION_CANDIDATE_MERGE_GAP):
        self.scene_cut_threshold = scene_cut_threshold
        self.change_peak_threshold = change_peak_threshold
        self.novelty_peak_threshold = novelty_peak_threshold
        self.min_segment_duration = min_segment_duration
        self.transition_merge_gap = transition_merge_gap

    def segment(self, scan_result: dict) -> dict:
        """
        Produce temporal segmentation from dense scan result.
        Returns segmentation dict.
        """
        points = scan_result["scan_points"]
        total_duration = scan_result["total_duration_sec"]
        scan_interval = scan_result["scan_interval_sec"]

        if not points:
            return self._empty_result(total_duration)

        # --- Step 1: Identify cut points ---
        cut_timestamps = []
        for pt in points:
            is_hard_cut = pt["scene_cut_score"] >= self.scene_cut_threshold
            is_change_peak = pt["visual_change_score"] >= self.change_peak_threshold
            is_novelty_peak = pt["novelty_score"] >= self.novelty_peak_threshold
            if is_hard_cut or (is_change_peak and is_novelty_peak):
                cut_timestamps.append(pt["source_video_timestamp_sec"])

        # --- Step 2: Build raw segments from cut points ---
        boundaries = [0.0] + cut_timestamps + [total_duration]
        # Deduplicate and sort
        boundaries = sorted(set(round(b, 2) for b in boundaries))

        raw_segments = []
        for i in range(len(boundaries) - 1):
            start = boundaries[i]
            end = boundaries[i + 1]
            if end - start < 0.1:
                continue
            # Collect scan points in this segment
            seg_points = [p for p in points
                          if start <= p["source_video_timestamp_sec"] < end]
            raw_segments.append((start, end, seg_points))

        # --- Step 3: Merge very short segments ---
        merged = []
        for start, end, seg_pts in raw_segments:
            duration = end - start
            if merged and duration < self.min_segment_duration:
                # Merge into previous segment
                prev_start, prev_end, prev_pts = merged[-1]
                merged[-1] = (prev_start, end, prev_pts + seg_pts)
            else:
                merged.append((start, end, seg_pts))

        # --- Step 4: Compute density metrics per segment ---
        segments = []
        for seg_idx, (start, end, seg_pts) in enumerate(merged):
            duration = round(end - start, 2)
            if not seg_pts:
                n = 0
                change_density = 0.0
                novelty_density = 0.0
                motion_density = 0.0
                strong_changes = []
                rep_frames = []
            else:
                n = len(seg_pts)
                # information_density = mean change per unit time (not per frame count)
                # This prevents long segments from dominating by frame count
                sum_change = sum(p["visual_change_score"] for p in seg_pts)
                sum_novelty = sum(p["novelty_score"] for p in seg_pts)
                sum_motion = sum(p["motion_score"] for p in seg_pts)

                # Per-second density (normalised by duration, not frame count)
                change_density = round(sum_change / max(duration, 0.01), 4)
                novelty_density = round(sum_novelty / max(duration, 0.01), 4)
                motion_density = round(sum_motion / max(duration, 0.01), 4)

                # Strong change points within this segment
                strong_changes = [
                    p["source_video_timestamp_sec"]
                    for p in seg_pts
                    if p["visual_change_score"] >= self.change_peak_threshold
                    or p["scene_cut_score"] >= self.scene_cut_threshold
                ]

                # Representative frames: highest quality_score points
                sorted_by_quality = sorted(seg_pts, key=lambda p: p["quality_score"], reverse=True)
                rep_frames = [p["frame_ref"] for p in sorted_by_quality[:3]]

            segments.append({
                "segment_id": f"seg_{seg_idx:04d}",
                "source_start_sec": round(start, 2),
                "source_end_sec": round(end, 2),
                "duration_sec": duration,
                "change_density": change_density,
                "novelty_density": novelty_density,
                "motion_density": motion_density,
                "information_density": round(change_density + novelty_density, 4),
                "strong_change_points": strong_changes,
                "representative_frame_refs": rep_frames,
                "raw_scan_point_count": n
            })

        # --- Step 5: Transition candidate regions ---
        transition_candidates = self._find_transition_candidates(points)

        return {
            "total_duration_sec": total_duration,
            "scan_interval_sec": scan_interval,
            "segment_count": len(segments),
            "transition_candidate_count": len(transition_candidates),
            "segments": segments,
            "transition_candidate_regions": transition_candidates,
            "segmentation_config": {
                "scene_cut_threshold": self.scene_cut_threshold,
                "change_peak_threshold": self.change_peak_threshold,
                "novelty_peak_threshold": self.novelty_peak_threshold,
                "min_segment_duration_sec": self.min_segment_duration,
                "transition_merge_gap_sec": self.transition_merge_gap
            }
        }

    def _find_transition_candidates(self, points: list) -> list:
        """
        Find short high-change regions that may represent transitions.
        Even if a transition is very short (1-2 seconds), it gets its own candidate region.
        These are entry points for Adaptive Local Resampling in K2.
        """
        # Identify individual spike points
        spikes = []
        for pt in points:
            is_spike = (pt["visual_change_score"] >= self.change_peak_threshold or
                        pt["scene_cut_score"] >= self.scene_cut_threshold)
            if is_spike:
                spikes.append({
                    "ts": pt["source_video_timestamp_sec"],
                    "peak_change_score": max(pt["visual_change_score"], pt["scene_cut_score"]),
                    "scene_cut_score": pt["scene_cut_score"],
                    "visual_change_score": pt["visual_change_score"]
                })

        if not spikes:
            return []

        # Merge nearby spikes into candidate regions
        candidates = []
        current_start = spikes[0]["ts"]
        current_end = spikes[0]["ts"]
        current_peak = spikes[0]["peak_change_score"]
        spike_reasons = []
        if spikes[0]["scene_cut_score"] >= self.scene_cut_threshold:
            spike_reasons.append("scene_cut")
        if spikes[0]["visual_change_score"] >= self.change_peak_threshold:
            spike_reasons.append("visual_change_peak")

        for sp in spikes[1:]:
            if sp["ts"] - current_end <= self.transition_merge_gap:
                # Extend current candidate
                current_end = sp["ts"]
                current_peak = max(current_peak, sp["peak_change_score"])
                if sp["scene_cut_score"] >= self.scene_cut_threshold and "scene_cut" not in spike_reasons:
                    spike_reasons.append("scene_cut")
                if sp["visual_change_score"] >= self.change_peak_threshold and "visual_change_peak" not in spike_reasons:
                    spike_reasons.append("visual_change_peak")
            else:
                # Finalise current candidate
                candidates.append({
                    "start_sec": round(current_start, 2),
                    "end_sec": round(current_end + 1.0, 2),  # pad 1s after last spike
                    "reason": "+".join(spike_reasons) if spike_reasons else "visual_change",
                    "peak_change_score": round(current_peak, 4)
                })
                current_start = sp["ts"]
                current_end = sp["ts"]
                current_peak = sp["peak_change_score"]
                spike_reasons = []
                if sp["scene_cut_score"] >= self.scene_cut_threshold:
                    spike_reasons.append("scene_cut")
                if sp["visual_change_score"] >= self.change_peak_threshold:
                    spike_reasons.append("visual_change_peak")

        # Finalise last candidate
        candidates.append({
            "start_sec": round(current_start, 2),
            "end_sec": round(current_end + 1.0, 2),
            "reason": "+".join(spike_reasons) if spike_reasons else "visual_change",
            "peak_change_score": round(current_peak, 4)
        })

        return candidates

    def _empty_result(self, total_duration: float) -> dict:
        return {
            "total_duration_sec": total_duration,
            "scan_interval_sec": 0,
            "segment_count": 0,
            "transition_candidate_count": 0,
            "segments": [],
            "transition_candidate_regions": [],
            "segmentation_config": {}
        }


# ---------------------------------------------------------------------------
# Diagnostic helper
# ---------------------------------------------------------------------------

def compute_diagnostic(scan_result: dict, segmentation: dict) -> dict:
    """
    Compare dense scan against legacy 10s sampling.
    Returns diagnostic summary without calling Vision LLM.
    """
    points = scan_result["scan_points"]
    duration = scan_result["total_duration_sec"]
    interval = scan_result["scan_interval_sec"]

    if not points:
        return {"error": "no scan points"}

    change_scores = [p["visual_change_score"] for p in points]
    novelty_scores = [p["novelty_score"] for p in points]
    scene_cut_scores = [p["scene_cut_score"] for p in points]

    def top_n_timestamps(scores, n=10):
        indexed = sorted(enumerate(scores), key=lambda x: -x[1])
        return [round(points[i]["source_video_timestamp_sec"], 1)
                for i, _ in indexed[:n]]

    # Legacy 10s sampling points
    legacy_timestamps = [round(t, 1) for t in
                         [i * 10.0 for i in range(int(duration / 10) + 1)]]

    # Find transition candidates that fall between legacy sample points
    trans_regions = segmentation.get("transition_candidate_regions", [])
    missed_by_legacy = []
    for tc in trans_regions:
        tc_center = (tc["start_sec"] + tc["end_sec"]) / 2
        nearest_legacy = min(legacy_timestamps, key=lambda t: abs(t - tc_center))
        if abs(nearest_legacy - tc_center) > 6.0:  # >6s from any 10s sample point
            missed_by_legacy.append({
                "transition_region": tc,
                "nearest_legacy_sample_sec": nearest_legacy,
                "gap_sec": round(abs(nearest_legacy - tc_center), 1)
            })

    return {
        "video_duration_sec": duration,
        "scan_interval_sec": interval,
        "dense_scan_points": len(points),
        "legacy_10s_sample_count": len(legacy_timestamps),
        "density_ratio": round(len(points) / max(len(legacy_timestamps), 1), 1),
        "top_change_timestamps": top_n_timestamps(change_scores),
        "top_novelty_timestamps": top_n_timestamps(novelty_scores),
        "top_scene_cut_timestamps": top_n_timestamps(scene_cut_scores),
        "segments": segmentation["segment_count"],
        "transition_candidate_regions": len(trans_regions),
        "transition_regions_missed_by_legacy_sampling": missed_by_legacy,
        "estimated_expensive_vision_calls": 0,
        "no_expensive_vision_calls": True
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys, os
    scan_path = sys.argv[1] if len(sys.argv) > 1 else "extracted/keyframe_v2/dense_scan.json"
    out_path = sys.argv[2] if len(sys.argv) > 2 else "extracted/keyframe_v2/source_segments.json"

    with open(scan_path, encoding="utf-8") as f:
        scan_result = json.load(f)

    segmenter = TemporalSegmenter()
    result = segmenter.segment(scan_result)

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"Segments: {result['segment_count']}")
    print(f"Transition candidates: {result['transition_candidate_count']}")
    print(f"Output: {out_path}")
