"""
services/vision_progress.py

Vision Analysis Progress Tracking Layer

职责：
- 初始化 vision_progress.json
- 更新分析进度（current_frame_id, completed_frames, last_update）
- 每帧完成后立即写入 vision_results/frame_XXXXXX.json
- 支持失败恢复（已完成帧不重复分析）
- 提供 merge → frame_observations.json

不调用 Vision API，不分析图片内容。
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from typing import List, Optional


# ---------------------------------------------------------------------------
# 异常
# ---------------------------------------------------------------------------

class VisionProgressError(Exception):
    pass


# ---------------------------------------------------------------------------
# 状态常量
# ---------------------------------------------------------------------------

STATUS_PENDING    = "pending"
STATUS_RUNNING    = "running"
STATUS_COMPLETED  = "completed"
STATUS_FAILED     = "failed"


# ---------------------------------------------------------------------------
# 路径工具
# ---------------------------------------------------------------------------

def progress_path(source_root: str) -> str:
    return os.path.join(source_root, "extracted", "vision_progress.json")

def results_dir(source_root: str) -> str:
    return os.path.join(source_root, "extracted", "vision_results")

def frame_result_path(source_root: str, frame_id: int) -> str:
    return os.path.join(results_dir(source_root), f"frame_{frame_id:06d}.json")

def observations_path(source_root: str) -> str:
    return os.path.join(source_root, "extracted", "frame_observations.json")


# ---------------------------------------------------------------------------
# 时间戳
# ---------------------------------------------------------------------------

def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ---------------------------------------------------------------------------
# 进度初始化
# ---------------------------------------------------------------------------

def init_progress(source_root: str, total_frames: int) -> dict:
    """
    初始化 vision_progress.json。

    如果已存在且 status=completed，保持不变（幂等）。
    如果已存在且 status=running/failed，重置为 running（支持恢复）。

    Returns:
        当前 progress dict
    """
    os.makedirs(os.path.join(source_root, "extracted"), exist_ok=True)
    os.makedirs(results_dir(source_root), exist_ok=True)

    path = progress_path(source_root)
    now = _now_iso()

    # 如果已有进度文件，读取后决定是否恢复
    if os.path.isfile(path):
        with open(path, encoding="utf-8") as f:
            existing = json.load(f)
        if existing.get("status") == STATUS_COMPLETED:
            return existing  # 已完成，不重置
        # 恢复：保留已完成帧数，重置 status=running
        existing["status"] = STATUS_RUNNING
        existing["last_update"] = now
        with open(path, "w", encoding="utf-8") as f:
            json.dump(existing, f, ensure_ascii=False, indent=2)
        return existing

    progress = {
        "task": "frame_vision_analysis",
        "status": STATUS_RUNNING,
        "total_frames": total_frames,
        "completed_frames": 0,
        "current_frame_id": None,
        "started_at": now,
        "last_update": now,
        "errors": [],
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(progress, f, ensure_ascii=False, indent=2)
    return progress


# ---------------------------------------------------------------------------
# 进度更新
# ---------------------------------------------------------------------------

def update_progress(
    source_root: str,
    current_frame_id: Optional[int] = None,
    increment_completed: bool = False,
    status: Optional[str] = None,
    error: Optional[str] = None,
) -> dict:
    """更新 vision_progress.json 中的进度字段。"""
    path = progress_path(source_root)
    if not os.path.isfile(path):
        raise VisionProgressError(f"vision_progress.json 不存在: {path}")

    with open(path, encoding="utf-8") as f:
        progress = json.load(f)

    if current_frame_id is not None:
        progress["current_frame_id"] = current_frame_id
    if increment_completed:
        progress["completed_frames"] = progress.get("completed_frames", 0) + 1
    if status is not None:
        progress["status"] = status
    if error is not None:
        progress.setdefault("errors", []).append({
            "timestamp": _now_iso(),
            "message": error,
        })
    progress["last_update"] = _now_iso()

    with open(path, "w", encoding="utf-8") as f:
        json.dump(progress, f, ensure_ascii=False, indent=2)

    return progress


# ---------------------------------------------------------------------------
# 单帧结果写入
# ---------------------------------------------------------------------------

def save_frame_result(source_root: str, frame_result: dict) -> str:
    """
    将单帧视觉分析结果写入 vision_results/frame_XXXXXX.json。

    frame_result 必须包含：
      frame_id, filename, timestamp_sec, objects, scene,
      observable_facts, uncertain_points

    Returns:
        写入路径
    """
    frame_id = frame_result.get("frame_id")
    if frame_id is None:
        raise VisionProgressError("frame_result 缺少 frame_id")

    required = ["filename", "timestamp_sec", "objects", "scene",
                "observable_facts", "uncertain_points"]
    for field in required:
        if field not in frame_result:
            raise VisionProgressError(f"frame_result 缺少字段: {field!r}")

    os.makedirs(results_dir(source_root), exist_ok=True)
    path = frame_result_path(source_root, frame_id)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(frame_result, f, ensure_ascii=False, indent=2)
    return path


# ---------------------------------------------------------------------------
# 已完成帧检测（用于失败恢复）
# ---------------------------------------------------------------------------

def completed_frame_ids(source_root: str) -> set:
    """返回已保存结果的 frame_id 集合。"""
    rdir = results_dir(source_root)
    if not os.path.isdir(rdir):
        return set()
    ids = set()
    import re
    for fname in os.listdir(rdir):
        m = re.match(r"^frame_(\d+)\.json$", fname)
        if m:
            ids.add(int(m.group(1)))
    return ids


# ---------------------------------------------------------------------------
# 合并 → frame_observations.json
# ---------------------------------------------------------------------------

def merge_results(source_root: str, source_id: str) -> dict:
    """
    读取 vision_results/*.json，合并生成 frame_observations.json。

    Returns:
        frame_observations dict
    """
    rdir = results_dir(source_root)
    if not os.path.isdir(rdir):
        raise VisionProgressError(f"vision_results 目录不存在: {rdir}")

    result_files = sorted(
        f for f in os.listdir(rdir) if f.endswith(".json")
    )
    if not result_files:
        raise VisionProgressError("vision_results/ 中无结果文件")

    observations = []
    for fname in result_files:
        with open(os.path.join(rdir, fname), encoding="utf-8") as f:
            obs = json.load(f)
        observations.append(obs)

    # 按 frame_id 排序
    observations.sort(key=lambda o: o["frame_id"])

    output = {
        "source_id": source_id,
        "total_frames": len(observations),
        "backend_used": "openclaw_vision",
        "observations": observations,
    }

    out_path = observations_path(source_root)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    return output


# ---------------------------------------------------------------------------
# 读取当前进度（供外部查询）
# ---------------------------------------------------------------------------

def read_progress(source_root: str) -> dict:
    """读取当前 vision_progress.json。"""
    path = progress_path(source_root)
    if not os.path.isfile(path):
        return {"status": "not_started"}
    with open(path, encoding="utf-8") as f:
        return json.load(f)
