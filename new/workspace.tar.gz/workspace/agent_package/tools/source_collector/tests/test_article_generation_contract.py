"""
tests/test_article_generation_contract.py

Article Generation Contract Layer 单元测试

覆盖：
  1.  contract 文件存在
  2.  schema 正确
  3.  所有 post_plan 帖子都有 contract
  4.  fact_references 有效（fact_id 存在于 content_facts）
  5.  image_references 有效（frame_id 存在于 frame_observations）
  6.  target_length 存在
  7.  禁止引用不存在的 fact_id（报错）
  8.  缺少输入文件时报错
"""

import json
import os
import pytest

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.article_generation_contract import (
    build_contract,
    ArticleContractError,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_source_root(
    tmp_path,
    include_source=True,
    include_facts=True,
    include_kp=True,
    include_plan=True,
    include_obs=True,
    bad_fact_ref=False,
):
    if include_source:
        (tmp_path / "metadata").mkdir()
        (tmp_path / "metadata" / "source.json").write_text(json.dumps({
            "source_id": "test_contract_001",
            "title": "升空测试视频",
        }, ensure_ascii=False), encoding="utf-8")

    extracted = tmp_path / "extracted"
    extracted.mkdir(exist_ok=True)

    facts = [
        {
            "fact": "画面中存在大型气球",
            "evidence_frames": [6, 10],
            "timestamp_range": {"start": 50.0, "end": 100.0},
            "confidence": "high",
        },
        {
            "fact": "高空阶段地球曲面清晰可见",
            "evidence_frames": [36, 41],
            "timestamp_range": {"start": 350.0, "end": 400.0},
            "confidence": "high",
        },
    ]

    if include_facts:
        (extracted / "content_facts.json").write_text(json.dumps({
            "source_id": "test_contract_001",
            "title": "升空测试视频",
            "facts": facts,
            "uncertain_facts": [],
        }, ensure_ascii=False), encoding="utf-8")

    if include_kp:
        (extracted / "key_points.json").write_text(json.dumps({
            "source_id": "test_contract_001",
            "main_topic": "升空测试视频",
            "key_points": [
                {"title": "发射准备", "description": "准备阶段",
                 "related_frames": [6, 10], "importance": "high"},
            ],
        }, ensure_ascii=False), encoding="utf-8")

    if include_obs:
        (extracted / "frame_observations.json").write_text(json.dumps({
            "source_id": "test_contract_001",
            "total_frames": 4,
            "backend_used": "openclaw_vision",
            "observations": [
                {"frame_id": 6,  "filename": "frame_000006.jpg", "timestamp_sec": 50.0,
                 "objects": ["气球"], "scene": "发射准备",
                 "observable_facts": ["气球充气"], "uncertain_points": []},
                {"frame_id": 10, "filename": "frame_000010.jpg", "timestamp_sec": 90.0,
                 "objects": ["雪地"], "scene": "发射准备",
                 "observable_facts": ["雪地可见"], "uncertain_points": []},
                {"frame_id": 36, "filename": "frame_000036.jpg", "timestamp_sec": 350.0,
                 "objects": ["地球"], "scene": "近太空区域",
                 "observable_facts": ["地球曲率可见"], "uncertain_points": []},
                {"frame_id": 41, "filename": "frame_000041.jpg", "timestamp_sec": 400.0,
                 "objects": ["太空"], "scene": "近太空悬浮阶段",
                 "observable_facts": ["天空为黑色"], "uncertain_points": []},
            ],
        }, ensure_ascii=False), encoding="utf-8")

    if include_plan:
        fact_refs = ["fact_99"] if bad_fact_ref else ["fact_0", "fact_1"]
        (extracted / "post_plan.json").write_text(json.dumps({
            "source_id": "test_contract_001",
            "series_title": "升空测试视频",
            "posts": [
                {
                    "post_id": "post_001",
                    "title": "从雪地出发",
                    "theme": "项目起点与发射准备",
                    "summary": "发射准备阶段",
                    "key_points": ["发射准备"],
                    "fact_ids": fact_refs,
                    "image_frames": [6, 10],
                    "target_length": "800-1000",
                },
                {
                    "post_id": "post_002",
                    "title": "天空变黑",
                    "theme": "升空过程与近太空视觉",
                    "summary": "升空阶段",
                    "key_points": ["发射准备"],
                    "fact_ids": ["fact_1"],
                    "image_frames": [36, 41],
                    "target_length": "800-1000",
                },
            ],
        }, ensure_ascii=False), encoding="utf-8")

    return str(tmp_path)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def source_root(tmp_path):
    return make_source_root(tmp_path)

@pytest.fixture
def source_root_no_facts(tmp_path):
    return make_source_root(tmp_path, include_facts=False)

@pytest.fixture
def source_root_no_plan(tmp_path):
    return make_source_root(tmp_path, include_plan=False)

@pytest.fixture
def source_root_no_obs(tmp_path):
    return make_source_root(tmp_path, include_obs=False)

@pytest.fixture
def source_root_bad_fact(tmp_path):
    return make_source_root(tmp_path, bad_fact_ref=True)


# ---------------------------------------------------------------------------
# Test 1: contract 文件存在
# ---------------------------------------------------------------------------

def test_contract_file_exists(source_root):
    build_contract(source_root)
    path = os.path.join(source_root, "extracted", "article_generation_contract.json")
    assert os.path.isfile(path), "article_generation_contract.json 未生成"


# ---------------------------------------------------------------------------
# Test 2: schema 正确
# ---------------------------------------------------------------------------

def test_contract_schema(source_root):
    build_contract(source_root)
    with open(os.path.join(source_root, "extracted", "article_generation_contract.json"), encoding="utf-8") as f:
        data = json.load(f)

    assert "source_id" in data
    assert "posts" in data and isinstance(data["posts"], list)

    for post in data["posts"]:
        for field in ["post_id", "title", "target_length",
                      "required_sections", "fact_references", "image_references"]:
            assert field in post, f"contract post 缺少字段: {field!r}"

        assert isinstance(post["required_sections"], list) and len(post["required_sections"]) > 0
        assert isinstance(post["fact_references"], list)
        assert isinstance(post["image_references"], list)


# ---------------------------------------------------------------------------
# Test 3: 所有 post_plan 帖子都有 contract
# ---------------------------------------------------------------------------

def test_all_posts_have_contract(source_root):
    build_contract(source_root)
    with open(os.path.join(source_root, "extracted", "post_plan.json"), encoding="utf-8") as f:
        plan_ids = {p["post_id"] for p in json.load(f)["posts"]}
    with open(os.path.join(source_root, "extracted", "article_generation_contract.json"), encoding="utf-8") as f:
        contract_ids = {p["post_id"] for p in json.load(f)["posts"]}
    assert plan_ids == contract_ids, (
        f"post_plan 中的帖子未全部出现在 contract 中: missing={plan_ids - contract_ids}"
    )


# ---------------------------------------------------------------------------
# Test 4: fact_references 有效
# ---------------------------------------------------------------------------

def test_fact_references_valid(source_root):
    build_contract(source_root)
    with open(os.path.join(source_root, "extracted", "content_facts.json"), encoding="utf-8") as f:
        valid_ids = {f"fact_{i}" for i in range(len(json.load(f)["facts"]))}
    with open(os.path.join(source_root, "extracted", "article_generation_contract.json"), encoding="utf-8") as f:
        data = json.load(f)
    for post in data["posts"]:
        for ref in post["fact_references"]:
            assert ref["fact_id"] in valid_ids, (
                f"post {post['post_id']!r} 引用了不存在的 fact_id: {ref['fact_id']!r}"
            )


# ---------------------------------------------------------------------------
# Test 5: image_references 有效
# ---------------------------------------------------------------------------

def test_image_references_valid(source_root):
    build_contract(source_root)
    with open(os.path.join(source_root, "extracted", "frame_observations.json"), encoding="utf-8") as f:
        valid_ids = {o["frame_id"] for o in json.load(f)["observations"]}
    with open(os.path.join(source_root, "extracted", "article_generation_contract.json"), encoding="utf-8") as f:
        data = json.load(f)
    for post in data["posts"]:
        assert len(post["image_references"]) >= 2, (
            f"post {post['post_id']!r} image_references 少于 2 个"
        )
        for ref in post["image_references"]:
            assert ref["frame_id"] in valid_ids, (
                f"post {post['post_id']!r} 引用了不存在的 frame_id: {ref['frame_id']}"
            )


# ---------------------------------------------------------------------------
# Test 6: target_length 存在
# ---------------------------------------------------------------------------

def test_target_length_exists(source_root):
    build_contract(source_root)
    with open(os.path.join(source_root, "extracted", "article_generation_contract.json"), encoding="utf-8") as f:
        data = json.load(f)
    for post in data["posts"]:
        assert "target_length" in post and post["target_length"]


# ---------------------------------------------------------------------------
# Test 7: 引用不存在 fact_id 时报错
# ---------------------------------------------------------------------------

def test_invalid_fact_ref_raises_error(source_root_bad_fact):
    with pytest.raises(ArticleContractError) as exc_info:
        build_contract(source_root_bad_fact)
    assert "fact_99" in str(exc_info.value) or "fact_id" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Test 8: 缺少输入文件时报错
# ---------------------------------------------------------------------------

def test_missing_content_facts_raises(source_root_no_facts):
    with pytest.raises(ArticleContractError) as exc_info:
        build_contract(source_root_no_facts)
    assert "content_facts.json" in str(exc_info.value)


def test_missing_post_plan_raises(source_root_no_plan):
    with pytest.raises(ArticleContractError) as exc_info:
        build_contract(source_root_no_plan)
    assert "post_plan.json" in str(exc_info.value)


def test_missing_observations_raises(source_root_no_obs):
    with pytest.raises(ArticleContractError) as exc_info:
        build_contract(source_root_no_obs)
    assert "frame_observations.json" in str(exc_info.value)
