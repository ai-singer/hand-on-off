"""
tests/test_asr.py

ASR Service 单元测试

覆盖：
  1. transcript.json 文件生成
  2. transcript.json schema 验证
  3. segment 结构验证
  4. transcript.txt 文件生成
  5. missing audio error
  6. missing audio_metadata.json error
  7. result 对象字段验证
  8. 多 segment 时长覆盖验证
"""

import json
import os
import wave
import pytest

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.asr import (
    run_asr,
    MockBackend,
    ASRError,
    ASRResult,
    ASRSegment,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_wav(path: str, duration_sec: float = 10.0, sample_rate: int = 16000):
    """生成合法 wav 文件。"""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    num_frames = int(sample_rate * duration_sec)
    with wave.open(path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(b"\x00\x00" * num_frames)


def make_source_root(tmp_path, wav_duration: float = 10.0, include_audio_meta: bool = True):
    """
    建立完整的 source root，含 source.json + audio_metadata.json + audio.wav。
    """
    # metadata/source.json
    meta_dir = tmp_path / "metadata"
    meta_dir.mkdir()
    (meta_dir / "source.json").write_text(json.dumps({
        "source_id": "test_asr_001",
        "platform": "bilibili",
        "title": "Test ASR Video",
        "audio_file": "raw/audio.m4a",
        "status": "READY_FOR_EXTRACTION",
    }, ensure_ascii=False), encoding="utf-8")

    # extracted/audio/audio.wav
    wav_path = str(tmp_path / "extracted" / "audio" / "audio.wav")
    make_wav(wav_path, duration_sec=wav_duration)

    # extracted/audio_metadata.json
    if include_audio_meta:
        extracted_dir = tmp_path / "extracted"
        extracted_dir.mkdir(exist_ok=True)
        (extracted_dir / "audio_metadata.json").write_text(json.dumps({
            "source_id": "test_asr_001",
            "input_audio": "raw/audio.m4a",
            "output_audio": "extracted/audio/audio.wav",
            "duration_seconds": wav_duration,
            "sample_rate": 16000,
            "backend_used": "ffmpeg",
        }), encoding="utf-8")

    return str(tmp_path)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def source_root_10s(tmp_path):
    return make_source_root(tmp_path, wav_duration=10.0)


@pytest.fixture
def source_root_90s(tmp_path):
    """90 秒音频 → 至少 3 个 30s segment。"""
    return make_source_root(tmp_path, wav_duration=90.0)


@pytest.fixture
def source_root_no_wav(tmp_path):
    """有 audio_metadata.json 但 wav 文件不存在。"""
    meta_dir = tmp_path / "metadata"
    meta_dir.mkdir()
    (meta_dir / "source.json").write_text(json.dumps({
        "source_id": "test_asr_002",
        "platform": "bilibili",
        "title": "Test",
        "audio_file": "raw/audio.m4a",
        "status": "READY_FOR_EXTRACTION",
    }), encoding="utf-8")
    extracted_dir = tmp_path / "extracted"
    extracted_dir.mkdir()
    (extracted_dir / "audio_metadata.json").write_text(json.dumps({
        "source_id": "test_asr_002",
        "output_audio": "extracted/audio/audio.wav",
        "duration_seconds": 10.0,
        "sample_rate": 16000,
        "backend_used": "ffmpeg",
    }), encoding="utf-8")
    # 不创建 wav 文件
    return str(tmp_path)


@pytest.fixture
def source_root_no_audio_meta(tmp_path):
    """audio_metadata.json 不存在（Audio Extraction 未运行）。"""
    meta_dir = tmp_path / "metadata"
    meta_dir.mkdir()
    (meta_dir / "source.json").write_text(json.dumps({
        "source_id": "test_asr_003",
        "platform": "bilibili",
        "title": "Test",
        "audio_file": "raw/audio.m4a",
        "status": "READY_FOR_EXTRACTION",
    }), encoding="utf-8")
    # 不创建 audio_metadata.json
    return str(tmp_path)


# ---------------------------------------------------------------------------
# Test 1: transcript.json 文件生成
# ---------------------------------------------------------------------------

def test_transcript_json_generated(source_root_10s):
    run_asr(source_root_10s, backend=MockBackend())
    transcript_path = os.path.join(source_root_10s, "extracted", "transcript.json")
    assert os.path.isfile(transcript_path), "transcript.json 不存在"


# ---------------------------------------------------------------------------
# Test 2: transcript.json schema 验证
# ---------------------------------------------------------------------------

def test_transcript_json_schema(source_root_10s):
    run_asr(source_root_10s, backend=MockBackend())
    transcript_path = os.path.join(source_root_10s, "extracted", "transcript.json")

    with open(transcript_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    required_fields = [
        "source_id", "audio_file", "language",
        "duration_seconds", "segments", "backend_used"
    ]
    for field in required_fields:
        assert field in data, f"transcript.json 缺少字段: {field!r}"

    assert data["source_id"] == "test_asr_001"
    assert data["language"] in ("zh", "en", "ja")
    assert isinstance(data["duration_seconds"], (int, float))
    assert data["duration_seconds"] > 0
    assert isinstance(data["segments"], list)
    assert data["backend_used"] in ("mock", "whisper")


# ---------------------------------------------------------------------------
# Test 3: segment 结构验证
# ---------------------------------------------------------------------------

def test_segment_structure(source_root_10s):
    run_asr(source_root_10s, backend=MockBackend())
    transcript_path = os.path.join(source_root_10s, "extracted", "transcript.json")

    with open(transcript_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    assert len(data["segments"]) > 0, "segments 不能为空"

    for i, seg in enumerate(data["segments"]):
        assert "start" in seg, f"segment[{i}] 缺少 start"
        assert "end" in seg, f"segment[{i}] 缺少 end"
        assert "text" in seg, f"segment[{i}] 缺少 text"
        assert isinstance(seg["start"], (int, float)), f"segment[{i}].start 类型错误"
        assert isinstance(seg["end"], (int, float)), f"segment[{i}].end 类型错误"
        assert isinstance(seg["text"], str), f"segment[{i}].text 类型错误"
        assert seg["end"] > seg["start"], f"segment[{i}].end <= start"


# ---------------------------------------------------------------------------
# Test 4: transcript.txt 文件生成
# ---------------------------------------------------------------------------

def test_transcript_txt_generated(source_root_10s):
    run_asr(source_root_10s, backend=MockBackend())
    txt_path = os.path.join(source_root_10s, "extracted", "transcript.txt")
    assert os.path.isfile(txt_path), "transcript.txt 不存在"

    content = open(txt_path, "r", encoding="utf-8").read()
    assert len(content) > 0, "transcript.txt 不能为空"
    # 验证格式：每行应包含时间戳
    lines = [l for l in content.strip().split("\n") if l]
    assert len(lines) > 0
    assert "s -" in lines[0], f"transcript.txt 格式错误: {lines[0]!r}"


# ---------------------------------------------------------------------------
# Test 5: missing audio wav error
# ---------------------------------------------------------------------------

def test_missing_wav_raises_error(source_root_no_wav):
    with pytest.raises(ASRError) as exc_info:
        run_asr(source_root_no_wav, backend=MockBackend())
    assert "wav" in str(exc_info.value).lower() or "audio" in str(exc_info.value).lower()


# ---------------------------------------------------------------------------
# Test 6: missing audio_metadata.json error
# ---------------------------------------------------------------------------

def test_missing_audio_metadata_raises_error(source_root_no_audio_meta):
    with pytest.raises(ASRError) as exc_info:
        run_asr(source_root_no_audio_meta, backend=MockBackend())
    assert "audio_metadata" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Test 7: result 对象字段验证
# ---------------------------------------------------------------------------

def test_result_object_fields(source_root_10s):
    result = run_asr(source_root_10s, backend=MockBackend())

    assert isinstance(result, ASRResult)
    assert result.source_id == "test_asr_001"
    assert isinstance(result.segments, list)
    assert len(result.segments) > 0
    assert isinstance(result.segments[0], ASRSegment)
    assert result.duration_seconds > 0
    assert result.backend_used == "mock"
    assert result.language == "zh"


# ---------------------------------------------------------------------------
# Test 8: 多 segment 时长覆盖验证
# ---------------------------------------------------------------------------

def test_segments_cover_full_duration(source_root_90s):
    """
    90 秒音频：MockBackend 每 30s 一段，应生成 3 个 segment，
    且最后一个 segment.end ≈ duration_seconds。
    """
    result = run_asr(source_root_90s, backend=MockBackend())

    assert len(result.segments) == 3, (
        f"90s 音频应有 3 个 segment，实际: {len(result.segments)}"
    )
    assert result.segments[-1].end == pytest.approx(result.duration_seconds, abs=0.1)
    assert result.segments[0].start == 0.0
