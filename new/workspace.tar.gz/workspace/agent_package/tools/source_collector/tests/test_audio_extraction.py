"""
tests/test_audio_extraction.py

Audio Extraction Service 单元测试

覆盖：
  1. 输入音频存在 -> wav 输出存在
  2. wav 输出格式正确（合法 wav 文件）
  3. audio_metadata.json 字段正确
  4. 输入缺失时返回明确错误
  5. source.json 不存在时返回明确错误
  6. result 对象字段验证
  7. 生产路径：merged_file 优先于 audio_file（production path）
  8. merged_file 不存在时降级到 audio_file
"""

import json
import os
import wave
import pytest

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.audio_extraction import (
    extract_audio,
    MockBackend,
    AudioExtractionError,
    AudioExtractionResult,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_source_json(tmp_path, extra: dict = None) -> dict:
    base = {
        "source_id": "test_source_001",
        "platform": "bilibili",
        "creator": "test_creator",
        "title": "Test Video",
        "source_type": "video",
        "raw_file": "raw/video.mp4",
        "audio_file": "raw/audio.m4a",
        "status": "READY_FOR_EXTRACTION",
    }
    if extra:
        base.update(extra)
    meta_dir = tmp_path / "metadata"
    meta_dir.mkdir(exist_ok=True)
    (meta_dir / "source.json").write_text(
        json.dumps(base, ensure_ascii=False), encoding="utf-8"
    )
    return base


def make_raw_file(tmp_path, rel_path: str, content: bytes = b"\x00" * 128):
    p = tmp_path / rel_path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(content)
    return p


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_source_root(tmp_path):
    """标准 source root：audio_file 存在。"""
    make_source_json(tmp_path)
    make_raw_file(tmp_path, "raw/audio.m4a")
    return str(tmp_path)


@pytest.fixture
def mock_source_root_with_merged(tmp_path):
    """
    生产路径 fixture：source.json 包含 metadata.merged_file，
    对应文件存在，audio_file 也存在（用于降级测试）。
    """
    make_source_json(tmp_path, extra={
        "source_id": "bilibili_av84178790",
        "metadata": {
            "merged_file": "raw/camera_to_space_merged.mp4"
        }
    })
    make_raw_file(tmp_path, "raw/camera_to_space_merged.mp4")
    make_raw_file(tmp_path, "raw/audio.m4a")
    return str(tmp_path)


@pytest.fixture
def mock_source_root_merged_missing(tmp_path):
    """
    merged_file 在 source.json 中声明但文件不存在，
    应降级到 audio_file。
    """
    make_source_json(tmp_path, extra={
        "metadata": {
            "merged_file": "raw/nonexistent_merged.mp4"
        }
    })
    # audio_file 存在
    make_raw_file(tmp_path, "raw/audio.m4a")
    return str(tmp_path)


@pytest.fixture
def mock_source_root_no_audio_file(tmp_path):
    """audio_file 指向不存在的文件，无 merged_file。"""
    make_source_json(tmp_path, extra={
        "audio_file": "raw/nonexistent_audio.m4a",
        "metadata": {}
    })
    return str(tmp_path)


@pytest.fixture
def mock_source_root_no_metadata(tmp_path):
    """metadata/source.json 不存在。"""
    return str(tmp_path)


# ---------------------------------------------------------------------------
# Test 1: wav 输出存在
# ---------------------------------------------------------------------------

def test_wav_output_exists(mock_source_root):
    result = extract_audio(mock_source_root, backend=MockBackend())
    output_abs = os.path.join(mock_source_root, result.output_audio)
    assert os.path.isfile(output_abs), f"wav 输出文件不存在: {output_abs}"


# ---------------------------------------------------------------------------
# Test 2: wav 格式正确
# ---------------------------------------------------------------------------

def test_wav_output_is_valid(mock_source_root):
    result = extract_audio(mock_source_root, backend=MockBackend())
    output_abs = os.path.join(mock_source_root, result.output_audio)
    with wave.open(output_abs, "rb") as wf:
        assert wf.getnchannels() == 1
        assert wf.getframerate() == MockBackend.SAMPLE_RATE
        assert wf.getnframes() > 0


# ---------------------------------------------------------------------------
# Test 3: audio_metadata.json 字段正确
# ---------------------------------------------------------------------------

def test_audio_metadata_fields(mock_source_root):
    result = extract_audio(mock_source_root, backend=MockBackend())
    meta_path = os.path.join(mock_source_root, "extracted", "audio_metadata.json")
    assert os.path.isfile(meta_path)

    with open(meta_path, "r", encoding="utf-8") as f:
        meta = json.load(f)

    for field in ["source_id", "input_audio", "output_audio", "duration_seconds", "sample_rate"]:
        assert field in meta, f"缺少字段: {field!r}"

    assert meta["source_id"] == "test_source_001"
    assert meta["input_audio"].endswith((".m4a", ".mp4"))
    assert meta["output_audio"].endswith(".wav")
    assert isinstance(meta["duration_seconds"], (int, float)) and meta["duration_seconds"] > 0
    assert isinstance(meta["sample_rate"], int) and meta["sample_rate"] > 0


# ---------------------------------------------------------------------------
# Test 4: 输入缺失时报错
# ---------------------------------------------------------------------------

def test_missing_audio_file_raises_error(mock_source_root_no_audio_file):
    with pytest.raises(AudioExtractionError) as exc_info:
        extract_audio(mock_source_root_no_audio_file, backend=MockBackend())
    assert "nonexistent_audio.m4a" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Test 5: source.json 不存在时报错
# ---------------------------------------------------------------------------

def test_missing_metadata_raises_error(mock_source_root_no_metadata):
    with pytest.raises(AudioExtractionError) as exc_info:
        extract_audio(mock_source_root_no_metadata, backend=MockBackend())
    assert "source.json" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Test 6: result 对象字段验证
# ---------------------------------------------------------------------------

def test_result_object_fields(mock_source_root):
    result = extract_audio(mock_source_root, backend=MockBackend())
    assert isinstance(result, AudioExtractionResult)
    assert result.source_id == "test_source_001"
    assert result.output_audio == "extracted/audio/audio.wav"
    assert result.duration_seconds > 0
    assert result.sample_rate == MockBackend.SAMPLE_RATE
    assert result.backend_used == "mock"


# ---------------------------------------------------------------------------
# Test 7: 生产路径 — merged_file 优先于 audio_file
# ---------------------------------------------------------------------------

def test_merged_file_takes_priority(mock_source_root_with_merged):
    """
    audio_file 存在时，应使用 audio_file（纯音频流，结构完整）而不是 merged_file。

    生产决策：merged_file 由手工 Python mux 生成，moov 结构不完整，
    ffmpeg 无法正确读取。原始 audio_file 是标准 DASH 音频流，结构完整。
    """
    result = extract_audio(mock_source_root_with_merged, backend=MockBackend())
    assert result.input_audio == "raw/audio.m4a", (
        f"应使用 audio_file，实际使用: {result.input_audio}"
    )
    assert result.source_id == "bilibili_av84178790"
    output_abs = os.path.join(mock_source_root_with_merged, result.output_audio)
    assert os.path.isfile(output_abs)


# ---------------------------------------------------------------------------
# Test 8: merged_file 不存在时降级到 audio_file
# ---------------------------------------------------------------------------

def test_merged_file_fallback_to_audio_file(mock_source_root_merged_missing):
    """
    merged_file 声明但文件不存在时，
    应自动降级到 audio_file。
    """
    result = extract_audio(mock_source_root_merged_missing, backend=MockBackend())
    assert result.input_audio == "raw/audio.m4a", (
        f"降级后应使用 audio_file，实际使用: {result.input_audio}"
    )


# ---------------------------------------------------------------------------
# Test 9: 真实 FfmpegBackend 输出验证（需要 ffmpeg 安装）
# ---------------------------------------------------------------------------

FFMPEG_AVAILABLE = os.path.isfile("/home/node/.local/bin/ffmpeg") or bool(
    __import__("shutil").which("ffmpeg")
)
REAL_SOURCE_ROOT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "sources", "bilibili", "ysjf", "space_camera_project"
)


@pytest.mark.skipif(
    not FFMPEG_AVAILABLE,
    reason="ffmpeg not installed — skipping real backend test"
)
@pytest.mark.skipif(
    not os.path.isdir(REAL_SOURCE_ROOT),
    reason="real source root not found"
)
def test_real_ffmpeg_backend_output():
    """
    FfmpegBackend 生产路径验证。

    要求：
    - backend_used == 'ffmpeg'
    - duration_seconds > 800（视频约 867 秒）
    - sample_rate == 16000
    - output wav 文件合法可读
    """
    from services.audio_extraction import FfmpegBackend

    result = extract_audio(REAL_SOURCE_ROOT, backend=FfmpegBackend())

    # backend 验证
    assert result.backend_used == "ffmpeg", (
        f"应使用 ffmpeg，实际: {result.backend_used}"
    )

    # 时长验证（视频 867 秒，允许 ±10 秒误差）
    assert result.duration_seconds > 800, (
        f"duration_seconds 应 > 800，实际: {result.duration_seconds}"
    )

    # 采样率验证
    assert result.sample_rate == 16000, (
        f"sample_rate 应为 16000，实际: {result.sample_rate}"
    )

    # 输出文件验证
    wav_abs = os.path.join(REAL_SOURCE_ROOT, result.output_audio)
    assert os.path.isfile(wav_abs), f"wav 文件不存在: {wav_abs}"

    # wav 格式验证
    import wave
    with wave.open(wav_abs, "rb") as wf:
        assert wf.getnchannels() == 1
        assert wf.getframerate() == 16000
        assert wf.getnframes() > 16000 * 800  # 至少 800 秒的帧

    # metadata.json 验证
    meta_path = os.path.join(REAL_SOURCE_ROOT, "extracted", "audio_metadata.json")
    assert os.path.isfile(meta_path)
    import json
    with open(meta_path) as f:
        meta = json.load(f)
    assert meta["backend_used"] == "ffmpeg"
    assert meta["duration_seconds"] > 800
    assert meta["sample_rate"] == 16000
