"""
tests/test_bilibili_auth.py

Bilibili Authentication Layer 单元测试

覆盖：
  1. cookie 配置不存在 -> 明确错误
  2. cookie 文件存在 -> 可以读取路径
  3. 返回结果不能包含 cookie 内容
"""

import os
import tempfile
import pytest

from collectors.bilibili.auth import (
    load_auth,
    try_load_auth,
    BilibiliAuthConfig,
    BilibiliAuthError,
    ENV_COOKIE_PATH,
)


# ---------------------------------------------------------------------------
# Test 1: 环境变量未设置 -> 明确错误
# ---------------------------------------------------------------------------

def test_load_auth_missing_env(monkeypatch):
    """
    BILIBILI_COOKIE_PATH 未设置时，
    load_auth 必须抛出 BilibiliAuthError，
    且错误信息包含环境变量名称。
    """
    monkeypatch.delenv(ENV_COOKIE_PATH, raising=False)

    with pytest.raises(BilibiliAuthError) as exc_info:
        load_auth()

    assert ENV_COOKIE_PATH in str(exc_info.value), (
        f"错误信息应包含环境变量名 {ENV_COOKIE_PATH!r}"
    )


def test_load_auth_env_set_but_file_missing(monkeypatch, tmp_path):
    """
    BILIBILI_COOKIE_PATH 指向不存在的文件时，
    load_auth 必须抛出 BilibiliAuthError。
    """
    nonexistent = str(tmp_path / "no_such_cookies.txt")
    monkeypatch.setenv(ENV_COOKIE_PATH, nonexistent)

    with pytest.raises(BilibiliAuthError) as exc_info:
        load_auth()

    assert nonexistent in str(exc_info.value), (
        "错误信息应包含不存在的文件路径"
    )


# ---------------------------------------------------------------------------
# Test 2: cookie 文件存在 -> 可以读取路径
# ---------------------------------------------------------------------------

def test_load_auth_success(monkeypatch, tmp_path):
    """
    BILIBILI_COOKIE_PATH 指向真实存在的文件时，
    load_auth 返回 BilibiliAuthConfig，
    且 cookie_path 等于配置的路径。
    """
    cookie_file = tmp_path / "cookies.txt"
    # 写入占位内容（测试不关心内容格式）
    cookie_file.write_text("# Netscape HTTP Cookie File\n")

    monkeypatch.setenv(ENV_COOKIE_PATH, str(cookie_file))

    config = load_auth()

    assert isinstance(config, BilibiliAuthConfig)
    assert config.cookie_path == str(cookie_file)


def test_try_load_auth_success(monkeypatch, tmp_path):
    """
    try_load_auth 成功时返回 (BilibiliAuthConfig, None)。
    """
    cookie_file = tmp_path / "cookies.txt"
    cookie_file.write_text("# Netscape HTTP Cookie File\n")
    monkeypatch.setenv(ENV_COOKIE_PATH, str(cookie_file))

    config, error = try_load_auth()

    assert config is not None
    assert error is None
    assert config.cookie_path == str(cookie_file)


def test_try_load_auth_failure(monkeypatch):
    """
    try_load_auth 失败时返回 (None, error_message)，不抛出异常。
    """
    monkeypatch.delenv(ENV_COOKIE_PATH, raising=False)

    config, error = try_load_auth()

    assert config is None
    assert error is not None
    assert len(error) > 0


# ---------------------------------------------------------------------------
# Test 3: 返回结果不能包含 cookie 内容
# ---------------------------------------------------------------------------

def test_auth_config_repr_does_not_expose_path(monkeypatch, tmp_path):
    """
    BilibiliAuthConfig.__repr__ 不能泄露 cookie_path 的实际值，
    防止日志中意外打印敏感路径。
    """
    cookie_file = tmp_path / "secret_cookies.txt"
    cookie_file.write_text("SESSDATA=abc123secret\n")
    monkeypatch.setenv(ENV_COOKIE_PATH, str(cookie_file))

    config = load_auth()

    # repr 不应包含实际路径
    assert str(cookie_file) not in repr(config), (
        "BilibiliAuthConfig repr 不应暴露 cookie_path 的实际值"
    )


def test_load_auth_does_not_return_cookie_content(monkeypatch, tmp_path):
    """
    load_auth 返回的对象只包含路径，不包含 cookie 文件内容。
    BilibiliAuthConfig 没有 content / data / cookie 等内容字段。
    """
    cookie_file = tmp_path / "cookies.txt"
    secret_content = "SESSDATA=topsecret_value_xyz"
    cookie_file.write_text(secret_content)
    monkeypatch.setenv(ENV_COOKIE_PATH, str(cookie_file))

    config = load_auth()

    # 转为字符串后不应包含 cookie 内容
    config_str = str(vars(config))
    assert secret_content not in config_str, (
        "BilibiliAuthConfig 不应包含 cookie 文件内容"
    )
