from collectors.bilibili.collector import BilibiliCollector


def test_bilibili_collector_success():
    source_target = {
        "platform": "bilibili",
        "creator": "test_creator",
        "url": "https://space.bilibili.com/test",
        "collection_type": "creator_content",
    }

    collector = BilibiliCollector()

    result = collector.collect(source_target)

    assert result["status"] == "success"
    assert result["platform"] == "bilibili"
    assert len(result["items"]) > 0
    assert result["errors"] == []


def test_bilibili_collector_item_structure():
    source_target = {
        "platform": "bilibili",
        "creator": "test_creator",
        "url": "https://space.bilibili.com/test",
        "collection_type": "creator_content",
    }

    collector = BilibiliCollector()

    result = collector.collect(source_target)

    item = result["items"][0]

    assert "source_id" in item
    assert "title" in item
    assert "url" in item
    assert "metadata" in item
