"""
tests/test_content_distillation.py

Content Distillation Layer 单元测试

覆盖：
  1.  content_facts.json 存在
  2.  key_points.json 存在
  3.  source_id 正确
  4.  facts schema 正确
  5.  每个 fact 有 evidence_frames
  6.  evidence_frames 必须来自 frame_observations
  7.  uncertain_facts 字段存在
  8.  key_points schema 正确
  9.  related_frames 必须有效（来自 frame_observations）
  10. 缺少 frame_observations 时失败
"""

import json
import os
import pytest

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.content_distillation import (
    distill_content,
    ContentDistillationError,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

MINIMAL_JPEG = bytes([0xFF, 0xD8, 0xFF, 0xD9])


def make_source_root(
    tmp_path,
    include_source_json=True,
    include_observations=True,
    empty_observations=False,
):
    if include_source_json:
        (tmp_path / "metadata").mkdir()
        (tmp_path / "metadata" / "source.json").write_text(json.dumps({
            "source_id": "test_distill_001",
            "title": "升空测试视频",
        }, ensure_ascii=False), encoding="utf-8")

    extracted = tmp_path / "extracted"
    extracted.mkdir(exist_ok=True)

    if include_observations:
        observations = [] if empty_observations else [
            {
                "frame_id": 1, "filename": "frame_000001.jpg", "timestamp_sec": 0.0,
                "objects": ["片头字幕", "黑色背景"],
                "scene": "片头",
                "observable_facts": ["画面为黑色背景", "有文字字幕"],
                "uncertain_points": ["字幕内容无法辨认"],
            },
            {
                "frame_id": 6, "filename": "frame_000006.jpg", "timestamp_sec": 50.0,
                "objects": ["气球", "雪地", "人员", "系绳"],
                "scene": "发射准备",
                "observable_facts": ["大型气球已充气", "地面有积雪", "现场多名人员"],
                "uncertain_points": ["气球是否已释放无法确认", "具体地点无法确认"],
            },
            {
                "frame_id": 36, "filename": "frame_000036.jpg", "timestamp_sec": 350.0,
                "objects": ["气球", "黑色天空", "地球弧面", "大气层"],
                "scene": "近太空区域",
                "observable_facts": [
                    "天空背景为黑色",
                    "地球曲面弧线清晰可见",
                    "大气层蓝色薄层可见",
                ],
                "uncertain_points": ["精确高度无法判断"],
            },
            {
                "frame_id": 76, "filename": "frame_000076.jpg", "timestamp_sec": 750.0,
                "objects": ["载荷设备", "人员", "雪地"],
                "scene": "着陆后回收现场",
                "observable_facts": ["载荷已落地", "人员可见"],
                "uncertain_points": ["设备是否完好无法确认"],
            },
        ]
        (extracted / "frame_observations.json").write_text(json.dumps({
            "source_id": "test_distill_001",
            "total_frames": len(observations),
            "backend_used": "openclaw_vision",
            "observations": observations,
        }, ensure_ascii=False), encoding="utf-8")

    return str(tmp_path)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def source_root(tmp_path):
    return make_source_root(tmp_path)


@pytest.fixture
def source_root_no_obs(tmp_path):
    return make_source_root(tmp_path, include_observations=False)


@pytest.fixture
def source_root_no_src(tmp_path):
    return make_source_root(tmp_path, include_source_json=False)


# ---------------------------------------------------------------------------
# Test 1: content_facts.json 存在
# ---------------------------------------------------------------------------

def test_content_facts_file_exists(source_root):
    distill_content(source_root)
    path = os.path.join(source_root, "extracted", "content_facts.json")
    assert os.path.isfile(path), "content_facts.json 未生成"


# ---------------------------------------------------------------------------
# Test 2: key_points.json 存在
# ---------------------------------------------------------------------------

def test_key_points_file_exists(source_root):
    distill_content(source_root)
    path = os.path.join(source_root, "extracted", "key_points.json")
    assert os.path.isfile(path), "key_points.json 未生成"


# ---------------------------------------------------------------------------
# Test 3: source_id 正确
# ---------------------------------------------------------------------------

def test_source_id_correct(source_root):
    result = distill_content(source_root)
    assert result.source_id == "test_distill_001"

    with open(os.path.join(source_root, "extracted", "content_facts.json"), encoding="utf-8") as f:
        cf = json.load(f)
    assert cf["source_id"] == "test_distill_001"

    with open(os.path.join(source_root, "extracted", "key_points.json"), encoding="utf-8") as f:
        kp = json.load(f)
    assert kp["source_id"] == "test_distill_001"


# ---------------------------------------------------------------------------
# Test 4: facts schema 正确
# ---------------------------------------------------------------------------

def test_facts_schema(source_root):
    distill_content(source_root)
    with open(os.path.join(source_root, "extracted", "content_facts.json"), encoding="utf-8") as f:
        data = json.load(f)

    required_top = ["source_id", "title", "facts", "uncertain_facts"]
    for field in required_top:
        assert field in data, f"content_facts.json 缺少顶层字段: {field!r}"

    for fact in data["facts"]:
        for field in ["fact", "evidence_frames", "timestamp_range", "confidence"]:
            assert field in fact, f"fact 缺少字段: {field!r}"
        assert isinstance(fact["fact"], str) and len(fact["fact"]) > 0
        assert isinstance(fact["evidence_frames"], list)
        assert isinstance(fact["timestamp_range"], dict)
        assert "start" in fact["timestamp_range"] and "end" in fact["timestamp_range"]
        assert fact["confidence"] in ("high", "medium", "low")


# ---------------------------------------------------------------------------
# Test 5: 每个 fact 有 evidence_frames
# ---------------------------------------------------------------------------

def test_facts_have_evidence_frames(source_root):
    result = distill_content(source_root)
    for fact in result.facts:
        assert len(fact.evidence_frames) > 0, (
            f"fact 缺少 evidence_frames: {fact.fact!r}"
        )


# ---------------------------------------------------------------------------
# Test 6: evidence_frames 必须来自 frame_observations
# ---------------------------------------------------------------------------

def test_evidence_frames_valid(source_root):
    distill_content(source_root)
    with open(os.path.join(source_root, "extracted", "frame_observations.json"), encoding="utf-8") as f:
        valid_ids = {o["frame_id"] for o in json.load(f)["observations"]}

    with open(os.path.join(source_root, "extracted", "content_facts.json"), encoding="utf-8") as f:
        data = json.load(f)

    for fact in data["facts"]:
        for fid in fact["evidence_frames"]:
            assert fid in valid_ids, (
                f"evidence_frame {fid} 不在 frame_observations 中"
            )


# ---------------------------------------------------------------------------
# Test 7: uncertain_facts 字段存在
# ---------------------------------------------------------------------------

def test_uncertain_facts_exists(source_root):
    distill_content(source_root)
    with open(os.path.join(source_root, "extracted", "content_facts.json"), encoding="utf-8") as f:
        data = json.load(f)
    assert "uncertain_facts" in data
    assert isinstance(data["uncertain_facts"], list)
    # 至少有一条（测试数据中有多个 uncertain_points）
    assert len(data["uncertain_facts"]) > 0


# ---------------------------------------------------------------------------
# Test 8: key_points schema 正确
# ---------------------------------------------------------------------------

def test_key_points_schema(source_root):
    distill_content(source_root)
    with open(os.path.join(source_root, "extracted", "key_points.json"), encoding="utf-8") as f:
        data = json.load(f)

    for field in ["source_id", "main_topic", "key_points"]:
        assert field in data, f"key_points.json 缺少字段: {field!r}"

    assert isinstance(data["key_points"], list) and len(data["key_points"]) > 0

    for kp in data["key_points"]:
        for field in ["title", "description", "related_frames", "importance"]:
            assert field in kp, f"key_point 缺少字段: {field!r}"
        assert isinstance(kp["title"], str) and len(kp["title"]) > 0
        assert isinstance(kp["related_frames"], list)
        assert kp["importance"] in ("high", "medium", "low")


# ---------------------------------------------------------------------------
# Test 9: related_frames 必须有效
# ---------------------------------------------------------------------------

def test_related_frames_valid(source_root):
    distill_content(source_root)
    with open(os.path.join(source_root, "extracted", "frame_observations.json"), encoding="utf-8") as f:
        valid_ids = {o["frame_id"] for o in json.load(f)["observations"]}

    with open(os.path.join(source_root, "extracted", "key_points.json"), encoding="utf-8") as f:
        data = json.load(f)

    for kp in data["key_points"]:
        for fid in kp["related_frames"]:
            assert fid in valid_ids, (
                f"key_point '{kp['title']}' related_frame {fid} 不在 frame_observations 中"
            )


# ---------------------------------------------------------------------------
# Test 10: 缺少 frame_observations 时失败
# ---------------------------------------------------------------------------

def test_missing_observations_raises_error(source_root_no_obs):
    with pytest.raises(ContentDistillationError) as exc_info:
        distill_content(source_root_no_obs)
    assert "frame_observations.json" in str(exc_info.value)
