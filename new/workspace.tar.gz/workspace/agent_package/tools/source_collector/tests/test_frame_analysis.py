"""
tests/test_frame_analysis.py

Frame Analysis Service 单元测试

覆盖：
  1. 输出文件存在
  2. frame_observations.json schema 校验
  3. 每个 observation 字段完整
  4. 时间戳覆盖验证（first/last）
  5. 多 frame 聚合验证（total_frames 一致）
  6. frame_metadata.json 缺失时报错
  7. source.json 缺失时报错
  8. 帧文件不存在时报错
  9. confidence 值域验证 [0.0, 1.0]
"""

import json
import os
import pytest

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.frame_analysis import (
    analyze_frames,
    MockVisionBackend,
    VisionAPIBackend,
    OpenClawVisionBackend,
    FrameAnalysisError,
    FrameAnalysisResult,
    FrameObservation,
    build_result_from_dicts,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

JPEG_MINIMAL = bytes([
    0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01,
    0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x43,
    0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08, 0x07, 0x07, 0x07, 0x09,
    0x09, 0x08, 0x0A, 0x0C, 0x14, 0x0D, 0x0C, 0x0B, 0x0B, 0x0C, 0x19, 0x12,
    0x13, 0x0F, 0x14, 0x1D, 0x1A, 0x1F, 0x1E, 0x1D, 0x1A, 0x1C, 0x1C, 0x20,
    0x24, 0x2E, 0x27, 0x20, 0x22, 0x2C, 0x23, 0x1C, 0x1C, 0x28, 0x37, 0x29,
    0x2C, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1F, 0x27, 0x39, 0x3D, 0x38, 0x32,
    0x3C, 0x2E, 0x33, 0x34, 0x32, 0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x00, 0x01,
    0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xFF, 0xC4, 0x00, 0x1F, 0x00, 0x00,
    0x01, 0x05, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
    0x09, 0x0A, 0x0B, 0xFF, 0xDA, 0x00, 0x08, 0x01, 0x01, 0x00, 0x00, 0x3F,
    0x00, 0xFB, 0xD7, 0xFF, 0xD9,
])


def make_source_root(tmp_path, num_frames=3, interval_sec=10.0, include_frame_meta=True, include_source_json=True):
    """构建最小 source root，含 frame_metadata.json 和实际 JPEG 文件。"""
    # metadata/source.json
    if include_source_json:
        meta_dir = tmp_path / "metadata"
        meta_dir.mkdir()
        (meta_dir / "source.json").write_text(json.dumps({
            "source_id": "test_analysis_001",
            "platform": "bilibili",
            "title": "Test Frame Analysis",
            "raw_file": "raw/video.mp4",
            "status": "READY_FOR_EXTRACTION",
        }, ensure_ascii=False), encoding="utf-8")

    extracted_dir = tmp_path / "extracted"
    extracted_dir.mkdir(exist_ok=True)

    # extracted/frames/ + JPEG 文件
    frames_dir = extracted_dir / "frames"
    frames_dir.mkdir(exist_ok=True)

    frame_records = []
    for i in range(num_frames):
        ts = round(i * interval_sec, 3)
        ts_ms = int(ts * 1000)
        fname = f"frame_{i+1:06d}_{ts_ms:08d}ms.jpg"
        fpath = frames_dir / fname
        fpath.write_bytes(JPEG_MINIMAL)
        frame_records.append({
            "index": i + 1,
            "timestamp_sec": ts,
            "filename": fname,
            "filepath": f"extracted/frames/{fname}",
        })

    # extracted/frame_metadata.json
    if include_frame_meta:
        duration = round((num_frames - 1) * interval_sec + interval_sec, 3)
        (extracted_dir / "frame_metadata.json").write_text(json.dumps({
            "source_id": "test_analysis_001",
            "input_video": "raw/video.mp4",
            "output_dir": "extracted/frames",
            "interval_sec": interval_sec,
            "total_frames": num_frames,
            "duration_seconds": duration,
            "backend_used": "mock",
            "frames": frame_records,
        }, ensure_ascii=False), encoding="utf-8")

    return str(tmp_path)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def source_root_3frames(tmp_path):
    return make_source_root(tmp_path, num_frames=3)


@pytest.fixture
def source_root_5frames(tmp_path):
    return make_source_root(tmp_path, num_frames=5, interval_sec=30.0)


@pytest.fixture
def source_root_no_frame_meta(tmp_path):
    return make_source_root(tmp_path, num_frames=3, include_frame_meta=False)


@pytest.fixture
def source_root_no_source_json(tmp_path):
    return make_source_root(tmp_path, num_frames=3, include_source_json=False)


# ---------------------------------------------------------------------------
# Test 1: 输出文件存在
# ---------------------------------------------------------------------------

def test_output_file_exists(source_root_3frames):
    analyze_frames(source_root_3frames, backend=MockVisionBackend())
    out_path = os.path.join(source_root_3frames, "extracted", "frame_observations.json")
    assert os.path.isfile(out_path), "frame_observations.json 未生成"


# ---------------------------------------------------------------------------
# Test 2: frame_observations.json schema 校验
# ---------------------------------------------------------------------------

def test_output_schema(source_root_3frames):
    analyze_frames(source_root_3frames, backend=MockVisionBackend())
    out_path = os.path.join(source_root_3frames, "extracted", "frame_observations.json")
    with open(out_path, encoding="utf-8") as f:
        data = json.load(f)

    required_top = ["source_id", "total_frames", "backend_used", "observations"]
    for field in required_top:
        assert field in data, f"顶层缺少字段: {field!r}"

    assert data["source_id"] == "test_analysis_001"
    assert isinstance(data["total_frames"], int) and data["total_frames"] > 0
    assert data["backend_used"] in ("mock", "visionapi", "mock vision", "mockvision")
    assert isinstance(data["observations"], list) and len(data["observations"]) > 0


# ---------------------------------------------------------------------------
# Test 3: 每个 observation 字段完整
# ---------------------------------------------------------------------------

def test_observation_fields(source_root_3frames):
    result = analyze_frames(source_root_3frames, backend=MockVisionBackend())
    required = ["frame_id", "filename", "timestamp_sec", "filepath",
                "observations", "objects", "scene", "confidence", "uncertain_points"]
    for obs in result.observations:
        obs_dict = {
            "frame_id": obs.frame_id,
            "filename": obs.filename,
            "timestamp_sec": obs.timestamp_sec,
            "filepath": obs.filepath,
            "observations": obs.observations,
            "objects": obs.objects,
            "scene": obs.scene,
            "confidence": obs.confidence,
            "uncertain_points": obs.uncertain_points,
        }
        for f in required:
            assert f in obs_dict, f"observation 缺少字段: {f!r}"
        # 类型检查
        assert isinstance(obs.frame_id, int)
        assert isinstance(obs.filename, str) and obs.filename.endswith(".jpg")
        assert isinstance(obs.timestamp_sec, (int, float))
        assert isinstance(obs.observations, list)
        assert isinstance(obs.objects, list)
        assert isinstance(obs.scene, str) and len(obs.scene) > 0
        assert isinstance(obs.confidence, (int, float))
        assert isinstance(obs.uncertain_points, list)


# ---------------------------------------------------------------------------
# Test 4: 时间戳覆盖验证（first/last）
# ---------------------------------------------------------------------------

def test_timestamp_coverage(source_root_3frames):
    result = analyze_frames(source_root_3frames, backend=MockVisionBackend())
    # 3 帧，interval=10s → t=0,10,20
    assert result.observations[0].timestamp_sec == 0.0, "第一帧时间戳应为 0.0"
    assert result.observations[-1].timestamp_sec == 20.0, (
        f"最后一帧时间戳应为 20.0，实际 {result.observations[-1].timestamp_sec}"
    )


# ---------------------------------------------------------------------------
# Test 5: 多 frame 聚合验证
# ---------------------------------------------------------------------------

def test_multi_frame_aggregation(source_root_5frames):
    result = analyze_frames(source_root_5frames, backend=MockVisionBackend())
    assert result.total_frames == 5, f"期望 5 帧，实际 {result.total_frames}"
    assert len(result.observations) == 5
    # frame_id 连续且 1-based
    for i, obs in enumerate(result.observations):
        assert obs.frame_id == i + 1, f"frame_id 不连续: 期望 {i+1}，实际 {obs.frame_id}"
    # 时间戳单调递增
    ts_list = [o.timestamp_sec for o in result.observations]
    assert ts_list == sorted(ts_list), "时间戳应单调递增"

    # frame_observations.json 中 total_frames 与 observations 列表长度一致
    out_path = os.path.join(source_root_5frames, "extracted", "frame_observations.json")
    with open(out_path, encoding="utf-8") as f:
        data = json.load(f)
    assert data["total_frames"] == len(data["observations"]), (
        "total_frames 与 observations 列表长度不一致"
    )


# ---------------------------------------------------------------------------
# Test 6: frame_metadata.json 缺失时报错
# ---------------------------------------------------------------------------

def test_missing_frame_metadata_raises_error(source_root_no_frame_meta):
    with pytest.raises(FrameAnalysisError) as exc_info:
        analyze_frames(source_root_no_frame_meta, backend=MockVisionBackend())
    assert "frame_metadata.json" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Test 7: source.json 缺失时报错
# ---------------------------------------------------------------------------

def test_missing_source_json_raises_error(source_root_no_source_json):
    with pytest.raises(FrameAnalysisError) as exc_info:
        analyze_frames(source_root_no_source_json, backend=MockVisionBackend())
    assert "source.json" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Test 8: 帧文件不存在时报错
# ---------------------------------------------------------------------------

def test_missing_frame_file_raises_error(tmp_path):
    """frame_metadata.json 中引用了不存在的帧文件。"""
    meta_dir = tmp_path / "metadata"
    meta_dir.mkdir()
    (meta_dir / "source.json").write_text(json.dumps({
        "source_id": "test_missing_frame",
        "raw_file": "raw/video.mp4",
    }), encoding="utf-8")

    extracted_dir = tmp_path / "extracted"
    extracted_dir.mkdir()
    frames_dir = extracted_dir / "frames"
    frames_dir.mkdir()

    # frame_metadata.json 引用不存在的文件
    (extracted_dir / "frame_metadata.json").write_text(json.dumps({
        "source_id": "test_missing_frame",
        "frames": [{
            "index": 1,
            "timestamp_sec": 0.0,
            "filename": "frame_000001_00000000ms.jpg",
            "filepath": "extracted/frames/frame_000001_00000000ms.jpg",
        }],
    }), encoding="utf-8")
    # 注意：不创建实际 JPEG 文件

    with pytest.raises(FrameAnalysisError) as exc_info:
        analyze_frames(str(tmp_path), backend=MockVisionBackend())
    assert "frame_000001_00000000ms.jpg" in str(exc_info.value) or "不存在" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Test 9: confidence 值域验证 [0.0, 1.0]
# ---------------------------------------------------------------------------

def test_confidence_range(source_root_3frames):
    result = analyze_frames(source_root_3frames, backend=MockVisionBackend())
    for obs in result.observations:
        assert 0.0 <= obs.confidence <= 1.0, (
            f"frame_id={obs.frame_id} confidence={obs.confidence} 超出 [0, 1] 范围"
        )


# ---------------------------------------------------------------------------
# Test 10: VisionAPIBackend 未实现时 raise NotImplementedError
# ---------------------------------------------------------------------------

def test_vision_api_backend_not_implemented(source_root_3frames):
    backend = VisionAPIBackend()
    with pytest.raises(NotImplementedError):
        analyze_frames(source_root_3frames, backend=backend)


# ---------------------------------------------------------------------------
# Test 11: OpenClawVisionBackend — build_result_from_dicts 路径
# ---------------------------------------------------------------------------

def test_openclaw_vision_backend_output(tmp_path):
    """
    模拟 OpenClaw 原生视觉分析完成后的结果注入路径。

    验证：
    - backend_used = "openclaw_vision"
    - schema 正确（source_id, total_frames, observations）
    - 每个 observation 含 objects / scene / observable_facts / uncertain_points
    - 时间戳覆盖完整（第一帧 0.0，最后帧与帧数/间隔一致）
    - uncertain_points 存在且非空（不允许全部为空列表）
    - observable_facts 不允许包含推测性断言（mock 检查）
    """
    # 1. 构建 source root
    meta_dir = tmp_path / "metadata"
    meta_dir.mkdir()
    (meta_dir / "source.json").write_text(json.dumps({
        "source_id": "bilibili_av84178790",
        "platform": "bilibili",
        "title": "升空30000米",
        "raw_file": "raw/video.mp4",
        "status": "READY_FOR_EXTRACTION",
    }, ensure_ascii=False), encoding="utf-8")

    extracted_dir = tmp_path / "extracted"
    extracted_dir.mkdir()
    frames_dir = extracted_dir / "frames"
    frames_dir.mkdir()

    # 创建 3 个真实 JPEG 文件（使用 minimal JPEG bytes）
    num_frames = 3
    interval_sec = 10.0
    frame_records = []
    for i in range(num_frames):
        ts = round(i * interval_sec, 3)
        ts_ms = int(ts * 1000)
        fname = f"frame_{i+1:06d}_{ts_ms:08d}ms.jpg"
        (frames_dir / fname).write_bytes(JPEG_MINIMAL)
        frame_records.append({
            "index": i + 1,
            "timestamp_sec": ts,
            "filename": fname,
            "filepath": f"extracted/frames/{fname}",
        })

    # 2. 模拟 OpenClaw 视觉分析输出（3 帧的观察结果）
    simulated_observations = [
        {
            "frame_id": 1,
            "timestamp_sec": 0.0,
            "filename": frame_records[0]["filename"],
            "filepath": frame_records[0]["filepath"],
            "objects": ["气球", "操作人员", "雪地", "系绳"],
            "scene": "户外雪地，气球发射准备阶段",
            "observable_facts": [
                "气球已充气，体积大",
                "现场有多名人员穿冬装",
                "地面有积雪覆盖",
            ],
            "uncertain_points": [
                "气球是否已释放无法从单帧判断",
                "载荷内容不可分辨",
            ],
        },
        {
            "frame_id": 2,
            "timestamp_sec": 10.0,
            "filename": frame_records[1]["filename"],
            "filepath": frame_records[1]["filepath"],
            "objects": ["气球", "地面", "云层", "地平线"],
            "scene": "低空上升阶段，地面逐渐缩小",
            "observable_facts": [
                "气球已离地，视角偏高",
                "地面建筑物可见但较小",
                "天空占据画面大部分",
            ],
            "uncertain_points": [
                "具体高度无法从画面确定",
                "飞行速度不可判断",
            ],
        },
        {
            "frame_id": 3,
            "timestamp_sec": 20.0,
            "filename": frame_records[2]["filename"],
            "filepath": frame_records[2]["filepath"],
            "objects": ["气球", "大气层边界", "黑暗太空背景", "地球曲率"],
            "scene": "临近空间，大气层边界清晰可见",
            "observable_facts": [
                "天空变为深色，接近黑色",
                "地球曲率在画面中可见",
                "气球仍保持球形",
            ],
            "uncertain_points": [
                "精确高度无法从画面确定",
                "气球是否达到最大高度无法判断",
            ],
        },
    ]

    # 3. 调用 build_result_from_dicts（OpenClawVisionBackend 生产路径）
    result = build_result_from_dicts(str(tmp_path), simulated_observations)

    # --- 验证 backend_used ---
    assert result.backend_used == "openclaw_vision", (
        f"backend_used 应为 openclaw_vision，实际 {result.backend_used!r}"
    )

    # --- 验证 schema ---
    out_path = os.path.join(str(tmp_path), "extracted", "frame_observations.json")
    assert os.path.isfile(out_path), "frame_observations.json 未生成"
    with open(out_path, encoding="utf-8") as f:
        data = json.load(f)

    assert data["source_id"] == "bilibili_av84178790"
    assert data["total_frames"] == 3
    assert data["backend_used"] == "openclaw_vision"
    assert len(data["observations"]) == 3

    for obs in data["observations"]:
        for field in ["frame_id", "filename", "timestamp_sec", "filepath",
                       "objects", "scene", "observable_facts", "uncertain_points"]:
            assert field in obs, f"observation 缺少字段: {field!r}"

    # --- 验证时间戳覆盖 ---
    timestamps = [o["timestamp_sec"] for o in data["observations"]]
    assert timestamps[0] == 0.0, "第一帧时间戳应为 0.0"
    assert timestamps[-1] == 20.0, "最后一帧时间戳应为 20.0"
    assert timestamps == sorted(timestamps), "时间戳应单调递增"

    # --- 验证 uncertain_points 非空 ---
    for obs in data["observations"]:
        assert len(obs["uncertain_points"]) > 0, (
            f"frame_id={obs['frame_id']} uncertain_points 不应为空"
        )

    # --- 验证 observable_facts 不含推测性关键词 ---
    speculative_keywords = ["可能", "应该", "也许", "推测", "猜测", "probably", "maybe", "likely"]
    for obs in data["observations"]:
        for fact in obs["observable_facts"]:
            for kw in speculative_keywords:
                assert kw not in fact, (
                    f"observable_facts 包含推测性词汇 {kw!r}: {fact!r}"
                )
