"""
tests/test_frame_analysis_openclaw.py

OpenClaw Vision Analysis 输出验证测试

覆盖：
  1.  frame_observations.json 存在
  2.  schema 正确（顶层字段）
  3.  backend_used == "openclaw_vision"
  4.  所有 candidate frame 均被处理
  5.  frame_id 唯一
  6.  timestamp_sec 正确（与 candidate_frames.json 一致）
  7.  objects 字段存在且非空
  8.  observable_facts 字段存在且非空
  9.  uncertain_points 字段存在
  10. 缺少 vision_results 目录时 merge 报错
"""

import json
import os
import pytest

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.vision_progress import (
    merge_results,
    VisionProgressError,
    results_dir,
    observations_path,
)

SOURCE_ROOT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "sources", "bilibili", "ysjf", "space_camera_project"
)
OBSERVATIONS_PATH = os.path.join(SOURCE_ROOT, "extracted", "frame_observations.json")
CANDIDATE_PATH = os.path.join(SOURCE_ROOT, "extracted", "candidate_frames.json")


# ---------------------------------------------------------------------------
# 跳过条件：真实文件不存在时跳过集成测试
# ---------------------------------------------------------------------------

skip_if_no_output = pytest.mark.skipif(
    not os.path.isfile(OBSERVATIONS_PATH),
    reason="frame_observations.json 不存在，跳过集成测试"
)
skip_if_no_candidates = pytest.mark.skipif(
    not os.path.isfile(CANDIDATE_PATH),
    reason="candidate_frames.json 不存在"
)


# ---------------------------------------------------------------------------
# Test 1: frame_observations.json 存在
# ---------------------------------------------------------------------------

@skip_if_no_output
def test_observations_file_exists():
    assert os.path.isfile(OBSERVATIONS_PATH), "frame_observations.json 不存在"


# ---------------------------------------------------------------------------
# Test 2: schema 正确
# ---------------------------------------------------------------------------

@skip_if_no_output
def test_observations_schema():
    with open(OBSERVATIONS_PATH, encoding="utf-8") as f:
        data = json.load(f)
    for field in ["source_id", "total_frames", "backend_used", "observations"]:
        assert field in data, f"顶层缺少字段: {field!r}"
    assert isinstance(data["total_frames"], int) and data["total_frames"] > 0
    assert isinstance(data["observations"], list) and len(data["observations"]) > 0

    for obs in data["observations"]:
        for field in ["frame_id", "filename", "timestamp_sec",
                      "objects", "scene", "observable_facts", "uncertain_points"]:
            assert field in obs, f"observation 缺少字段: {field!r}"


# ---------------------------------------------------------------------------
# Test 3: backend_used == "openclaw_vision"
# ---------------------------------------------------------------------------

@skip_if_no_output
def test_backend_used_is_openclaw_vision():
    with open(OBSERVATIONS_PATH, encoding="utf-8") as f:
        data = json.load(f)
    assert data["backend_used"] == "openclaw_vision", (
        f"backend_used 应为 openclaw_vision，实际: {data['backend_used']!r}"
    )


# ---------------------------------------------------------------------------
# Test 4: 所有 candidate frame 均被处理
# ---------------------------------------------------------------------------

@skip_if_no_output
@skip_if_no_candidates
def test_all_candidates_processed():
    with open(CANDIDATE_PATH, encoding="utf-8") as f:
        candidates = json.load(f)["candidates"]
    with open(OBSERVATIONS_PATH, encoding="utf-8") as f:
        observations = json.load(f)["observations"]

    candidate_ids = {c["frame_id"] for c in candidates}
    observed_ids = {o["frame_id"] for o in observations}
    missing = candidate_ids - observed_ids
    assert len(missing) == 0, f"以下 candidate frame 未被处理: {sorted(missing)}"


# ---------------------------------------------------------------------------
# Test 5: frame_id 唯一
# ---------------------------------------------------------------------------

@skip_if_no_output
def test_frame_ids_unique():
    with open(OBSERVATIONS_PATH, encoding="utf-8") as f:
        data = json.load(f)
    ids = [o["frame_id"] for o in data["observations"]]
    assert len(ids) == len(set(ids)), f"存在重复 frame_id: {ids}"


# ---------------------------------------------------------------------------
# Test 6: timestamp_sec 与 candidate_frames.json 一致
# ---------------------------------------------------------------------------

@skip_if_no_output
@skip_if_no_candidates
def test_timestamps_match_candidates():
    with open(CANDIDATE_PATH, encoding="utf-8") as f:
        candidates = {c["frame_id"]: c["timestamp_sec"] for c in json.load(f)["candidates"]}
    with open(OBSERVATIONS_PATH, encoding="utf-8") as f:
        observations = json.load(f)["observations"]

    for obs in observations:
        fid = obs["frame_id"]
        if fid in candidates:
            assert obs["timestamp_sec"] == candidates[fid], (
                f"frame_id={fid} timestamp 不一致: "
                f"expected {candidates[fid]}, got {obs['timestamp_sec']}"
            )


# ---------------------------------------------------------------------------
# Test 7: objects 字段存在且非空
# ---------------------------------------------------------------------------

@skip_if_no_output
def test_objects_nonempty():
    with open(OBSERVATIONS_PATH, encoding="utf-8") as f:
        data = json.load(f)
    for obs in data["observations"]:
        assert isinstance(obs["objects"], list), f"frame_id={obs['frame_id']} objects 不是 list"
        assert len(obs["objects"]) > 0, f"frame_id={obs['frame_id']} objects 为空"


# ---------------------------------------------------------------------------
# Test 8: observable_facts 字段存在且非空
# ---------------------------------------------------------------------------

@skip_if_no_output
def test_observable_facts_nonempty():
    with open(OBSERVATIONS_PATH, encoding="utf-8") as f:
        data = json.load(f)
    for obs in data["observations"]:
        assert isinstance(obs["observable_facts"], list)
        assert len(obs["observable_facts"]) > 0, (
            f"frame_id={obs['frame_id']} observable_facts 为空"
        )


# ---------------------------------------------------------------------------
# Test 9: uncertain_points 字段存在
# ---------------------------------------------------------------------------

@skip_if_no_output
def test_uncertain_points_exists():
    with open(OBSERVATIONS_PATH, encoding="utf-8") as f:
        data = json.load(f)
    for obs in data["observations"]:
        assert "uncertain_points" in obs, (
            f"frame_id={obs['frame_id']} 缺少 uncertain_points"
        )
        assert isinstance(obs["uncertain_points"], list)


# ---------------------------------------------------------------------------
# Test 10: 缺少 vision_results 时 merge 报错
# ---------------------------------------------------------------------------

def test_merge_missing_results_dir_raises(tmp_path):
    (tmp_path / "metadata").mkdir()
    (tmp_path / "metadata" / "source.json").write_text(
        json.dumps({"source_id": "test"}), encoding="utf-8"
    )
    (tmp_path / "extracted").mkdir()
    # 不创建 vision_results/
    with pytest.raises(VisionProgressError):
        merge_results(str(tmp_path), source_id="test")
