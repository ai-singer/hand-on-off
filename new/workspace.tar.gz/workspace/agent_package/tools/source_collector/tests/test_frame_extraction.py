"""
tests/test_frame_extraction.py

Frame Extraction Service 单元测试

覆盖：
  1. frames 目录存在且非空
  2. JPEG 文件合法（magic bytes）
  3. frame_metadata.json schema 验证
  4. 时间戳覆盖验证（first/last frame timestamp）
  5. 帧数量与时长/间隔一致
  6. 视频文件不存在时报错
  7. source.json 不存在时报错
  8. 文件命名格式验证
"""

import json
import os
import pytest

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.frame_extraction import (
    extract_frames,
    MockBackend,
    FrameExtractionError,
    FrameExtractionResult,
    FrameInfo,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

JPEG_MAGIC = bytes([0xFF, 0xD8, 0xFF])


def make_source_root(tmp_path, include_video: bool = True, duration_hint: float = 60.0):
    """建立最小 source root。"""
    meta_dir = tmp_path / "metadata"
    meta_dir.mkdir()
    (meta_dir / "source.json").write_text(json.dumps({
        "source_id": "test_frame_001",
        "platform": "bilibili",
        "title": "Test Frame Video",
        "raw_file": "raw/video.mp4",
        "audio_file": "raw/audio.m4a",
        "status": "READY_FOR_EXTRACTION",
    }, ensure_ascii=False), encoding="utf-8")

    if include_video:
        raw_dir = tmp_path / "raw"
        raw_dir.mkdir()
        (raw_dir / "video.mp4").write_bytes(b"\x00" * 256)

    # audio_metadata.json（供 MockBackend 读取时长）
    extracted_dir = tmp_path / "extracted"
    extracted_dir.mkdir(exist_ok=True)
    (extracted_dir / "audio_metadata.json").write_text(json.dumps({
        "source_id": "test_frame_001",
        "output_audio": "extracted/audio/audio.wav",
        "duration_seconds": duration_hint,
        "sample_rate": 16000,
        "backend_used": "mock",
    }), encoding="utf-8")

    return str(tmp_path)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def source_root_60s(tmp_path):
    return make_source_root(tmp_path, duration_hint=60.0)


@pytest.fixture
def source_root_100s(tmp_path):
    return make_source_root(tmp_path, duration_hint=100.0)


@pytest.fixture
def source_root_no_video(tmp_path):
    return make_source_root(tmp_path, include_video=False)


@pytest.fixture
def source_root_no_metadata(tmp_path):
    return str(tmp_path)


# ---------------------------------------------------------------------------
# Test 1: frames 目录存在且非空
# ---------------------------------------------------------------------------

def test_frames_dir_exists_and_nonempty(source_root_60s):
    result = extract_frames(source_root_60s, interval_sec=10.0, backend=MockBackend())
    frames_dir = os.path.join(source_root_60s, "extracted", "frames")
    assert os.path.isdir(frames_dir), "extracted/frames/ 目录不存在"
    files = [f for f in os.listdir(frames_dir) if f.endswith(".jpg")]
    assert len(files) > 0, "frames 目录为空"


# ---------------------------------------------------------------------------
# Test 2: JPEG 文件合法（magic bytes）
# ---------------------------------------------------------------------------

def test_frames_are_valid_jpegs(source_root_60s):
    result = extract_frames(source_root_60s, interval_sec=10.0, backend=MockBackend())
    frames_dir = os.path.join(source_root_60s, "extracted", "frames")
    jpg_files = sorted(f for f in os.listdir(frames_dir) if f.endswith(".jpg"))
    assert len(jpg_files) > 0

    for fname in jpg_files:
        fpath = os.path.join(frames_dir, fname)
        with open(fpath, "rb") as f:
            magic = f.read(3)
        assert magic == JPEG_MAGIC, f"{fname} 不是合法 JPEG（magic: {magic.hex()}）"


# ---------------------------------------------------------------------------
# Test 3: frame_metadata.json schema 验证
# ---------------------------------------------------------------------------

def test_frame_metadata_schema(source_root_60s):
    result = extract_frames(source_root_60s, interval_sec=10.0, backend=MockBackend())
    meta_path = os.path.join(source_root_60s, "extracted", "frame_metadata.json")
    assert os.path.isfile(meta_path), "frame_metadata.json 不存在"

    with open(meta_path, "r", encoding="utf-8") as f:
        meta = json.load(f)

    required_top = ["source_id", "input_video", "output_dir",
                    "interval_sec", "total_frames", "duration_seconds",
                    "backend_used", "frames"]
    for field in required_top:
        assert field in meta, f"frame_metadata.json 缺少字段: {field!r}"

    assert meta["source_id"] == "test_frame_001"
    assert meta["output_dir"] == "extracted/frames"
    assert isinstance(meta["total_frames"], int) and meta["total_frames"] > 0
    assert isinstance(meta["duration_seconds"], (int, float)) and meta["duration_seconds"] > 0
    assert meta["backend_used"] in ("ffmpeg", "mock")
    assert isinstance(meta["frames"], list) and len(meta["frames"]) > 0

    # 验证 frame 条目结构
    frame0 = meta["frames"][0]
    for field in ["index", "timestamp_sec", "filename", "filepath"]:
        assert field in frame0, f"frame 条目缺少字段: {field!r}"


# ---------------------------------------------------------------------------
# Test 4: 时间戳覆盖验证
# ---------------------------------------------------------------------------

def test_timestamp_coverage(source_root_60s):
    """
    第一帧时间戳 = 0.0，
    最后一帧时间戳 < duration_seconds。
    """
    result = extract_frames(source_root_60s, interval_sec=10.0, backend=MockBackend())
    assert result.frames[0].timestamp_sec == 0.0
    assert result.frames[-1].timestamp_sec < result.duration_seconds


# ---------------------------------------------------------------------------
# Test 5: 帧数量与时长/间隔一致
# ---------------------------------------------------------------------------

def test_frame_count_matches_interval(source_root_60s):
    """
    60s 视频，10s 间隔 → 6 帧（0,10,20,30,40,50）
    """
    result = extract_frames(source_root_60s, interval_sec=10.0, backend=MockBackend())
    expected = int(60.0 / 10.0)
    assert result.total_frames == expected, (
        f"期望 {expected} 帧，实际 {result.total_frames}"
    )


# ---------------------------------------------------------------------------
# Test 6: 视频文件不存在时报错
# ---------------------------------------------------------------------------

def test_missing_video_raises_error(source_root_no_video):
    with pytest.raises(FrameExtractionError) as exc_info:
        extract_frames(source_root_no_video, interval_sec=10.0, backend=MockBackend())
    assert "video.mp4" in str(exc_info.value) or "不存在" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Test 7: source.json 不存在时报错
# ---------------------------------------------------------------------------

def test_missing_source_json_raises_error(source_root_no_metadata):
    with pytest.raises(FrameExtractionError) as exc_info:
        extract_frames(source_root_no_metadata, interval_sec=10.0, backend=MockBackend())
    assert "source.json" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Test 8: 文件命名格式验证
# ---------------------------------------------------------------------------

def test_frame_filename_format(source_root_60s):
    """
    文件名格式：frame_{index:06d}_{timestamp_ms:08d}ms.jpg
    示例：frame_000001_00000000ms.jpg
    """
    result = extract_frames(source_root_60s, interval_sec=10.0, backend=MockBackend())
    import re
    pattern = re.compile(r"^frame_\d{6}_\d{8}ms\.jpg$")
    for fr in result.frames:
        assert pattern.match(fr.filename), (
            f"文件名格式错误: {fr.filename!r}"
        )
    # 第一帧时间戳 = 0ms
    assert result.frames[0].filename == "frame_000001_00000000ms.jpg"


# ---------------------------------------------------------------------------
# Test 9: 不同间隔验证（100s / 30s 间隔）
# ---------------------------------------------------------------------------

def test_different_interval(source_root_100s):
    """
    100s 视频，30s 间隔 → 4 帧（0,30,60,90）
    """
    result = extract_frames(source_root_100s, interval_sec=30.0, backend=MockBackend())
    # 0, 30, 60, 90 → 4 帧（100 > 90，90 < 100 满足条件）
    expected = int(100.0 / 30.0)  # = 3，但 t=0 也算 → 实际 4
    # MockBackend: while t < duration → t=0,30,60,90 → 4 帧
    assert result.total_frames == 4, (
        f"100s/30s 期望 4 帧，实际 {result.total_frames}"
    )
    assert result.frames[0].timestamp_sec == 0.0
    assert result.frames[-1].timestamp_sec == 90.0
