"""
tests/test_frame_screening.py

Frame Screening Layer 单元测试

覆盖：
  1. 输出文件存在
  2. candidate_frames.json schema 校验
  3. 第一帧和最后一帧必须在候选中（endpoint 规则）
  4. 时间百分位覆盖（0%/50%/100% 附近有候选帧）
  5. candidate_count 与 candidates 列表长度一致
  6. 候选帧无重复 frame_id
  7. 候选帧按 frame_id 升序排列
  8. 每个候选帧有非空 selection_reason
  9. frame_metadata.json 缺失时报错
  10. source.json 缺失时报错
  11. 最大候选数约束（max_candidates）
  12. 最小候选数约束（min_candidates）
"""

import json
import os
import pytest

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.frame_screening import (
    screen_frames,
    FrameScreeningError,
    FrameScreeningResult,
    CandidateFrame,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_source_root(
    tmp_path,
    num_frames: int = 87,
    interval_sec: float = 10.0,
    include_frame_meta: bool = True,
    include_source_json: bool = True,
):
    """构建最小 source root（无需真实 JPEG 文件）。"""
    if include_source_json:
        meta_dir = tmp_path / "metadata"
        meta_dir.mkdir()
        (meta_dir / "source.json").write_text(json.dumps({
            "source_id": "test_screen_001",
            "platform": "bilibili",
            "title": "Test Screening",
            "raw_file": "raw/video.mp4",
        }, ensure_ascii=False), encoding="utf-8")

    extracted_dir = tmp_path / "extracted"
    extracted_dir.mkdir(exist_ok=True)

    if include_frame_meta:
        frame_records = []
        for i in range(num_frames):
            ts = round(i * interval_sec, 3)
            ts_ms = int(ts * 1000)
            fname = f"frame_{i+1:06d}_{ts_ms:08d}ms.jpg"
            frame_records.append({
                "index": i + 1,
                "timestamp_sec": ts,
                "filename": fname,
                "filepath": f"extracted/frames/{fname}",
            })

        duration = round((num_frames - 1) * interval_sec + interval_sec, 3)
        (extracted_dir / "frame_metadata.json").write_text(json.dumps({
            "source_id": "test_screen_001",
            "input_video": "raw/video.mp4",
            "output_dir": "extracted/frames",
            "interval_sec": interval_sec,
            "total_frames": num_frames,
            "duration_seconds": duration,
            "backend_used": "ffmpeg",
            "frames": frame_records,
        }, ensure_ascii=False), encoding="utf-8")

    return str(tmp_path)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def source_root_87frames(tmp_path):
    return make_source_root(tmp_path, num_frames=87)


@pytest.fixture
def source_root_10frames(tmp_path):
    return make_source_root(tmp_path, num_frames=10)


@pytest.fixture
def source_root_3frames(tmp_path):
    return make_source_root(tmp_path, num_frames=3)


@pytest.fixture
def source_root_no_frame_meta(tmp_path):
    return make_source_root(tmp_path, num_frames=10, include_frame_meta=False)


@pytest.fixture
def source_root_no_source_json(tmp_path):
    return make_source_root(tmp_path, num_frames=10, include_source_json=False)


# ---------------------------------------------------------------------------
# Test 1: 输出文件存在
# ---------------------------------------------------------------------------

def test_output_file_exists(source_root_87frames):
    screen_frames(source_root_87frames)
    out_path = os.path.join(source_root_87frames, "extracted", "candidate_frames.json")
    assert os.path.isfile(out_path), "candidate_frames.json 未生成"


# ---------------------------------------------------------------------------
# Test 2: schema 校验
# ---------------------------------------------------------------------------

def test_output_schema(source_root_87frames):
    result = screen_frames(source_root_87frames)
    out_path = os.path.join(source_root_87frames, "extracted", "candidate_frames.json")
    with open(out_path, encoding="utf-8") as f:
        data = json.load(f)

    for field in ["source_id", "total_frames", "candidate_count",
                  "selection_strategy", "candidates"]:
        assert field in data, f"顶层缺少字段: {field!r}"

    assert data["source_id"] == "test_screen_001"
    assert data["total_frames"] == 87
    assert isinstance(data["candidate_count"], int) and data["candidate_count"] > 0
    assert isinstance(data["selection_strategy"], str) and len(data["selection_strategy"]) > 0
    assert isinstance(data["candidates"], list) and len(data["candidates"]) > 0

    # 检查候选帧字段
    for c in data["candidates"]:
        for field in ["frame_id", "filename", "timestamp_sec",
                      "filepath", "selection_reason"]:
            assert field in c, f"candidate 缺少字段: {field!r}"
        assert isinstance(c["frame_id"], int)
        assert isinstance(c["timestamp_sec"], (int, float))
        assert isinstance(c["selection_reason"], list)


# ---------------------------------------------------------------------------
# Test 3: endpoint 规则 — 第一帧和最后一帧必须在候选中
# ---------------------------------------------------------------------------

def test_endpoints_always_included(source_root_87frames):
    result = screen_frames(source_root_87frames)
    frame_ids = [c.frame_id for c in result.candidates]
    assert 1 in frame_ids, "第一帧 (frame_id=1) 未包含在候选中"
    assert 87 in frame_ids, "最后一帧 (frame_id=87) 未包含在候选中"


# ---------------------------------------------------------------------------
# Test 4: 时间百分位覆盖
# ---------------------------------------------------------------------------

def test_time_percentile_coverage(source_root_87frames):
    """
    0%/50%/100% 百分位对应时间附近必须有候选帧。
    容差：interval_sec = 10s。
    """
    result = screen_frames(source_root_87frames)
    timestamps = [c.timestamp_sec for c in result.candidates]
    duration = result.candidates[-1].timestamp_sec  # 最大时间戳

    tolerance = 15.0  # 10s 间隔，允许 1.5 帧误差

    # 0% → t=0
    assert any(abs(ts - 0.0) <= tolerance for ts in timestamps), \
        "0% 时间百分位附近无候选帧"

    # 50% → t=duration/2
    mid = duration / 2
    assert any(abs(ts - mid) <= tolerance for ts in timestamps), \
        f"50% 时间百分位 (t={mid:.1f}s) 附近无候选帧"

    # 100% → t=duration
    assert any(abs(ts - duration) <= tolerance for ts in timestamps), \
        "100% 时间百分位附近无候选帧"


# ---------------------------------------------------------------------------
# Test 5: candidate_count 与 candidates 列表长度一致
# ---------------------------------------------------------------------------

def test_candidate_count_consistent(source_root_87frames):
    result = screen_frames(source_root_87frames)
    assert result.candidate_count == len(result.candidates), (
        f"candidate_count={result.candidate_count} 与 "
        f"candidates 列表长度={len(result.candidates)} 不一致"
    )

    # 也验证 JSON 中一致
    out_path = os.path.join(source_root_87frames, "extracted", "candidate_frames.json")
    with open(out_path, encoding="utf-8") as f:
        data = json.load(f)
    assert data["candidate_count"] == len(data["candidates"])


# ---------------------------------------------------------------------------
# Test 6: 无重复 frame_id
# ---------------------------------------------------------------------------

def test_no_duplicate_frame_ids(source_root_87frames):
    result = screen_frames(source_root_87frames)
    frame_ids = [c.frame_id for c in result.candidates]
    assert len(frame_ids) == len(set(frame_ids)), "候选帧中存在重复 frame_id"


# ---------------------------------------------------------------------------
# Test 7: 候选帧按 frame_id 升序排列
# ---------------------------------------------------------------------------

def test_candidates_sorted(source_root_87frames):
    result = screen_frames(source_root_87frames)
    frame_ids = [c.frame_id for c in result.candidates]
    assert frame_ids == sorted(frame_ids), "候选帧未按 frame_id 升序排列"


# ---------------------------------------------------------------------------
# Test 8: 每个候选帧有非空 selection_reason
# ---------------------------------------------------------------------------

def test_selection_reason_nonempty(source_root_87frames):
    result = screen_frames(source_root_87frames)
    for c in result.candidates:
        assert len(c.selection_reason) > 0, (
            f"frame_id={c.frame_id} selection_reason 为空"
        )
        for reason in c.selection_reason:
            assert isinstance(reason, str) and len(reason) > 0


# ---------------------------------------------------------------------------
# Test 9: frame_metadata.json 缺失时报错
# ---------------------------------------------------------------------------

def test_missing_frame_metadata_raises_error(source_root_no_frame_meta):
    with pytest.raises(FrameScreeningError) as exc_info:
        screen_frames(source_root_no_frame_meta)
    assert "frame_metadata.json" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Test 10: source.json 缺失时报错
# ---------------------------------------------------------------------------

def test_missing_source_json_raises_error(source_root_no_source_json):
    with pytest.raises(FrameScreeningError) as exc_info:
        screen_frames(source_root_no_source_json)
    assert "source.json" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Test 11: max_candidates 约束
# ---------------------------------------------------------------------------

def test_max_candidates_constraint(source_root_87frames):
    """candidate_count 不应超过 max_candidates。"""
    result = screen_frames(source_root_87frames, max_candidates=15)
    assert result.candidate_count <= 15, (
        f"candidate_count={result.candidate_count} 超过 max_candidates=15"
    )


# ---------------------------------------------------------------------------
# Test 12: min_candidates 约束（小帧数场景）
# ---------------------------------------------------------------------------

def test_min_candidates_constraint(source_root_10frames):
    """
    10 帧场景，min_candidates=8 → 候选帧数应 >= 8。
    （step 会被自动降到 1，全选）
    """
    result = screen_frames(source_root_10frames, min_candidates=8, max_candidates=20)
    assert result.candidate_count >= 8, (
        f"candidate_count={result.candidate_count} 低于 min_candidates=8"
    )
