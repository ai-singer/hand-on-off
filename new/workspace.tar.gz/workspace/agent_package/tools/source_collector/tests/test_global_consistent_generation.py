"""
tests/test_global_consistent_generation.py

Global Consistent Image Generation V1.0 — validation tests

Covers:
  1.  9 slots all generated (files exist)
  2.  all slot anchor refs resolvable
  3.  same payload cross-post stable → PASS
  4.  payload structural identity drift → FAIL
  5.  same balloon with valid lifecycle/state changes → PASS
  6.  balloon identity changes without evidence → FAIL
  7.  team clothing/identity drift → FAIL
  8.  single image PASS but cross-post entity mismatch → global set FAIL
  9.  targeted repair does not overwrite unrelated PASS image
  10. allocation blocked before global validation PASS
  11. legacy images are never overwritten
  12. global allocation references only validated images
"""

import json
import os
import sys
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

SOURCE_ROOT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "sources", "bilibili", "ysjf", "space_camera_project"
)
GLOBAL_V1_DIR     = os.path.join(SOURCE_ROOT, "posts", "images", "global_v1")
LEGACY_DIRS       = [os.path.join(SOURCE_ROOT, "posts", "images", f"post_00{i}") for i in range(1, 4)]
ANCHORS_PATH      = os.path.join(SOURCE_ROOT, "posts", "shared_visual_anchors.json")
PLAN_PATH         = os.path.join(SOURCE_ROOT, "posts", "global_visual_plan.json")
GEN_PATH          = os.path.join(SOURCE_ROOT, "posts", "global_image_generation.json")
ALLOCATION_PATH   = os.path.join(SOURCE_ROOT, "posts", "global_image_allocation.json")
COMPARISON_PATH   = os.path.join(SOURCE_ROOT, "validation", "global_vs_legacy_visual_comparison.json")


def _load(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


# ---------------------------------------------------------------------------
# Test 1: 9 slots all generated (files exist)
# ---------------------------------------------------------------------------

def test_all_9_global_images_exist():
    gen = _load(GEN_PATH)
    for img in gen["images"]:
        # output_path is relative to SOURCE_ROOT
        abs_path = os.path.join(SOURCE_ROOT, img["output_path"])
        assert os.path.isfile(abs_path), f"Global image not found: {abs_path}"


def test_global_v1_directory_has_9_images():
    if not os.path.isdir(GLOBAL_V1_DIR):
        pytest.skip("global_v1 directory not yet created")
    files = [f for f in os.listdir(GLOBAL_V1_DIR) if f.endswith(('.jpg', '.png'))]
    assert len(files) == 9, f"Expected 9 images in global_v1, found {len(files)}: {files}"


# ---------------------------------------------------------------------------
# Test 2: all slot anchor refs resolvable
# ---------------------------------------------------------------------------

def test_all_slot_anchor_refs_resolvable():
    plan    = _load(PLAN_PATH)
    anchors = _load(ANCHORS_PATH)
    valid_ids = set(anchors["anchors"].keys())
    for slot in plan["image_slots"]:
        for aid in slot["required_anchor_ids"]:
            assert aid in valid_ids, (
                f"Slot {slot['image_id']} references missing anchor: {aid}"
            )


# ---------------------------------------------------------------------------
# Test 3: same payload cross-post stable → PASS
# ---------------------------------------------------------------------------

def test_payload_identity_consistent_across_posts():
    gen = _load(GEN_PATH)
    xval = gen["cross_image_validation"]
    assert xval["payload_identity_consistency"] == "PASS"


# ---------------------------------------------------------------------------
# Test 4: payload structural identity drift → FAIL (simulation)
# ---------------------------------------------------------------------------

def test_payload_structural_drift_fails():
    """Simulate: if payload anchor changes structure between posts, it's a FAIL."""
    anchors = _load(ANCHORS_PATH)
    stable = anchors["anchors"]["payload_anchor"]["stable_attributes"]
    forbidden = anchors["anchors"]["payload_anchor"]["forbidden_variants"]

    # Drift: payload becomes metal casing — must be in forbidden_variants
    drift_description = "metal casing with visible branding"
    caught = any(
        fv.lower() in drift_description.lower() or
        drift_description.lower() in fv.lower()
        for fv in forbidden
    )
    assert caught, "Payload anchor must catch metal casing drift"

    # Drift: large industrial equipment — must be forbidden
    drift2 = "complex scientific instrument chassis"
    caught2 = any(drift2.lower() in fv.lower() or fv.lower() in drift2.lower() for fv in forbidden)
    assert caught2, "Payload anchor must catch large industrial equipment drift"


# ---------------------------------------------------------------------------
# Test 5: same balloon with valid lifecycle/state changes → PASS
# ---------------------------------------------------------------------------

def test_balloon_lifecycle_changes_are_valid():
    anchors = _load(ANCHORS_PATH)
    variable = anchors["anchors"]["balloon_anchor"]["variable_attributes"]
    # inflation state change is a valid variable attribute
    assert any("inflation" in v.lower() for v in variable), \
        "Balloon anchor must allow inflation state as variable attribute"
    assert any("apparent size" in v.lower() for v in variable), \
        "Balloon anchor must allow apparent size change as variable attribute"


# ---------------------------------------------------------------------------
# Test 6: balloon identity changes without evidence → FAIL
# ---------------------------------------------------------------------------

def test_balloon_identity_change_without_evidence_fails():
    anchors = _load(ANCHORS_PATH)
    forbidden = anchors["anchors"]["balloon_anchor"]["forbidden_variants"]
    # Colored balloon has no source evidence
    assert any("colored" in fv.lower() for fv in forbidden), \
        "Balloon anchor must forbid colored balloon"
    # Multiple balloons has no source evidence
    assert any("multiple" in fv.lower() for fv in forbidden), \
        "Balloon anchor must forbid multiple balloons"


# ---------------------------------------------------------------------------
# Test 7: team clothing/identity drift → FAIL
# ---------------------------------------------------------------------------

def test_team_clothing_drift_fails():
    anchors = _load(ANCHORS_PATH)
    forbidden = anchors["anchors"]["team_anchor"]["forbidden_variants"]
    # Orange industrial uniforms must be forbidden
    assert any("orange" in fv.lower() for fv in forbidden), \
        "Team anchor must forbid orange uniforms"
    # Reflective strips must be forbidden
    assert any("reflective" in fv.lower() for fv in forbidden), \
        "Team anchor must forbid reflective strips"
    # Logos must be forbidden
    assert any("logo" in fv.lower() for fv in forbidden), \
        "Team anchor must forbid logos on clothing"


# ---------------------------------------------------------------------------
# Test 8: single image PASS but cross-post entity mismatch → global set FAIL
# ---------------------------------------------------------------------------

def test_cross_post_mismatch_fails_global_set():
    """
    Simulate: one image passes single-image validation but has team in
    orange uniforms → violates team_anchor → global set must FAIL.
    """
    single_image_valid = True  # passes all single-image checks
    team_anchor_consistent = False  # orange uniforms violate team_anchor

    global_set_pass = single_image_valid and team_anchor_consistent
    assert global_set_pass is False, \
        "Single image PASS + team_anchor FAIL must result in global set FAIL"


# ---------------------------------------------------------------------------
# Test 9: targeted repair does not overwrite unrelated PASS image
# ---------------------------------------------------------------------------

def test_targeted_repair_preserves_other_images():
    """Verify that if global_img_003 needed repair, global_img_001 is unchanged."""
    gen = _load(GEN_PATH)
    img_001 = next(img for img in gen["images"] if img["image_id"] == "global_img_001")
    img_003 = next(img for img in gen["images"] if img["image_id"] == "global_img_003")

    # img_001 must always be PASS regardless of img_003 state
    assert img_001["validation"]["auto_vision_result"] == "PASS"
    # img_003 may be NEEDS_REVIEW, but img_001 is untouched
    # (repair rounds on img_003 do not reset img_001)
    assert img_001["repair_rounds"] == 0


# ---------------------------------------------------------------------------
# Test 10: allocation blocked before global validation PASS
# ---------------------------------------------------------------------------

def test_allocation_requires_global_validation():
    allocation = _load(ALLOCATION_PATH)
    # prerequisite field must be present and non-empty
    assert "prerequisite" in allocation
    prereq = allocation["prerequisite"]
    assert "GLOBAL_VISUAL_SET_VALIDATION" in prereq, \
        "Allocation must declare global validation as prerequisite"


# ---------------------------------------------------------------------------
# Test 11: legacy images are never overwritten
# ---------------------------------------------------------------------------

def test_legacy_images_not_overwritten():
    """
    Global v1 images are in global_v1/. Legacy images are in post_00x/.
    Verify that post_00x/ directories still exist and are not empty.
    """
    for legacy_dir in LEGACY_DIRS:
        if os.path.isdir(legacy_dir):
            files = [f for f in os.listdir(legacy_dir) if f.endswith(('.jpg', '.png'))]
            assert len(files) >= 3, \
                f"Legacy directory {legacy_dir} appears to have been cleared: {files}"


# ---------------------------------------------------------------------------
# Test 12: global allocation references only validated images
# ---------------------------------------------------------------------------

def test_global_allocation_references_validated_images():
    allocation = _load(ALLOCATION_PATH)
    gen        = _load(GEN_PATH)
    gen_ids = {img["image_id"] for img in gen["images"]}

    for entry in allocation["allocation"]:
        gid = entry["global_image_id"]
        assert gid in gen_ids, \
            f"Allocation references image not in generation record: {gid}"
        # Each allocated image must have a PASS or NEEDS_REVIEW result (not ERROR/FAIL)
        img_record = next(img for img in gen["images"] if img["image_id"] == gid)
        result = img_record["validation"]["auto_vision_result"]
        assert result in ("PASS", "NEEDS_REVIEW"), \
            f"Allocation must not include images with result={result}: {gid}"
