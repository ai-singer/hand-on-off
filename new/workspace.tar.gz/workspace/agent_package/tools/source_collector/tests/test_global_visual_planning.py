"""
tests/test_global_visual_planning.py

Global Visual Planning Layer — service contract tests

Covers:
  1.  same entity across posts creates one anchor           PASS
  2.  different unrelated entities do not merge             PASS
  3.  image slot references valid anchor                    PASS
  4.  missing anchor reference                              FAIL
  5.  post allocation after generation                      PASS
  6.  cross-post equipment mismatch detected                FAIL
  7.  cross-post temporal disorder detected                 FAIL
  8.  single post without shared entity still works         PASS
  9.  global_visual_plan.json artifact valid                PASS
  10. shared_visual_anchors.json artifact valid             PASS
  11. cross_post_visual_validation.json artifact valid      PASS
  12. image_slots count = 9 (3 posts × 3 images)           PASS
  13. all slots have required fields                        PASS
  14. camera_origin resolves per event_state               PASS
"""

import json
import os
import sys
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.global_visual_planning import (
    build_global_visual_plan,
    build_shared_visual_anchors,
    build_cross_post_validation_schema,
    classify_transition_role,
    resolve_camera_origin,
    detect_entity_type,
)

SOURCE_ROOT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "sources", "bilibili", "ysjf", "space_camera_project"
)

PLAN_PATH    = os.path.join(SOURCE_ROOT, "posts", "global_visual_plan.json")
ANCHORS_PATH = os.path.join(SOURCE_ROOT, "posts", "shared_visual_anchors.json")
XVAL_PATH    = os.path.join(SOURCE_ROOT, "validation", "cross_post_visual_validation.json")


def _load_inputs():
    post_plan = json.load(open(os.path.join(SOURCE_ROOT, "extracted", "post_plan.json")))
    kf_anchor = json.load(open(os.path.join(SOURCE_ROOT, "posts", "keyframe_transition_anchor.json")))
    kf_deltas = json.load(open(os.path.join(SOURCE_ROOT, "extracted", "keyframe_state_deltas.json")))
    cap_sys   = json.load(open(os.path.join(SOURCE_ROOT, "capture_system.json")))
    return post_plan, kf_anchor, kf_deltas, cap_sys


# ---------------------------------------------------------------------------
# Test 1: same entity across posts creates one anchor
# ---------------------------------------------------------------------------

def test_same_entity_across_posts_single_anchor():
    _, _, _, cap_sys = _load_inputs()
    anchors = build_shared_visual_anchors(cap_sys)
    # team appears in post_001 and post_003 — one anchor entry
    assert "team_anchor" in anchors["anchors"]
    team = anchors["anchors"]["team_anchor"]
    assert len(team["appears_in_posts"]) >= 2
    assert "post_001" in team["appears_in_posts"]
    assert "post_003" in team["appears_in_posts"]


# ---------------------------------------------------------------------------
# Test 2: different unrelated entities do not merge
# ---------------------------------------------------------------------------

def test_different_entities_do_not_merge():
    _, _, _, cap_sys = _load_inputs()
    anchors = build_shared_visual_anchors(cap_sys)
    # team and balloon are distinct anchors
    assert "team_anchor" in anchors["anchors"]
    assert "balloon_anchor" in anchors["anchors"]
    assert anchors["anchors"]["team_anchor"]["entity_type"] == "team"
    assert anchors["anchors"]["balloon_anchor"]["entity_type"] == "capture_platform"


# ---------------------------------------------------------------------------
# Test 3: image slot references valid anchor
# ---------------------------------------------------------------------------

def test_image_slot_references_valid_anchors():
    post_plan, kf_anchor, kf_deltas, cap_sys = _load_inputs()
    plan    = build_global_visual_plan(post_plan, kf_anchor, kf_deltas, cap_sys)
    anchors = build_shared_visual_anchors(cap_sys)
    valid_anchor_ids = set(anchors["anchors"].keys())
    for slot in plan["image_slots"]:
        for aid in slot["required_anchor_ids"]:
            assert aid in valid_anchor_ids, (
                f"Slot {slot['image_id']} references unknown anchor: {aid}"
            )


# ---------------------------------------------------------------------------
# Test 4: missing anchor reference detected
# ---------------------------------------------------------------------------

def test_missing_anchor_reference_detected():
    """Simulate a slot referencing a non-existent anchor."""
    fake_slot = {
        "image_id": "post_001_img_01",
        "required_anchor_ids": ["nonexistent_anchor_xyz"],
    }
    valid_anchor_ids = {"team_anchor", "balloon_anchor", "environment_anchor", "payload_anchor"}
    missing = [
        aid for aid in fake_slot["required_anchor_ids"]
        if aid not in valid_anchor_ids
    ]
    assert len(missing) > 0, "Missing anchor must be detected"
    assert "nonexistent_anchor_xyz" in missing


# ---------------------------------------------------------------------------
# Test 5: post allocation after generation
# ---------------------------------------------------------------------------

def test_post_allocation_after_generation():
    post_plan, kf_anchor, kf_deltas, cap_sys = _load_inputs()
    plan = build_global_visual_plan(post_plan, kf_anchor, kf_deltas, cap_sys)
    # Each post must have exactly 3 slots
    for pid in ["post_001", "post_002", "post_003"]:
        slots = [s for s in plan["image_slots"] if s["assigned_post"] == pid]
        assert len(slots) == 3, f"{pid} must have 3 image slots, got {len(slots)}"
        # Slots must be ordered by image_order (derived from image_id suffix)
        orders = [int(s["image_id"].split("_img_")[1]) for s in slots]
        assert orders == sorted(orders), f"{pid} slots not in order: {orders}"


# ---------------------------------------------------------------------------
# Test 6: cross-post equipment mismatch detected
# ---------------------------------------------------------------------------

def test_cross_post_equipment_mismatch_detected():
    """
    If a post generates images with rigid metal pole instead of flexible rope,
    balloon_anchor.forbidden_variants should catch it.
    """
    _, _, _, cap_sys = _load_inputs()
    anchors = build_shared_visual_anchors(cap_sys)
    balloon_forbidden = anchors["anchors"]["balloon_anchor"]["forbidden_variants"]
    mismatch_description = "rigid metal pole instead of flexible rope"
    caught = any(
        fv.lower() in mismatch_description.lower() or
        mismatch_description.lower() in fv.lower()
        for fv in balloon_forbidden
    )
    assert caught, "Balloon anchor must catch rigid metal pole mismatch"


# ---------------------------------------------------------------------------
# Test 7: cross-post temporal disorder detected
# ---------------------------------------------------------------------------

def test_cross_post_temporal_disorder_detected():
    post_plan, kf_anchor, kf_deltas, cap_sys = _load_inputs()
    plan = build_global_visual_plan(post_plan, kf_anchor, kf_deltas, cap_sys)
    # Extract state_order from event_state string (STATE_001 < STATE_002 < STATE_003)
    post_states = {}
    for s in plan["image_slots"]:
        pid = s["assigned_post"]
        if pid not in post_states:
            post_states[pid] = s["event_state"]
    state_order = {"STATE_001": 1, "STATE_002": 2, "STATE_003": 3}
    ordered = [state_order.get(post_states[pid], 0) for pid in ["post_001", "post_002", "post_003"]]
    assert ordered == sorted(ordered), f"Cross-post temporal disorder: {ordered}"


# ---------------------------------------------------------------------------
# Test 8: single post without shared entity still works
# ---------------------------------------------------------------------------

def test_single_post_without_shared_entity_works():
    """A post that has no cross-post shared entities should still generate valid slots."""
    # Simulate a minimal post_plan with one post, no cross-post entities
    minimal_plan = {
        "posts": [{"post_id": "post_solo", "title": "Solo", "image_frames": [5]}]
    }
    minimal_anchor = {
        "posts": [
            {
                "post_id": "post_solo",
                "event_state": "STATE_001",
                "timeline": [
                    {
                        "image_order": 1,
                        "source_frame_refs": [5],
                        "representative_timestamp_sec": 40.0,
                        "expected_state": "some_state",
                        "expected_state_description": "test",
                        "required_visual_elements": [],
                        "forbidden_visual_elements": [],
                    }
                ],
            }
        ]
    }
    minimal_deltas = {
        "posts": [{"post_id": "post_solo", "event_state": "STATE_001", "transitions": []}]
    }
    _, _, _, cap_sys = _load_inputs()
    result = build_global_visual_plan(minimal_plan, minimal_anchor, minimal_deltas, cap_sys)
    assert len(result["image_slots"]) == 1
    assert result["image_slots"][0]["assigned_post"] == "post_solo"


# ---------------------------------------------------------------------------
# Test 9: global_visual_plan.json artifact valid
# ---------------------------------------------------------------------------

def test_global_visual_plan_artifact_valid():
    data = json.load(open(PLAN_PATH, encoding="utf-8"))
    assert data["schema_version"].startswith("GLOBAL_VISUAL_PLAN")
    assert "project_id" in data
    assert "posts" in data
    assert "shared_anchor_refs" in data
    assert "image_slots" in data
    assert len(data["image_slots"]) == 9


# ---------------------------------------------------------------------------
# Test 10: shared_visual_anchors.json artifact valid
# ---------------------------------------------------------------------------

def test_shared_visual_anchors_artifact_valid():
    data = json.load(open(ANCHORS_PATH, encoding="utf-8"))
    assert data["schema_version"].startswith("SHARED_VISUAL_ANCHORS")
    assert "project_id" in data
    assert "anchors" in data
    for anchor_id, anchor in data["anchors"].items():
        assert "entity_type" in anchor, f"Anchor {anchor_id} missing entity_type"
        assert "stable_attributes" in anchor
        assert "forbidden_variants" in anchor
        assert len(anchor["stable_attributes"]) >= 1
        assert len(anchor["forbidden_variants"]) >= 1


# ---------------------------------------------------------------------------
# Test 11: cross_post_visual_validation.json artifact valid
# ---------------------------------------------------------------------------

def test_cross_post_validation_artifact_valid():
    data = json.load(open(XVAL_PATH, encoding="utf-8"))
    assert data["schema_version"].startswith("CROSS_POST_VISUAL_VALIDATION")
    assert "checks" in data
    required_checks = [
        "same_entity_consistency",
        "equipment_continuity",
        "cross_post_temporal_consistency",
        "same_event_identity",
    ]
    for check in required_checks:
        assert check in data["checks"], f"Missing check: {check}"
        assert data["checks"][check]["violation_blocks_pass"] is True


# ---------------------------------------------------------------------------
# Test 12: image_slots count = 9
# ---------------------------------------------------------------------------

def test_image_slots_count():
    data = json.load(open(PLAN_PATH, encoding="utf-8"))
    assert len(data["image_slots"]) == 9, f"Expected 9 slots, got {len(data['image_slots'])}"


# ---------------------------------------------------------------------------
# Test 13: all slots have required fields
# ---------------------------------------------------------------------------

def test_all_slots_have_required_fields():
    data = json.load(open(PLAN_PATH, encoding="utf-8"))
    required_fields = [
        "image_id", "assigned_post", "event_state", "keyframe_state",
        "timeline_range", "camera_origin", "required_anchor_ids",
        "transition_role", "visual_purpose",
    ]
    for slot in data["image_slots"]:
        for field in required_fields:
            assert field in slot, f"Slot {slot.get('image_id','?')} missing field: {field}"
        assert "source_frame_refs" in slot["timeline_range"]
        assert "representative_timestamp_sec" in slot["timeline_range"]


# ---------------------------------------------------------------------------
# Test 14: camera_origin resolves per event_state
# ---------------------------------------------------------------------------

def test_camera_origin_resolves_correctly():
    assert resolve_camera_origin("STATE_001", "early_preparation") == "ground_level_handheld_or_tripod"
    assert resolve_camera_origin("STATE_002", "initial_ascent") == "balloon_payload_camera"
    assert resolve_camera_origin("STATE_002", "maximum_altitude") == "balloon_payload_camera"
    assert resolve_camera_origin("STATE_003", "descent") == "balloon_payload_camera"
    assert resolve_camera_origin("STATE_003", "landing_or_recovery") == "ground_level_at_recovery_site"
    assert resolve_camera_origin("STATE_003", "post_recovery_handling") == "ground_level_at_recovery_site"
