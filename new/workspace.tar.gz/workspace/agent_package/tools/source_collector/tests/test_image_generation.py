"""
tests/test_image_generation.py

Image Generation Service 单元测试

覆盖：
  1.  valid visual plan accepted (3 items)
  2.  visual count mismatch rejected
  3.  backend missing raises BackendMissingError
  4.  generation success metadata schema valid
  5.  broken image rejected (zero bytes)
  6.  zero-byte image rejected
  7.  source/output same path rejected
  8.  required provenance fields preserved
  9.  failed generation retry bounded (max 3)
  10. post_002/post_003 not touched
"""

import json
import os
import sys
import struct
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.image_generation import (
    discover_backend,
    generate_post_images,
    BackendMissingError,
    VisualPlanContractMismatchError,
    ValidationFailedError,
    ImageResult,
    BackendConfig,
    _get_image_dimensions,
    _check_not_source_frame,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_minimal_visual_plan(tmp_path, count=3, post_id="post_001"):
    posts_dir = tmp_path / "posts"
    posts_dir.mkdir(parents=True, exist_ok=True)
    plan = {
        "post_id": post_id,
        "images": [
            {
                "image_id": f"{post_id}_img_{i:02d}",
                "based_on_frames": [i * 5],
                "preserved_facts": [f"fact_{i}"],
                "visual_goal": f"goal {i}",
                "prompt": f"test prompt {i}, photorealistic, no watermark, no text",
            }
            for i in range(1, count + 1)
        ]
    }
    plan_path = posts_dir / f"{post_id}_visual_output.json"
    plan_path.write_text(json.dumps(plan, ensure_ascii=False), encoding="utf-8")
    return str(tmp_path)


def make_fake_jpeg(w=100, h=80) -> bytes:
    """Craft a minimal valid JPEG with known dimensions."""
    # SOI + APP0 + SOF0 (Baseline DCT) + EOI
    soi = b"\xff\xd8"
    app0 = b"\xff\xe0" + struct.pack(">H", 16) + b"JFIF\x00\x01\x01\x00\x00\x01\x00\x01\x00\x00"
    sof0_data = struct.pack(">HBHHB", 11, 8, h, w, 1) + b"\x01\x11\x00"
    sof0 = b"\xff\xc0" + struct.pack(">H", len(sof0_data) + 2) + sof0_data
    eoi = b"\xff\xd9"
    return soi + app0 + sof0 + eoi


# ---------------------------------------------------------------------------
# Test 1: valid visual plan accepted
# ---------------------------------------------------------------------------

def test_valid_visual_plan_accepted(tmp_path):
    source_root = make_minimal_visual_plan(tmp_path, count=3)
    plan_path = os.path.join(source_root, "posts", "post_001_visual_output.json")
    with open(plan_path, encoding="utf-8") as f:
        plan = json.load(f)
    assert len(plan["images"]) == 3


# ---------------------------------------------------------------------------
# Test 2: visual count mismatch rejected
# ---------------------------------------------------------------------------

def test_visual_count_mismatch_rejected(tmp_path):
    source_root = make_minimal_visual_plan(tmp_path, count=2)
    with pytest.raises(VisualPlanContractMismatchError):
        generate_post_images(source_root, "post_001", expected_visual_count=3,
                             openclaw_config_path="/nonexistent/path.json")


# ---------------------------------------------------------------------------
# Test 3: backend missing raises BackendMissingError
# ---------------------------------------------------------------------------

def test_backend_missing(tmp_path):
    source_root = make_minimal_visual_plan(tmp_path, count=3)
    with pytest.raises((BackendMissingError, Exception)):
        generate_post_images(source_root, "post_001", expected_visual_count=3,
                             openclaw_config_path="/nonexistent/path.json")


# ---------------------------------------------------------------------------
# Test 4: generation success metadata schema valid
# ---------------------------------------------------------------------------

def test_generation_metadata_schema():
    result = ImageResult(
        visual_id="post_001_img_01",
        output_path="/tmp/post_001_01.jpg",
        source_frame_refs=[6, 10],
        fact_refs=["雪地环境"],
        generation_prompt="test prompt",
        generation_mode="text_to_image",
        width=768, height=1024,
        format="jpg",
        file_size_bytes=204800,
        generation_success=True,
        attempts=1,
    )
    assert result.generation_success is True
    assert result.width > 0
    assert result.height > 0
    assert result.file_size_bytes > 0
    assert result.format in ("jpg", "png", "jpeg", "webp")


# ---------------------------------------------------------------------------
# Test 5 & 6: broken / zero-byte image rejected via dimension check
# ---------------------------------------------------------------------------

def test_broken_image_has_zero_dimensions():
    broken = b"\xff\xd8\xff\xd9"  # SOI + EOI only, no SOF
    from services.image_generation import _get_image_dimensions
    w, h = _get_image_dimensions(broken, "image/jpeg")
    # broken jpeg should return 0,0
    assert (w, h) == (0, 0)


def test_zero_byte_image_has_zero_dimensions():
    w, h = _get_image_dimensions(b"", "image/jpeg")
    assert (w, h) == (0, 0)


# ---------------------------------------------------------------------------
# Test 7: source/output same path check
# ---------------------------------------------------------------------------

def test_source_output_same_path_detected(tmp_path):
    """If output file hash equals a source frame hash, _check_not_source_frame returns False."""
    frames_dir = tmp_path / "extracted" / "frames"
    frames_dir.mkdir(parents=True)
    img_bytes = make_fake_jpeg()

    # write same bytes as both source frame and output
    frame_path = frames_dir / "frame_000006_00050000ms.jpg"
    frame_path.write_bytes(img_bytes)

    output_path = tmp_path / "posts" / "images" / "post_001" / "post_001_01.jpg"
    output_path.parent.mkdir(parents=True)
    output_path.write_bytes(img_bytes)  # same content!

    is_safe = _check_not_source_frame(str(output_path), str(tmp_path), [6])
    assert is_safe is False, "Same-content file should be detected as direct reuse"


def test_different_output_passes_source_check(tmp_path):
    frames_dir = tmp_path / "extracted" / "frames"
    frames_dir.mkdir(parents=True)
    frame_path = frames_dir / "frame_000006_00050000ms.jpg"
    frame_path.write_bytes(make_fake_jpeg(100, 80))

    output_path = tmp_path / "posts" / "images" / "post_001" / "post_001_01.jpg"
    output_path.parent.mkdir(parents=True)
    output_path.write_bytes(make_fake_jpeg(200, 300))  # different dimensions/content

    is_safe = _check_not_source_frame(str(output_path), str(tmp_path), [6])
    assert is_safe is True


# ---------------------------------------------------------------------------
# Test 8: required provenance fields preserved
# ---------------------------------------------------------------------------

def test_provenance_fields_in_result():
    result = ImageResult(
        visual_id="post_001_img_01",
        output_path="/tmp/post_001_01.jpg",
        source_frame_refs=[6, 10],
        fact_refs=["雪地", "气球"],
        generation_prompt="photorealistic balloon launch",
        generation_mode="text_to_image",
        width=768, height=1024,
        format="jpg",
        file_size_bytes=204800,
        generation_success=True,
        attempts=1,
    )
    assert result.visual_id.startswith("post_001")
    assert len(result.source_frame_refs) > 0
    assert len(result.fact_refs) > 0
    assert len(result.generation_prompt) > 10
    assert result.generation_mode == "text_to_image"


# ---------------------------------------------------------------------------
# Test 9: failed generation retry bounded
# ---------------------------------------------------------------------------

def test_retry_bounded(tmp_path, monkeypatch):
    """Verify that _generate_one respects max_attempts=3."""
    from services import image_generation as ig
    call_count = {"n": 0}

    def fake_call(backend, prompt, aspect_ratio="3:4", timeout=120):
        call_count["n"] += 1
        raise ig.ProviderError("simulated failure")

    monkeypatch.setattr(ig, "_call_generate", fake_call)

    source_root = make_minimal_visual_plan(tmp_path, count=3)
    output_path = os.path.join(source_root, "posts", "images", "post_001", "post_001_01.jpg")
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    backend = BackendConfig(
        provider="test", api_key="k", base_url="http://x", model_id="m"
    )
    result = ig._generate_one(
        backend=backend,
        visual_id="test_img_01",
        prompt="test",
        source_frame_refs=[6],
        fact_refs=["fact_1"],
        output_path=output_path,
        source_root=source_root,
        max_attempts=3,
    )
    assert call_count["n"] == 3
    assert result.generation_success is False
    assert "GENERATION_FAILED_AFTER_RETRIES" in (result.error or "")


# ---------------------------------------------------------------------------
# Test 10: post_002/post_003 not touched
# ---------------------------------------------------------------------------

def test_post_002_003_not_touched(tmp_path):
    """generate_post_images for post_001 should not create post_002/post_003 files."""
    source_root = make_minimal_visual_plan(tmp_path, count=3, post_id="post_001")

    # We can't call the real backend here, so just verify plan file check
    # by passing wrong config path (will raise before touching other posts)
    try:
        generate_post_images(source_root, "post_001", expected_visual_count=3,
                             openclaw_config_path="/nonexistent.json")
    except Exception:
        pass

    posts_dir = os.path.join(source_root, "posts")
    for p in ["post_002.txt", "post_003.txt",
              "post_002_visual_output.json", "post_003_visual_output.json",
              "post_002_image_generation.json", "post_003_image_generation.json"]:
        assert not os.path.exists(os.path.join(posts_dir, p)), (
            f"generate_post_images for post_001 should not touch {p}"
        )
