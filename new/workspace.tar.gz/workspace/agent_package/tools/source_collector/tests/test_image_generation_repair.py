"""
tests/test_image_generation_repair.py

AI Visual Generation Repair 验证测试

覆盖：
  1.  repair 不得覆盖已经 PASS 的 post_001_03
  2.  metadata 支持 invented_text_or_logo 字段
  3.  metadata 支持 unsupported_salient_object_or_structure 字段
  4.  invented_text_or_logo = true 时不得自动 PASS
  5.  unsupported_salient_object_or_structure = true 时不得自动 PASS
  6.  不足两张修复成功时整轮不得 PASS
"""

import json
import os
import sys
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

SOURCE_ROOT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "sources", "bilibili", "ysjf", "space_camera_project"
)
POSTS_DIR   = os.path.join(SOURCE_ROOT, "posts")
IMG_DIR     = os.path.join(POSTS_DIR, "images", "post_001")
META_PATH   = os.path.join(POSTS_DIR, "post_001_image_generation.json")


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _determine_pass(img_meta: dict) -> bool:
    """
    An image auto-passes only when:
    - generation_success is True
    - invented_text_or_logo is False
    - unsupported_salient_object_or_structure is False
    """
    if not img_meta.get("generation_success", False):
        return False
    if img_meta.get("invented_text_or_logo", True):   # default True = fail-safe
        return False
    if img_meta.get("unsupported_salient_object_or_structure", True):
        return False
    return True


def _repair_round_pass(images: list, repair_targets: list) -> bool:
    """Repair round passes only when all repair targets individually pass."""
    for img in images:
        if img["visual_id"] in repair_targets:
            if not _determine_pass(img):
                return False
    return True


# ---------------------------------------------------------------------------
# Test 1: repair 不得覆盖已经 PASS 的 post_001_03
# ---------------------------------------------------------------------------

def test_post_001_03_exists():
    """post_001_03 must exist in either jpg or png format after consistency repair."""
    jpg = os.path.join(IMG_DIR, "post_001_03.jpg")
    png = os.path.join(IMG_DIR, "post_001_03.png")
    exists = os.path.isfile(jpg) or os.path.isfile(png)
    assert exists, "post_001_03 (jpg or png) 不存在"
    path = png if os.path.isfile(png) else jpg
    assert os.path.getsize(path) > 0, "post_001_03 文件为空"


# ---------------------------------------------------------------------------
# Test 2: metadata 支持 invented_text_or_logo
# ---------------------------------------------------------------------------

def test_metadata_has_invented_text_or_logo():
    with open(META_PATH, encoding="utf-8") as f:
        data = json.load(f)
    for img in data["images"]:
        assert "invented_text_or_logo" in img, (
            f"{img['visual_id']} metadata 缺少 invented_text_or_logo 字段"
        )
        assert isinstance(img["invented_text_or_logo"], bool)


# ---------------------------------------------------------------------------
# Test 3: metadata 支持 unsupported_salient_object_or_structure
# ---------------------------------------------------------------------------

def test_metadata_has_unsupported_salient_object():
    with open(META_PATH, encoding="utf-8") as f:
        data = json.load(f)
    for img in data["images"]:
        assert "unsupported_salient_object_or_structure" in img, (
            f"{img['visual_id']} metadata 缺少 unsupported_salient_object_or_structure 字段"
        )
        assert isinstance(img["unsupported_salient_object_or_structure"], bool)


# ---------------------------------------------------------------------------
# Test 4: invented_text_or_logo = true 时不得自动 PASS
# ---------------------------------------------------------------------------

def test_invented_text_blocks_pass():
    fake_img = {
        "visual_id": "post_001_img_test",
        "generation_success": True,
        "invented_text_or_logo": True,
        "unsupported_salient_object_or_structure": False,
    }
    assert _determine_pass(fake_img) is False, (
        "invented_text_or_logo=True 时不应判定为 PASS"
    )


# ---------------------------------------------------------------------------
# Test 5: unsupported_salient_object = true 时不得自动 PASS
# ---------------------------------------------------------------------------

def test_unsupported_salient_object_blocks_pass():
    fake_img = {
        "visual_id": "post_001_img_test",
        "generation_success": True,
        "invented_text_or_logo": False,
        "unsupported_salient_object_or_structure": True,
    }
    assert _determine_pass(fake_img) is False, (
        "unsupported_salient_object_or_structure=True 时不应判定为 PASS"
    )


# ---------------------------------------------------------------------------
# Test 6: 不足两张修复成功时整轮不得 PASS
# ---------------------------------------------------------------------------

def test_partial_repair_fails_round():
    """If only one of two repair targets passes, the repair round must fail."""
    images = [
        {
            "visual_id": "post_001_img_01",
            "generation_success": True,
            "invented_text_or_logo": False,
            "unsupported_salient_object_or_structure": False,
        },
        {
            "visual_id": "post_001_img_02",
            "generation_success": True,
            "invented_text_or_logo": True,   # still has text → fail
            "unsupported_salient_object_or_structure": False,
        },
    ]
    repair_targets = ["post_001_img_01", "post_001_img_02"]
    assert _repair_round_pass(images, repair_targets) is False, (
        "只有一张修复通过时整轮不应为 PASS"
    )


# ---------------------------------------------------------------------------
# Integration: current metadata passes all checks
# ---------------------------------------------------------------------------

def test_current_metadata_repair_targets_pass():
    with open(META_PATH, encoding="utf-8") as f:
        data = json.load(f)
    repair_targets = {"post_001_img_01", "post_001_img_02"}
    for img in data["images"]:
        if img["visual_id"] in repair_targets:
            assert _determine_pass(img), (
                f"{img['visual_id']} 当前 metadata 未通过自动检查: "
                f"invented_text={img.get('invented_text_or_logo')}, "
                f"unsupported={img.get('unsupported_salient_object_or_structure')}, "
                f"success={img.get('generation_success')}"
            )


def test_all_three_images_exist():
    for i in range(1, 4):
        jpg = os.path.join(IMG_DIR, f"post_001_0{i}.jpg")
        png = os.path.join(IMG_DIR, f"post_001_0{i}.png")
        path = jpg if os.path.isfile(jpg) else png
        assert os.path.isfile(path), f"post_001_0{i} (jpg or png) 不存在"
        assert os.path.getsize(path) > 0, f"post_001_0{i} 为空文件"
