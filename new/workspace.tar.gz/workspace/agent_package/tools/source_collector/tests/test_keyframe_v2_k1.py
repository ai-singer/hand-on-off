"""
tests/test_keyframe_v2_k1.py

Minimum K1 validation tests:
1. QuickSelect Top-K correctness
2. Stream min-heap Top-K correctness
3. Long stable segment does not get high information_density due to length
4. Short high-change region captured as transition candidate
5. Source segment timestamps monotonic
6. K1 does not call expensive Vision
7. Frozen V1 artifacts untouched
"""

import json
import os
import sys
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from services.keyframe_dense_scan import select_top_k
from services.temporal_segmentation import TemporalSegmenter

SOURCE_ROOT = os.path.join(os.path.dirname(__file__), '..', 'sources', 'bilibili', 'ysjf', 'space_camera_project')
DENSE_SCAN_PATH = os.path.join(SOURCE_ROOT, 'extracted', 'keyframe_v2', 'dense_scan.json')
SEGMENTS_PATH = os.path.join(SOURCE_ROOT, 'extracted', 'keyframe_v2', 'source_segments.json')

# V1 frozen artifacts that must not be modified
FROZEN_V1_PATHS = [
    os.path.join(SOURCE_ROOT, 'extracted', 'frame_observations.json'),
    os.path.join(SOURCE_ROOT, 'extracted', 'content_facts.json'),
    os.path.join(SOURCE_ROOT, 'extracted', 'candidate_frames.json'),
    os.path.join(SOURCE_ROOT, 'posts', 'shared_visual_anchors.json'),
    os.path.join(SOURCE_ROOT, 'posts', 'global_visual_plan.json'),
]


# ---------------------------------------------------------------------------
# Test 1: QuickSelect Top-K correctness
# ---------------------------------------------------------------------------

def test_quickselect_top_k_correctness():
    items = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]
    result = select_top_k(items, k=3, mode="batch_quickselect")
    assert len(result) == 3
    assert set(result) == {9, 6, 5}
    # All returned values should be >= any non-returned value
    result_set = set(result)
    non_result = [x for x in items if x not in result_set or items.count(x) > list(result).count(x)]
    assert min(result) >= max(non_result) if non_result else True


def test_quickselect_top_k_with_key():
    items = [{"score": 3}, {"score": 9}, {"score": 1}, {"score": 7}]
    result = select_top_k(items, k=2, key=lambda x: x["score"], mode="batch_quickselect")
    assert len(result) == 2
    scores = {r["score"] for r in result}
    assert scores == {9, 7}


def test_quickselect_top_k_k_larger_than_list():
    items = [1, 2, 3]
    result = select_top_k(items, k=10, mode="batch_quickselect")
    assert set(result) == {1, 2, 3}


# ---------------------------------------------------------------------------
# Test 2: Stream min-heap Top-K correctness
# ---------------------------------------------------------------------------

def test_minheap_top_k_correctness():
    items = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]
    result = select_top_k(items, k=3, mode="stream_min_heap")
    assert len(result) == 3
    assert set(result) == {9, 6, 5}


def test_minheap_matches_quickselect():
    import random
    random.seed(42)
    items = [random.randint(0, 100) for _ in range(50)]
    k = 7
    r_qs = sorted(select_top_k(items, k=k, mode="batch_quickselect"), reverse=True)
    r_mh = sorted(select_top_k(items, k=k, mode="stream_min_heap"), reverse=True)
    assert r_qs == r_mh


# ---------------------------------------------------------------------------
# Test 3: Long stable segment does not get high information_density by length
# ---------------------------------------------------------------------------

def test_long_stable_segment_low_density():
    """
    A 100-second segment with very low change scores must have low information_density,
    even though it has many scan points.
    """
    low_change = 0.02
    stable_pts = [
        {
            "source_video_timestamp_sec": float(i),
            "frame_ref": f"dense_{i:05d}",
            "visual_change_score": low_change,
            "novelty_score": low_change,
            "motion_score": low_change,
            "scene_cut_score": 0.0,
            "quality_score": 0.5
        }
        for i in range(100)
    ]
    high_change = 0.8
    short_pts = [
        {
            "source_video_timestamp_sec": float(100 + i),
            "frame_ref": f"dense_{100+i:05d}",
            "visual_change_score": high_change,
            "novelty_score": high_change,
            "motion_score": high_change,
            "scene_cut_score": 0.5,
            "quality_score": 0.8
        }
        for i in range(3)
    ]
    scan_result = {
        "scan_points": stable_pts + short_pts,
        "total_duration_sec": 103.0,
        "scan_interval_sec": 1.0
    }
    segmenter = TemporalSegmenter(
        scene_cut_threshold=0.4,
        change_peak_threshold=0.5,
        novelty_peak_threshold=0.5,
        min_segment_duration=1.0  # allow 1s segments so spike isn't merged back into stable block
    )
    result = segmenter.segment(scan_result)
    segs = result["segments"]

    # Find the long stable segment (dur >= 50s)
    stable_seg = max((s for s in segs if s["duration_sec"] >= 50), key=lambda s: s["duration_sec"], default=None)
    assert stable_seg is not None, "No stable segment found"

    # Find the short high-change segment (dur <= 5s, must exist since spike creates 1-3s boundaries)
    short_seg = max((s for s in segs if s["duration_sec"] <= 5), key=lambda s: s["information_density"], default=None)
    assert short_seg is not None, f"No short segment found; all segments: {[(s['segment_id'], s['duration_sec']) for s in segs]}"

    # Long stable segment must have LOWER information_density than short high-change segment
    assert stable_seg["information_density"] < short_seg["information_density"], (
        f"Long stable segment (dur={stable_seg['duration_sec']}s) density={stable_seg['information_density']} "
        f">= short high-change segment (dur={short_seg['duration_sec']}s) density={short_seg['information_density']}"
    )


# ---------------------------------------------------------------------------
# Test 4: Short high-change region captured as transition candidate
# ---------------------------------------------------------------------------

def test_short_high_change_transition_captured():
    """
    A 2-second spike of high scene_cut + visual_change should produce a transition candidate,
    even if surrounded by 400+ seconds of stable content.
    """
    stable = [
        {
            "source_video_timestamp_sec": float(i),
            "frame_ref": f"dense_{i:05d}",
            "visual_change_score": 0.02,
            "novelty_score": 0.02,
            "motion_score": 0.01,
            "scene_cut_score": 0.05,
            "quality_score": 0.5
        }
        for i in range(400)
    ]
    spike = [
        {
            "source_video_timestamp_sec": float(200 + i),
            "frame_ref": f"dense_spike_{i:05d}",
            "visual_change_score": 0.85,
            "novelty_score": 0.70,
            "motion_score": 0.60,
            "scene_cut_score": 0.95,
            "quality_score": 0.8
        }
        for i in range(2)
    ]
    # Insert spike at t=200-201, overriding existing stable points at those timestamps
    all_pts = [p for p in stable if p["source_video_timestamp_sec"] not in {200.0, 201.0}]
    all_pts += spike
    all_pts.sort(key=lambda p: p["source_video_timestamp_sec"])

    scan_result = {
        "scan_points": all_pts,
        "total_duration_sec": 400.0,
        "scan_interval_sec": 1.0
    }
    segmenter = TemporalSegmenter(
        scene_cut_threshold=0.3,
        change_peak_threshold=0.25,
        novelty_peak_threshold=0.20,
        min_segment_duration=2.0,
        transition_merge_gap=2.0
    )
    result = segmenter.segment(scan_result)
    candidates = result["transition_candidate_regions"]
    assert len(candidates) > 0, "No transition candidates found for 2s spike"

    # The candidate must cover the spike region (t≈200-202)
    covers_spike = any(c["start_sec"] <= 201.0 <= c["end_sec"] for c in candidates)
    assert covers_spike, f"Spike at t=200-201 not covered by any candidate: {candidates}"


# ---------------------------------------------------------------------------
# Test 5: Source segment timestamps monotonic
# ---------------------------------------------------------------------------

def test_segment_timestamps_monotonic():
    if not os.path.exists(SEGMENTS_PATH):
        pytest.skip("source_segments.json not yet generated")
    data = json.load(open(SEGMENTS_PATH))
    segs = data["segments"]
    assert len(segs) > 0
    starts = [s["source_start_sec"] for s in segs]
    assert starts == sorted(starts), "Segment start_sec not monotonically increasing"
    for s in segs:
        assert s["source_start_sec"] <= s["source_end_sec"], (
            f"Segment {s['segment_id']}: start > end"
        )


# ---------------------------------------------------------------------------
# Test 6: No expensive Vision calls
# ---------------------------------------------------------------------------

def test_no_expensive_vision_calls():
    if not os.path.exists(DENSE_SCAN_PATH):
        pytest.skip("dense_scan.json not yet generated")
    data = json.load(open(DENSE_SCAN_PATH))
    assert data.get("no_expensive_vision_calls") is True
    assert data.get("estimated_expensive_vision_calls") == 0


# ---------------------------------------------------------------------------
# Test 7: Frozen V1 artifacts untouched
# ---------------------------------------------------------------------------

def test_frozen_v1_artifacts_untouched():
    """
    K1 must not create or modify V1 frozen artifacts.
    We check that none of the V1 paths were touched by verifying
    they either don't exist (acceptable) or exist with unmodified content
    by checking they are not inside the keyframe_v2 output directory.
    More importantly: keyframe_v2 output must be in its own subdirectory.
    """
    kv2_dir = os.path.join(SOURCE_ROOT, 'extracted', 'keyframe_v2')
    assert os.path.isdir(kv2_dir), "keyframe_v2 output directory must exist"

    # V1 outputs must NOT be inside keyframe_v2 dir
    for v1_path in FROZEN_V1_PATHS:
        assert not v1_path.startswith(kv2_dir), (
            f"V1 artifact found inside keyframe_v2 dir: {v1_path}"
        )

    # V1 candidate_frames.json must not have been overwritten with K1 content
    cf_path = os.path.join(SOURCE_ROOT, 'extracted', 'candidate_frames.json')
    if os.path.exists(cf_path):
        cf = json.load(open(cf_path))
        # V1 candidate_frames uses a different schema than dense_scan
        assert "scan_points" not in cf, "V1 candidate_frames.json appears to have been overwritten with K1 schema"
