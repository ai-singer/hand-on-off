"""
tests/test_keyframe_v2_k2a.py

K2A validation tests:
1.  Segment-local Top-K correctness
2.  QuickSelect matches full sort result
3.  Long stable segment cannot dominate candidate budget
4.  Short high-change segment receives candidates
5.  Transition region receives protected before/transition/after candidates
6.  Candidate IDs/refs unique
7.  Source timestamps preserved
8.  No semantic Vision calls
9.  K1 artifacts unchanged
10. Frozen V1 artifacts unchanged
"""

import json
import os
import sys
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from services.keyframe_candidate_selection import (
    CandidateSelector, dynamic_local_k, composite_score, DEFAULT_WEIGHTS
)
from services.keyframe_dense_scan import select_top_k

SOURCE_ROOT = os.path.join(os.path.dirname(__file__), '..', 'sources', 'bilibili', 'ysjf', 'space_camera_project')
K2A_PATH = os.path.join(SOURCE_ROOT, 'extracted', 'keyframe_v2', 'candidates_k2a.json')
DENSE_SCAN_PATH = os.path.join(SOURCE_ROOT, 'extracted', 'keyframe_v2', 'dense_scan.json')
SEGMENTS_PATH = os.path.join(SOURCE_ROOT, 'extracted', 'keyframe_v2', 'source_segments.json')

FROZEN_V1_PATHS = [
    os.path.join(SOURCE_ROOT, 'extracted', 'frame_observations.json'),
    os.path.join(SOURCE_ROOT, 'extracted', 'content_facts.json'),
    os.path.join(SOURCE_ROOT, 'extracted', 'candidate_frames.json'),
    os.path.join(SOURCE_ROOT, 'posts', 'shared_visual_anchors.json'),
    os.path.join(SOURCE_ROOT, 'posts', 'global_visual_plan.json'),
]

FROZEN_K1_PATHS = [
    os.path.join(SOURCE_ROOT, 'extracted', 'keyframe_v2', 'dense_scan.json'),
    os.path.join(SOURCE_ROOT, 'extracted', 'keyframe_v2', 'source_segments.json'),
]


def _make_pt(ts, vc=0.1, nv=0.1, mo=0.1, sc=0.0, qs=0.5, idx=None):
    idx = idx if idx is not None else int(ts)
    return {
        "source_video_timestamp_sec": ts,
        "frame_ref": f"dense_{idx:05d}_{int(ts*1000):08d}ms",
        "visual_change_score": vc,
        "novelty_score": nv,
        "motion_score": mo,
        "scene_cut_score": sc,
        "quality_score": qs,
    }


def _make_seg(seg_id, start, end, info_density=0.1):
    return {
        "segment_id": seg_id,
        "source_start_sec": start,
        "source_end_sec": end,
        "duration_sec": round(end - start, 2),
        "information_density": info_density,
        "change_density": info_density / 2,
        "novelty_density": info_density / 2,
        "motion_density": 0.05,
        "strong_change_points": [],
        "representative_frame_refs": [],
        "raw_scan_point_count": int(end - start),
    }


# ---------------------------------------------------------------------------
# Test 1: Segment-local Top-K correctness
# ---------------------------------------------------------------------------

def test_segment_local_topk_selects_within_segment():
    """Each segment's candidates come only from that segment's scan points."""
    seg_a = _make_seg("seg_0000", 0.0, 10.0, info_density=0.5)
    seg_b = _make_seg("seg_0001", 10.0, 20.0, info_density=0.1)

    pts_a = [_make_pt(float(i), vc=0.8, nv=0.8, sc=0.8) for i in range(10)]
    pts_b = [_make_pt(float(10 + i), vc=0.1, nv=0.1, sc=0.0) for i in range(10)]

    scan_result = {"scan_points": pts_a + pts_b, "total_duration_sec": 20.0, "scan_interval_sec": 1.0}
    segmentation = {
        "segments": [seg_a, seg_b],
        "transition_candidate_regions": [],
        "scan_interval_sec": 1.0,
        "total_duration_sec": 20.0,
        "segment_count": 2,
        "transition_candidate_count": 0,
    }

    selector = CandidateSelector(global_budget=20)
    result = selector.select(scan_result, segmentation)
    candidates = result["candidates"]

    # All candidates must have valid segment IDs
    seg_ids = {"seg_0000", "seg_0001"}
    for c in candidates:
        assert c["source_segment_id"] in seg_ids

    # High-density seg_a should contribute more candidates than low seg_b
    from collections import Counter
    counts = Counter(c["source_segment_id"] for c in candidates)
    # seg_a has higher information_density so should get >= seg_b
    assert counts.get("seg_0000", 0) >= counts.get("seg_0001", 0), (
        f"High-density seg_0000 ({counts.get('seg_0000',0)}) should have >= "
        f"low-density seg_0001 ({counts.get('seg_0001',0)}) candidates"
    )


# ---------------------------------------------------------------------------
# Test 2: QuickSelect matches full sort
# ---------------------------------------------------------------------------

def test_quickselect_matches_full_sort():
    import random
    random.seed(99)
    items = [{"score": random.random(), "id": i} for i in range(100)]
    k = 15

    qs_result = select_top_k(items, k=k, key=lambda x: x["score"], mode="batch_quickselect")
    full_sort_result = sorted(items, key=lambda x: x["score"], reverse=True)[:k]

    qs_ids = sorted(x["id"] for x in qs_result)
    fs_ids = sorted(x["id"] for x in full_sort_result)
    assert qs_ids == fs_ids, f"QuickSelect and full sort disagree: {qs_ids} vs {fs_ids}"


# ---------------------------------------------------------------------------
# Test 3: Long stable segment cannot dominate
# ---------------------------------------------------------------------------

def test_long_stable_segment_does_not_dominate():
    """A 500s stable segment should not get dramatically more candidates than a 3s high-change segment."""
    long_seg = _make_seg("seg_long", 0.0, 500.0, info_density=0.05)
    short_seg = _make_seg("seg_short", 500.0, 503.0, info_density=2.0)

    pts_long = [_make_pt(float(i), vc=0.05, nv=0.05) for i in range(500)]
    pts_short = [_make_pt(float(500 + i), vc=0.9, nv=0.9, sc=0.9, idx=500+i) for i in range(3)]

    scan_result = {"scan_points": pts_long + pts_short, "total_duration_sec": 503.0, "scan_interval_sec": 1.0}
    segmentation = {
        "segments": [long_seg, short_seg],
        "transition_candidate_regions": [],
        "scan_interval_sec": 1.0,
        "total_duration_sec": 503.0,
        "segment_count": 2,
        "transition_candidate_count": 0,
    }

    selector = CandidateSelector(
        max_local_k=6,
        max_segment_share=0.10,
        global_budget=100
    )
    result = selector.select(scan_result, segmentation)
    from collections import Counter
    counts = Counter(c["source_segment_id"] for c in result["candidates"])

    long_count = counts.get("seg_long", 0)
    short_count = counts.get("seg_short", 0)

    # Long segment must not get more than max_local_k candidates
    assert long_count <= 6, f"Long segment got {long_count} candidates (max_local_k=6)"
    # Short high-density segment should have candidates
    assert short_count > 0, "Short high-density segment got 0 candidates"
    # Long segment must not dominate over short high-change segment by huge margin
    assert long_count <= short_count * 3 + 1, (
        f"Long segment ({long_count}) dominates short high-change ({short_count})"
    )


# ---------------------------------------------------------------------------
# Test 4: Short high-change segment receives candidates
# ---------------------------------------------------------------------------

def test_short_high_change_segment_receives_candidates():
    """A 2s high-change segment must receive at least 1 candidate."""
    segs = [
        _make_seg("seg_stable", 0.0, 100.0, info_density=0.02),
        _make_seg("seg_spike",  100.0, 102.0, info_density=1.5),
    ]
    pts = (
        [_make_pt(float(i), vc=0.02, nv=0.02) for i in range(100)] +
        [_make_pt(float(100 + i), vc=0.9, nv=0.9, sc=0.95, idx=100+i) for i in range(2)]
    )
    scan_result = {"scan_points": pts, "total_duration_sec": 102.0, "scan_interval_sec": 1.0}
    segmentation = {
        "segments": segs,
        "transition_candidate_regions": [],
        "scan_interval_sec": 1.0,
        "total_duration_sec": 102.0,
        "segment_count": 2,
        "transition_candidate_count": 0,
    }

    selector = CandidateSelector()
    result = selector.select(scan_result, segmentation)
    from collections import Counter
    counts = Counter(c["source_segment_id"] for c in result["candidates"])
    assert counts.get("seg_spike", 0) >= 1, "Short high-change segment received 0 candidates"


# ---------------------------------------------------------------------------
# Test 5: Transition region protected candidates
# ---------------------------------------------------------------------------

def test_transition_region_receives_protected_candidates():
    """A transition region must result in before/peak/after candidates."""
    seg = _make_seg("seg_0000", 0.0, 20.0, info_density=0.3)
    pts = [_make_pt(float(i), vc=0.1 + (0.8 if 9 <= i <= 11 else 0),
                    sc=0.9 if 9 <= i <= 11 else 0.0) for i in range(20)]
    tc_region = {"start_sec": 9.0, "end_sec": 12.0, "peak_change_score": 0.9, "reason": "scene_cut"}

    scan_result = {"scan_points": pts, "total_duration_sec": 20.0, "scan_interval_sec": 1.0}
    segmentation = {
        "segments": [seg],
        "transition_candidate_regions": [tc_region],
        "scan_interval_sec": 1.0,
        "total_duration_sec": 20.0,
        "segment_count": 1,
        "transition_candidate_count": 1,
    }

    selector = CandidateSelector()
    result = selector.select(scan_result, segmentation)

    assert result["summary"]["transition_regions_covered"] == 1
    assert result["summary"]["transition_regions_uncovered"] == 0
    tc_cands = [c for c in result["candidates"] if c["transition_candidate"]]
    assert len(tc_cands) >= 1, "No transition candidates generated"
    # At least one candidate should be near the transition region
    near_tc = [c for c in result["candidates"]
               if 7.0 <= c["source_video_timestamp_sec"] <= 14.0]
    assert len(near_tc) >= 1, "No candidate near transition region"


# ---------------------------------------------------------------------------
# Test 6 & 7: Refs unique + timestamps preserved (from actual output)
# ---------------------------------------------------------------------------

def test_candidate_refs_unique():
    if not os.path.exists(K2A_PATH):
        pytest.skip("candidates_k2a.json not yet generated")
    data = json.load(open(K2A_PATH))
    refs = [c["source_frame_ref"] for c in data["candidates"]]
    assert len(refs) == len(set(refs)), f"Duplicate refs found: {len(refs) - len(set(refs))}"


def test_candidate_timestamps_in_scan():
    if not os.path.exists(K2A_PATH) or not os.path.exists(DENSE_SCAN_PATH):
        pytest.skip("K2A or scan output not generated")
    data = json.load(open(K2A_PATH))
    scan = json.load(open(DENSE_SCAN_PATH))
    valid_ts = {p["source_video_timestamp_sec"] for p in scan["scan_points"]}
    for c in data["candidates"]:
        assert c["source_video_timestamp_sec"] in valid_ts, (
            f"Candidate ts {c['source_video_timestamp_sec']} not in scan"
        )


# ---------------------------------------------------------------------------
# Test 8: No expensive Vision calls
# ---------------------------------------------------------------------------

def test_no_expensive_vision_calls():
    if not os.path.exists(K2A_PATH):
        pytest.skip("candidates_k2a.json not yet generated")
    data = json.load(open(K2A_PATH))
    assert data["performance"]["expensive_vision_calls"] == 0
    assert data["performance"]["full_video_global_topk_used"] == False


# ---------------------------------------------------------------------------
# Test 9: K1 artifacts unchanged
# ---------------------------------------------------------------------------

def test_k1_artifacts_unchanged():
    for path in FROZEN_K1_PATHS:
        if os.path.exists(path):
            data = json.load(open(path))
            # K2A output must not overwrite K1 files with K2A schema
            assert "schema_version" not in data or "K2A" not in str(data.get("schema_version", "")), (
                f"K1 artifact {path} appears overwritten with K2A schema"
            )


# ---------------------------------------------------------------------------
# Test 10: Frozen V1 artifacts unchanged
# ---------------------------------------------------------------------------

def test_frozen_v1_artifacts_unchanged():
    kv2_dir = os.path.join(SOURCE_ROOT, 'extracted', 'keyframe_v2')
    for v1_path in FROZEN_V1_PATHS:
        assert not v1_path.startswith(kv2_dir), f"V1 path inside keyframe_v2 dir: {v1_path}"
    cf_path = os.path.join(SOURCE_ROOT, 'extracted', 'candidate_frames.json')
    if os.path.exists(cf_path):
        cf = json.load(open(cf_path))
        assert "schema_version" not in cf or "K2A" not in str(cf.get("schema_version", "")), (
            "V1 candidate_frames.json overwritten with K2A schema"
        )
