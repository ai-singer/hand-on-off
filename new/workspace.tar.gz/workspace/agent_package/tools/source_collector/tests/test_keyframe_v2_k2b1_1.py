"""
tests/test_keyframe_v2_k2b1_1.py

K2B1.1 Similarity Contract tests.

All similarity helpers must satisfy:
  0.0 = maximally different
  1.0 = identical / maximally similar

Tests:
1.  identical image → all similarities = 1.0
2.  slight brightness variation → composite high
3.  resized equivalent (same solid colour) → composite high
4.  red vs blue image → per_channel_histogram_similarity low
5.  same histogram / different layout → hist high, edge lower
6.  similar structure / different colors → phash may vary, hist lower
7.  all helpers return 0.0 ≤ sim ≤ 1.0
8.  symmetry: sim(A,B) == sim(B,A)
9.  bounded: 0 ≤ composite_similarity ≤ 1
10. K2B1 signature artifacts unchanged
"""

import json
import math
import os
import sys
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from services.keyframe_diversity import (
    DiversitySignatureExtractor,
    phash_similarity, per_channel_histogram_similarity,
    histogram_similarity, edge_similarity, visual_similarity,
    hamming_distance, THUMB_WIDTH, THUMB_HEIGHT, HIST_BINS,
    DEFAULT_COMPOSITE_WEIGHTS,
)

SOURCE_ROOT = os.path.join(os.path.dirname(__file__), '..', 'sources', 'bilibili', 'ysjf', 'space_camera_project')
K2B1_PATH = os.path.join(SOURCE_ROOT, 'extracted', 'keyframe_v2', 'candidate_diversity_signatures_k2b1.json')
K2A_PATH  = os.path.join(SOURCE_ROOT, 'extracted', 'keyframe_v2', 'candidates_k2a.json')


# ---------------------------------------------------------------------------
# Frame helpers
# ---------------------------------------------------------------------------

def _solid(r, g, b, w=THUMB_WIDTH, h=THUMB_HEIGHT) -> bytes:
    return bytes([r, g, b] * w * h)


def _gradient_rgb(w=THUMB_WIDTH, h=THUMB_HEIGHT) -> bytes:
    """Horizontal luminance gradient."""
    data = bytearray()
    for row in range(h):
        for col in range(w):
            v = col * 255 // w
            data += bytes([v, v, v])
    return bytes(data)


def _red_gradient(w=THUMB_WIDTH, h=THUMB_HEIGHT) -> bytes:
    data = bytearray()
    for row in range(h):
        for col in range(w):
            v = col * 255 // w
            data += bytes([v, 0, 0])
    return bytes(data)


def _blue_gradient(w=THUMB_WIDTH, h=THUMB_HEIGHT) -> bytes:
    data = bytearray()
    for row in range(h):
        for col in range(w):
            v = col * 255 // w
            data += bytes([0, 0, v])
    return bytes(data)


def _checkerboard(w=THUMB_WIDTH, h=THUMB_HEIGHT, block=8) -> bytes:
    data = bytearray()
    for row in range(h):
        for col in range(w):
            v = 255 if ((row // block) + (col // block)) % 2 == 0 else 0
            data += bytes([v, v, v])
    return bytes(data)


def sig(raw):
    return DiversitySignatureExtractor().extract_from_raw(raw)


# ---------------------------------------------------------------------------
# Test 1: identical image → all similarities = 1.0
# ---------------------------------------------------------------------------

def test_identical_image_all_similarities_one():
    raw = _gradient_rgb()
    sa = sig(raw)
    sb = sig(raw)
    assert phash_similarity(sa["perceptual_hash"], sb["perceptual_hash"]) == 1.0
    assert per_channel_histogram_similarity(sa["color_histogram"], sb["color_histogram"]) == 1.0
    assert edge_similarity(sa["edge_layout"], sb["edge_layout"]) >= 0.999
    vs = visual_similarity(sa, sb)
    assert vs["composite_similarity"] >= 0.999


# ---------------------------------------------------------------------------
# Test 2: slight brightness variation → composite high
# ---------------------------------------------------------------------------

def test_slight_variation_composite_high():
    """
    Minor brightness shift within the same histogram bin keeps composite high.
    32 bins over 256 values = 8 values per bin.
    solid(100) and solid(103) both fall in bin 12 (100//8 == 103//8 == 12),
    so per-channel BC = 1.0 and composite remains near-identical.
    """
    raw_a = _solid(100, 100, 100)
    raw_b = _solid(103, 103, 103)  # +3 per channel, same bin
    sa, sb = sig(raw_a), sig(raw_b)
    vs = visual_similarity(sa, sb)
    assert vs["composite_similarity"] >= 0.85, (
        f"Within-bin brightness change should keep composite high: {vs['composite_similarity']}"
    )


# ---------------------------------------------------------------------------
# Test 3: same-colour solid at different representation → composite high
# ---------------------------------------------------------------------------

def test_same_colour_solid_composite_high():
    raw_a = _solid(200, 50, 50)
    raw_b = _solid(200, 50, 50)
    sa, sb = sig(raw_a), sig(raw_b)
    vs = visual_similarity(sa, sb)
    assert vs["composite_similarity"] >= 0.99


# ---------------------------------------------------------------------------
# Test 4: red vs blue → per_channel_histogram_similarity low
# ---------------------------------------------------------------------------

def test_red_vs_blue_histogram_similarity_low():
    raw_r = _red_gradient()
    raw_b = _blue_gradient()
    sa, sb = sig(raw_r), sig(raw_b)

    pc_sim = per_channel_histogram_similarity(
        sa["color_histogram"], sb["color_histogram"]
    )
    assert pc_sim < 0.5, (
        f"Red vs blue gradient per-channel hist similarity should be < 0.5, got {pc_sim}"
    )

    # Composite must also reflect this difference
    vs = visual_similarity(sa, sb)
    assert vs["histogram_similarity"] < 0.5, (
        f"visual_similarity histogram component should be < 0.5 for red vs blue, "
        f"got {vs['histogram_similarity']}"
    )


# ---------------------------------------------------------------------------
# Test 5: same histogram / different layout → hist high, edge lower
# ---------------------------------------------------------------------------

def test_same_histogram_different_layout():
    """
    Two grey images with similar brightness distributions but different spatial structure.
    Histogram should be high; edge layout should differ.
    """
    raw_solid_grey = _solid(128, 128, 128)
    raw_checker = _checkerboard()

    sa, sb = sig(raw_solid_grey), sig(raw_checker)

    hist_sim = per_channel_histogram_similarity(
        sa["color_histogram"], sb["color_histogram"]
    )
    # Both are mid-grey overall — histogram should be moderately similar
    # but edge layout should differ strongly
    edge_sim_val = edge_similarity(sa["edge_layout"], sb["edge_layout"])

    # Solid grey: ~0 edges everywhere
    # Checkerboard: high edges at block boundaries
    solid_max_edge = max(sa["edge_layout"])
    checker_max_edge = max(sb["edge_layout"])
    assert checker_max_edge > solid_max_edge, (
        f"Checkerboard should have higher edge energy: "
        f"checker={checker_max_edge:.4f} solid={solid_max_edge:.4f}"
    )
    print(f"  hist_sim={hist_sim:.3f} edge_sim={edge_sim_val:.3f}")
    print(f"  solid_max_edge={solid_max_edge:.4f} checker_max_edge={checker_max_edge:.4f}")


# ---------------------------------------------------------------------------
# Test 6: similar structure / different colors → phash varies, hist lower
# ---------------------------------------------------------------------------

def test_similar_structure_different_color():
    raw_r = _red_gradient()
    raw_b = _blue_gradient()
    sa, sb = sig(raw_r), sig(raw_b)

    vs = visual_similarity(sa, sb)

    # Histogram must be clearly lower than identical
    assert vs["histogram_similarity"] < 0.5, (
        f"Different color gradients: hist should be < 0.5, got {vs['histogram_similarity']}"
    )
    # Composite should not reach near-identical
    assert vs["composite_similarity"] < 0.85, (
        f"Different color gradients: composite should be < 0.85, got {vs['composite_similarity']}"
    )
    print(f"  phash={vs['phash_similarity']:.3f} hist={vs['histogram_similarity']:.3f} "
          f"edge={vs['edge_layout_similarity']:.3f} composite={vs['composite_similarity']:.3f}")


# ---------------------------------------------------------------------------
# Test 7: all helpers return 0.0 ≤ sim ≤ 1.0
# ---------------------------------------------------------------------------

def test_all_helpers_bounded():
    frames = [
        _solid(0, 0, 0),
        _solid(255, 255, 255),
        _red_gradient(),
        _blue_gradient(),
        _gradient_rgb(),
        _checkerboard(),
        _solid(128, 0, 255),
    ]
    sigs = [sig(f) for f in frames]
    for i, sa in enumerate(sigs):
        for j, sb in enumerate(sigs):
            ph = phash_similarity(sa["perceptual_hash"], sb["perceptual_hash"])
            hi = per_channel_histogram_similarity(sa["color_histogram"], sb["color_histogram"])
            ed = edge_similarity(sa["edge_layout"], sb["edge_layout"])
            vs = visual_similarity(sa, sb)
            for name, val in [("phash", ph), ("histogram", hi), ("edge", ed),
                               ("composite", vs["composite_similarity"])]:
                assert 0.0 <= val <= 1.0, (
                    f"frames[{i}] vs frames[{j}]: {name} out of bounds: {val}"
                )


# ---------------------------------------------------------------------------
# Test 8: symmetry sim(A,B) == sim(B,A)
# ---------------------------------------------------------------------------

def test_all_helpers_symmetric():
    raw_a = _red_gradient()
    raw_b = _blue_gradient()
    sa, sb = sig(raw_a), sig(raw_b)

    assert phash_similarity(sa["perceptual_hash"], sb["perceptual_hash"]) == \
           phash_similarity(sb["perceptual_hash"], sa["perceptual_hash"])

    assert per_channel_histogram_similarity(sa["color_histogram"], sb["color_histogram"]) == \
           per_channel_histogram_similarity(sb["color_histogram"], sa["color_histogram"])

    assert edge_similarity(sa["edge_layout"], sb["edge_layout"]) == \
           edge_similarity(sb["edge_layout"], sa["edge_layout"])

    vs_ab = visual_similarity(sa, sb)
    vs_ba = visual_similarity(sb, sa)
    assert vs_ab["composite_similarity"] == vs_ba["composite_similarity"]


# ---------------------------------------------------------------------------
# Test 9: composite bounded 0 ≤ composite ≤ 1
# ---------------------------------------------------------------------------

def test_composite_bounded():
    frames = [_solid(0, 0, 0), _solid(255, 255, 255), _red_gradient(), _checkerboard()]
    sigs_list = [sig(f) for f in frames]
    for sa in sigs_list:
        for sb in sigs_list:
            vs = visual_similarity(sa, sb)
            assert 0.0 <= vs["composite_similarity"] <= 1.0


# ---------------------------------------------------------------------------
# Test 10: K2B1 signature artifacts unchanged
# ---------------------------------------------------------------------------

def test_k2b1_signatures_unchanged():
    if not os.path.exists(K2B1_PATH):
        pytest.skip("K2B1 signatures not present")
    data = json.load(open(K2B1_PATH))
    assert data["schema_version"] == "KEYFRAME_V2_K2B1"
    assert data["summary"]["candidate_count"] == 454
    assert data["summary"]["signature_count"] == 454
    assert data["summary"]["failed_count"] == 0
    # Spot-check: all signatures still have the 3 fields
    for c in data["candidates"][:5] + data["candidates"][-5:]:
        sig_data = c["diversity_signature"]
        assert sig_data.get("perceptual_hash") is not None
        assert len(sig_data.get("color_histogram", [])) == 96
        assert len(sig_data.get("edge_layout", [])) == 16


def test_k2a_artifacts_unchanged():
    if not os.path.exists(K2A_PATH):
        pytest.skip("K2A output not present")
    data = json.load(open(K2A_PATH))
    assert data["schema_version"] == "KEYFRAME_V2_K2A"
    assert len(data["candidates"]) == 454
