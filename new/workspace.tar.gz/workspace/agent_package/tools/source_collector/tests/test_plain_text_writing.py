"""
tests/test_plain_text_writing.py

Plain-Text Article Writing + AI Visual Output 验证测试

覆盖：
  1.  post_001.txt / post_002.txt / post_003.txt 存在
  2.  metadata 文件存在
  3.  visual_output.json 文件存在
  4.  正文不含 Markdown 语法（无 # 标题、无 ![]() 图片、无 --- 分隔线）
  5.  字数在 700-1500 范围（中文字）
  6.  used_facts 合法（来自 content_facts）
  7.  used_frames 合法（来自 frame_observations）
  8.  每个 visual_output 中的图片条目都有 prompt
  9.  visual_output 声明不直接使用原始抽帧（transformation_rule 存在）
  10. metadata 包含 output_format=plain_text 和 visual_strategy 字段
"""

import json
import os
import re
import pytest

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

SOURCE_ROOT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "sources", "bilibili", "ysjf", "space_camera_project"
)
POSTS_DIR = os.path.join(SOURCE_ROOT, "posts")
FACTS_PATH = os.path.join(SOURCE_ROOT, "extracted", "content_facts.json")
OBS_PATH   = os.path.join(SOURCE_ROOT, "extracted", "frame_observations.json")

POST_IDS = ["post_001", "post_002", "post_003"]


def count_chinese(text: str) -> int:
    return len(re.findall(r'[\u4e00-\u9fff]', text))


def load_valid_fact_ids():
    with open(FACTS_PATH, encoding="utf-8") as f:
        facts = json.load(f)["facts"]
    return {f"fact_{i}" for i in range(len(facts))}


def load_valid_frame_ids():
    with open(OBS_PATH, encoding="utf-8") as f:
        return {o["frame_id"] for o in json.load(f)["observations"]}


# ---------------------------------------------------------------------------
# Test 1: .txt 文件存在
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("post_id", POST_IDS)
def test_txt_file_exists(post_id):
    path = os.path.join(POSTS_DIR, f"{post_id}.txt")
    assert os.path.isfile(path), f"{post_id}.txt 不存在"


# ---------------------------------------------------------------------------
# Test 2: metadata 文件存在
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("post_id", POST_IDS)
def test_metadata_exists(post_id):
    path = os.path.join(POSTS_DIR, f"{post_id}_metadata.json")
    assert os.path.isfile(path), f"{post_id}_metadata.json 不存在"


# ---------------------------------------------------------------------------
# Test 3: visual_output.json 存在
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("post_id", POST_IDS)
def test_visual_output_exists(post_id):
    path = os.path.join(POSTS_DIR, f"{post_id}_visual_output.json")
    assert os.path.isfile(path), f"{post_id}_visual_output.json 不存在"


# ---------------------------------------------------------------------------
# Test 4: 正文不含 Markdown 语法
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("post_id", POST_IDS)
def test_no_markdown_syntax(post_id):
    path = os.path.join(POSTS_DIR, f"{post_id}.txt")
    with open(path, encoding="utf-8") as f:
        content = f.read()

    # 不允许 Markdown 标题（行首 #）
    assert not re.search(r'^#{1,6}\s', content, re.MULTILINE), (
        f"{post_id}.txt 包含 Markdown 标题语法（#）"
    )
    # 不允许 Markdown 图片语法
    assert not re.search(r'!\[.*?\]\(.*?\)', content), (
        f"{post_id}.txt 包含 Markdown 图片语法（![]()）"
    )
    # 不允许 Markdown 水平线（--- 或 ***）
    assert not re.search(r'^---+\s*$', content, re.MULTILINE), (
        f"{post_id}.txt 包含 Markdown 分隔线（---）"
    )


# ---------------------------------------------------------------------------
# Test 5: 字数在合理范围
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("post_id", POST_IDS)
def test_word_count_in_range(post_id):
    path = os.path.join(POSTS_DIR, f"{post_id}.txt")
    with open(path, encoding="utf-8") as f:
        content = f.read()
    count = count_chinese(content)
    assert 700 <= count <= 1500, (
        f"{post_id}.txt 中文字数 {count} 不在范围 (700-1500) 内"
    )


# ---------------------------------------------------------------------------
# Test 6: used_facts 合法
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("post_id", POST_IDS)
def test_used_facts_valid(post_id):
    valid_ids = load_valid_fact_ids()
    path = os.path.join(POSTS_DIR, f"{post_id}_metadata.json")
    with open(path, encoding="utf-8") as f:
        meta = json.load(f)
    for fid in meta.get("used_facts", []):
        assert fid in valid_ids, (
            f"{post_id} used_facts 包含无效 fact_id: {fid!r}"
        )


# ---------------------------------------------------------------------------
# Test 7: used_frames 合法
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("post_id", POST_IDS)
def test_used_frames_valid(post_id):
    valid_ids = load_valid_frame_ids()
    path = os.path.join(POSTS_DIR, f"{post_id}_metadata.json")
    with open(path, encoding="utf-8") as f:
        meta = json.load(f)
    for fid in meta.get("used_frames", []):
        assert fid in valid_ids, (
            f"{post_id} used_frames 包含无效 frame_id: {fid}"
        )


# ---------------------------------------------------------------------------
# Test 8: visual_output 每个图片条目有 prompt
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("post_id", POST_IDS)
def test_visual_output_has_prompts(post_id):
    path = os.path.join(POSTS_DIR, f"{post_id}_visual_output.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    images = data.get("images", [])
    assert len(images) >= 2, f"{post_id}_visual_output.json images 少于 2 个"
    for img in images:
        assert "prompt" in img and len(img["prompt"]) > 20, (
            f"{post_id} image_id={img.get('image_id')} 缺少有效 prompt"
        )


# ---------------------------------------------------------------------------
# Test 9: visual_output 声明二创规则（transformation_rule 存在）
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("post_id", POST_IDS)
def test_visual_output_has_transformation_rule(post_id):
    path = os.path.join(POSTS_DIR, f"{post_id}_visual_output.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    for img in data.get("images", []):
        assert "transformation_rule" in img and len(img["transformation_rule"]) > 10, (
            f"{post_id} image_id={img.get('image_id')} 缺少 transformation_rule"
        )


# ---------------------------------------------------------------------------
# Test 10: metadata 包含 output_format + visual_strategy
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("post_id", POST_IDS)
def test_metadata_format_fields(post_id):
    path = os.path.join(POSTS_DIR, f"{post_id}_metadata.json")
    with open(path, encoding="utf-8") as f:
        meta = json.load(f)
    assert meta.get("output_format") == "plain_text", (
        f"{post_id} metadata output_format 应为 plain_text"
    )
    assert "visual_strategy" in meta and meta["visual_strategy"], (
        f"{post_id} metadata 缺少 visual_strategy"
    )
