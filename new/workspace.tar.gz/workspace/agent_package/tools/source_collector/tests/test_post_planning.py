"""
tests/test_post_planning.py

Post Planning Layer 单元测试

覆盖：
  1.  post_plan.json 存在
  2.  schema 正确
  3.  source_id 正确
  4.  posts 非空
  5.  每个 post 有 post_id
  6.  每个 post 有 fact_ids
  7.  fact_ids 必须存在于 content_facts
  8.  key_points 必须存在于 key_points.json
  9.  image_frames 必须存在于 frame_observations
  10. 缺少输入文件时报错（缺 content_facts / key_points）
"""

import json
import os
import pytest

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.post_planning import (
    plan_posts,
    PostPlanningError,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_source_root(
    tmp_path,
    include_source=True,
    include_facts=True,
    include_kp=True,
    include_obs=True,
):
    if include_source:
        (tmp_path / "metadata").mkdir()
        (tmp_path / "metadata" / "source.json").write_text(json.dumps({
            "source_id": "test_plan_001",
            "title": "升空测试视频",
        }, ensure_ascii=False), encoding="utf-8")

    extracted = tmp_path / "extracted"
    extracted.mkdir(exist_ok=True)

    if include_facts:
        (extracted / "content_facts.json").write_text(json.dumps({
            "source_id": "test_plan_001",
            "title": "升空测试视频",
            "facts": [
                {
                    "fact": "画面中存在大型气球",
                    "evidence_frames": [6, 10],
                    "timestamp_range": {"start": 50.0, "end": 100.0},
                    "confidence": "high",
                },
                {
                    "fact": "发射现场为积雪覆盖的户外环境",
                    "evidence_frames": [6, 10],
                    "timestamp_range": {"start": 50.0, "end": 100.0},
                    "confidence": "high",
                },
                {
                    "fact": "高空阶段地球曲面清晰可见",
                    "evidence_frames": [36, 41],
                    "timestamp_range": {"start": 350.0, "end": 400.0},
                    "confidence": "high",
                },
            ],
            "uncertain_facts": [
                {"statement": "设备用途无法确认", "reason": "来自 frame_id=6"},
            ],
        }, ensure_ascii=False), encoding="utf-8")

    if include_kp:
        (extracted / "key_points.json").write_text(json.dumps({
            "source_id": "test_plan_001",
            "main_topic": "升空测试视频",
            "key_points": [
                {
                    "title": "发射准备",
                    "description": "气球发射准备阶段",
                    "related_frames": [6, 10],
                    "importance": "high",
                },
                {
                    "title": "进入近太空",
                    "description": "天空变黑，地球曲率可见",
                    "related_frames": [36, 41],
                    "importance": "high",
                },
                {
                    "title": "着陆与回收",
                    "description": "载荷着陆，人员回收",
                    "related_frames": [76, 78],
                    "importance": "high",
                },
            ],
        }, ensure_ascii=False), encoding="utf-8")

    if include_obs:
        (extracted / "frame_observations.json").write_text(json.dumps({
            "source_id": "test_plan_001",
            "total_frames": 6,
            "backend_used": "openclaw_vision",
            "observations": [
                {"frame_id": 6,  "filename": "frame_000006.jpg", "timestamp_sec": 50.0,
                 "objects": ["气球"], "scene": "发射准备",
                 "observable_facts": ["气球充气完毕"], "uncertain_points": []},
                {"frame_id": 10, "filename": "frame_000010.jpg", "timestamp_sec": 90.0,
                 "objects": ["气球", "雪地"], "scene": "发射准备",
                 "observable_facts": ["雪地可见"], "uncertain_points": []},
                {"frame_id": 36, "filename": "frame_000036.jpg", "timestamp_sec": 350.0,
                 "objects": ["地球弧面"], "scene": "近太空",
                 "observable_facts": ["地球曲率可见"], "uncertain_points": []},
                {"frame_id": 41, "filename": "frame_000041.jpg", "timestamp_sec": 400.0,
                 "objects": ["太空背景"], "scene": "近太空",
                 "observable_facts": ["天空为黑色"], "uncertain_points": []},
                {"frame_id": 76, "filename": "frame_000076.jpg", "timestamp_sec": 750.0,
                 "objects": ["载荷", "人员"], "scene": "回收现场",
                 "observable_facts": ["载荷已落地"], "uncertain_points": []},
                {"frame_id": 78, "filename": "frame_000078.jpg", "timestamp_sec": 770.0,
                 "objects": ["人员", "设备"], "scene": "回收现场",
                 "observable_facts": ["人员检查设备"], "uncertain_points": []},
            ],
        }, ensure_ascii=False), encoding="utf-8")

    return str(tmp_path)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def source_root(tmp_path):
    return make_source_root(tmp_path)

@pytest.fixture
def source_root_no_facts(tmp_path):
    return make_source_root(tmp_path, include_facts=False)

@pytest.fixture
def source_root_no_kp(tmp_path):
    return make_source_root(tmp_path, include_kp=False)

@pytest.fixture
def source_root_no_obs(tmp_path):
    return make_source_root(tmp_path, include_obs=False)


# ---------------------------------------------------------------------------
# Test 1: post_plan.json 存在
# ---------------------------------------------------------------------------

def test_post_plan_file_exists(source_root):
    plan_posts(source_root)
    path = os.path.join(source_root, "extracted", "post_plan.json")
    assert os.path.isfile(path), "post_plan.json 未生成"


# ---------------------------------------------------------------------------
# Test 2: schema 正确
# ---------------------------------------------------------------------------

def test_post_plan_schema(source_root):
    plan_posts(source_root)
    with open(os.path.join(source_root, "extracted", "post_plan.json"), encoding="utf-8") as f:
        data = json.load(f)

    for field in ["source_id", "series_title", "posts"]:
        assert field in data, f"post_plan.json 缺少字段: {field!r}"

    assert isinstance(data["posts"], list) and len(data["posts"]) > 0

    for post in data["posts"]:
        for field in ["post_id", "title", "theme", "summary",
                      "key_points", "fact_ids", "image_frames", "target_length"]:
            assert field in post, f"post 缺少字段: {field!r}"


# ---------------------------------------------------------------------------
# Test 3: source_id 正确
# ---------------------------------------------------------------------------

def test_source_id_correct(source_root):
    result = plan_posts(source_root)
    assert result.source_id == "test_plan_001"

    with open(os.path.join(source_root, "extracted", "post_plan.json"), encoding="utf-8") as f:
        data = json.load(f)
    assert data["source_id"] == "test_plan_001"


# ---------------------------------------------------------------------------
# Test 4: posts 非空
# ---------------------------------------------------------------------------

def test_posts_nonempty(source_root):
    result = plan_posts(source_root)
    assert len(result.posts) > 0, "posts 列表为空"


# ---------------------------------------------------------------------------
# Test 5: 每个 post 有 post_id
# ---------------------------------------------------------------------------

def test_posts_have_post_id(source_root):
    result = plan_posts(source_root)
    for post in result.posts:
        assert post.post_id and len(post.post_id) > 0, "post 缺少 post_id"
    # post_id 唯一
    ids = [p.post_id for p in result.posts]
    assert len(ids) == len(set(ids)), "post_id 存在重复"


# ---------------------------------------------------------------------------
# Test 6: 每个 post 有 fact_ids
# ---------------------------------------------------------------------------

def test_posts_have_fact_ids(source_root):
    result = plan_posts(source_root)
    for post in result.posts:
        assert isinstance(post.fact_ids, list) and len(post.fact_ids) > 0, (
            f"post {post.post_id!r} 缺少 fact_ids"
        )


# ---------------------------------------------------------------------------
# Test 7: fact_ids 必须存在于 content_facts
# ---------------------------------------------------------------------------

def test_fact_ids_valid(source_root):
    plan_posts(source_root)
    with open(os.path.join(source_root, "extracted", "content_facts.json"), encoding="utf-8") as f:
        facts = json.load(f)["facts"]
    valid_fact_ids = {f"fact_{i}" for i in range(len(facts))}

    with open(os.path.join(source_root, "extracted", "post_plan.json"), encoding="utf-8") as f:
        data = json.load(f)

    for post in data["posts"]:
        for fid in post["fact_ids"]:
            assert fid in valid_fact_ids, (
                f"post {post['post_id']!r} 引用了不存在的 fact_id: {fid!r}"
            )


# ---------------------------------------------------------------------------
# Test 8: key_points 必须存在于 key_points.json
# ---------------------------------------------------------------------------

def test_key_points_valid(source_root):
    plan_posts(source_root)
    with open(os.path.join(source_root, "extracted", "key_points.json"), encoding="utf-8") as f:
        kp_titles = {k["title"] for k in json.load(f)["key_points"]}

    with open(os.path.join(source_root, "extracted", "post_plan.json"), encoding="utf-8") as f:
        data = json.load(f)

    for post in data["posts"]:
        for kp in post["key_points"]:
            assert kp in kp_titles, (
                f"post {post['post_id']!r} 引用了不存在的 key_point: {kp!r}"
            )


# ---------------------------------------------------------------------------
# Test 9: image_frames 必须存在于 frame_observations
# ---------------------------------------------------------------------------

def test_image_frames_valid(source_root):
    plan_posts(source_root)
    with open(os.path.join(source_root, "extracted", "frame_observations.json"), encoding="utf-8") as f:
        valid_ids = {o["frame_id"] for o in json.load(f)["observations"]}

    with open(os.path.join(source_root, "extracted", "post_plan.json"), encoding="utf-8") as f:
        data = json.load(f)

    for post in data["posts"]:
        assert len(post["image_frames"]) >= 2, (
            f"post {post['post_id']!r} image_frames 少于 2 个"
        )
        for fid in post["image_frames"]:
            assert fid in valid_ids, (
                f"post {post['post_id']!r} image_frame {fid} 不在 frame_observations 中"
            )


# ---------------------------------------------------------------------------
# Test 10: 缺少输入文件时报错
# ---------------------------------------------------------------------------

def test_missing_content_facts_raises(source_root_no_facts):
    with pytest.raises(PostPlanningError) as exc_info:
        plan_posts(source_root_no_facts)
    assert "content_facts.json" in str(exc_info.value)


def test_missing_key_points_raises(source_root_no_kp):
    with pytest.raises(PostPlanningError) as exc_info:
        plan_posts(source_root_no_kp)
    assert "key_points.json" in str(exc_info.value)


def test_missing_observations_raises(source_root_no_obs):
    with pytest.raises(PostPlanningError) as exc_info:
        plan_posts(source_root_no_obs)
    assert "frame_observations.json" in str(exc_info.value)
