"""
tests/test_post_writing.py

Article Writing Layer 单元测试

覆盖：
  1.  markdown 文件存在
  2.  metadata 文件存在
  3.  标题正确
  4.  word_count 存在且在合理范围
  5.  used_facts 有效（来自 content_facts）
  6.  used_frames 有效（来自 frame_observations）
  7.  没有引用其他 post 专属的 frames
  8.  文章长度符合范围（800-1200 中文字）
  9.  缺少 contract 时失败
  10. markdown 结构正确（含标题行）
"""

import json
import os
import re
import pytest

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

SOURCE_ROOT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "sources", "bilibili", "ysjf", "space_camera_project"
)

POST_MD   = os.path.join(SOURCE_ROOT, "posts", "post_001.md")
POST_META = os.path.join(SOURCE_ROOT, "posts", "post_001_metadata.json")
CONTRACT  = os.path.join(SOURCE_ROOT, "extracted", "article_generation_contract.json")
FACTS     = os.path.join(SOURCE_ROOT, "extracted", "content_facts.json")
OBS       = os.path.join(SOURCE_ROOT, "extracted", "frame_observations.json")


# ---------------------------------------------------------------------------
# 跳过条件
# ---------------------------------------------------------------------------

skip_if_no_md = pytest.mark.skipif(
    not os.path.isfile(POST_MD),
    reason="post_001.md 不存在，跳过集成测试"
)
skip_if_no_meta = pytest.mark.skipif(
    not os.path.isfile(POST_META),
    reason="post_001_metadata.json 不存在"
)


def count_chinese(text: str) -> int:
    return len(re.findall(r'[\u4e00-\u9fff]', text))


# ---------------------------------------------------------------------------
# Test 1: markdown 文件存在
# ---------------------------------------------------------------------------

@skip_if_no_md
def test_markdown_file_exists():
    assert os.path.isfile(POST_MD)


# ---------------------------------------------------------------------------
# Test 2: metadata 文件存在
# ---------------------------------------------------------------------------

@skip_if_no_meta
def test_metadata_file_exists():
    assert os.path.isfile(POST_META)


# ---------------------------------------------------------------------------
# Test 3: 标题正确
# ---------------------------------------------------------------------------

@skip_if_no_md
def test_title_correct():
    with open(POST_MD, encoding="utf-8") as f:
        content = f.read()
    assert "把相机送上天" in content, "文章标题应包含 '把相机送上天'"
    # 第一行应是 H1 标题
    first_line = content.strip().split("\n")[0]
    assert first_line.startswith("#"), f"文章首行应为 H1 标题，实际: {first_line!r}"


# ---------------------------------------------------------------------------
# Test 4: word_count 存在且合理
# ---------------------------------------------------------------------------

@skip_if_no_meta
def test_word_count_exists():
    with open(POST_META, encoding="utf-8") as f:
        meta = json.load(f)
    assert "word_count" in meta, "metadata 缺少 word_count"
    assert isinstance(meta["word_count"], int) and meta["word_count"] > 0


# ---------------------------------------------------------------------------
# Test 5: used_facts 有效
# ---------------------------------------------------------------------------

@skip_if_no_meta
def test_used_facts_valid():
    with open(POST_META, encoding="utf-8") as f:
        meta = json.load(f)
    with open(FACTS, encoding="utf-8") as f:
        valid_ids = {f"fact_{i}" for i in range(len(json.load(f)["facts"]))}

    assert "used_facts" in meta and isinstance(meta["used_facts"], list)
    for fid in meta["used_facts"]:
        assert fid in valid_ids, f"used_facts 中存在无效 fact_id: {fid!r}"


# ---------------------------------------------------------------------------
# Test 6: used_frames 有效
# ---------------------------------------------------------------------------

@skip_if_no_meta
def test_used_frames_valid():
    with open(POST_META, encoding="utf-8") as f:
        meta = json.load(f)
    with open(OBS, encoding="utf-8") as f:
        valid_ids = {o["frame_id"] for o in json.load(f)["observations"]}

    assert "used_frames" in meta and isinstance(meta["used_frames"], list)
    for fid in meta["used_frames"]:
        assert fid in valid_ids, f"used_frames 中存在无效 frame_id: {fid}"


# ---------------------------------------------------------------------------
# Test 7: 没有引用 post_002/post_003 专属的 frames
# ---------------------------------------------------------------------------

@skip_if_no_meta
def test_no_other_post_frames():
    """
    post_001 专属帧: [1, 6, 10, 11]（t=0–160s）
    post_002 专属帧: [21, 26, 36, 44, 51]（t=200–500s）
    post_003 专属帧: [61, 66, 76, 81]（t=600–800s）
    """
    other_post_frames = {21, 26, 36, 44, 51, 61, 66, 76, 81}
    with open(POST_META, encoding="utf-8") as f:
        meta = json.load(f)
    for fid in meta.get("used_frames", []):
        assert fid not in other_post_frames, (
            f"post_001 引用了属于其他帖子的 frame_id: {fid}"
        )


# ---------------------------------------------------------------------------
# Test 8: 文章长度符合范围 (800-1200 中文字)
# ---------------------------------------------------------------------------

@skip_if_no_md
def test_article_length_in_range():
    with open(POST_MD, encoding="utf-8") as f:
        content = f.read()
    count = count_chinese(content)
    assert 700 <= count <= 1500, (
        f"文章中文字数 {count} 不在合理范围 (700-1500) 内"
    )


# ---------------------------------------------------------------------------
# Test 9: 缺少 contract 时 — 验证 contract 文件存在性
# ---------------------------------------------------------------------------

def test_contract_file_exists():
    """article_generation_contract.json 必须存在才能进行文章生产。"""
    assert os.path.isfile(CONTRACT), (
        "article_generation_contract.json 不存在，无法进行文章生产"
    )


# ---------------------------------------------------------------------------
# Test 10: markdown 结构正确
# ---------------------------------------------------------------------------

@skip_if_no_md
def test_markdown_structure():
    with open(POST_MD, encoding="utf-8") as f:
        content = f.read()

    # 有 H1 标题
    assert re.search(r'^# .+', content, re.MULTILINE), "缺少 H1 标题"

    # 有至少一个 H2 小节
    assert re.search(r'^## .+', content, re.MULTILINE), "缺少 H2 小节"

    # 有图片引用
    assert re.search(r'!\[.*\]\(.*\.jpg\)', content), "缺少图片引用"

    # 图片路径指向 frames 目录
    img_refs = re.findall(r'!\[.*?\]\((.*?)\)', content)
    for ref in img_refs:
        assert "frames" in ref, f"图片路径未指向 frames 目录: {ref!r}"
