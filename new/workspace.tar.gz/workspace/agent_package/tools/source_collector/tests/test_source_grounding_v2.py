"""
tests/test_source_grounding_v2.py

Source Grounding V2 — mechanism-aware pipeline tests

Covers:
  1.  mechanism-heavy source with only object facts → coverage gate FAIL
  2.  critical structural relationship missing → FAIL
  3.  before/after covered but transition missing → recovery required
  4.  adaptive local resampling records interval + reason
  5.  HUMAN_REPORTED cannot become VISUALLY_CONFIRMED without evidence
  6.  project-specific fact must not appear in global rule text
  7.  upstream semantic change triggers downstream invalidation
  8.  complete evidence grounding → PASS
  9.  entity identity merge without SAME_ENTITY evidence → FAIL
  10. visual-scale-dependent content without scale evidence → FAIL
  11. interview/narration frame correctly classified (not altitude)
"""

import json
import os
import sys
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

SOURCE_ROOT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "sources", "bilibili", "ysjf", "space_camera_project"
)

RULES_PATH         = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "contracts", "source_grounding_rules_v2.json")
FACTS_V2_PATH      = os.path.join(SOURCE_ROOT, "extracted", "mechanism_facts_v2.json")
ANCHORS_V2_PATH    = os.path.join(SOURCE_ROOT, "posts", "shared_visual_anchors_v2.json")
SCALE_PATH         = os.path.join(SOURCE_ROOT, "extracted", "visual_scale_constraints_v2.json")
AUDIT_PATH         = os.path.join(SOURCE_ROOT, "validation", "source_mechanism_evidence_audit.json")
MEF_META_PATH      = os.path.join(SOURCE_ROOT, "extracted", "mechanism_evidence_frame_metadata.json")
OBS_V2_PATH        = os.path.join(SOURCE_ROOT, "extracted", "mechanism_observations_v2.json")
DELTAS_V2_PATH     = os.path.join(SOURCE_ROOT, "extracted", "keyframe_state_deltas_v2.json")
CAP_V2_PATH        = os.path.join(SOURCE_ROOT, "capture_system_v2.json")
DOWNSTREAM_PATH    = os.path.join(SOURCE_ROOT, "validation", "downstream_invalidation_v2.json")


def _load(path):
    with open(os.path.normpath(path), encoding="utf-8") as f:
        return json.load(f)


# ---------------------------------------------------------------------------
# Test 1: mechanism-heavy source with only object facts → coverage gate FAIL
# ---------------------------------------------------------------------------

def test_mechanism_facts_missing_triggers_gate_fail():
    """Simulate: source has physical system, pipeline only has scene/object facts, no mechanism facts."""
    rules = _load(RULES_PATH)
    sg1 = next(r for r in rules["rules"] if r["rule_id"] == "SG1")

    # SG1 must define a gate behavior that halts on missing mechanism facts
    assert "MECHANISM_FACTS_MISSING" in sg1["gate_behavior"]
    assert "halt" in sg1["gate_behavior"].lower() or "stop" in sg1["gate_behavior"].lower() or "do not proceed" in sg1["gate_behavior"].lower()

    # Simulate: source involves a device (trigger condition met) but no mechanism facts
    source_involves_device = True
    mechanism_facts_present = False
    gate_result = "PASS" if (not source_involves_device or mechanism_facts_present) else "MECHANISM_FACTS_MISSING"
    assert gate_result == "MECHANISM_FACTS_MISSING"


# ---------------------------------------------------------------------------
# Test 2: critical structural relationship missing → FAIL
# ---------------------------------------------------------------------------

def test_missing_structural_relationship_fails():
    """Confirm SG2 requires relationship extraction, not just object lists."""
    rules = _load(RULES_PATH)
    sg2 = next(r for r in rules["rules"] if r["rule_id"] == "SG2")

    assert "suspended_from" in sg2["required_relationship_types"]
    assert "RELATIONSHIP_EXTRACTION_INCOMPLETE" in sg2["gate_behavior"]

    # V2 mechanism facts must have structural_relationships
    facts = _load(FACTS_V2_PATH)
    assert len(facts["structural_relationships"]) > 0, "mechanism_facts_v2 must contain structural_relationships"

    # All confirmed facts must have evidence refs
    for rel in facts["structural_relationships"]:
        if rel["status"] == "VISUALLY_CONFIRMED":
            assert len(rel["evidence_frame_refs"]) > 0, f"Confirmed relationship {rel['rel_id']} must have evidence_frame_refs"


# ---------------------------------------------------------------------------
# Test 3: before/after covered but transition missing → recovery required
# ---------------------------------------------------------------------------

def test_transition_gap_triggers_recovery():
    """SG3 requires before/transition/after coverage. Missing transition → TRANSITION_EVIDENCE_GAP."""
    rules = _load(RULES_PATH)
    sg3 = next(r for r in rules["rules"] if r["rule_id"] == "SG3")
    assert "TRANSITION_EVIDENCE_GAP" in sg3["gate_behavior"]

    # V2 deltas must include the STATE_002→STATE_003 separation transition
    deltas = _load(DELTAS_V2_PATH)
    post_ids = [p["post_id"] for p in deltas["posts"]]
    assert "post_002_to_003_bridge" in post_ids, \
        "keyframe_state_deltas_v2 must include the separation transition bridge"

    bridge = next(p for p in deltas["posts"] if p["post_id"] == "post_002_to_003_bridge")
    assert len(bridge["transitions"]) > 0
    # Transition must cover separation event
    change_objects = [c["object"] for t in bridge["transitions"] for c in t["changes"]]
    assert "overhead_structure" in change_objects or "separation_event" in change_objects


# ---------------------------------------------------------------------------
# Test 4: adaptive local resampling records interval + reason
# ---------------------------------------------------------------------------

def test_adaptive_resampling_records_metadata():
    """Mechanism evidence frame metadata must record selection rationale, not just filenames."""
    mef = _load(MEF_META_PATH)
    assert "selection_rationale" in mef
    assert len(mef["selection_rationale"]) > 0
    assert "adaptive_densification_required" in mef

    for frame in mef["frames"]:
        assert "mechanism_window" in frame, f"Frame {frame['frame_id']} must declare mechanism_window"
        assert "evidence_category" in frame, f"Frame {frame['frame_id']} must declare evidence_category"
        assert "key_finding" in frame, f"Frame {frame['frame_id']} must have key_finding"


# ---------------------------------------------------------------------------
# Test 5: HUMAN_REPORTED cannot become VISUALLY_CONFIRMED without evidence
# ---------------------------------------------------------------------------

def test_human_reported_not_promoted_without_evidence():
    """SG9 requires evidence_status separation. HUMAN_REPORTED claims must not enter as CONFIRMED."""
    rules = _load(RULES_PATH)
    sg9 = next(r for r in rules["rules"] if r["rule_id"] == "SG9")
    status_keys = [s.split(":")[0].strip() for s in sg9["status_values"]]
    assert "HUMAN_REPORTED" in status_keys
    assert "VISUALLY_CONFIRMED" in status_keys

    # In mechanism_facts_v2, uncertain_mechanisms must not have status=VISUALLY_CONFIRMED
    facts = _load(FACTS_V2_PATH)
    for um in facts.get("uncertain_mechanisms", []):
        assert um["status"] != "VISUALLY_CONFIRMED", \
            f"Uncertain mechanism {um['uncertainty_id']} must not be VISUALLY_CONFIRMED"

    # HR-03 (lifecycle with partial confirmation) must not be fully confirmed
    audit = _load(AUDIT_PATH)
    hr03 = next(c for c in audit["claims"] if c["claim_id"] == "HR-03")
    assert hr03["evidence_status"] == "PARTIALLY_CONFIRMED"


# ---------------------------------------------------------------------------
# Test 6: project-specific fact must not appear in global rule text
# ---------------------------------------------------------------------------

def test_project_facts_do_not_leak_into_global_rules():
    """SG rules must contain no project-specific content."""
    rules = _load(RULES_PATH)
    forbidden = rules.get("forbidden_content", [])
    assert len(forbidden) > 0, "Global rules must declare forbidden_content list"

    rules_text = json.dumps(rules["rules"]).lower()
    for term in forbidden:
        assert term.lower() not in rules_text, \
            f"Project-specific term '{term}' found in global rules text"


# ---------------------------------------------------------------------------
# Test 7: upstream semantic change triggers downstream invalidation
# ---------------------------------------------------------------------------

def test_upstream_change_triggers_downstream_invalidation():
    """shared_visual_anchors_v2 must declare downstream_invalidated_artifacts."""
    anchors_v2 = _load(ANCHORS_V2_PATH)
    assert "downstream_invalidated_artifacts" in anchors_v2
    invalidated = anchors_v2["downstream_invalidated_artifacts"]
    assert len(invalidated) > 0

    # global_v1 images must be in invalidated list
    assert any("global_v1" in item for item in invalidated), \
        "global_v1 images must be listed as downstream_invalidated_artifacts"


# ---------------------------------------------------------------------------
# Test 8: complete evidence grounding → PASS
# ---------------------------------------------------------------------------

def test_complete_evidence_grounding_passes():
    """All VISUALLY_CONFIRMED facts in mechanism_facts_v2 must have non-empty evidence_frame_refs."""
    facts = _load(FACTS_V2_PATH)

    for entity in facts["entities"]:
        if entity["status"] == "VISUALLY_CONFIRMED":
            assert len(entity["evidence_frame_refs"]) > 0, \
                f"Entity {entity['entity_id']} VISUALLY_CONFIRMED but has no evidence_frame_refs"

    for rel in facts["structural_relationships"]:
        if rel["status"] == "VISUALLY_CONFIRMED":
            assert len(rel["evidence_frame_refs"]) > 0, \
                f"Relationship {rel['rel_id']} VISUALLY_CONFIRMED but has no evidence_frame_refs"

    for mech in facts["mechanisms"]:
        if mech["status"] == "VISUALLY_CONFIRMED":
            assert len(mech["evidence_frame_refs"]) > 0, \
                f"Mechanism {mech['mech_id']} VISUALLY_CONFIRMED but has no evidence_frame_refs"

    for cs in facts["capture_system_facts"]:
        if cs["status"] == "VISUALLY_CONFIRMED":
            assert len(cs["evidence_frame_refs"]) > 0, \
                f"Capture fact {cs['fact_id']} VISUALLY_CONFIRMED but has no evidence_frame_refs"


# ---------------------------------------------------------------------------
# Test 9: entity identity merge without SAME_ENTITY evidence → FAIL
# ---------------------------------------------------------------------------

def test_entity_identity_merge_requires_evidence():
    """SG8 requires SAME_ENTITY determination before merging. V2 anchors must not merge balloon+parachute."""
    rules = _load(RULES_PATH)
    sg8 = next(r for r in rules["rules"] if r["rule_id"] == "SG8")
    assert "ENTITY_IDENTITY_MERGE_UNSUPPORTED" in sg8["gate_behavior"]

    # V2 anchors must have SEPARATE anchors for balloon_cluster and parachute
    anchors_v2 = _load(ANCHORS_V2_PATH)
    anchor_ids = list(anchors_v2["anchors"].keys())
    assert "balloon_cluster_anchor" in anchor_ids, "balloon_cluster must be a separate anchor"
    assert "parachute_anchor" in anchor_ids, "parachute must be a separate anchor — distinct entity from balloon"

    # They must not share entity_id
    balloon_eid = anchors_v2["anchors"]["balloon_cluster_anchor"]["entity_id"]
    parachute_eid = anchors_v2["anchors"]["parachute_anchor"]["entity_id"]
    assert balloon_eid != parachute_eid, "balloon_cluster and parachute must have different entity_ids"


# ---------------------------------------------------------------------------
# Test 10: visual-scale-dependent content without scale evidence → FAIL
# ---------------------------------------------------------------------------

def test_visual_scale_without_evidence_fails():
    """SG7 requires visual_scale_constraints backed by reference frames."""
    rules = _load(RULES_PATH)
    sg7 = next(r for r in rules["rules"] if r["rule_id"] == "SG7")
    assert "VISUAL_SCALE_EVIDENCE_MISSING" in sg7["gate_behavior"]

    scale = _load(SCALE_PATH)
    assert len(scale["constraints"]) > 0

    # Peak altitude constraint must have reference frames
    peak = next((c for c in scale["constraints"] if "peak" in c["constraint_id"].lower()), None)
    assert peak is not None, "visual_scale_constraints_v2 must include a peak altitude entry"
    assert len(peak["reference_frames"]) > 0, "Peak altitude scale constraint must have reference_frames"
    assert "forbidden_compositions" in peak, "Peak altitude must list forbidden_compositions"
    assert any("orbital" in f.lower() or "small sphere" in f.lower() for f in peak["forbidden_compositions"]), \
        "Peak constraint must forbid orbital/small-sphere composition"


# ---------------------------------------------------------------------------
# Test 11: interview/narration frame correctly classified
# ---------------------------------------------------------------------------

def test_interview_frame_not_classified_as_altitude():
    """frame_36 (t=350s) must be classified as interview_narration, not altitude footage."""
    obs = _load(OBS_V2_PATH)

    mef_007 = next((o for o in obs["observations"] if o["frame_id"] == "mef_007"), None)
    assert mef_007 is not None, "mef_007 (frame_36 t=350s) must be in mechanism_observations_v2"
    assert mef_007["content_type"] == "interview_narration", \
        "frame_36 must be classified as interview_narration, not altitude footage"
    assert "mislabel_correction" in mef_007, "mef_007 must document the V1 mislabel correction"
    assert "interview" in mef_007["mislabel_correction"]["correct_label"].lower()

    # capture_system_v2 must acknowledge intercut content types
    cap = _load(CAP_V2_PATH)
    ctc = cap["capture_system"].get("content_type_classification", {})
    assert "interview_narration" in ctc, "capture_system_v2 must classify interview_narration content type"
