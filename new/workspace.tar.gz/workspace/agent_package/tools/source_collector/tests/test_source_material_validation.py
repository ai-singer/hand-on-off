"""
tests/test_source_material_validation.py

Raw Material Contract Validation for:
  sources/bilibili/ysjf/space_camera_project/

Tests:
  1. metadata/source.json 文件存在
  2. source.json schema 字段完整
  3. raw video 文件存在（根据 raw_file 字段定位）
  4. source status 可以转换为 READY_FOR_EXTRACTION

不涉及：视频解析、ASR、LLM、内容生成。
"""

import json
import os
import pytest

# 项目根目录（source_collector/）
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 测试目标目录
SOURCE_ROOT = os.path.join(BASE_DIR, "sources", "bilibili", "ysjf", "space_camera_project")
METADATA_FILE = os.path.join(SOURCE_ROOT, "metadata", "source.json")

# source.json 必须包含的字段
REQUIRED_FIELDS = [
    "source_id",
    "platform",
    "creator",
    "title",
    "source_type",
    "raw_file",
]

# 允许进入 READY_FOR_EXTRACTION 的前置状态
VALID_PRECONDITION_STATUSES = {"RAW", "COLLECTED"}

# 已完成转换的状态
VALID_TERMINAL_STATUSES = {"READY_FOR_EXTRACTION", "EXTRACTED", "VERIFIED"}


def load_metadata() -> dict:
    """加载并解析 source.json，供多个测试复用。"""
    with open(METADATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


# ---------------------------------------------------------------------------
# Test 1: metadata 文件存在
# ---------------------------------------------------------------------------

def test_metadata_file_exists():
    """metadata/source.json 必须存在。"""
    assert os.path.isfile(METADATA_FILE), (
        f"metadata 文件不存在: {METADATA_FILE}"
    )


# ---------------------------------------------------------------------------
# Test 2: source.json schema 字段完整
# ---------------------------------------------------------------------------

def test_source_json_schema():
    """source.json 必须包含所有必填字段，且值不为空。"""
    data = load_metadata()
    missing = [field for field in REQUIRED_FIELDS if not data.get(field)]
    assert not missing, (
        f"source.json 缺少必填字段或值为空: {missing}"
    )


# ---------------------------------------------------------------------------
# Test 3: raw video 文件存在
# ---------------------------------------------------------------------------

def test_raw_video_file_exists():
    """根据 source.json 中的 raw_file 字段定位视频文件，文件必须存在。"""
    data = load_metadata()
    raw_file_rel = data.get("raw_file")
    assert raw_file_rel, "source.json 中 raw_file 字段为空"

    raw_file_abs = os.path.join(SOURCE_ROOT, raw_file_rel)
    assert os.path.isfile(raw_file_abs), (
        f"raw video 文件不存在: {raw_file_abs}  (raw_file={raw_file_rel!r})"
    )


# ---------------------------------------------------------------------------
# Test 4: status 可以进入 READY_FOR_EXTRACTION
# ---------------------------------------------------------------------------

def test_status_transition_to_ready_for_extraction():
    """
    source status 必须满足以下条件之一：
    1. 处于有效前置状态（RAW | COLLECTED），可以转换为 READY_FOR_EXTRACTION
    2. 已经是 READY_FOR_EXTRACTION 或更终态（已完成转换）
    """
    data = load_metadata()
    current_status = data.get("status", "")
    is_precondition = current_status in VALID_PRECONDITION_STATUSES
    is_terminal = current_status in VALID_TERMINAL_STATUSES
    assert is_precondition or is_terminal, (
        f"status={current_status!r} 不是有效的前置状态或终态。"
        f"前置状态: {VALID_PRECONDITION_STATUSES}，"
        f"终态: {VALID_TERMINAL_STATUSES}"
    )
    # 确认可达性：前置状态可转换，终态已完成
    if is_precondition:
        assert "READY_FOR_EXTRACTION" == "READY_FOR_EXTRACTION"
    if is_terminal:
        assert current_status in VALID_TERMINAL_STATUSES
