"""
tests/test_vision_progress.py

Vision Analysis Progress Tracking 单元测试

覆盖：
  1.  progress 文件初始化
  2.  status 初始值为 running
  3.  completed_frames 正确递增
  4.  current_frame_id 更新
  5.  单帧结果文件生成
  6.  merge 正确生成 frame_observations.json
  7.  中途失败不丢失已完成结果
  8.  缺失必填字段时 save_frame_result 报错
  9.  completed_frame_ids 返回正确集合
  10. init_progress 幂等：completed 状态不被重置
  11. update_progress 错误字段追加
  12. merge 结果按 frame_id 升序
"""

import json
import os
import pytest

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.vision_progress import (
    init_progress,
    update_progress,
    save_frame_result,
    merge_results,
    completed_frame_ids,
    read_progress,
    VisionProgressError,
    STATUS_RUNNING,
    STATUS_COMPLETED,
    STATUS_FAILED,
    progress_path,
    results_dir,
    observations_path,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_source_root(tmp_path, with_source_json=True):
    if with_source_json:
        (tmp_path / "metadata").mkdir()
        (tmp_path / "metadata" / "source.json").write_text(json.dumps({
            "source_id": "test_progress_001",
        }), encoding="utf-8")
    return str(tmp_path)


def make_frame_result(frame_id: int, timestamp: float = 0.0) -> dict:
    return {
        "frame_id": frame_id,
        "filename": f"frame_{frame_id:06d}_00000000ms.jpg",
        "timestamp_sec": timestamp,
        "objects": ["气球", "雪地"],
        "scene": "户外雪地",
        "observable_facts": ["画面中存在白色气球"],
        "uncertain_points": ["无法确认地点"],
    }


# ---------------------------------------------------------------------------
# Test 1: progress 文件初始化
# ---------------------------------------------------------------------------

def test_init_creates_progress_file(tmp_path):
    root = make_source_root(tmp_path)
    init_progress(root, total_frames=22)
    path = progress_path(root)
    assert os.path.isfile(path), "vision_progress.json 未生成"
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    assert data["total_frames"] == 22
    assert data["task"] == "frame_vision_analysis"
    assert "started_at" in data
    assert "last_update" in data


# ---------------------------------------------------------------------------
# Test 2: status 初始值为 running
# ---------------------------------------------------------------------------

def test_init_status_is_running(tmp_path):
    root = make_source_root(tmp_path)
    progress = init_progress(root, total_frames=5)
    assert progress["status"] == STATUS_RUNNING
    assert progress["completed_frames"] == 0
    assert progress["current_frame_id"] is None


# ---------------------------------------------------------------------------
# Test 3: completed_frames 正确递增
# ---------------------------------------------------------------------------

def test_completed_frames_increments(tmp_path):
    root = make_source_root(tmp_path)
    init_progress(root, total_frames=5)
    update_progress(root, increment_completed=True)
    update_progress(root, increment_completed=True)
    progress = read_progress(root)
    assert progress["completed_frames"] == 2


# ---------------------------------------------------------------------------
# Test 4: current_frame_id 更新
# ---------------------------------------------------------------------------

def test_current_frame_id_updates(tmp_path):
    root = make_source_root(tmp_path)
    init_progress(root, total_frames=5)
    update_progress(root, current_frame_id=6)
    progress = read_progress(root)
    assert progress["current_frame_id"] == 6
    update_progress(root, current_frame_id=11)
    progress = read_progress(root)
    assert progress["current_frame_id"] == 11


# ---------------------------------------------------------------------------
# Test 5: 单帧结果文件生成
# ---------------------------------------------------------------------------

def test_save_frame_result_creates_file(tmp_path):
    root = make_source_root(tmp_path)
    init_progress(root, total_frames=3)
    fr = make_frame_result(frame_id=1, timestamp=0.0)
    path = save_frame_result(root, fr)
    assert os.path.isfile(path), f"帧结果文件未生成: {path}"
    with open(path, encoding="utf-8") as f:
        saved = json.load(f)
    assert saved["frame_id"] == 1
    assert saved["objects"] == ["气球", "雪地"]
    assert saved["scene"] == "户外雪地"


# ---------------------------------------------------------------------------
# Test 6: merge 正确生成 frame_observations.json
# ---------------------------------------------------------------------------

def test_merge_generates_observations(tmp_path):
    root = make_source_root(tmp_path)
    init_progress(root, total_frames=3)
    for i, (fid, ts) in enumerate([(1, 0.0), (6, 50.0), (11, 100.0)]):
        save_frame_result(root, make_frame_result(fid, ts))

    result = merge_results(root, source_id="test_progress_001")
    out_path = observations_path(root)
    assert os.path.isfile(out_path)
    assert result["source_id"] == "test_progress_001"
    assert result["backend_used"] == "openclaw_vision"
    assert result["total_frames"] == 3
    assert len(result["observations"]) == 3


# ---------------------------------------------------------------------------
# Test 7: 中途失败不丢失已完成结果
# ---------------------------------------------------------------------------

def test_partial_results_survive_failure(tmp_path):
    root = make_source_root(tmp_path)
    init_progress(root, total_frames=5)

    # 保存前3帧
    for fid, ts in [(1, 0.0), (6, 50.0), (11, 100.0)]:
        save_frame_result(root, make_frame_result(fid, ts))

    # 模拟失败：更新 status=failed
    update_progress(root, status=STATUS_FAILED, error="模拟中途失败")

    # 验证已保存的3帧文件还在
    ids = completed_frame_ids(root)
    assert ids == {1, 6, 11}, f"已完成帧丢失: {ids}"

    # 恢复：重新 init，status 应变回 running
    progress = init_progress(root, total_frames=5)
    assert progress["status"] == STATUS_RUNNING

    # 能正常 merge 已有结果
    result = merge_results(root, source_id="test_progress_001")
    assert result["total_frames"] == 3


# ---------------------------------------------------------------------------
# Test 8: save_frame_result 缺失必填字段时报错
# ---------------------------------------------------------------------------

def test_save_frame_result_missing_field(tmp_path):
    root = make_source_root(tmp_path)
    init_progress(root, total_frames=1)
    incomplete = {
        "frame_id": 1,
        "filename": "frame_000001.jpg",
        # 缺少 timestamp_sec, objects, scene, observable_facts, uncertain_points
    }
    with pytest.raises(VisionProgressError):
        save_frame_result(root, incomplete)


# ---------------------------------------------------------------------------
# Test 9: completed_frame_ids 返回正确集合
# ---------------------------------------------------------------------------

def test_completed_frame_ids(tmp_path):
    root = make_source_root(tmp_path)
    init_progress(root, total_frames=5)
    save_frame_result(root, make_frame_result(1, 0.0))
    save_frame_result(root, make_frame_result(6, 50.0))
    ids = completed_frame_ids(root)
    assert ids == {1, 6}


# ---------------------------------------------------------------------------
# Test 10: init_progress 幂等：completed 状态不被重置
# ---------------------------------------------------------------------------

def test_init_idempotent_when_completed(tmp_path):
    root = make_source_root(tmp_path)
    init_progress(root, total_frames=3)
    update_progress(root, status=STATUS_COMPLETED)
    # 再次 init，不应重置
    progress = init_progress(root, total_frames=3)
    assert progress["status"] == STATUS_COMPLETED, (
        "completed 状态不应被 init_progress 重置"
    )


# ---------------------------------------------------------------------------
# Test 11: update_progress 错误字段追加
# ---------------------------------------------------------------------------

def test_update_progress_error_append(tmp_path):
    root = make_source_root(tmp_path)
    init_progress(root, total_frames=5)
    update_progress(root, error="第一个错误")
    update_progress(root, error="第二个错误")
    progress = read_progress(root)
    assert len(progress["errors"]) == 2
    messages = [e["message"] for e in progress["errors"]]
    assert "第一个错误" in messages
    assert "第二个错误" in messages


# ---------------------------------------------------------------------------
# Test 12: merge 结果按 frame_id 升序
# ---------------------------------------------------------------------------

def test_merge_results_sorted_by_frame_id(tmp_path):
    root = make_source_root(tmp_path)
    init_progress(root, total_frames=3)
    # 故意乱序写入
    save_frame_result(root, make_frame_result(11, 100.0))
    save_frame_result(root, make_frame_result(1, 0.0))
    save_frame_result(root, make_frame_result(6, 50.0))

    result = merge_results(root, source_id="test_progress_001")
    frame_ids = [o["frame_id"] for o in result["observations"]]
    assert frame_ids == sorted(frame_ids), f"observations 未按 frame_id 升序: {frame_ids}"
