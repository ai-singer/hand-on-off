"""
tests/test_visual_generation_rules.py

VISUAL_GENERATION_RULES_V1 contract 测试

覆盖：
  1.  invented_text=true → cannot PASS
  2.  watermark/UI=true → cannot PASS
  3.  unsupported_salient_object=true → cannot PASS
  4.  unsupported_identity_marker=true → cannot PASS
  5.  structural_relationship_consistent=false → cannot PASS
  6.  all single images PASS but cross-image fails → group cannot PASS
  7.  same_team_inconsistency → group cannot PASS
  8.  targeted repair preserves unrelated PASS images
  9.  repair metadata fields are recorded
  10. frozen visual group cannot be silently overwritten
  11. source-frame hash difference alone cannot cause PASS
  12. team anchor required for same-team multi-image condition
"""

import json
import os
import sys
import hashlib
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

RULES_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "contracts", "visual_generation_rules.json"
)
IMG_META_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "sources", "bilibili", "ysjf", "space_camera_project",
    "posts", "post_001_image_generation.json"
)
IMG_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "sources", "bilibili", "ysjf", "space_camera_project",
    "posts", "images", "post_001"
)


# ---------------------------------------------------------------------------
# Helper: gate logic that enforces all rules
# ---------------------------------------------------------------------------

def _single_image_passes(img: dict) -> bool:
    """Return True only if all single-image rule fields are correct."""
    # Both field names must be False (neither True)
    if img.get("invented_text") is True:
        return False
    if img.get("invented_text_or_logo") is True:
        return False
    checks = [
        img.get("watermark_or_platform_ui") is not True,
        img.get("unsupported_salient_object") is not True,
        img.get("unsupported_identity_marker") is not True,
        img.get("unsupported_salient_object_or_structure") is not True,
        img.get("major_visual_artifact") is not True,
        img.get("structural_relationship_consistent") is not False,
        img.get("generation_success", False) is True,
    ]
    return all(checks)


def _group_passes(images: list, group_meta: dict) -> bool:
    """Return True only if all single images pass AND all group checks pass."""
    for img in images:
        if not _single_image_passes(img):
            return False
    if group_meta.get("same_team_consistency") is False:
        return False
    if group_meta.get("scene_consistency") is False:
        return False
    if group_meta.get("equipment_continuity") is False:
        return False
    return True


def _make_img(overrides: dict) -> dict:
    """Create a minimal passing image metadata dict with overrides."""
    base = {
        "visual_id": "test_img",
        "generation_success": True,
        "invented_text_or_logo": False,
        "invented_text": False,
        "watermark_or_platform_ui": False,
        "unsupported_salient_object": False,
        "unsupported_salient_object_or_structure": False,
        "unsupported_identity_marker": False,
        "major_visual_artifact": False,
        "structural_relationship_consistent": True,
        "fact_consistency": True,
        "direct_source_frame_reuse": False,
    }
    base.update(overrides)
    return base


def _make_group(overrides: dict) -> dict:
    base = {
        "same_team_consistency": True,
        "scene_consistency": True,
        "equipment_continuity": True,
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# Test 1: invented_text → cannot PASS
# ---------------------------------------------------------------------------

def test_invented_text_blocks_pass():
    img = _make_img({"invented_text": True})
    assert _single_image_passes(img) is False


# ---------------------------------------------------------------------------
# Test 2: watermark/UI → cannot PASS
# ---------------------------------------------------------------------------

def test_watermark_blocks_pass():
    img = _make_img({"watermark_or_platform_ui": True})
    assert _single_image_passes(img) is False


# ---------------------------------------------------------------------------
# Test 3: unsupported_salient_object → cannot PASS
# ---------------------------------------------------------------------------

def test_unsupported_salient_object_blocks_pass():
    img = _make_img({"unsupported_salient_object": True})
    assert _single_image_passes(img) is False


# ---------------------------------------------------------------------------
# Test 4: unsupported_identity_marker → cannot PASS
# ---------------------------------------------------------------------------

def test_unsupported_identity_marker_blocks_pass():
    img = _make_img({"unsupported_identity_marker": True})
    assert _single_image_passes(img) is False


# ---------------------------------------------------------------------------
# Test 5: structural_relationship_consistent=false → cannot PASS
# ---------------------------------------------------------------------------

def test_structural_inconsistency_blocks_pass():
    img = _make_img({"structural_relationship_consistent": False})
    assert _single_image_passes(img) is False


# ---------------------------------------------------------------------------
# Test 6: individual PASS but cross-image fails → group cannot PASS
# ---------------------------------------------------------------------------

def test_individual_pass_but_cross_image_fails():
    images = [_make_img({}), _make_img({}), _make_img({})]
    group_meta = _make_group({"scene_consistency": False})
    # all individual images pass
    for img in images:
        assert _single_image_passes(img) is True
    # but group should fail
    assert _group_passes(images, group_meta) is False


# ---------------------------------------------------------------------------
# Test 7: same_team_inconsistency → group cannot PASS
# ---------------------------------------------------------------------------

def test_same_team_inconsistency_blocks_group():
    images = [_make_img({}), _make_img({})]
    group_meta = _make_group({"same_team_consistency": False})
    assert _group_passes(images, group_meta) is False


# ---------------------------------------------------------------------------
# Test 8: targeted repair preserves unrelated PASS images
# ---------------------------------------------------------------------------

def test_targeted_repair_preserves_passing_images():
    """Only the failed image should be in changed_images; others in preserved_images."""
    repair_record = {
        "repair_reason": "invented_text on img_01",
        "repair_round": 1,
        "original_problem": "text overlay on equipment box",
        "changed_images": ["post_001_img_01"],
        "preserved_images": ["post_001_img_02", "post_001_img_03"],
        "validation_after_repair": "PASS"
    }
    assert "post_001_img_02" in repair_record["preserved_images"]
    assert "post_001_img_03" in repair_record["preserved_images"]
    assert "post_001_img_01" not in repair_record["preserved_images"]
    assert "post_001_img_01" in repair_record["changed_images"]


# ---------------------------------------------------------------------------
# Test 9: repair metadata fields are recorded
# ---------------------------------------------------------------------------

def test_repair_metadata_fields_present():
    required = ["repair_reason", "repair_round", "original_problem",
                "changed_images", "preserved_images", "validation_after_repair"]
    repair_record = {
        "repair_reason": "test",
        "repair_round": 1,
        "original_problem": "test",
        "changed_images": [],
        "preserved_images": [],
        "validation_after_repair": "PASS"
    }
    for field in required:
        assert field in repair_record, f"repair metadata missing field: {field}"


# ---------------------------------------------------------------------------
# Test 10: frozen group cannot be silently overwritten
# ---------------------------------------------------------------------------

def test_frozen_group_status_is_preserved():
    """Once status=PASS_AND_FROZEN, it should not revert to a non-frozen state."""
    meta = {"status": "PASS_AND_FROZEN", "visual_count": 3}
    # Simulated: a frozen group must not accept status downgrades
    new_status = "IN_PROGRESS"
    assert meta["status"] == "PASS_AND_FROZEN", "Frozen status was unexpectedly changed"
    # Verify the rule contract file defines frozen_protection
    with open(RULES_PATH, encoding="utf-8") as f:
        rules = json.load(f)
    assert "frozen_protection" in rules
    assert rules["frozen_protection"]["frozen_marker_value"] == "PASS_AND_FROZEN"


# ---------------------------------------------------------------------------
# Test 11: source-frame hash difference alone cannot cause PASS
# ---------------------------------------------------------------------------

def test_hash_difference_insufficient_for_pass():
    """An image with different hash from source but invented_text=True should still fail."""
    img = _make_img({
        "direct_source_frame_reuse": False,  # hash check passed
        "invented_text": True,               # but has text
    })
    assert _single_image_passes(img) is False, (
        "Hash difference alone must not be sufficient for PASS when other checks fail"
    )


# ---------------------------------------------------------------------------
# Test 12: team anchor required for same-team multi-image
# ---------------------------------------------------------------------------

def test_team_anchor_spec_required():
    """Rules contract must define team_anchor_mechanism with required fields."""
    with open(RULES_PATH, encoding="utf-8") as f:
        rules = json.load(f)
    assert "team_anchor_mechanism" in rules
    anchor = rules["team_anchor_mechanism"]
    required_fields = [
        "approximate_people_count",
        "clothing_style",
        "clothing_color_palette",
        "gear_type",
    ]
    for field in required_fields:
        assert field in anchor["required_anchor_fields"], (
            f"team_anchor_mechanism missing required field: {field}"
        )


# ---------------------------------------------------------------------------
# Integration: rules contract file is valid
# ---------------------------------------------------------------------------

def test_rules_contract_file_exists():
    assert os.path.isfile(RULES_PATH), f"visual_generation_rules.json 不存在: {RULES_PATH}"


def test_rules_contract_schema():
    with open(RULES_PATH, encoding="utf-8") as f:
        rules = json.load(f)
    required_sections = [
        "contract_version",
        "source_grounding_rules",
        "single_image_rules",
        "structural_rules",
        "cross_image_rules",
        "review_and_gate_rules",
        "image_state_machine",
        "repair_strategy",
        "team_anchor_mechanism",
        "frozen_protection",
    ]
    for section in required_sections:
        assert section in rules, f"rules contract missing section: {section}"


def test_rules_contract_version():
    with open(RULES_PATH, encoding="utf-8") as f:
        rules = json.load(f)
    assert rules["contract_version"] in (
        "VISUAL_GENERATION_RULES_V1",
        "VISUAL_GENERATION_RULES_V1.1",
        "VISUAL_GENERATION_RULES_V1.2",
        "VISUAL_GENERATION_RULES_V1.3",
        "VISUAL_GENERATION_RULES_V1.4",
    ), f"Unexpected contract version: {rules['contract_version']}"
