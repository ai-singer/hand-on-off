"""
tests/test_visual_rules_v11.py

VISUAL_GENERATION_RULES_V1.1 — Temporal Event-State Consistency 测试

覆盖：
  1.  STATE_A → STATE_B → STATE_C (正序) PASS
  2.  STATE_A → STATE_C → STATE_A (乱序) FAIL
  3.  post_001 使用 high_altitude frame → event_state_consistency = False → FAIL
  4.  post_002 使用 launch_preparation 主视觉 → FAIL
  5.  post_003 使用 landing/recovery → PASS
  6.  缺少 event_state_anchor → FAIL
  7.  图片单独 PASS 但时间顺序错误 → 整组 FAIL
  8.  event_state metadata 字段正确保存
"""

import json
import os
import sys
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

RULES_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "contracts", "visual_generation_rules.json"
)
ANCHOR_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "sources", "bilibili", "ysjf", "space_camera_project",
    "posts", "event_state_anchor.json"
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_anchor():
    with open(ANCHOR_PATH, encoding="utf-8") as f:
        return json.load(f)


def _state_order(anchor: dict, state_id: str) -> int:
    for s in anchor["event_states"]:
        if s["state_id"] == state_id:
            return s["state_order"]
    raise ValueError(f"state_id not found: {state_id}")


def _temporal_order_valid(state_sequence: list, anchor: dict) -> bool:
    """Return True if state_sequence is strictly increasing in state_order."""
    orders = [_state_order(anchor, sid) for sid in state_sequence]
    return orders == sorted(set(orders)) and len(orders) == len(set(orders))


def _event_state_consistent(post_id: str, visual_elements: list, anchor: dict) -> bool:
    """
    Check if a list of visual elements is consistent with the post's assigned event state.
    Returns False if any forbidden element phrase substantially matches a visual element.
    Uses phrase-level matching (all words in the forbidden phrase must appear in the element).
    """
    state = next((s for s in anchor["event_states"] if s["post_id"] == post_id), None)
    if state is None:
        return False
    for forbidden in state["forbidden_visual_elements"]:
        forbidden_words = set(forbidden.lower().split())
        # Remove short stop words from matching to avoid false positives
        stop_words = {"or", "as", "a", "an", "the", "of", "in", "at", "on", "and", "is", "to"}
        key_words = forbidden_words - stop_words
        if len(key_words) == 0:
            continue
        for element in visual_elements:
            element_words = set(element.lower().split())
            # Require majority of key_words to match (>=60%)
            matched = len(key_words & element_words)
            if matched >= max(1, len(key_words) * 0.6):
                return False
    return True


def _post_uses_assigned_state(post_id: str, event_state_id: str, anchor: dict) -> bool:
    """Return True if the post_id maps to the given event_state_id in the anchor."""
    state = next((s for s in anchor["event_states"] if s["post_id"] == post_id), None)
    if state is None:
        return False
    return state["state_id"] == event_state_id


# ---------------------------------------------------------------------------
# Test 1: STATE_A → STATE_B → STATE_C (正序) PASS
# ---------------------------------------------------------------------------

def test_correct_temporal_order_passes():
    anchor = _load_anchor()
    sequence = ["STATE_001", "STATE_002", "STATE_003"]
    assert _temporal_order_valid(sequence, anchor) is True


# ---------------------------------------------------------------------------
# Test 2: STATE_A → STATE_C → STATE_A (乱序) FAIL
# ---------------------------------------------------------------------------

def test_reversed_temporal_order_fails():
    anchor = _load_anchor()
    sequence = ["STATE_001", "STATE_003", "STATE_001"]
    assert _temporal_order_valid(sequence, anchor) is False


def test_partial_reverse_order_fails():
    anchor = _load_anchor()
    sequence = ["STATE_002", "STATE_001"]  # backward
    assert _temporal_order_valid(sequence, anchor) is False


# ---------------------------------------------------------------------------
# Test 3: post_001 使用 high_altitude frame → FAIL
# ---------------------------------------------------------------------------

def test_post_001_high_altitude_elements_fail():
    anchor = _load_anchor()
    # earth curvature is a forbidden element for STATE_001 / post_001
    elements = ["earth curvature visible from high altitude", "dark sky background"]
    assert _event_state_consistent("post_001", elements, anchor) is False


# ---------------------------------------------------------------------------
# Test 4: post_002 使用 launch_preparation 主视觉 → FAIL
# ---------------------------------------------------------------------------

def test_post_002_ground_preparation_as_main_fails():
    anchor = _load_anchor()
    elements = ["crew on ground preparing balloon", "snow field balloon inflation"]
    # "crew on ground preparing balloon as main subject" is forbidden for STATE_002
    result = _event_state_consistent("post_002", elements, anchor)
    assert result is False


# ---------------------------------------------------------------------------
# Test 5: post_003 使用 landing/recovery → PASS
# ---------------------------------------------------------------------------

def test_post_003_landing_recovery_passes():
    anchor = _load_anchor()
    elements = ["recovery team on ground inspecting payload", "landed equipment in wilderness"]
    assert _event_state_consistent("post_003", elements, anchor) is True


# ---------------------------------------------------------------------------
# Test 6: 缺少 event_state_anchor → FAIL
# ---------------------------------------------------------------------------

def test_missing_event_state_anchor_fails(tmp_path):
    """If anchor file is missing, event_state_consistent should fail gracefully."""
    fake_anchor_path = str(tmp_path / "nonexistent_anchor.json")
    assert not os.path.exists(fake_anchor_path)
    # Simulate: without anchor, we cannot validate → must fail
    try:
        with open(fake_anchor_path, encoding="utf-8") as f:
            json.load(f)
        loaded = True
    except FileNotFoundError:
        loaded = False
    assert loaded is False, "Missing anchor file must not be silently ignored"


# ---------------------------------------------------------------------------
# Test 7: 图片单独 PASS 但时间顺序错误 → 整组 FAIL
# ---------------------------------------------------------------------------

def test_individual_pass_temporal_fail_blocks_group():
    """Images individually pass all checks but post_002 uses wrong state assignment."""
    anchor = _load_anchor()
    images = [
        {"visual_id": "img_01", "post_id": "post_001", "event_state_id": "STATE_001",
         "generation_success": True, "invented_text_or_logo": False,
         "unsupported_salient_object_or_structure": False, "fact_consistency": True},
        {"visual_id": "img_02", "post_id": "post_002", "event_state_id": "STATE_003",  # wrong: should be STATE_002
         "generation_success": True, "invented_text_or_logo": False,
         "unsupported_salient_object_or_structure": False, "fact_consistency": True},
    ]
    # Each post must use its assigned state, not just any increasing order
    all_assigned_correctly = all(
        _post_uses_assigned_state(img["post_id"], img["event_state_id"], anchor)
        for img in images
    )
    assert all_assigned_correctly is False, "post_002 using STATE_003 must fail assignment check"


# ---------------------------------------------------------------------------
# Test 8: event_state metadata 字段正确保存
# ---------------------------------------------------------------------------

def test_event_state_anchor_schema():
    anchor = _load_anchor()
    assert "source_id" in anchor
    assert "event_states" in anchor
    assert len(anchor["event_states"]) >= 3

    required_fields = [
        "state_id", "state_order", "name", "post_id",
        "time_range", "allowed_visual_elements", "forbidden_visual_elements"
    ]
    for state in anchor["event_states"]:
        for field in required_fields:
            assert field in state, f"event_state {state.get('state_id')} missing field: {field}"
        assert isinstance(state["state_order"], int)
        assert isinstance(state["allowed_visual_elements"], list)
        assert isinstance(state["forbidden_visual_elements"], list)
        assert len(state["allowed_visual_elements"]) > 0
        assert len(state["forbidden_visual_elements"]) > 0


def test_rules_contract_has_temporal_rules():
    with open(RULES_PATH, encoding="utf-8") as f:
        rules = json.load(f)
    assert "temporal_event_state_rules" in rules, "V1.1+ must add temporal_event_state_rules section"
    # event_state_anchor moved to event_state_anchor.json in V1.2+; accept either location
    has_anchor = (
        "event_state_anchor" in rules or
        os.path.isfile(ANCHOR_PATH)
    )
    assert has_anchor, "event_state_anchor must exist either in rules contract or as anchor file"
    assert rules["contract_version"] in (
        "VISUAL_GENERATION_RULES_V1.1",
        "VISUAL_GENERATION_RULES_V1.2",
        "VISUAL_GENERATION_RULES_V1.3",
        "VISUAL_GENERATION_RULES_V1.4",
    )


def test_anchor_cross_post_temporal_order():
    anchor = _load_anchor()
    assert "cross_post_temporal_order" in anchor
    order = anchor["cross_post_temporal_order"]
    assert order["expected_sequence"] == ["STATE_001", "STATE_002", "STATE_003"]
    assert len(order["forbidden_patterns"]) > 0


def test_anchor_state_orders_are_strictly_increasing():
    anchor = _load_anchor()
    orders = [s["state_order"] for s in anchor["event_states"]]
    assert orders == sorted(orders)
    assert len(orders) == len(set(orders)), "state_order values must be unique"
