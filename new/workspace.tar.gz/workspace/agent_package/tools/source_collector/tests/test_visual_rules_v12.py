"""
tests/test_visual_rules_v12.py

VISUAL_GENERATION_RULES_V1.2 — Camera Origin + Platform Reachability + Intra-Post Temporal Order

覆盖：
  1.  external observer view → camera_origin_consistency = False → FAIL
  2.  payload camera view → PASS
  3.  30km balloon view → platform_reachability_consistency = True → PASS
  4.  orbit/satellite view → platform_reachability_consistency = False → FAIL
  5.  post image order correct (t1 < t2 < t3) → PASS
  6.  post image order reversed → FAIL
  7.  deep space background (star field dominant) → altitude_visual_plausibility = False → FAIL
  8.  atmospheric boundary view → altitude_visual_plausibility = True → PASS
"""

import json
import os
import sys
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

RULES_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "contracts", "visual_generation_rules.json"
)
ANCHOR_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "sources", "bilibili", "ysjf", "space_camera_project",
    "posts", "event_state_anchor.json"
)
OBS_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "sources", "bilibili", "ysjf", "space_camera_project",
    "extracted", "frame_observations.json"
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_rules():
    with open(RULES_PATH, encoding="utf-8") as f:
        return json.load(f)


def _check_camera_origin(description: str) -> bool:
    """
    Return True if description is consistent with payload-mounted camera (first-person).
    Return False if it implies an external observer view.
    """
    forbidden_phrases = [
        "external view of balloon",
        "someone photographed a balloon",
        "another aircraft",
        "photographed from outside",
        "satellite tracking balloon",
        "distant observer watching balloon",
        "far away view of balloon",
        "third party camera",
    ]
    desc_lower = description.lower()
    return not any(phrase in desc_lower for phrase in forbidden_phrases)


def _check_platform_reachability(description: str) -> bool:
    """
    Return True if description is consistent with 30km balloon altitude.
    Return False if it implies orbital/spacecraft scale.
    """
    forbidden_phrases = [
        "full earth disk",
        "complete sphere of earth",
        "star field as main background",
        "iss photography",
        "nasa orbital",
        "deep space background",
        "orbital photography",
        "spacecraft view",
        "satellite view of earth",
    ]
    desc_lower = description.lower()
    return not any(phrase in desc_lower for phrase in forbidden_phrases)


def _check_altitude_plausibility(description: str) -> bool:
    """
    Return True if description matches 30km altitude visual signatures.
    Return False if it implies impossible altitude features.
    """
    forbidden_phrases = [
        "full star field primary background",
        "complete absence of atmosphere",
        "stars visible everywhere",
        "deep black starry void",
        "hubble style",
        "no atmosphere layer anywhere",
    ]
    desc_lower = description.lower()
    return not any(phrase in desc_lower for phrase in forbidden_phrases)


def _check_intra_post_temporal_order(frame_timestamps: list) -> bool:
    """Return True if frame timestamps are strictly increasing."""
    return frame_timestamps == sorted(frame_timestamps) and \
           len(frame_timestamps) == len(set(frame_timestamps))


# ---------------------------------------------------------------------------
# Test 1: external observer view → FAIL
# ---------------------------------------------------------------------------

def test_external_observer_view_fails():
    description = "external view of balloon floating in near-space, photographed from outside by another aircraft"
    assert _check_camera_origin(description) is False


# ---------------------------------------------------------------------------
# Test 2: payload camera view → PASS
# ---------------------------------------------------------------------------

def test_payload_camera_view_passes():
    description = "view from payload camera looking down at Earth curvature with thin blue atmosphere layer"
    assert _check_camera_origin(description) is True


# ---------------------------------------------------------------------------
# Test 3: 30km balloon view → PASS
# ---------------------------------------------------------------------------

def test_30km_balloon_view_passes():
    description = "dark blue to near-black sky, Earth curvature visible below, thin blue atmosphere layer, clouds on surface"
    assert _check_platform_reachability(description) is True
    assert _check_altitude_plausibility(description) is True


# ---------------------------------------------------------------------------
# Test 4: orbit/satellite view → FAIL
# ---------------------------------------------------------------------------

def test_orbital_satellite_view_fails():
    description = "satellite view of earth showing complete sphere of earth from orbit, iss photography style"
    assert _check_platform_reachability(description) is False


# ---------------------------------------------------------------------------
# Test 5: post image order correct → PASS
# ---------------------------------------------------------------------------

def test_correct_intra_post_order_passes():
    timestamps = [200.0, 350.0, 500.0]  # t1 < t2 < t3
    assert _check_intra_post_temporal_order(timestamps) is True


# ---------------------------------------------------------------------------
# Test 6: post image order reversed → FAIL
# ---------------------------------------------------------------------------

def test_reversed_intra_post_order_fails():
    timestamps = [500.0, 200.0, 350.0]  # reversed
    assert _check_intra_post_temporal_order(timestamps) is False


def test_partial_reversed_intra_post_order_fails():
    timestamps = [350.0, 200.0, 500.0]  # middle reversed
    assert _check_intra_post_temporal_order(timestamps) is False


# ---------------------------------------------------------------------------
# Test 7: deep space background → FAIL
# ---------------------------------------------------------------------------

def test_deep_space_star_field_fails():
    description = "full star field primary background with no atmosphere layer, deep black starry void"
    assert _check_altitude_plausibility(description) is False


# ---------------------------------------------------------------------------
# Test 8: atmospheric boundary view → PASS
# ---------------------------------------------------------------------------

def test_atmospheric_boundary_view_passes():
    description = "near-space view with thin blue atmosphere layer along Earth edge, dark sky above, clouds below"
    assert _check_altitude_plausibility(description) is True
    assert _check_platform_reachability(description) is True


# ---------------------------------------------------------------------------
# Integration: rules contract contains V1.2 sections
# ---------------------------------------------------------------------------

def test_rules_contract_has_v12_rules():
    rules = _load_rules()
    assert rules["contract_version"] in (
        "VISUAL_GENERATION_RULES_V1.2",
        "VISUAL_GENERATION_RULES_V1.3",
        "VISUAL_GENERATION_RULES_V1.4",
    )
    assert "photography_origin_rules" in rules
    phr = rules["photography_origin_rules"]
    assert "P1_camera_origin_consistency" in phr
    assert "P2_documentary_reconstruction" in phr
    assert "P3_platform_reachability_constraint" in phr
    assert "P4_altitude_visual_plausibility" in phr

    ter = rules["temporal_event_state_rules"]
    assert "C7_intra_post_temporal_order" in ter


def test_rules_contract_c7_field():
    rules = _load_rules()
    c7 = rules["temporal_event_state_rules"]["C7_intra_post_temporal_order"]
    assert c7["check_field"] == "intra_post_temporal_order_consistency"
    assert c7["violation_blocks_pass"] is True


def test_post_002_intra_post_order():
    """post_002 frame refs [21,26] → [31,36] → [41,44]: timestamps must be increasing."""
    with open(OBS_PATH, encoding="utf-8") as f:
        obs = json.load(f)
    obs_map = {o["frame_id"]: o["timestamp_sec"] for o in obs["observations"]}

    # Representative frames per image
    img_frame_groups = [[21, 26], [31, 36], [41, 44]]
    # Use min timestamp per group as image representative
    img_timestamps = [min(obs_map.get(f, 0) for f in group) for group in img_frame_groups]
    assert _check_intra_post_temporal_order(img_timestamps), (
        f"post_002 intra-post temporal order failed: {img_timestamps}"
    )
