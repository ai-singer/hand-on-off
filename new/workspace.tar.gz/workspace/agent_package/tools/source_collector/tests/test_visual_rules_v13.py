"""
tests/test_visual_rules_v13.py

VISUAL_GENERATION_RULES_V1.3 — C8 Keyframe State Transition Fidelity

覆盖：
  1.  state A → state B → state C (correct order)           PASS
  2.  state B → state A (regression)                        FAIL
  3.  subsequent state appears early (previous_state_constraint)  FAIL
  4.  keyframe with no state change from prior               FAIL
  5.  correct keyframe change preserved                      PASS
  6.  transition metadata saved correctly                    PASS
  7.  missing delta artifact                                 FAIL
  8.  delta artifact schema valid                            PASS
  9.  transition anchor schema valid                         PASS
  10. rules contract has V1.3 C8 section                     PASS
  11. post_001 C8 replay                                     PASS
  12. post_002 C8 replay                                     PASS
"""

import json
import os
import sys
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

RULES_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "contracts", "visual_generation_rules.json"
)
SOURCE_ROOT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "sources", "bilibili", "ysjf", "space_camera_project"
)
DELTA_PATH  = os.path.join(SOURCE_ROOT, "extracted", "keyframe_state_deltas.json")
ANCHOR_PATH = os.path.join(SOURCE_ROOT, "posts", "keyframe_transition_anchor.json")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_rules():
    with open(RULES_PATH, encoding="utf-8") as f:
        return json.load(f)


def _load_deltas():
    with open(DELTA_PATH, encoding="utf-8") as f:
        return json.load(f)


def _load_anchor():
    with open(ANCHOR_PATH, encoding="utf-8") as f:
        return json.load(f)


# Simulate a minimal image-level state descriptor
def _make_image(state: str, timestamp: float) -> dict:
    return {"state": state, "timestamp_sec": timestamp}


def _check_state_transition_order(images: list) -> bool:
    """
    Return True if each image's state does not match a prior image's forbidden
    'next state' (i.e., no state regression or premature appearance).
    Simple version: timestamps must be increasing and states must not regress
    if a lifecycle order is defined.
    """
    # Check timestamps strictly increasing
    timestamps = [img["timestamp_sec"] for img in images]
    return timestamps == sorted(timestamps) and len(timestamps) == len(set(timestamps))


def _check_no_premature_state(images: list, later_state: str, later_index: int) -> bool:
    """
    Check that later_state does not appear in any image before later_index.
    """
    for i, img in enumerate(images):
        if i < later_index and img["state"] == later_state:
            return False
    return True


def _check_state_changed_between(img_a: dict, img_b: dict) -> bool:
    """Return True if the state actually changed (not same)."""
    return img_a["state"] != img_b["state"]


# ---------------------------------------------------------------------------
# Test 1: correct forward order PASS
# ---------------------------------------------------------------------------

def test_correct_state_order_passes():
    images = [
        _make_image("early_preparation", 0.0),
        _make_image("balloon_fully_inflated", 90.0),
        _make_image("release_preparation", 100.0),
    ]
    assert _check_state_transition_order(images) is True


# ---------------------------------------------------------------------------
# Test 2: state regression FAIL
# ---------------------------------------------------------------------------

def test_state_regression_fails():
    images = [
        _make_image("balloon_fully_inflated", 90.0),
        _make_image("early_preparation", 0.0),   # timestamp regression
        _make_image("release_preparation", 100.0),
    ]
    assert _check_state_transition_order(images) is False


# ---------------------------------------------------------------------------
# Test 3: subsequent state appears early FAIL
# ---------------------------------------------------------------------------

def test_premature_state_appearance_fails():
    images = [
        _make_image("balloon_fully_inflated", 0.0),   # fully inflated appears at img_1
        _make_image("balloon_fully_inflated", 90.0),  # same as img_1 — no change
        _make_image("release_preparation", 100.0),
    ]
    # "balloon_fully_inflated" at index 1 should not already be at index 0
    # (previous_state_constraint: img_2 introduces fully_inflated, img_1 must not have it)
    # Here both 0 and 1 have the same state — premature appearance
    assert _check_no_premature_state(images, "balloon_fully_inflated", 1) is False


# ---------------------------------------------------------------------------
# Test 4: no state change between adjacent frames FAIL
# ---------------------------------------------------------------------------

def test_no_state_change_fails():
    img_a = _make_image("balloon_fully_inflated", 90.0)
    img_b = _make_image("balloon_fully_inflated", 95.0)
    assert _check_state_changed_between(img_a, img_b) is False


# ---------------------------------------------------------------------------
# Test 5: correct keyframe change preserved PASS
# ---------------------------------------------------------------------------

def test_keyframe_change_preserved_passes():
    img_a = _make_image("initial_ascent", 200.0)
    img_b = _make_image("atmospheric_boundary_sky_turning_black", 350.0)
    assert _check_state_changed_between(img_a, img_b) is True


# ---------------------------------------------------------------------------
# Test 6: transition metadata saved correctly PASS
# ---------------------------------------------------------------------------

def test_transition_metadata_saved():
    deltas = _load_deltas()
    assert "posts" in deltas
    assert len(deltas["posts"]) > 0
    for post in deltas["posts"]:
        assert "post_id" in post
        assert "transitions" in post
        for t in post["transitions"]:
            assert "from_frame" in t
            assert "to_frame" in t
            assert "from_timestamp_sec" in t
            assert "to_timestamp_sec" in t
            assert "changes" in t
            assert len(t["changes"]) > 0
            for change in t["changes"]:
                assert "object" in change
                assert "before" in change
                assert "after" in change
                assert "delta_type" in change


# ---------------------------------------------------------------------------
# Test 7: missing delta artifact FAIL simulation
# ---------------------------------------------------------------------------

def test_missing_delta_artifact_detected():
    missing_path = "/tmp/nonexistent_keyframe_state_deltas.json"
    assert not os.path.isfile(missing_path), \
        "Delta artifact must exist for validation to proceed"


# ---------------------------------------------------------------------------
# Test 8: delta artifact schema valid PASS
# ---------------------------------------------------------------------------

def test_delta_artifact_schema_valid():
    deltas = _load_deltas()
    assert deltas["artifact_version"].startswith("KEYFRAME_STATE_DELTAS")
    valid_types = {
        "OBJECT_APPEARANCE_CHANGE",
        "SIZE_STATE_CHANGE",
        "POSITION_CHANGE",
        "LIFECYCLE_CHANGE",
        "ENVIRONMENT_CHANGE",
    }
    for post in deltas["posts"]:
        for t in post["transitions"]:
            # Timestamps must advance
            assert t["to_timestamp_sec"] > t["from_timestamp_sec"], (
                f"{post['post_id']} transition {t['from_frame']}→{t['to_frame']}: "
                f"timestamp did not advance"
            )
            for change in t["changes"]:
                assert change["delta_type"] in valid_types, (
                    f"Unknown delta_type: {change['delta_type']}"
                )


# ---------------------------------------------------------------------------
# Test 9: transition anchor schema valid PASS
# ---------------------------------------------------------------------------

def test_transition_anchor_schema_valid():
    anchor = _load_anchor()
    assert "posts" in anchor
    for post in anchor["posts"]:
        assert "post_id" in post
        assert "timeline" in post
        prev_ts = -1.0
        for item in post["timeline"]:
            assert "image_order" in item
            assert "expected_state" in item
            assert "required_visual_elements" in item
            assert "forbidden_visual_elements" in item
            ts = item["representative_timestamp_sec"]
            assert ts > prev_ts, (
                f"{post['post_id']} image_order {item['image_order']}: "
                f"timestamp not increasing ({ts} <= {prev_ts})"
            )
            prev_ts = ts


# ---------------------------------------------------------------------------
# Test 10: rules contract has V1.3 C8 section PASS
# ---------------------------------------------------------------------------

def test_rules_contract_has_v13_rules():
    rules = _load_rules()
    assert rules["contract_version"] in (
        "VISUAL_GENERATION_RULES_V1.3",
        "VISUAL_GENERATION_RULES_V1.4",
    )
    assert "keyframe_state_transition_rules" in rules
    c8 = rules["keyframe_state_transition_rules"]["C8_keyframe_state_transition_fidelity"]
    assert c8["check_field"] == "keyframe_state_match"
    assert c8["group_check_field"] == "state_transition_consistency"
    assert c8["violation_blocks_pass"] is True
    assert c8["violation_blocks_frozen"] is True
    assert "anchor_path" in c8
    assert "delta_artifact_path" in c8


# ---------------------------------------------------------------------------
# Test 11: post_001 C8 replay
# ---------------------------------------------------------------------------

def test_post_001_c8_replay():
    """
    post_001 images cover frames [1,6,10,11]:
      img_01: title/early preparation (t=0-50s)
      img_02: fully inflated balloon, dusk light (t=90s)
      img_03: upward angle, release preparation (t=100s)
    Verify:
      - timestamps increasing ✓
      - each image_order has a distinct expected_state ✓
      - no state appears before its designated image ✓
    """
    anchor = _load_anchor()
    post = next(p for p in anchor["posts"] if p["post_id"] == "post_001")
    timeline = post["timeline"]

    # Timestamps must be strictly increasing
    timestamps = [item["representative_timestamp_sec"] for item in timeline]
    assert timestamps == sorted(timestamps), f"post_001 timestamps not increasing: {timestamps}"
    assert len(timestamps) == len(set(timestamps)), "post_001 duplicate timestamps"

    # Each step must have a distinct expected_state
    states = [item["expected_state"] for item in timeline]
    assert len(states) == len(set(states)), f"post_001 duplicate states: {states}"

    # Forbidden elements at img_1 must not include 'balloon' from a completed state
    img1_forbidden = timeline[0]["forbidden_visual_elements"]
    assert any("fully inflated" in f for f in img1_forbidden), \
        "post_001 img_1 must forbid 'fully inflated balloon' (to preserve transition)"

    # img_2 must require fully inflated balloon
    img2_required = timeline[1]["required_visual_elements"]
    assert any("fully inflated" in r for r in img2_required), \
        "post_001 img_2 must require 'fully inflated'"


# ---------------------------------------------------------------------------
# Test 12: post_002 C8 replay
# ---------------------------------------------------------------------------

def test_post_002_c8_replay():
    """
    post_002 images cover STATE_002 ascent:
      img_01: initial ascent, blue sky (t=200s)
      img_02: atmospheric boundary, sky turning black (t=350s)
      img_03: maximum altitude, black sky + Earth arc (t=430s)
    Verify:
      - timestamps strictly increasing ✓
      - img_01 does NOT allow 'completely black sky' (forbidden) ✓
      - img_02 transition introduces black sky + atmosphere layer ✓
      - img_03 state not prematurely in img_01 ✓
    """
    anchor = _load_anchor()
    post = next(p for p in anchor["posts"] if p["post_id"] == "post_002")
    timeline = post["timeline"]

    # Timestamps must be strictly increasing
    timestamps = [item["representative_timestamp_sec"] for item in timeline]
    assert timestamps == sorted(timestamps), f"post_002 timestamps not increasing: {timestamps}"

    # img_01 must forbid black sky
    img1_forbidden = timeline[0]["forbidden_visual_elements"]
    assert any("black" in f.lower() for f in img1_forbidden), \
        "post_002 img_1 must forbid black sky (state not yet reached)"

    # img_02 must require black or near-black sky
    img2_required = timeline[1]["required_visual_elements"]
    assert any("black" in r.lower() for r in img2_required), \
        "post_002 img_2 must require black/near-black sky (transition state)"

    # img_03 must require Earth arc AND forbid blue sky
    img3_required  = timeline[2]["required_visual_elements"]
    img3_forbidden = timeline[2]["forbidden_visual_elements"]
    assert any("earth arc" in r.lower() or "atmosphere" in r.lower() for r in img3_required), \
        "post_002 img_3 must require Earth arc or atmosphere layer"
    assert any("blue sky" in f.lower() for f in img3_forbidden), \
        "post_002 img_3 must forbid blue sky (already past transition)"

    # State progression: each step has distinct expected_state
    states = [item["expected_state"] for item in timeline]
    assert len(states) == len(set(states)), f"post_002 duplicate states: {states}"
