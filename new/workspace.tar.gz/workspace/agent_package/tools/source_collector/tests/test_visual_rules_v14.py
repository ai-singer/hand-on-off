"""
tests/test_visual_rules_v14.py

VISUAL_GENERATION_RULES_V1.4 — P5 Capture System Fidelity

覆盖：
  1.  valid capture system contract                          PASS
  2.  missing capture system contract                        FAIL
  3.  generated view outside observable space                FAIL
  4.  generated view within observable space                 PASS
  5.  P1 PASS but capture system FAIL → overall FAIL         FAIL
  6.  different projects can use different capture contracts  PASS
  7.  rules file contains no project-specific fields         PASS
  8.  capture system schema has required fields              PASS
  9.  post_001 capture_system_consistency replay             PASS
  10. post_002 capture_system_consistency replay             PASS / NEEDS_REVIEW
  11. Article 005 capture_system.json valid against schema   PASS
  12. P5 rule is project-agnostic in rules contract          PASS
"""

import json
import os
import sys
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

RULES_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "contracts", "visual_generation_rules.json"
)
SCHEMA_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "contracts", "capture_system_contract.schema.json"
)
SOURCE_ROOT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "sources", "bilibili", "ysjf", "space_camera_project"
)
CAPTURE_SYSTEM_PATH = os.path.join(SOURCE_ROOT, "capture_system.json")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_rules():
    with open(RULES_PATH, encoding="utf-8") as f:
        return json.load(f)


def _load_schema():
    with open(SCHEMA_PATH, encoding="utf-8") as f:
        return json.load(f)


def _load_capture_system(path=None):
    p = path or CAPTURE_SYSTEM_PATH
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def _check_capture_system_fidelity(view_description: str, capture_system: dict) -> bool:
    """
    Return True if view_description is within the observable space.
    Return False if it matches any forbidden_view via key discriminating phrases.
    Uses exact multi-word phrase matching rather than individual word matching
    to avoid false positives from shared vocabulary.
    """
    forbidden = capture_system["capture_system"]["forbidden_views"]
    desc_lower = view_description.lower()

    # Discriminating phrases that uniquely identify each forbidden view type.
    # These must NOT appear in valid payload-camera descriptions.
    forbidden_discriminators = [
        "external view of",
        "photographed by another aircraft",
        "from another aircraft",
        "from a distance",
        "far away",
        "full balloon silhouette as main subject",
        "third-party camera",
        "second camera",
        "satellite orbital",
        "spacecraft orbital",
        "orbital view",
        "iss-style",
        "deep space",
        "external third-party",
        "not on the payload",
        "simultaneously from an external",
    ]
    for phrase in forbidden_discriminators:
        if phrase in desc_lower:
            return False
    return True


def _validate_capture_system_contract(contract: dict) -> tuple:
    """Validate a capture_system.json against required schema fields. Returns (valid, errors)."""
    errors = []
    if "source_id" not in contract:
        errors.append("missing source_id")
    cs = contract.get("capture_system", {})
    required_fields = [
        "platform_type", "camera_position", "camera_orientation",
        "observable_regions", "forbidden_views"
    ]
    for field in required_fields:
        if field not in cs:
            errors.append(f"missing capture_system.{field}")
    if isinstance(cs.get("observable_regions"), list) and len(cs["observable_regions"]) < 1:
        errors.append("observable_regions must have at least 1 entry")
    if isinstance(cs.get("forbidden_views"), list) and len(cs["forbidden_views"]) < 1:
        errors.append("forbidden_views must have at least 1 entry")
    return len(errors) == 0, errors


# ---------------------------------------------------------------------------
# Test 1: valid capture system contract PASS
# ---------------------------------------------------------------------------

def test_valid_capture_system_contract_passes():
    contract = _load_capture_system()
    valid, errors = _validate_capture_system_contract(contract)
    assert valid, f"Capture system contract invalid: {errors}"


# ---------------------------------------------------------------------------
# Test 2: missing capture system contract FAIL simulation
# ---------------------------------------------------------------------------

def test_missing_capture_system_contract_detected():
    missing = "/tmp/nonexistent_capture_system.json"
    assert not os.path.isfile(missing), \
        "P5 requires capture_system.json to exist for the source project"


# ---------------------------------------------------------------------------
# Test 3: generated view outside observable space FAIL
# ---------------------------------------------------------------------------

def test_view_outside_observable_space_fails():
    contract = _load_capture_system()
    # External view of complete balloon from far away — explicitly forbidden
    view = "external view of balloon floating in sky photographed from another aircraft far away"
    assert _check_capture_system_fidelity(view, contract) is False


def test_satellite_orbital_view_fails_p5():
    contract = _load_capture_system()
    view = "satellite orbital view of earth from spacecraft photography perspective"
    assert _check_capture_system_fidelity(view, contract) is False


# ---------------------------------------------------------------------------
# Test 4: generated view within observable space PASS
# ---------------------------------------------------------------------------

def test_payload_downward_view_passes_p5():
    contract = _load_capture_system()
    view = "payload camera looking down at earth surface below, clouds visible, tether rope at frame edge"
    assert _check_capture_system_fidelity(view, contract) is True


def test_payload_upward_view_passes_p5():
    contract = _load_capture_system()
    view = "payload camera looking upward at balloon above, earth curvature below, atmosphere layer visible"
    assert _check_capture_system_fidelity(view, contract) is True


# ---------------------------------------------------------------------------
# Test 5: P1 PASS but P5 FAIL → overall FAIL
# ---------------------------------------------------------------------------

def test_p1_pass_p5_fail_is_overall_fail():
    """
    Simulate: P1 = True (first-person camera), but view shows impossible object
    that violates capture system observable space → overall must FAIL.
    """
    p1_result = True   # camera origin consistent
    # P5 check: view contains an object outside observable regions
    # e.g., a second camera visible watching the balloon — not in observable_regions
    p5_result = False  # capture system fidelity failed

    overall_pass = p1_result and p5_result
    assert overall_pass is False, "P1 PASS + P5 FAIL must result in overall FAIL"


# ---------------------------------------------------------------------------
# Test 6: different projects can use different capture contracts PASS
# ---------------------------------------------------------------------------

def test_different_projects_different_contracts():
    # Simulate two different project contracts
    contract_a = {
        "source_id": "project_drone_survey",
        "capture_system": {
            "platform_type": "drone_camera",
            "camera_position": "vehicle_bottom",
            "camera_orientation": "downward",
            "observable_regions": ["ground below drone", "terrain", "buildings"],
            "forbidden_views": ["underwater", "space orbital view", "internal building view"]
        }
    }
    contract_b = {
        "source_id": "project_submarine",
        "capture_system": {
            "platform_type": "underwater_camera",
            "camera_position": "vehicle_front",
            "camera_orientation": "forward",
            "observable_regions": ["underwater terrain", "marine life", "seafloor"],
            "forbidden_views": ["aerial view", "space view", "above water surface"]
        }
    }
    valid_a, errors_a = _validate_capture_system_contract(contract_a)
    valid_b, errors_b = _validate_capture_system_contract(contract_b)
    assert valid_a, f"Contract A invalid: {errors_a}"
    assert valid_b, f"Contract B invalid: {errors_b}"
    assert contract_a["source_id"] != contract_b["source_id"]


# ---------------------------------------------------------------------------
# Test 7: rules file contains no project-specific fields PASS
# ---------------------------------------------------------------------------

def test_rules_file_has_no_project_specific_fields():
    rules = _load_rules()
    p5 = rules["capture_system_fidelity_rules"]["P5_capture_system_fidelity"]
    rule_text = json.dumps(p5)

    # These project-specific terms must NOT appear in the rule itself
    forbidden_in_rules = [
        "Article 005",
        "balloon",
        "30000",
        "30km",
        "bilibili",
        "ysjf",
        "space_camera",
        "whisper",
        "gemini",
    ]
    for term in forbidden_in_rules:
        assert term.lower() not in rule_text.lower(), \
            f"Rule P5 must not contain project-specific term: '{term}'"


# ---------------------------------------------------------------------------
# Test 8: capture system schema has required fields PASS
# ---------------------------------------------------------------------------

def test_capture_system_schema_structure():
    schema = _load_schema()
    assert schema.get("type") == "object"
    assert "properties" in schema
    props = schema["properties"]
    assert "source_id" in props
    assert "capture_system" in props
    cs_props = props["capture_system"]["properties"]
    required_cs_fields = [
        "platform_type", "camera_position", "camera_orientation",
        "observable_regions", "forbidden_views"
    ]
    for field in required_cs_fields:
        assert field in cs_props, f"Schema missing capture_system.{field}"


# ---------------------------------------------------------------------------
# Test 9: post_001 capture_system_consistency replay PASS
# ---------------------------------------------------------------------------

def test_post_001_capture_system_replay():
    """
    post_001 = ground-level launch preparation phase.
    Camera is at ground level (crew held / tripod / handheld).
    Observable: launch field, balloon on ground, crew, sky above.
    All 3 images depict ground-level scenes — within capture system.
    """
    contract = _load_capture_system()
    post_001_image_descriptions = [
        "snowy outdoor field with crew in winter clothing preparing for launch, balloon visible",
        "fully inflated balloon on ground with payload suspended, crew gathered below at dusk",
        "upward-looking angle from ground toward balloon dominating frame, crew visible at base"
    ]
    for desc in post_001_image_descriptions:
        # Ground crew and launch preparation are in observable_regions for ground phase
        # No forbidden views present
        result = _check_capture_system_fidelity(desc, contract)
        assert result is True, f"post_001 image failed P5: {desc}"


# ---------------------------------------------------------------------------
# Test 10: post_002 capture_system_consistency replay PASS
# ---------------------------------------------------------------------------

def test_post_002_capture_system_replay():
    """
    post_002 = high-altitude ascent, payload camera mounted on balloon.
    img_01: payload looking down, ground shrinking — PASS
    img_02: payload looking out, Earth curvature + atmosphere — PASS
    img_03: payload looking up at balloon, Earth below — PASS
    All are within observable regions of balloon_payload_camera.
    """
    contract = _load_capture_system()

    post_002_descriptions = [
        # img_01: low ascent, looking down
        "payload camera perspective looking downward, snow-covered ground shrinking below, "
        "tether rope visible at frame edge, blue sky, early ascent",
        # img_02: mid-ascent, looking outward
        "payload camera looking outward, Earth curvature visible, thin blue atmosphere layer "
        "at edge, sky transitioning to near-black, tether rope visible",
        # img_03: peak altitude, looking up at balloon
        "payload camera looking upward at balloon above, tether rope connecting payload to balloon, "
        "Earth arc and atmosphere layer visible below, near-black sky"
    ]

    results = []
    for desc in post_002_descriptions:
        result = _check_capture_system_fidelity(desc, contract)
        results.append(result)

    assert all(results), (
        f"post_002 P5 replay: {list(zip(['img_01','img_02','img_03'], results))}"
    )


# ---------------------------------------------------------------------------
# Test 11: Article 005 capture_system.json valid PASS
# ---------------------------------------------------------------------------

def test_article_005_capture_system_valid():
    contract = _load_capture_system()
    valid, errors = _validate_capture_system_contract(contract)
    assert valid, f"Article 005 capture_system.json invalid: {errors}"
    assert contract["source_id"] == "bilibili_ysjf_space_camera_project"
    cs = contract["capture_system"]
    assert cs["platform_type"] == "balloon_payload_camera"
    assert len(cs["observable_regions"]) >= 3
    assert len(cs["forbidden_views"]) >= 3


# ---------------------------------------------------------------------------
# Test 12: P5 rule is project-agnostic in rules contract PASS
# ---------------------------------------------------------------------------

def test_rules_contract_has_v14_rules():
    rules = _load_rules()
    assert rules["contract_version"] == "VISUAL_GENERATION_RULES_V1.4"
    assert "capture_system_fidelity_rules" in rules
    p5 = rules["capture_system_fidelity_rules"]["P5_capture_system_fidelity"]
    assert p5["check_field"] == "capture_system_consistency"
    assert p5["violation_blocks_pass"] is True
    assert "contract_path_pattern" in p5
    assert "contract_schema" in p5
    # Must reference schema, not embed project facts
    assert "<source_project>" in p5["contract_path_pattern"]
