# AGENTS.md

# Agent Workspace Configuration Router v1.9


# Overview

This workspace uses a layered architecture:

Core Identity

↓

Workflow Control

↓

Business Configuration

↓

Source Collection

↓

Source Material

↓

Knowledge Library

↓

Runtime Data

↓

Production Output


The Agent must distinguish:

- Identity.
- Rules.
- Execution capabilities.
- External inputs.
- Verified knowledge.
- Learned templates.
- Runtime outputs.


The Agent must never:

- Treat runtime data as rules.
- Treat external materials as verified knowledge.
- Treat templates as mandatory facts.
- Bypass review rules during generation.


---

# 1. Core Identity Layer


Files:

- SOUL.md
- IDENTITY.md
- USER.md


Purpose:

Define:

- Agent identity.
- Behavior principles.
- Expression boundaries.
- Interaction constraints.


---

# 2. Workflow Control Layer


Files:

- AGENTS.md
- HEARTBEAT.md


Purpose:

Define:

- Task routing.
- Execution order.
- Loading rules.
- Agent coordination.


Tool capabilities are defined separately in TOOLS.md.


---

# 3. Business Configuration Layer


Location:

agent_config/


Purpose:

Store domain execution strategies and production rules that define how Agents perform specific tasks.


Contains:


## Global Production Rules


Files:

- content_strategy.md
- content_operation_strategy.md
- source_strategy.md
- text_generation.md
- visual_strategy.md
- operation.md


Responsibility split within global production rules:

- content_strategy.md — content direction, content value, topic direction.
- content_operation_strategy.md — platform evaluation and packaging
  (visual opportunity, series potential, audience fit, topic scoring,
  HKRR communication evaluation, tag strategy).
- operation.md — execution workflow, phase order, state model, recovery.


## Creator Distilled Knowledge


Location:

agent_config/distilled/<creator>/


Files:

- topic_selection_rules.md
- topic_pattern_examples.md
- script_structure_rules.md
- title_formula_rules.md
- visual_pattern_rules.md


Purpose:

Store creator-specific learned patterns extracted by distillation.

Rule:

Distilled knowledge is referenced, never copied.

Each distilled file has exactly one loading entry (see Section 9):

| Distilled file | Loaded by |
|---|---|
| topic_selection_rules.md | content_strategy.md · content_operation_strategy.md |
| topic_pattern_examples.md | content_strategy.md |
| script_structure_rules.md | text_generation.md |
| title_formula_rules.md | text_generation.md |
| visual_pattern_rules.md | visual_strategy.md |


## Review Rules


Files:

- review_rules.md


Purpose:

Define universal review requirements:

- Evidence consistency.
- Fact boundaries.
- Quality gates.
- General publishing constraints.


## Platform Specific Review Rules


Files:

- phanthy_review_standard.md


Purpose:

Define Phanthy platform-specific requirements:

- Content length.
- Formatting rules.
- Image requirements.
- Category accuracy.
- Tag accuracy.
- Source requirements.
- AI content restrictions.


Rule:

Platform-specific rules supplement global review rules.


They do not replace:

- SOUL.md
- IDENTITY.md
- Global safety principles.


## Intelligence Rules


Files:

- content_distillation.md
- visual_distillation.md
- template_retrieval.md
- template_feedback.md


Purpose:

Define:

- Knowledge extraction.
- Pattern learning.
- Template retrieval.
- Template optimization.


Rule:

agent_config defines domain execution strategies.

It does not store:

- Identity definitions.
- Global workflow rules.
- Tool capabilities.
- Raw materials.
- Generated posts.
- Learned templates.


---

# 4. Source Collection Layer


Location:

source_collector/


Purpose:

Execute external information collection.


Responsibilities:

- Collection scheduling.
- Source acquisition.
- Metadata extraction.
- Duplicate detection.
- Raw material creation.


Structure:

source_collector/

collectors/

scheduler/

processors/

storage/

config/


Relationship:

agent_config

(collection strategy)

↓

source_collector

(execution capability)

↓

source_material


---

# 5. Source Material Layer


Location:

source_material/


Purpose:

Store collected external materials.


Structure:

source_material/

raw/

extracted/

verified/


Workflow:


Raw Material

↓

Extraction

↓

Verification

↓

Distillation


Rules:

- Raw materials preserve original information.
- Extracted information must trace back to sources.
- Only verified materials enter learning workflows.


---

# 6. Knowledge Library Layer


Location:

template_library/


Purpose:

Store reusable learned patterns.


Structure:

template_library/

README.md

content_templates/

visual_templates/

metadata/

template_index.json

feedback/


Rules:

- Templates are learned knowledge.
- Templates cannot override identity.
- Templates cannot bypass review rules.
- Templates require validation before activation.


---

# 7. Runtime Data Layer


Locations:

选题库/

posts/

covers/

memory/

logs/


Purpose:

Store:

- Tasks.
- Generated content.
- Generated visual assets.
- Operation records.
- Runtime history.


Rules:

Runtime data is temporary operational output.


Runtime data cannot modify:

- Rules.
- Identity.
- Workflow definitions.


---

# 8. Agent Loading Rules


## Content Production


Load:


SOUL.md

↓

IDENTITY.md

↓

USER.md

↓

AGENTS.md

↓

Required agent_config files

↓

template_library (when reuse is required)


Distilled creator knowledge is loaded transitively:

required agent_config files reference the distilled files they depend on
(see Section 9). A distilled file is never loaded directly by the Content
Production sequence; it is reached through its owning agent_config file.


## Reference-Only Rule


Distilled knowledge is always referenced, never copied.

- The distilled file is the Single Source of Truth for its rules.
- The referencing agent_config file states purpose, scope and the reference.
- The referencing file must not reproduce the distilled rule body.


---

# 9. Agent Specific Rule Loading


## Text Generation Agent


Required:

- text_generation.md
- distilled/<creator>/script_structure_rules.md
- distilled/<creator>/title_formula_rules.md


Optional summary constraints:

- review_rules.md key constraints


Purpose:

Generate evidence-grounded content.


Creator style:

Script structure and title mechanics are defined solely by the distilled
files listed above. text_generation.md references them and does not
reproduce their rule bodies.


Do not load full platform review rules unless required.


---

## Visual Generation Agent


Required:

- visual_strategy.md
- distilled/<creator>/visual_pattern_rules.md


Optional:

- visual_distillation.md


Purpose:

Generate visual assets consistent with:

- Evidence.
- Visual identity.
- Asset constraints.


Creator style:

Cover and visual pattern rules are defined solely by
distilled/<creator>/visual_pattern_rules.md.
visual_strategy.md references it and does not reproduce its rule bodies.


---

## Draft Generation Agent


Required:

- text_generation.md
- visual_strategy.md


Optional:

- review_rules.md summary


Purpose:

Convert generated content into structured drafts.


---

## Tag Generation Agent


Required:

- content_operation_strategy.md
- content_strategy.md
- Platform review rules when applicable


For Phanthy:

Load:

agent_config/phanthy_review_standard.md


Purpose:

Generate:

- Category.
- Tags.
- Metadata.


Rule ownership:

- Tag selection, tag types, tag count and tag placement:
  content_operation_strategy.md Section 6.
- Content direction and category alignment:
  content_strategy.md Section 1.
- Category and tag accuracy criteria:
  phanthy_review_standard.md.


Requirement:

Tags must match actual content.


---

## Content Review Agent


Required:

- review_rules.md
- phanthy_review_standard.md


Purpose:

Perform:

- Fact review.
- Evidence review.
- Visual consistency review.
- Format review.
- Platform compliance review.


---

## Final Package Agent


Required:

- review_rules.md
- platform review rules


Purpose:

Verify final publishing package:

- Content.
- Images.
- Metadata.
- Tags.
- Source references.


---

# 10. Complete Content Production Pipeline


External Source

↓

source_collector

↓

source_material

↓

Evidence Extraction

↓

Content Opportunity Mining

↓

Portfolio Planning

↓

content_generation

↓

visual_generation

↓

draft_generation

↓

tag_generation

↓

review

↓

final_package

↓

operation

↓

feedback

↓

template_update


---

# 11. Rule Priority


Priority:


SOUL.md

>

IDENTITY.md

>

USER.md

>

review_rules.md

>

platform_review_rules

>

agent_config/

>

template_library/

>

runtime data


Explanation:


SOUL.md:

Defines identity and fundamental behavior.


IDENTITY.md:

Defines agent role.


USER.md:

Defines user-specific preferences.


review_rules.md:

Defines universal quality and safety requirements.


platform_review_rules:

Defines platform-specific publishing requirements.


agent_config:

Defines domain execution strategies.


template_library:

Provides reusable patterns.


runtime data:

Provides current task information only.


---

# 12. Conflict Resolution


Rules:

- Runtime data cannot modify rules.
- Templates cannot modify identity.
- External materials require verification before learning.
- Learning results require validation before activation.
- Platform rules cannot override global safety rules.
- Generated content cannot bypass review stages.


---

# Version


Version:

v1.9


Changes:

v1.9:

- Added content_operation_strategy.md to the Business Configuration Layer.
- Split platform evaluation and packaging responsibilities out of
  content_strategy.md into content_operation_strategy.md.
- Added a Creator Distilled Knowledge subsection with an explicit
  loading-entry map for the five distilled files.
- Section 8: added the Reference-Only Rule for distilled knowledge.
- Section 9: Text Generation Agent now requires script_structure_rules.md
  and title_formula_rules.md.
- Section 9: Visual Generation Agent now requires visual_pattern_rules.md.
- Section 9: Tag Generation Agent now requires content_operation_strategy.md
  and documents tag rule ownership.


v1.8:

- Removed audience definition from Identity Layer.
- Separated Tool Layer responsibility from Workflow Control Layer.
- Clarified agent_config boundary.
- Preserved reusable global workflow architecture.