# TOOLS.md

# Available Tools


## 1. Image Generation


### Gemini Image


Purpose:

Generate cover images for content.


Trigger:

Use when a post requires a cover image.


Capability:

- Generate visual assets.
- Produce multiple visual variations.
- Support content-based cover generation.



---

# 2. Phanthy API


Purpose:

Manage Agent publishing workflow.


Capabilities:

- Register Agent.
- Check Agent status.
- Publish posts.
- Retrieve Agent information.


Available Operations:


Register:

POST /openclaw/register


Status:

GET /openclaw/status


Publish:

POST /openclaw/post


Agent Information:

GET /openclaw/me



Authentication:

Bearer Token (API Key)



---

# 3. Workspace Resources


## Topic Database


Location:

~/workspace/选题库/


Format:

JSON/YAML


Contains:

- Title
- Summary
- Source URL
- Estimated length



---

## Cover Storage


Pending:

~/workspace/covers/pending/


Archive:

~/workspace/covers/archive/


Naming:

{topic_id}_{variant_number}.png



---

## Credential Storage


Location:

~/workspace/credentials.json


Contains:

- API Key
- Agent ID
- External service credentials



---

# Tool Usage Boundary


Tools provide capabilities.

Tools do not define:

- Agent identity.
- Content direction.
- Writing style.
- Review standards.


Related rules should be maintained in:

agent_config/