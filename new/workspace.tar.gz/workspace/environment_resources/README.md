# Environment Resources

**分类：** 受控部署资源（Controlled Deployment Resources）
**状态：** ⚠️ **结构与模板 — 不含任何真实凭证**

---

## 1. 为什么这里没有真实凭证

部署包的这一部分**原本应当包含可复用的环境资源**（凭证文件、Cookie 文件）。
但经全量静态扫描确认：

**源 workspace 中不存在任何凭证文件。**

| 检查项 | 结果 |
|---|---|
| `credentials.json` | ❌ ABSENT |
| `.env` | ❌ ABSENT |
| `phanthy-api-key.txt` | ❌ ABSENT |
| `phanthy_config.json` | ❌ ABSENT |
| `bilibili_cookies.txt` / `cookies.txt` | ❌ ABSENT |
| `source_collector/secrets/` 目录 | ❌ ABSENT |
| 任何 `*.pem` / `*.key` / `*.p12` / `*.pfx` | ❌ ABSENT |
| 任何点文件（dotfile） | ❌ none |
| `token*` / `secret*` 命名的文件 | ❌ ABSENT |

**因此"复制真实文件结构、不修改内容"这一规则无对象可施。**
本目录提供的是**目标结构 + 模板**，由部署管理员填写。

---

## 2. 唯一存在的凭证材料，及其处置

源 workspace 中确实存在**一处**真实凭证材料，但它不是文件，而是**内联字面量**：

| 位置 | 形式 | 数量 |
|---|---|---|
| `scripts/smart_reply.py` | 硬编码 `API_KEY` 字面量 | 1 |
| `scripts/poller_external.py` | 硬编码 `API_KEY` 字面量 | 1 |
| `scripts/poller_daemon.py` | 模块级 `API_KEY` 常量 | 1 |
| `scripts/message_poller.sh` | shell 变量字面量 | 2 |
| `scripts/message_poller_minute.sh` | `${API_KEY:-...}` 默认值 | 1 |
| `memory/2026-09-15-phanthy-config.md` | 笔记中留档 | 1 |

**7 处，同一把 40 字符 `phanthy_` 前缀密钥。**

### 处置决定：**不提取、不迁移、不复用**

理由：

1. **该密钥已泄露。** 它以明文进入交接快照，任何持有快照的人都能读取。
2. **它不是"可复用资源"，而是"待轮换的失效凭证"。** 把它写进本目录会把一个已知泄露的
   密钥包装成"受控部署资源"，与本目录的用途相反。
3. **提取动作本身会创建新的密钥文件。** 本包不应产生任何含密钥值的文件。
4. **规则要求"不修改内容"** —— 从源码提取不是"保留"，而是"新建"。

### 必须执行的动作

> 🔴 **在源环境轮换该 Phanthy API Key**，并删除上述 6 处脚本字面量与 1 处 memory 留档。
> 这是**独立于本部署包**的安全动作。新实例应使用**新签发**的凭证。

---

## 3. 目录内容

```
environment_resources/
├── README.md                      本文件
├── .env                           ⚠️ 模板 — 值为空
├── credentials.json.template      ⚠️ 模板 — 值为空
└── cookies/
    ├── README.md                  放置说明
    └── .gitkeep                   保持目录存在
```

---

## 4. 两类资源的分工

| 资源 | 文件 | 存放什么 | 权威依据 |
|---|---|---|---|
| **运行时路径** | `.env` | `BILIBILI_COOKIE_PATH`（必需）、`OPENCLAW_CONFIG_PATH`（可选）、`SOURCE_ROOT`（可选） | `auth.py:29` |
| **凭证值** | `credentials.json` | Phanthy API Key、Agent ID | `TOOLS.md` §Credential Storage |
| **Cookie 文件** | `cookies/bilibili_cookies.txt` | B 站 Cookie（Netscape 格式） | `auth.py` |

> **注意：** `.env` 里放的是**路径**，不是密钥。真正的密钥值只放 `credentials.json`。
> 这一分工来自 `TOOLS.md` 的声明，也是 Layer Placement Matrix 的要求：
> 凭证值只允许存放在凭证文件，配置文件中只引用路径。

---

## 5. 使用步骤

1. 把 `.env` 复制到部署目标的 workspace 根，或按宿主约定放置。
2. 填写 `BILIBILI_COOKIE_PATH`，指向 `cookies/` 下放置的 Cookie 文件。
3. 复制 `credentials.json.template` 为 `credentials.json`，填入新签发的 Phanthy 凭证。
4. 收紧权限：`chmod 600 .env credentials.json cookies/*`
5. 确认两者**未进入版本控制**。

---

## 6. 安全约束（强制）

| # | 约束 |
|---|---|
| S-1 | 本目录中的模板文件**不得提交带值的版本**到任何版本库 |
| S-2 | 文件内容**不得**打印到日志、报告或对话中 |
| S-3 | 权限必须收紧至仅属主可读（`600`） |
| S-4 | 新实例必须使用**新签发**的凭证，不得复用源环境的任何密钥 |
| S-5 | `credentials.json` 与 Cookie 文件**不得**进入 Agent Capability Package（`agent_package/`） |

---

*environment_resources — 受控部署资源，结构与模板*
