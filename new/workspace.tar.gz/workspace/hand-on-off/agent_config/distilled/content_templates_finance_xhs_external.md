# content_templates_finance_xhs_external.md

# 财经图文内容模板库（外部素材蒸馏）

来源：xhs finance image_text S/A 级外部素材
蒸馏时间：2026-09-22
蒸馏依据：distillation_framework.md v1.0 Track 2
样本数：7 条（S=6, A=1）

---

## Template 01｜反认知冷水型

**来源笔记：** 全网鼓吹一人公司OPC，但这盆冷水必须得泼（S级，signal=7.4）

### Hook Pattern
```yaml
type: contrarian
structure: 先承认热点真实性，然后用「但这盆冷水必须得泼」宣告反叙事
trigger_mechanism: 认知冲突——大众都在鼓吹，但我有不同看法
```

### Content Structure
```yaml
opening: 建立信任背书（我做过XX，经历过XX轮风口）→ 宣告要说真话
main_sections:
  - 承认热点的真实吸引力（不否认表层现象）
  - 揭示被忽视的底层风险或条件
  - 给出分层建议（适合谁/不适合谁）
transitions: 每段开头用数字或「但是」引导，制造节奏感
ending: 邀请挑战（欢迎评论区开怼）→ 激活互动
```

### Explanation Method
```yaml
primary: 经验论证（用亲身经历建立可信度）
secondary: 反例揭示（用风口失败案例说明风险）
```

### Key Rules
- 标题必须包含明确的流行词 + 否定/转折动作
- 开头 100 字必须建立作者资质（为什么我有资格说这话）
- 内容结构：承认 → 但是 → 本质 → 分层建议
- 不能全盘否定，要给出「适合人群」出口

---

## Template 02｜类比机制解释型

**来源笔记：** 一张图讲透经营与管理的本质区别（S级，signal=6.1）

### Hook Pattern
```yaml
type: question + analogy
structure: 用一个超具体的生活比喻作为核心框架，然后用这个框架解释抽象概念
trigger_mechanism: 认知降维——把复杂概念映射到读者已知经验
```

### Content Structure
```yaml
opening: 直接抛出核心比喻（开公司 = 驾驶一辆车去远方）
main_sections:
  - 概念A：用比喻的A面解释（方向盘/油门 = 经营）
  - 概念B：用比喻的B面解释（发动机/仪表盘 = 管理）
  - 核心洞察：揭示两者的残酷优先级关系
transitions: 数字列表 + 小标题 + 括号注释（关键词=具体动作）
ending: 一句话总结残酷真相（在错误的道路上加速，死得越惨）
```

### Explanation Method
```yaml
primary: 完整类比框架（一个比喻贯穿全文）
secondary: 反例警示（方向错误时执行力越强越危险）
information_flow: 并列结构 → 优先级揭示 → 警示结论
```

### Key Rules
- 必须选一个读者日常熟悉的场景作比喻载体
- 概念必须是两个容易混淆的词
- 比喻要能覆盖概念的所有核心维度
- 结尾必须有「残酷逻辑」反转，不能只是中性解释

---

## Template 03｜案例堆叠型（商业模式揭秘）

**来源笔记：** 🔥这才是犹太人的底层经商逻辑（S级，signal=6.3）

### Hook Pattern
```yaml
type: data + contrarian revelation
structure: 先描述普通认知的局限（我以为...），再用「直到看完3个案例」制造转折
trigger_mechanism: 认知升级诱饵——暗示读者目前的认知是错的
```

### Content Structure
```yaml
opening: 旧认知（低买高卖）→ 遭遇挑战 → 新认知预告（3个案例）
main_sections:
  - 案例1：场景 + 机制 + 利润来源（免费钓鱼）
  - 案例2：场景 + 机制 + 利润来源（99元钓场）
  - 案例3：场景 + 机制 + 利润来源（零成本雨伞）
  - 核心洞察提炼（4条通用规律）
transitions: emoji数字标记（①②③④），每案例一行概括标题
ending: 感悟升华 + 与读者共鸣（为什么有人零成本赚钱）
```

### Explanation Method
```yaml
primary: 案例堆叠（3个案例，每个结构一致：场景→机制→利润）
secondary: 规律提炼（案例后归纳可复用的通用逻辑）
case_strategy:
  type: real/hypothetical mixed
  position: main body
  function: proof + illustration
```

### Key Rules
- 案例数量：3-5个，结构完全一致（便于读者快速理解）
- 每个案例必须有「反直觉」的利润来源
- 案例之间要有递进关系（复杂度或颠覆程度递增）
- 结尾提炼的规律数量不超过 4 条

---

## Template 04｜极简金句型

**来源笔记：** 赚钱的底层逻辑：本质是贩卖欲望（S级，signal=6.7）

### Hook Pattern
```yaml
type: contrarian statement
structure: 标题即结论，正文是对标题的多角度展开
trigger_mechanism: 强观点吸引——直接用颠覆性判断做标题
```

### Content Structure
```yaml
opening: 直接否定常识认知（很多人以为...其实...）
main_sections:
  - 核心洞察一句话版本
  - 分人群映射（对男人/对女人/对富人/对普通人）
  - 抽象升华（产品是载体，人心是赛道）
transitions: 无明显段落分隔，流式散文
ending: 实用点（悟到这点，少走很多弯路）
```

### Explanation Method
```yaml
primary: 格言式断言（短句 + 对仗）
secondary: 分类映射（不同人群对应不同欲望）
sentence_rhythm: 短句为主（10-15字/句），对仗结构
```

### Key Rules
- 正文控制在 150 字以内（极简是核心）
- 每句话都是独立的金句，可单独传播
- 避免举例（举例会破坏金句密度）
- 标题必须是完整判断句，不能是问句

---

## Template 05｜财务概念大白话型

**来源笔记：** 利润表大白话，看了就懂了（A级，signal=5.9）

### Hook Pattern
```yaml
type: accessibility promise
structure: 标题承诺「大白话」降低认知门槛，正文兑现承诺
trigger_mechanism: 焦虑消解——让觉得「看不懂」的人觉得「我也能懂」
```

### Content Structure
```yaml
opening: 直接进入主题，不做铺垫
main_sections:
  - 概念定义（一句话）
  - 结构拆解（图示 + 文字说明）
  - 实际意义（对普通人意味着什么）
transitions: 图文结合，文字作注释
ending: 无需总结，图即结论
```

### Explanation Method
```yaml
primary: 可视化降维（图表 + 简短注释）
secondary: 类比或举例（日常生活收支类比）
information_flow: 定义 → 结构 → 意义
cognitive_load: light（故意降低）
```

### Key Rules
- 标题必须包含「大白话/看懂/讲清楚」等降门槛词
- 图片是主体，文字是辅助（图文比 ≥ 6:4）
- 避免专业术语，每个术语必须立即用大白话解释
- 适用场景：财务报表、经济指标、金融产品解释

---

## Template 06｜盘点揭秘型

**来源笔记：** 那些最后一地鸡毛公司！（S级，signal=7.3）

### Hook Pattern
```yaml
type: curiosity gap + social proof
structure: 标题用感叹号制造情绪，暗示「你不知道的真相」
trigger_mechanism: 好奇心 + 八卦心理（知名公司为什么倒了）
```

### Content Structure
```yaml
opening: 一句情绪化感慨引入（个别公司挺可惜的）
main_sections:
  - 公司列表（图文形式，每家公司配图）
  - 每家简短背景（鼎盛时期描述）
  - 结局暗示（只说现象，留白原因）
transitions: 图片驱动，每张图是一个公司
ending: 留白引发脑补（至于真正原因，只有自行脑补）
```

### Explanation Method
```yaml
primary: 盘点列举（图片为主）
secondary: 悬念留白（不给答案，激发评论区讨论）
ending_strategy:
  type: question（隐性）
  interaction_design: 引导评论区补充/猜测原因
```

### Key Rules
- 标题用感叹号，强烈情绪感
- 内容以图片为主（每家公司一张图）
- 不提供完整分析（留白是激活评论区的核心机制）
- 「你知道的但别人不知道」的内容最适合这个模板

---

## 跨模板共性规律

### 高收藏触发机制
1. **认知冲突**：「我以为...但其实...」结构 → 收藏率最高
2. **可操作感**：有具体案例/步骤/规律可以直接用
3. **留白悬念**：不把话说死，留空间让读者自己填
4. **人群映射**：「这说的就是我」的精准描述

### 标题公式
```
[情绪词/数字] + [已知概念] + [转折/揭秘动作]
例：🔥这才是 + 犹太人底层逻辑（已知） = 隐含「你之前理解是错的」
例：全网鼓吹 + 一人公司 + 但这盆冷水必须得泼 = 反常识
```

### 内容密度原则
- S级内容：信息密度高，每段都有独立观点，可拆成多条金句
- 避免稀释：不用「首先/其次/最后」这类连接词拼凑篇幅

---

版本：v1.0
创建时间：2026-09-22
适用垂类：商业财经（Finance）
素材来源：XHS 外部图文 S/A 级（7条）
