#!/usr/bin/env python3
"""探查 XHS 搜索页实际发出的 XHR 请求和响应结构"""
import asyncio
from pathlib import Path

CHROMIUM_PATH = "/usr/bin/chromium"
COOKIE_PATH   = Path("/home/node/.openclaw/workspace/xiaohongshu_cookies.txt")

def load_cookie_list():
    content = COOKIE_PATH.read_text(encoding="utf-8").strip()
    cookies = []
    for line in content.splitlines():
        if line.strip() and not line.startswith("#"):
            parts = line.split("\t")
            if len(parts) >= 7:
                cookies.append({
                    "name": parts[5], "value": parts[6],
                    "domain": ".xiaohongshu.com", "path": "/",
                })
    return cookies

async def main():
    from playwright.async_api import async_playwright
    import urllib.parse, json

    cookies = load_cookie_list()
    captured = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(
            executable_path=CHROMIUM_PATH,
            headless=True,
            args=["--no-sandbox", "--disable-dev-shm-usage"]
        )
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
            viewport={"width": 1280, "height": 800},
        )
        await context.add_cookies(cookies)

        page = await context.new_page()

        async def on_response(resp):
            url = resp.url
            if "xiaohongshu.com/api" in url or "edith.xiaohongshu.com" in url:
                try:
                    body = await resp.text()
                    captured.append({
                        "status": resp.status,
                        "url": url,
                        "body_preview": body[:300],
                    })
                except Exception:
                    captured.append({"status": resp.status, "url": url, "body_preview": "(unreadable)"})

        page.on("response", on_response)

        print("访问主页...")
        await page.goto("https://www.xiaohongshu.com/explore", timeout=20000)
        await page.wait_for_timeout(3000)

        print("访问搜索页...")
        kw = urllib.parse.quote("商业分析")
        await page.goto(f"https://www.xiaohongshu.com/search_result?keyword={kw}&type=51", timeout=20000)
        await page.wait_for_timeout(8000)

        await browser.close()

    print(f"\n捕获到 {len(captured)} 个 API 请求:\n")
    for c in captured:
        print(f"  [{c['status']}] {c['url']}")
        if c['status'] == 200 and "search" in c['url'].lower():
            print(f"    BODY: {c['body_preview']}\n")

if __name__ == "__main__":
    asyncio.run(main())
