#!/usr/bin/env python3
"""
Step 5-7: 建立 Benchmark + normalize + 分级 + 风险过滤
"""
import json
import math
import re
import shutil
from datetime import datetime
from pathlib import Path

WORKSPACE     = Path("/home/node/.openclaw/workspace")
HAND_ON_OFF   = WORKSPACE / "hand-on-off"
FINANCE_BASE  = HAND_ON_OFF / "source_material/xhs/finance"
VIDEO_DIR     = FINANCE_BASE / "video"
IMAGE_TEXT_DIR = FINANCE_BASE / "image_text"
BLOCKED_DIR   = FINANCE_BASE / "image_text_blocked"
REGISTRY_DIR  = HAND_ON_OFF / "source_material/xhs/creator_registry"

RISK_KEYWORDS = [
    "股票","炒股","A股","选股","个股","持仓","仓位",
    "投资建议","投资推荐","交易策略","买卖信号",
    "理财产品","基金推荐","证券","期货操作",
    "暴富","一夜暴富","躺赚","被动收入",
    "财务自由","财富自由",
]

def parse_count(v):
    if v is None: return 0
    s = str(v).replace(",","").replace("+","").strip()
    try: return int(s)
    except: return 0

def load_all_notes():
    notes = []
    for p in VIDEO_DIR.iterdir():
        meta = p / "meta.json"
        if meta.exists():
            d = json.loads(meta.read_text())
            d["_path"] = str(meta)
            d["_type"] = "video"
            d["_note_id"] = p.name
            notes.append(d)
    for p in IMAGE_TEXT_DIR.glob("*.json"):
        d = json.loads(p.read_text())
        d["_path"] = str(p)
        d["_type"] = "image_text"
        d["_note_id"] = p.stem
        notes.append(d)
    return notes

def get_metrics(note):
    info = note.get("interact_info", {})
    return {
        "liked":     parse_count(info.get("liked_count", 0)),
        "collected": parse_count(info.get("collected_count", 0)),
        "comment":   parse_count(info.get("comment_count", 0)),
        "share":     parse_count(info.get("share_count", 0)),
    }

def percentile(data, p):
    if not data: return 0
    s = sorted(data)
    idx = (len(s) - 1) * p / 100
    lo, hi = int(idx), min(int(idx)+1, len(s)-1)
    return s[lo] + (s[hi] - s[lo]) * (idx - lo)

def signal_score(m):
    return (
        math.log1p(m["collected"]) * 0.35 +
        math.log1p(m["share"])     * 0.30 +
        math.log1p(m["comment"])   * 0.25 +
        math.log1p(m["liked"])     * 0.10
    )

def tier(collected, p95, p90, p75):
    if collected >= p95: return "S"
    if collected >= p90: return "A"
    if collected >= p75: return "B"
    return "C"

def risk_check(note):
    text = (note.get("title","") + note.get("desc","")).lower()
    for kw in RISK_KEYWORDS:
        if kw in text:
            return kw
    return None

def main():
    print("=" * 50)
    print("Step 5: 建立 Account Benchmark")
    print("=" * 50)
    notes = load_all_notes()
    print(f"  共加载 {len(notes)} 条笔记")

    metrics_list = [get_metrics(n) for n in notes]
    collecteds = [m["collected"] for m in metrics_list]
    shareds    = [m["share"] for m in metrics_list]
    comments   = [m["comment"] for m in metrics_list]
    likeds     = [m["liked"] for m in metrics_list]

    p95_c = percentile(collecteds, 95)
    p90_c = percentile(collecteds, 90)
    p75_c = percentile(collecteds, 75)
    p50_c = percentile(collecteds, 50)

    benchmark = {
        "creator": "小Lin说",
        "user_id": "5abf90244eacab2c32c7c5e6",
        "computed_at": datetime.now().strftime("%Y-%m-%d"),
        "sample_size": len(notes),
        "benchmark": {
            "liked":     {"p50": round(percentile(likeds,50)), "p75": round(percentile(likeds,75)), "p90": round(percentile(likeds,90)), "p95": round(percentile(likeds,95))},
            "collected": {"p50": round(p50_c), "p75": round(p75_c), "p90": round(p90_c), "p95": round(p95_c)},
            "comment":   {"p50": round(percentile(comments,50)), "p75": round(percentile(comments,75)), "p90": round(percentile(comments,90)), "p95": round(percentile(comments,95))},
            "share":     {"p50": round(percentile(shareds,50)), "p75": round(percentile(shareds,75)), "p90": round(percentile(shareds,90)), "p95": round(percentile(shareds,95))},
            "avg": {
                "liked":     round(sum(likeds)/len(likeds)) if likeds else 0,
                "collected": round(sum(collecteds)/len(collecteds)) if collecteds else 0,
                "comment":   round(sum(comments)/len(comments)) if comments else 0,
                "share":     round(sum(shareds)/len(shareds)) if shareds else 0,
            }
        }
    }
    REGISTRY_DIR.mkdir(parents=True, exist_ok=True)
    bm_path = REGISTRY_DIR / "linshuo_benchmark.json"
    bm_path.write_text(json.dumps(benchmark, ensure_ascii=False, indent=2))
    print(f"  ✓ Benchmark 写入: {bm_path.relative_to(WORKSPACE)}")
    print(f"  collected P50={round(p50_c)} P75={round(p75_c)} P90={round(p90_c)} P95={round(p95_c)}")

    print("\n" + "=" * 50)
    print("Step 6: 标准化 + 分级")
    print("=" * 50)

    scores = [signal_score(m) for m in metrics_list]
    max_score = max(scores) if scores else 9.21
    norm_factor = 100 / max_score if max_score > 0 else 1

    tier_counts = {"S":0,"A":0,"B":0,"C":0}
    for note, m, sc in zip(notes, metrics_list, scores):
        t = tier(m["collected"], p95_c, p90_c, p75_c)
        norm_score = round(sc * norm_factor, 1)
        tier_counts[t] += 1

        # 写回 meta.json
        note["material_tier"] = t
        note["signal_score"]  = norm_score
        note["metrics"]       = m
        path = Path(note["_path"])
        # 只写有意义字段，去掉内部字段
        out = {k: v for k, v in note.items() if not k.startswith("_")}
        path.write_text(json.dumps(out, ensure_ascii=False, indent=2))

    print(f"  分级结果: S={tier_counts['S']} A={tier_counts['A']} B={tier_counts['B']} C={tier_counts['C']}")

    print("\n" + "=" * 50)
    print("Step 7: 风险过滤")
    print("=" * 50)
    BLOCKED_DIR.mkdir(parents=True, exist_ok=True)
    blocked = 0
    for note in notes:
        if note.get("_type") != "image_text": continue
        hit = risk_check(note)
        if hit:
            src = Path(note["_path"])
            dst = BLOCKED_DIR / src.name
            shutil.move(str(src), str(dst))
            # 更新 tier
            meta = json.loads(dst.read_text())
            meta["material_tier"] = "blocked"
            meta["blocked_reason"] = hit
            dst.write_text(json.dumps(meta, ensure_ascii=False, indent=2))
            print(f"  → blocked: {src.name} (命中: {hit})")
            blocked += 1
    if blocked == 0:
        print("  ✓ 无风险内容")
    else:
        print(f"  共移出 {blocked} 条至 image_text_blocked/")

    print("\n" + "=" * 50)
    print("完成")
    print("=" * 50)

if __name__ == "__main__":
    main()
