#!/usr/bin/env python3
"""
小林说财经笔记采集 + 图片下载一体化脚本
目标博主: 小Lin说 (5abf90244eacab2c32c7c5e6)
输出结构:
  hand-on-off/source_material/xhs/finance/image_text/{note_id}.json
  hand-on-off/source_material/xhs/finance/video/{note_id}/meta.json
  hand-on-off/source_material/xhs/finance/image_text/{note_id}/images/{n}.jpg
"""

import asyncio
import json
import sys
import time
from datetime import date
from pathlib import Path

# ── 路径 ──────────────────────────────────────────────────────────────────────
WORKSPACE     = Path("/home/node/.openclaw/workspace")
HAND_ON_OFF   = WORKSPACE / "hand-on-off"
FINANCE_BASE  = HAND_ON_OFF / "source_material/xhs/finance"
IMAGE_TEXT_DIR = FINANCE_BASE / "image_text"
VIDEO_DIR      = FINANCE_BASE / "video"
SCRAPER_DIR    = HAND_ON_OFF / "tools/xhs_scraper/xhs-scraper-skill/scripts"

sys.path.insert(0, str(SCRAPER_DIR))

# ── 参数 ──────────────────────────────────────────────────────────────────────
USER_ID       = "5abf90244eacab2c32c7c5e6"
CREATOR_NAME  = "小Lin说"
MAX_NOTES     = 100  # 建立 Benchmark 需要 100 条

# ── Cookie 加载（复用 scrape_two_stage 的逻辑）────────────────────────────────
from scrape_two_stage import _load_cookie, get_note_list, get_note_detail

import aiohttp

async def download_image(session: aiohttp.ClientSession, url: str, dest: Path) -> bool:
    if dest.exists():
        return True
    for fmt_url in [url.replace("/webp", "/jpg"), url]:
        try:
            async with session.get(
                fmt_url,
                timeout=aiohttp.ClientTimeout(total=20),
                headers={"Referer": "https://www.xiaohongshu.com/"},
            ) as resp:
                if resp.status == 200:
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    dest.write_bytes(await resp.read())
                    return True
        except Exception:
            continue
    return False


async def main():
    IMAGE_TEXT_DIR.mkdir(parents=True, exist_ok=True)
    VIDEO_DIR.mkdir(parents=True, exist_ok=True)

    cookie, cookie_source = _load_cookie()
    if not cookie:
        print("× Cookie 加载失败")
        sys.exit(1)
    print(f"✓ Cookie: {cookie_source} ({len(cookie)} chars)")

    # Stage 1 — 获取笔记列表
    note_list = await get_note_list(USER_ID, cookie, MAX_NOTES)
    if not note_list:
        print("× Stage 1 失败，退出")
        sys.exit(1)

    ok_count = 0
    skip_count = 0
    img_ok = 0
    img_fail = 0

    print(f"\n开始 Stage 2 + 图片下载，共 {len(note_list)} 条笔记\n")

    async with aiohttp.ClientSession() as img_session:
        for i, note in enumerate(note_list, 1):
            note_id    = note.get("note_id", "")
            xsec_token = note.get("xsec_token", "")
            title_prev = note.get("display_title", "")[:20]
            is_video   = note.get("type") == "video"

            # 目标路径
            if is_video:
                dest_json = VIDEO_DIR / note_id / "meta.json"
            else:
                dest_json = IMAGE_TEXT_DIR / f"{note_id}.json"

            # 已采集则跳过 Stage 2，但仍检查图片
            if dest_json.exists():
                print(f"[{i}/{len(note_list)}] ↷ 已存在: {note_id} ({title_prev})")
                # 补下载图片（如果目录缺失）
                detail = json.loads(dest_json.read_text())
                images = detail.get("image_list", [])
                if images and not is_video:
                    img_dir = IMAGE_TEXT_DIR / note_id / "images"
                    for j, img in enumerate(images):
                        url = img.get("url", "")
                        if not url:
                            continue
                        dest_img = img_dir / f"{j+1}.jpg"
                        ok = await download_image(img_session, url, dest_img)
                        if ok: img_ok += 1
                        else:  img_fail += 1
                skip_count += 1
                continue

            print(f"[{i}/{len(note_list)}] {note_id}  {title_prev}...")
            detail = await get_note_detail(note_id, xsec_token, cookie)
            if not detail:
                print(f"  × 获取详情失败")
                await asyncio.sleep(2)
                continue

            # 写入 JSON
            dest_json.parent.mkdir(parents=True, exist_ok=True)
            dest_json.write_text(
                json.dumps(detail, ensure_ascii=False, indent=2),
                encoding="utf-8"
            )
            print(f"  ✓ JSON 保存: {dest_json.relative_to(WORKSPACE)}")

            # 下载图片（图文类）
            images = detail.get("image_list", [])
            if images and not is_video:
                img_dir = IMAGE_TEXT_DIR / note_id / "images"
                print(f"  → 下载 {len(images)} 张图片...")
                for j, img in enumerate(images):
                    url = img.get("url", "")
                    if not url:
                        continue
                    dest_img = img_dir / f"{j+1}.jpg"
                    ok = await download_image(img_session, url, dest_img)
                    if ok:
                        img_ok += 1
                    else:
                        img_fail += 1
                        print(f"    × 图片 {j+1} 下载失败: {url[:60]}")
                print(f"  ✓ 图片完成: {img_ok} 成功")

            ok_count += 1
            await asyncio.sleep(2)

    print("\n" + "=" * 50)
    print(f"采集完成")
    print(f"  新增笔记: {ok_count}")
    print(f"  已跳过:   {skip_count}")
    print(f"  图片下载: 成功 {img_ok} / 失败 {img_fail}")
    print(f"  输出目录: {FINANCE_BASE.relative_to(WORKSPACE)}")


if __name__ == "__main__":
    asyncio.run(main())
