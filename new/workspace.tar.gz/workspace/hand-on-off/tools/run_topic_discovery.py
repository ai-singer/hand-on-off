#!/usr/bin/env python3
"""
Topic-Based Discovery：Playwright 拦截 XHS 搜索 XHR，获取财经图文笔记候选
然后 Stage 2 获取详情，归一化分级，写入 finance/image_text/
"""
import asyncio
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

# ── 路径 ──────────────────────────────────────────────────────────────────────
WORKSPACE      = Path("/home/node/.openclaw/workspace")
HAND_ON_OFF    = WORKSPACE / "hand-on-off"
FINANCE_BASE   = HAND_ON_OFF / "source_material/xhs/finance"
IMAGE_TEXT_DIR = FINANCE_BASE / "image_text"
BLOCKED_DIR    = FINANCE_BASE / "image_text_blocked"
RAW_DIR        = WORKSPACE / "source_material/xhs/raw"
REGISTRY_DIR   = HAND_ON_OFF / "source_material/xhs/creator_registry"
BENCHMARK_PATH = REGISTRY_DIR / "linshuo_benchmark.json"
COOKIE_PATH    = WORKSPACE / "xiaohongshu_cookies.txt"
SCRAPER_DIR    = HAND_ON_OFF / "tools/xhs_scraper/xhs-scraper-skill/scripts"

sys.path.insert(0, str(SCRAPER_DIR))
from scrape_two_stage import _load_cookie, get_note_detail

# ── 配置 ──────────────────────────────────────────────────────────────────────
SEARCH_KEYWORDS = ["商业分析", "财务知识", "企业经营", "商业逻辑", "公司案例"]
CHROMIUM_PATH   = "/usr/bin/chromium"
PAGE_WAIT_SEC   = 6
NOTE_DELAY_SEC  = 3

RISK_KEYWORDS = [
    "股票","炒股","A股","选股","个股","持仓","仓位",
    "投资建议","投资推荐","交易策略","买卖信号",
    "理财产品","基金推荐","证券","期货操作",
    "暴富","一夜暴富","躺赚","被动收入",
    "财务自由","财富自由",
]

# ── Cookie 解析 ───────────────────────────────────────────────────────────────
def load_cookie_list():
    content = COOKIE_PATH.read_text(encoding="utf-8").strip()
    cookies = []
    for line in content.splitlines():
        if line.strip() and not line.startswith("#"):
            parts = line.split("\t")
            if len(parts) >= 7:
                cookies.append({
                    "name": parts[5], "value": parts[6],
                    "domain": ".xiaohongshu.com", "path": "/",
                })
    return cookies

def load_cookie_str():
    cookie, _ = _load_cookie()
    return cookie

# ── Playwright 搜索拦截（Async）────────────────────────────────────────────────
async def search_notes_playwright(keywords: list[str]) -> list[dict]:
    from playwright.async_api import async_playwright
    import urllib.parse

    all_candidates = []
    seen_ids = set()

    cookies = load_cookie_list()

    async with async_playwright() as p:
        browser = await p.chromium.launch(
            executable_path=CHROMIUM_PATH,
            headless=True,
            args=["--no-sandbox", "--disable-dev-shm-usage"]
        )
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
            viewport={"width": 1280, "height": 800},
        )
        await context.add_cookies(cookies)

        # 先访问主页建立 session
        page = await context.new_page()
        print("  → 建立 XHS session...")
        try:
            await page.goto("https://www.xiaohongshu.com/explore", timeout=20000)
            await page.wait_for_timeout(3000)
        except Exception as e:
            print(f"  ⚠ 主页加载异常: {e}")
        await page.close()

        for kw in keywords:
            candidates = []

            async def on_response(resp):
                try:
                    if "search/notes" in resp.url and resp.status == 200:
                        data = await resp.json()
                        items = data.get("data", {}).get("items", [])
                        for item in items:
                            # v2 API: item.id + item.note_card
                            note_card  = item.get("note_card", {})
                            note_id    = item.get("id") or note_card.get("note_id")
                            xsec_token = item.get("xsec_token") or note_card.get("xsec_token", "")
                            title      = note_card.get("display_title") or note_card.get("title", "")
                            note_type  = note_card.get("type", "")
                            if note_id and note_id not in seen_ids:
                                if note_type != "video":
                                    candidates.append({
                                        "note_id": note_id,
                                        "xsec_token": xsec_token,
                                        "display_title": title,
                                    })
                                    seen_ids.add(note_id)
                except Exception:
                    pass

            search_page = await context.new_page()
            search_page.on("response", on_response)
            encoded_kw = urllib.parse.quote(kw)
            url = f"https://www.xiaohongshu.com/search_result?keyword={encoded_kw}&type=51"
            print(f"  → 搜索: {kw} ...")
            try:
                await search_page.goto(url, timeout=20000)
                await search_page.wait_for_timeout(PAGE_WAIT_SEC * 1000)
            except Exception as e:
                print(f"    ⚠ 搜索页异常: {e}")
            await search_page.close()

            print(f"    ✓ 捕获图文候选: {len(candidates)} 条")
            all_candidates.extend(candidates)
            await asyncio.sleep(3)

        await browser.close()

    print(f"\n  总候选: {len(all_candidates)} 条（去重后）")
    return all_candidates


# ── 分级 ─────────────────────────────────────────────────────────────────────
import math

def parse_count(v):
    if v is None: return 0
    try: return int(str(v).replace(",","").replace("+","").strip())
    except: return 0

def load_benchmark():
    if BENCHMARK_PATH.exists():
        bm = json.loads(BENCHMARK_PATH.read_text())
        return bm["benchmark"]
    return None

def tier_note(collected, bm):
    if bm is None: return "C"
    p95 = bm["collected"]["p95"]
    p90 = bm["collected"]["p90"]
    p75 = bm["collected"]["p75"]
    if collected >= p95: return "S"
    if collected >= p90: return "A"
    if collected >= p75: return "B"
    return "C"

def signal_score(m):
    return (
        math.log1p(m["collected"]) * 0.35 +
        math.log1p(m["share"])     * 0.30 +
        math.log1p(m["comment"])   * 0.25 +
        math.log1p(m["liked"])     * 0.10
    )

def account_factor(bm, note_collected_list):
    if not note_collected_list or bm is None: return 1.0
    ext_avg = sum(note_collected_list) / len(note_collected_list)
    lin_avg = bm["avg"]["collected"]
    if lin_avg == 0: return 1.0
    return ext_avg / lin_avg

def risk_check(note):
    text = (note.get("title","") + note.get("desc",""))
    for kw in RISK_KEYWORDS:
        if kw in text:
            return kw
    return None


# ── 主流程 ───────────────────────────────────────────────────────────────────
async def main():
    IMAGE_TEXT_DIR.mkdir(parents=True, exist_ok=True)
    BLOCKED_DIR.mkdir(parents=True, exist_ok=True)
    RAW_DIR.mkdir(parents=True, exist_ok=True)

    # 已存在 note_id
    existing = {p.stem for p in IMAGE_TEXT_DIR.glob("*.json")}
    existing |= {p.stem for p in BLOCKED_DIR.glob("*.json")}
    print(f"已存在图文: {len(existing)} 条\n")

    # Step 1: Playwright 搜索
    print("=" * 50)
    print("Step 1: Playwright 搜索候选")
    print("=" * 50)
    candidates = await search_notes_playwright(SEARCH_KEYWORDS)

    # 去掉已存在的
    candidates = [c for c in candidates if c["note_id"] not in existing]
    print(f"  新候选（去重后）: {len(candidates)} 条\n")

    if not candidates:
        print("无新候选，退出")
        return

    # 保存候选列表
    raw_file = RAW_DIR / f"xhs_finance_image_candidates_{datetime.now().strftime('%Y%m%d')}.json"
    raw_file.write_text(json.dumps(candidates, ensure_ascii=False, indent=2))
    print(f"  候选保存: {raw_file.relative_to(WORKSPACE)}\n")

    # Step 2: Stage 2 获取详情
    print("=" * 50)
    print("Step 2: Stage 2 获取详情")
    print("=" * 50)
    cookie_str = load_cookie_str()
    bm = load_benchmark()

    details = []
    collected_vals = []

    for i, cand in enumerate(candidates, 1):
        note_id    = cand["note_id"]
        xsec_token = cand.get("xsec_token", "")
        title_prev = cand.get("display_title", "")[:25]
        print(f"[{i}/{len(candidates)}] {note_id} {title_prev}...")

        detail = await get_note_detail(note_id, xsec_token, cookie_str)
        if not detail:
            print("  × 失败")
            await asyncio.sleep(NOTE_DELAY_SEC)
            continue

        info = detail.get("interact_info", {})
        collected = parse_count(info.get("collected_count", 0))
        collected_vals.append(collected)
        details.append((note_id, detail, collected))
        print(f"  ✓ collected={collected} title={detail.get('title','')[:30]}")
        await asyncio.sleep(NOTE_DELAY_SEC)

    print(f"\n  Stage 2 成功: {len(details)}/{len(candidates)} 条")

    # Step 3: 外部账号归一化 + 分级 + 风险过滤
    print("\n" + "=" * 50)
    print("Step 3: 归一化分级 + 风险过滤")
    print("=" * 50)

    af = account_factor(bm, collected_vals)
    print(f"  Account Factor: {af:.2f} (外部均值/小Lin说均值)")

    tier_counts = {"S":0,"A":0,"B":0,"C":0,"blocked":0}
    sa_count = 0

    for note_id, detail, raw_collected in details:
        adj_collected = int(raw_collected / af) if af > 0 else raw_collected
        t = tier_note(adj_collected, bm)

        info = detail.get("interact_info", {})
        m = {
            "liked":     parse_count(info.get("liked_count", 0)),
            "collected": raw_collected,
            "comment":   parse_count(info.get("comment_count", 0)),
            "share":     parse_count(info.get("share_count", 0)),
        }
        sc = round(signal_score(m), 1)

        detail["material_tier"]    = t
        detail["signal_score"]     = sc
        detail["metrics"]          = m
        detail["adj_collected"]    = adj_collected
        detail["account_factor"]   = round(af, 2)

        # 风险过滤
        hit = risk_check(detail)
        if hit:
            dest = BLOCKED_DIR / f"{note_id}.json"
            detail["material_tier"] = "blocked"
            detail["blocked_reason"] = hit
            dest.write_text(json.dumps(detail, ensure_ascii=False, indent=2))
            tier_counts["blocked"] += 1
            print(f"  → blocked: {note_id} (命中: {hit})")
        else:
            dest = IMAGE_TEXT_DIR / f"{note_id}.json"
            dest.write_text(json.dumps(detail, ensure_ascii=False, indent=2))
            tier_counts[t] += 1
            if t in ("S","A"):
                sa_count += 1
                print(f"  [{t}] {detail.get('title','')[:35]} adj_collected={adj_collected}")

    print(f"\n  分级: S={tier_counts['S']} A={tier_counts['A']} B={tier_counts['B']} C={tier_counts['C']} blocked={tier_counts['blocked']}")
    print(f"  S/A 入库: {sa_count} 条")
    print("\n✓ Topic-Based Discovery 完成")


if __name__ == "__main__":
    asyncio.run(main())
