#!/usr/bin/env python3
"""
Step 9: 从视频 S/A 级素材提取话题候选，追加到 topic_pool.json
"""
import json
from datetime import datetime, timezone
from pathlib import Path

WORKSPACE   = Path("/home/node/.openclaw/workspace")
HAND_ON_OFF = WORKSPACE / "hand-on-off"
VIDEO_DIR   = HAND_ON_OFF / "source_material/xhs/finance/video"
POOL_PATH   = HAND_ON_OFF / "source_material/xhs/creator_registry/topic_pool.json"

# 已有 note_id 集合（避免重复）
existing = set()
if POOL_PATH.exists():
    pool = json.loads(POOL_PATH.read_text())
    existing = {e["note_id"] for e in pool}
else:
    pool = []

# S/A 视频笔记
candidates = []
for p in sorted(VIDEO_DIR.iterdir()):
    meta_path = p / "meta.json"
    if not meta_path.exists():
        continue
    d = json.loads(meta_path.read_text())
    if d.get("material_tier") not in ("S", "A"):
        continue
    if p.name in existing:
        continue
    candidates.append((p.name, d))

print(f"待处理新 S/A 视频: {len(candidates)} 条\n")

# 规则映射表：根据 title 关键词推断 topic/angle/mechanism/hook
def infer_topic(title, tags):
    t = title + " " + " ".join(tags)
    
    rules = [
        (["外卖","美团","饿了么","罚"], "平台经济监管机制", "平台垄断与反垄断执法逻辑", "平台被罚35亿，监管到底在管什么？", "外卖平台的商业模式与监管博弈"),
        (["百亿企业","家族企业","上班"], "家族企业治理结构", "家族企业的权力结构与职业经理人困局", "在自家百亿企业打工是什么感受？", "家族企业的股权与治理机制"),
        (["特朗普","收入","赚钱"], "政商结合与权力变现机制", "政治人物的商业收入来源与利益结构", "总统是怎么用权力赚钱的？", "政商关系与利益输送机制"),
        (["药价","药","谈判","医保"], "医药定价机制与医保谈判", "药品定价背后的利益博弈", "同一款药为什么价格差这么多？", "医保谈判与药价形成机制"),
        (["并购","收购","马斯克"], "企业并购机制与资本整合", "全球最大并购案的商业逻辑", "为什么大公司热衷于买买买？", "并购溢价、整合逻辑与资本套利"),
        (["养老金","退休","社保"], "养老金制度与退休收入机制", "养老金的计算逻辑与制度设计", "退休后每月能领多少？怎么算的？", "养老金替代率与退休保障机制"),
        (["AI","资本","大模型","估值"], "AI产业资本化机制", "AI公司的估值逻辑与资本涌入原因", "AI公司凭什么值那么多钱？", "AI商业化路径与资本估值逻辑"),
        (["保险","不倒","爆雷"], "保险业稳定性机制", "保险公司为何在金融风暴中屹立不倒", "银行倒了保险还在，为什么？", "保险偿付机制与监管框架"),
        (["Deepseek","梁文锋","融资"], "AI独角兽融资逻辑", "Deepseek连续融资背后的产业信号", "Deepseek为什么这么值钱？", "大模型商业化与资本押注逻辑"),
        (["Kimi","月之暗面","大模型"], "国产大模型竞争格局", "Kimi引发中美关注的技术与商业逻辑", "一个中国AI为什么让美国紧张？", "大模型技术突破与地缘竞争"),
    ]
    
    for keywords, topic, mechanism, hook, angle in rules:
        if any(kw in t for kw in keywords):
            return topic, angle, mechanism, hook
    
    # 默认：用 title 本身
    return (
        title[:20] + "的商业机制",
        "普通人视角的机制解析",
        "商业逻辑与利益结构",
        title[:25] + "，背后是什么逻辑？"
    )

added = 0
for note_id, d in candidates:
    title = d.get("title", "")
    tags  = [t.get("name","") for t in d.get("tag_list", [])]
    info  = d.get("interact_info", {})
    topic, angle, mechanism, hook = infer_topic(title, tags)
    
    entry = {
        "note_id": note_id,
        "material_tier": d.get("material_tier"),
        "signal_score": d.get("signal_score", 0),
        "source_title": title,
        "metrics": d.get("metrics", {}),
        "topic": topic,
        "angle": angle,
        "mechanism": mechanism,
        "content_hook": hook,
        "tags": tags,
        "source_url": f"https://www.xiaohongshu.com/explore/{note_id}",
        "extracted_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    pool.append(entry)
    print(f"  [{d.get('material_tier')}] {title[:35]}")
    print(f"       topic: {topic}")
    print(f"       hook:  {hook}")
    print()
    added += 1

POOL_PATH.write_text(json.dumps(pool, ensure_ascii=False, indent=2))
print(f"✓ topic_pool.json 更新完成，新增 {added} 条，共 {len(pool)} 条")
