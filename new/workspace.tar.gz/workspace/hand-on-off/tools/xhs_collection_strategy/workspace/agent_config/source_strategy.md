# Source Strategy v2.0

# Source Purpose

The Agent must base publishable content on reliable source materials.

Source strategy defines:

- Where information comes from.
- How source information is extracted.
- What conditions are required before generation.

---

# Source Layer Architecture

Sources are divided into two distinct layers with different roles.

They must never be mixed.

---

## Layer 1: Discovery Layer

Purpose:

Discover what users care about.

Not for:

Providing facts, data, or knowledge.

Sources:

- Social platforms (e.g., Xiaohongshu, Weibo, short video platforms)
- Content aggregators
- Comment sections and discussion threads

What to extract:

- User questions and confusion
- High-frequency pain points
- Cognitive conflicts (A appears true, but B also happens)
- High-engagement topics and content patterns
- Recurring discussion themes

Output:

topic_candidate

Fields:

- topic
- user_question
- engagement_signals
- audience_pain_point
- cognitive_conflict
- content_pattern_notes

Prohibited:

- Treat platform content as factual evidence
- Directly rewrite popular posts
- Use creator opinions as verified conclusions
- Treat engagement metrics as proof of truth

---

## Layer 2: Evidence Layer

Purpose:

Provide verified facts, data, and mechanism explanations for topics.

Sources:

### Primary Sources (Highest Priority)

- Official company filings (annual reports, quarterly reports, prospectuses)
- Government announcements and regulatory documents
- Official statistical releases
- Investor relations materials

### Secondary Sources

- Industry research reports
- Academic papers and business research
- International institution data
- Professional analysis from established research organizations

Prohibited:

- Use social platform content as evidence
- Use unattributed statistics
- Use individual opinions as factual conclusions
- Collect or use content related to: stock picking, investment advice, trading strategies, wealth management products, get-rich-quick methods, or any content that could constitute financial advice
- Collect or use content involving sensitive topics: political commentary, social controversies, religious content, ethnic issues, or any content that could trigger platform moderation or legal risk

Reason:

As a virtual content creator, the Agent must proactively avoid legal risk.
Content that implies investment recommendations may violate financial regulations.
Content touching sensitive topics may trigger platform removal or regulatory action.
Both categories expose the creator identity to liability.

---

# Social Platform Material Classification

Social platform materials fall into two types with different handling rules.

---

## Type A: Video Content

Role:

Topic discovery only.

Extract:

- Title and subject
- Comment themes
- User questions and confusion
- Cognitive conflicts

Do not extract:

- Factual claims
- Data or statistics
- Opinions presented as conclusions

Reason:

Video content has high transmission value but low fact density and structural stability.

---

## Type B: Text and Image Content

Role:

Knowledge structure learning and expression pattern reference.

Extract:

### Structure Layer
- Title patterns
- Opening approaches
- Information sequencing
- Closing methods
- User cognitive path

### Cognition Layer
- User misconceptions
- Core questions being addressed
- Explanation models used
- Key concepts introduced

### Expression Layer
- Chart and visual types
- Information density
- Case usage patterns
- Visual structure

Do not extract:

- Unverified data
- Personal judgments
- Emotional conclusions
- Claims without attributed sources

---

# Material Value Scoring

## Core Principle

Absolute traffic numbers cannot be used across accounts.
Accounts differ in follower base, weight, and platform recommendation pool.

Use: Account-normalized relative performance comparison.
Not: Platform-wide absolute ranking.

---

## Step 1: Build Account Benchmark

Collect the target account's (小Lin说) historical content metrics:

- liked_count
- collected_count
- comment_count
- share_count

Compute distribution percentiles per metric:

- P50 (median baseline)
- P75
- P90
- P95

This forms the Account Benchmark Distribution.

---

## Step 2: Account Factor for External Content

When evaluating content from other accounts:

```
Account Factor = Other Account Avg Performance / 小Lin说 Avg Performance

Adjusted Performance = Raw Performance ÷ Account Factor
```

Large accounts (Account Factor > 1): downweight.
Small/mid accounts (Account Factor ≈ 1): full weight.

---

## Step 3: Tier Classification

### Video (Topic Discovery)

| Tier | Condition | Action |
|------|-----------|--------|
| S | Adjusted performance ≥ P95 AND collected/share strong AND business mechanism space exists | Priority topic pool |
| A | Adjusted performance ≥ P90 AND topic clear | Research pool |
| B | High engagement but low collected (trending/emotional) | Trend observation only |
| C | Performance driven by account size only, no adjusted advantage | Discard |

### Image/Text (Knowledge Distillation)

Primary metric: collected_rate (collected / views if available, else collected count)

| Tier | Condition | Action |
|------|-----------|--------|
| S | Adjusted collected_rate ≥ P95 | Priority distillation |
| A | Adjusted collected_rate ≥ P90 | Distillation pool |
| B | Moderate collected, high comment quality | Reference |
| C | Low collected, no adjusted advantage | Discard |

---

## Final Value Formula

```
Material Value =
  Relative Performance (normalized)
  + User Value Signal (collected > share > comment > liked)
  + Business Mechanism Space
  + Evidence Producibility
```

Goal: Find content that, if produced by 小Lin说 on the same topic,
would most likely exceed the account's own average performance.

---

## Content Signal Score (legacy, used for quick sorting)

Used to determine whether a piece of social platform material enters the topic pool.

Default weights:

- Save rate: 35%
- Share rate: 30%
- Comment quality: 25%
- Like rate: 10%

Content Signal Score:

```
Save signal × 35%
+ Share signal × 30%
+ Comment quality × 25%
+ Like signal × 10%
```

## Indicator Explanations

### Save (Highest Weight)

Indicates the user believes the content has long-term utility.

High-value signals:

- Frameworks and models
- Methodologies
- Structured knowledge
- Explanations of mechanisms

### Share (Second Weight)

Indicates the content has social transmission value.

High-value topics:

- Operational logic
- Real cases
- Industry changes
- Counterintuitive insights

### Comment Quality (Third Weight)

Quantity does not matter. Quality does.

High-quality comments:

- Ask follow-up questions
- Contribute additional cases
- Express disagreement or confusion
- Share relevant personal experience

Low-quality comments:

- Simple affirmations ("learned something", "great post")
- Emoji-only responses

Evaluation:

```
Comment quality = High-quality comments / Total comments
```

### Like (Lowest Weight)

Indicates immediate first-impression approval only.

Use only to judge:

- Title appeal
- Surface-level interest
- Emotional response

Cannot be used as the primary topic selection signal.

---

# Material Priority Tiers

## S-Tier

Characteristics:

- High save rate
- High share rate
- Deep, substantive comments
- Verifiable evidence sources exist

Action:

Enter priority production pool.

---

## A-Tier

Characteristics:

- Clear user interest
- Mechanism explanation space exists

Action:

Enter research pool.

---

## B-Tier

Characteristics:

- High engagement
- Primarily emotion-driven spread

Action:

Use as trend observation only.

---

## C-Tier

Characteristics:

- Pure trending topic
- No long-term value
- No explanation space

Action:

Discard.

---

# Topic Gate

Any topic must pass all checks before entering production:

```
Is this a real user concern?
↓
Is there a mechanism explanation space?
↓
Can reliable evidence be found?
↓
Can a structured analysis be formed?
↓
Can it be expressed visually?
↓
Can an ordinary user understand it?
```

All checks must pass before entering Research.

---

# Source Hierarchy

## Primary Source

Definition:

The main reference used for factual content production.

Priority:

- Official company filings
- Government statistical releases
- Verified institutional data
- First-hand project documentation

Required fields:

```yaml
source_material:
  source_url:
  organization:
  publication_date:
  extracted_facts:
  key_points:
  verification_status:
```

---

## Secondary Source

Definition:

Additional sources used for cross-verification, supplementary context, or alternative perspectives.

Rules:

Secondary sources cannot replace missing primary evidence for important claims.

---

# Source Gate

Before generating a final publishable draft:

Required:

source_material must exist.

Minimum information:

- Source URL or identifiable origin
- Issuing organization
- Publication date (if available)
- Extracted facts
- Verification status

---

# Generation Permission

## With Valid Source Material

Allowed:

- Generate draft content
- Transform expression style
- Adjust structure
- Create visual plan

## Without Valid Source Material

Allowed:

- Topic analysis
- Outline generation
- Research planning

Not allowed:

- Final publishable content
- Unsupported factual claims
- Invented examples presented as facts

---

# Information Extraction Rules

Extract:

## Facts

Information directly supported by source.

## Key Points

The core value of the source:

- Problem identified
- Data presented
- Mechanism explained
- Result demonstrated

## User Value

Identify:

- Why users should care
- What users can learn
- What problem this solves

---

# Transformation Boundary

The Agent may change:

- Writing style
- Narrative structure
- Explanation order

The Agent must preserve:

- Core facts
- Source meaning
- Important limitations and caveats

The Agent must not:

- Invent personal experience
- Add unsupported statistics
- Create fabricated quotations
- Attribute opinions without evidence

---

# Fact and Interpretation Separation

Source Fact:

Directly supported by source material.

Agent Interpretation:

Analysis or explanation generated by the Agent.

Rule:

Interpretation must not be presented as source fact.

---

# Source Validation

Before publishing check:

□ Source exists.

□ Claims can be traced to source.

□ Numbers have attributed evidence.

□ Personal statements have attribution.

□ No unverified platform content used as fact.

---

# Failure Routing

Missing source:

→ Stop final generation.

Unsupported claim:

→ Send to review_rules.md.

Source quality issue:

→ Update source_strategy.md.

---

# Responsibility Boundary

source_strategy.md defines:

- Source layer architecture
- Source selection and prioritization
- Material classification and scoring
- Topic gate criteria
- Source validation requirements
- Information extraction rules

source_strategy.md does not define:

- Writing style
- Visual design
- Publishing workflow
- Platform-specific content rules
