# creator_registry/

XHS 候选博主注册表。

## 文件

- `candidate_registry.json` — 候选博主总表

## 字段说明

| 字段 | 说明 |
|---|---|
| `creator_id` | 唯一标识，格式 `xhs_{user_id}` |
| `creator_name` | 小红书昵称 |
| `user_id` | 小红书 user_id，从主页 URL 提取 |
| `profile_url` | 主页 URL |
| `category` | 内容品类（geography / cultural_heritage / nature_wildlife / travel / history / science / lifestyle / art） |
| `sub_category` | 子品类，自由填写 |
| `source` | 候选来源（manual / search_xhs / competitor / trending / referral） |
| `popularity_signal` | 热度信号（followers / avg_likes / avg_collects / signal_source） |
| `learning_value` | 学习价值（content_originality / post_frequency / style_distinctiveness / relevance / reason） |
| `collect_priority` | 采集优先级 1–5，5 最高 |
| `status` | candidate → resolved → collecting → done |
| `added_at` | 加入时间（ISO8601 UTC） |
| `last_collected_at` | 最近采集时间 |
| `notes` | 人工备注 |

## 如何添加新博主

1. 从小红书主页 URL 获取 `user_id`：
   ```
   https://www.xiaohongshu.com/user/profile/{user_id}
   ```

2. 在 `candidate_registry.json` 中追加一条记录，`status` 设为 `candidate`

3. 运行 Collector 采集：
   ```bash
   python3 ~/.openclaw/skills/xhs-scraper-skill/scripts/scrape_two_stage.py \
     --user-id <user_id> \
     --creator-name <name> \
     --max-notes 100 \
     --output-dir ~/workspace/source_material/xhs/raw/
   ```

4. 采集完成后将 `status` 更新为 `done`，填写 `last_collected_at`
