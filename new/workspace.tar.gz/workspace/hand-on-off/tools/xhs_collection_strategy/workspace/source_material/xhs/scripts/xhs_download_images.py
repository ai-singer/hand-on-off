# XHS Image Downloader Skill
# 小红书图片下载 - Playwright 浏览器上下文方案
# Version: v1.0 | 2026-09-22

---
name: xhs-image-downloader
description: 使用 Playwright 浏览器上下文在服务端下载小红书图片。需要有效 Cookie。已验证失败方案已记录，勿重试。
allowed-tools: Bash, Read
---

# 前置条件

## 依赖
```bash
pip install playwright
playwright install chromium
# 或指定路径安装：
PLAYWRIGHT_BROWSERS_PATH=/home/node/.playwright playwright install chromium
```

## Cookie
- 存放于：`~/workspace/xiaohongshu_cookies.txt`（Netscape 格式）
- Cookie 有效期约 30 天，失效后需重新导出

---

# 关键结论（重要，先读）

## ✅ 可行方案

**Playwright 同一浏览器 Context 内请求图片 URL**

原理：
- 用 Playwright 打开小红书页面，拦截页面发出的 `sns-webpic-qc.xhscdn.com` 响应
- 在**同一个 browser context** 内新建 page，请求拦截到的 URL
- 因为共享浏览器 Cookie/Session，CDN 允许访问，返回 200

```python
# 关键代码模式
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    context = browser.new_context(...)
    context.add_cookies(cookies)

    page = context.new_page()
    img_urls = []
    page.on("response", lambda r: img_urls.append(r.url) if "sns-webpic" in r.url else None)
    page.goto(f"https://www.xiaohongshu.com/explore/{note_id}")

    # ✅ 在同一 context 内下载
    img_page = context.new_page()
    resp = img_page.goto(img_urls[0])
    body = resp.body()  # 成功获取图片字节
```

## ❌ 已验证失败方案（不要重试）

| 方案 | 结果 | 原因 |
|------|------|------|
| `curl` 直接请求 CDN URL | 403 | IP 白名单，外部 IP 拒绝 |
| `curl` + Cookie 请求 CDN URL | 403 | CDN 层不验证 Cookie |
| `curl` + Referer 请求 CDN URL | 403 | 同上 |
| Stage 2 存入的图片 URL 延迟请求 | 403 | URL 含时效签名，采集后很快过期 |
| Playwright headless 访问笔记页 | 「页面不见了」 | 批量访问后 IP 被临时封禁 |
| yt-dlp 下载视频 | No video formats found | XHS 提取器不支持当前页面结构 |
| Playwright 视频 CDN 拦截 | 无媒体请求 | 批量采集后 IP 被封，页面不渲染视频 |

---

# IP 风控注意事项

## 触发条件
- 短时间内请求大量 note_id（Stage 1+2 采集 100 条后）
- Playwright 连续访问多个笔记页面
- 触发后：所有 `/explore/{note_id}` 返回「页面不见了」

## 恢复方法
1. 停止所有访问，等待 12–24 小时自然恢复
2. 更换 Cookie（从浏览器重新导出）
3. 更换 IP（代理/VPN）

## 速率限制（必须遵守）
- 笔记详情 (Stage 2)：每条间隔 ≥ 3 秒
- 图片下载：每批 ≤ 10 张，间隔 ≥ 3 秒
- Playwright 笔记页访问：每条间隔 ≥ 5 秒，单次 session ≤ 20 条
- Stage 1+2 采集完后，建议间隔 ≥ 30 分钟再做 Playwright 访问

---

# 完整图片下载脚本

```python
"""
xhs_download_images.py
用途：批量下载小红书图文笔记图片
前提：已完成 Stage 2 采集，meta.json 含图片 URL
"""

import json, time
from pathlib import Path
from playwright.sync_api import sync_playwright

WORKSPACE = Path("/home/node/.openclaw/workspace")
COOKIE_PATH = WORKSPACE / "xiaohongshu_cookies.txt"
FINANCE_IMG_DIR = WORKSPACE / "source_material/xhs/finance/image_text"
OUTPUT_BASE = WORKSPACE / "source_material/xhs/finance/image_text_imgs"

BATCH_SIZE = 10       # 每批最多下载图片数
DELAY_PER_IMG = 3     # 每张图片间隔秒数
DELAY_PER_NOTE = 5    # 每条笔记间隔秒数
MAX_NOTES_PER_SESSION = 20  # 每次 Playwright session 最多处理笔记数


def load_cookies():
    content = COOKIE_PATH.read_text().strip()
    cookies = []
    for line in content.splitlines():
        if line.strip() and not line.startswith("#"):
            parts = line.split("\t")
            if len(parts) >= 7:
                cookies.append({
                    "name": parts[5], "value": parts[6],
                    "domain": ".xiaohongshu.com", "path": "/"
                })
    return cookies


def download_note_images(context, note_id, img_urls, out_dir):
    """在同一 context 内下载图片"""
    out_dir.mkdir(parents=True, exist_ok=True)
    saved = []

    img_page = context.new_page()
    for i, url in enumerate(img_urls[:BATCH_SIZE]):
        out_path = out_dir / f"img_{i:02d}.jpg"
        if out_path.exists():
            saved.append(str(out_path))
            continue
        try:
            resp = img_page.goto(url, timeout=15000)
            if resp and resp.status == 200:
                body = resp.body()
                if len(body) > 1024:  # 过滤空文件
                    out_path.write_bytes(body)
                    saved.append(str(out_path))
                    print(f"    ✓ img_{i}: {len(body)//1024}KB")
            else:
                print(f"    × img_{i}: HTTP {resp.status if resp else 'None'}")
        except Exception as e:
            print(f"    × img_{i}: {e}")
        time.sleep(DELAY_PER_IMG)

    img_page.close()
    return saved


def get_live_img_urls(page, note_id):
    """打开笔记页，拦截实时图片 URL"""
    captured = []

    def on_response(resp):
        url = resp.url
        if "sns-webpic" in url and resp.status == 200:
            if not any(x in url for x in ["avatar", "icon", "fe-static", "spectrum", "js", "css"]):
                captured.append(url)

    page.on("response", on_response)
    try:
        page.goto(
            f"https://www.xiaohongshu.com/explore/{note_id}?xsec_source=pc_feed",
            referer="https://www.xiaohongshu.com/explore",
            timeout=20000
        )
        time.sleep(5)
    except Exception as e:
        print(f"  页面加载异常: {e}")
    finally:
        page.remove_listener("response", on_response)

    pg_title = page.title()
    if "不见了" in pg_title or "404" in pg_title:
        print(f"  × 页面不可访问（IP 被限流，需等待或换 Cookie）")
        return []

    return captured


def run(tiers=("S", "A"), max_notes=20):
    cookies = load_cookies()
    print(f"加载 {len(cookies)} 个 Cookie")

    # 收集目标笔记
    targets = []
    for f in sorted(FINANCE_IMG_DIR.glob("*.json")):
        meta = json.loads(f.read_text())
        if meta.get("material_tier") in tiers:
            out_dir = OUTPUT_BASE / f.stem
            if not out_dir.exists() or not list(out_dir.glob("*.jpg")):
                targets.append((f.stem, meta))

    print(f"待下载笔记: {len(targets)} 条（评级: {tiers}）")
    targets = targets[:max_notes]

    results = {"ok": 0, "blocked": 0, "failed": 0}

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(
            user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.130 Safari/537.36",
            viewport={"width": 1920, "height": 1080},
        )
        context.add_init_script(
            "Object.defineProperty(navigator, 'webdriver', { get: () => undefined });"
        )
        context.add_cookies(cookies)
        page = context.new_page()

        # 先访问首页建立 session
        page.goto("https://www.xiaohongshu.com/explore", timeout=20000)
        time.sleep(3)

        for i, (note_id, meta) in enumerate(targets):
            print(f"\n[{i+1}/{len(targets)}] [{meta['material_tier']}] {meta.get('title','')[:40]}")
            img_urls = get_live_img_urls(page, note_id)

            if not img_urls:
                results["blocked"] += 1
                print("  → 跳过（页面不可访问）")
                break  # IP 被封就停止整批

            out_dir = OUTPUT_BASE / note_id
            saved = download_note_images(context, note_id, img_urls, out_dir)
            if saved:
                results["ok"] += 1
                print(f"  ✓ 保存 {len(saved)} 张图片")
            else:
                results["failed"] += 1

            time.sleep(DELAY_PER_NOTE)

        browser.close()

    print(f"\n完成: 成功={results['ok']} 被限流={results['blocked']} 失败={results['failed']}")
    return results


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--tier", default="S,A")
    parser.add_argument("--max", type=int, default=20)
    args = parser.parse_args()
    tiers = tuple(t.strip() for t in args.tier.split(","))
    run(tiers=tiers, max_notes=args.max)
```

---

# 使用方法

```bash
cd /home/node/.openclaw/workspace

# 下载 S/A 级图文图片（默认最多 20 条）
PLAYWRIGHT_BROWSERS_PATH=/home/node/.playwright \
  python3 source_material/xhs/scripts/xhs_download_images.py --tier S,A

# 指定评级和数量
PLAYWRIGHT_BROWSERS_PATH=/home/node/.playwright \
  python3 source_material/xhs/scripts/xhs_download_images.py --tier S,A,B --max 10
```

## 输出目录结构
```
source_material/xhs/finance/image_text_imgs/
  {note_id}/
    img_00.jpg
    img_01.jpg
    ...
```

---

# 诊断检查清单

出现问题时按顺序检查：

1. **所有笔记返回「页面不见了」** → IP 被限流，换 Cookie 或等待 12–24h
2. **图片下载 403** → 不在同一 context 内请求，检查代码是否用了 `img_page = context.new_page()`
3. **img_urls 为空** → 页面正常加载但无图片请求，可能是图文笔记加载慢，增加 `time.sleep` 到 8 秒
4. **Cookie 过期** → API 返回 code=-101，重新从浏览器导出 Cookie
5. **Playwright 安装问题** → `PLAYWRIGHT_BROWSERS_PATH=/home/node/.playwright` 确认浏览器路径
