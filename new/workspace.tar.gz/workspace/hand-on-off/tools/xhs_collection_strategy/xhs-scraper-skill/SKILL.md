---
name: xhs-scraper-skill
description: 两阶段爬取小红书笔记数据。Stage 1 获取指定博主的笔记列表（note_id + xsec_token），Stage 2 逐条获取完整笔记详情（标题、正文、图片元数据）。支持根据垂类自动发现高质量博主。输出 JSON 文件。需要有效的小红书 Cookie 和 xhshow Python 包。
allowed-tools: Bash, Read
---

# XHS Scraper Skill

两阶段爬取小红书指定博主的全部笔记，获取完整正文和结构化数据。

## 前置要求

### Python 依赖

```bash
pip install aiohttp xhshow
```

- `aiohttp`: 异步 HTTP 客户端
- `xhshow`: 小红书签名库（生成 x-s / x-t / x-s-common 请求头）

### Cookie 配置

在 `~/xhs-auto-bot/.env` 中配置有效的小红书登录 Cookie：

```
XHS_COOKIE=a1=xxx; webId=xxx; web_session=xxx; ...
```

Cookie 从浏览器登录小红书后提取，有效期通常为 30 天。

---

## 使用方法

### 基本用法

```bash
cd ~/.openclaw/skills/xhs-scraper-skill/scripts
python3 scrape_two_stage.py <user_id> [博主名称] [max_notes]
```

### 参数说明

| 参数 | 必填 | 说明 |
|---|---|---|
| `user_id` | ✅ | 小红书博主的 user_id（从主页 URL 获取） |
| `博主名称` | 可选 | 用于输出文件命名，默认使用 user_id |
| `max_notes` | 可选 | 最大采集笔记数，默认 100 |

### 示例

```bash
# 采集 100 条笔记（默认）
python3 scrape_two_stage.py 6083e9ba0000000001003043 思想聚焦

# 采集 50 条笔记
python3 scrape_two_stage.py 6083e9ba0000000001003043 思想聚焦 50
```

---

## 两阶段流程

### Stage 1: 获取笔记列表

调用 `/api/sns/web/v1/user_posted`，分页获取博主全部笔记元数据：

- `note_id`: 笔记唯一 ID
- `xsec_token`: 详情请求所需的访问令牌
- `display_title`: 笔记标题预览

每页 30 条，自动翻页，页间延迟 2 秒。

### Stage 2: 获取笔记详情

对每条笔记调用 `/api/sns/web/v1/feed`，获取完整数据：

- `title`: 笔记标题
- `desc`: 完整正文
- `image_list`: 图片列表（含 jpg/webp/avif 格式 URL）
- `tag_list`: 话题标签
- `interact_info`: 点赞、收藏、评论数
- `user`: 作者信息

每条请求间延迟 2 秒，避免触发风控。

---

## 输出格式

输出文件：`~/xhs_scraping_test/xhs_{博主名称}_notes_full.json`

```json
[
  {
    "title": "笔记标题",
    "desc": "完整正文内容...",
    "image_list": [
      {
        "url": "https://...",
        "width": 1080,
        "height": 1440
      }
    ],
    "tag_list": [
      { "name": "生活", "type": "topic" }
    ],
    "interact_info": {
      "liked_count": "1234",
      "collected_count": "567",
      "comment_count": "89"
    },
    "user": {
      "user_id": "...",
      "nickname": "博主昵称"
    }
  }
]
```

---

## 错误处理

| 错误 | 原因 | 处理 |
|---|---|---|
| `Cookie 已过期` | code=-101 | 更新 `~/xhs-auto-bot/.env` 中的 Cookie |
| `fetch failed` | 网络不通 | 检查网络连通性 |
| `× 获取失败` | 单条笔记请求失败 | 自动跳过，继续处理下一条 |

---

## 博主发现流程（Creator Discovery）

当用户提供垂类而非具体博主时，执行以下流程自动发现高质量博主。

### Step 1：生成搜索关键词

根据垂类生成 3–5 个搜索关键词。

示例（finance 垂类）：

- 商业分析
- 财务知识
- 企业经营
- 商业逻辑
- 公司案例

禁止使用以下关键词（规避法律风险）：

- 炒股、股票推荐、买入卖出
- 投资建议、理财产品
- 暴富、快速赚钱
- 敏感政治、社会争议话题

### Step 2：通过 Baidu Search 搜索小红书博主

使用 baidu_search skill，搜索格式：

```
小红书 {关键词} 博主 知识 商业
site:xiaohongshu.com {关键词}
```

提取结果中的博主名称和主页 URL。

### Step 3：质量筛选标准

从搜索结果中筛选候选博主，评估维度：

| 维度 | 要求 |
|------|------|
| 内容方向 | 与垂类强相关，机制解释型优先 |
| 内容类型 | 知识型 > 娱乐型 |
| 原创性 | 有独立观点和分析，非纯搬运 |
| 风险规避 | 不涉及投资建议、敏感话题 |

### Step 4：提取并验证 user_id

从博主主页 URL 提取 user_id：

```
https://www.xiaohongshu.com/user/profile/{user_id}
```

提取后立即通过 `/api/sns/web/v1/user/otherinfo` 接口验证 user_id 有效性，确认返回的 `basic_info.nickname` 与博主名称匹配。

### Step 5：写入 creator_registry

将通过筛选**且 user_id 已验证**的博主写入：

```
source_material/xhs/creator_registry/candidate_registry.json
```

字段包括：

- `creator_name`
- `user_id`（已通过 API 验证）
- `category`
- `discovery_keywords`（发现该博主使用的关键词）
- `risk_check`（是否通过风险规避检查）
- `identity_verified`：true
- `verified_at`：验证时间
- `status`: `candidate`

**规则：未经 API 验证的 user_id 不得写入 registry，不得执行采集。**

### Step 6：确认后执行采集

向用户展示候选博主列表（含验证结果），确认后执行两阶段采集。

---

## 话题扩展采集流程（Topic-Based Discovery）

当博主风格已固定后，主动根据博主话题扩展采集范围，以流量数据为核心筛选标准。

适用场景：

- 已完成博主风格蒸馏
- 需要扩充特定话题的素材池
- 希望发现同垂类高质量内容

### Step 1：提取博主核心话题

从已采集博主的笔记中提取高频话题标签（tag_list）和高流量笔记主题。

输出：topic_list（3–10 个核心话题词）

### Step 2：话题关键词搜索

使用 baidu_search skill，针对每个话题搜索小红书相关帖子：

```
site:xiaohongshu.com {话题关键词}
小红书 {话题关键词} 收藏 干货
```

禁止搜索词（同博主发现流程风险规避规则）：

- 炒股、股票推荐、投资建议
- 暴富、快速赚钱
- 敏感政治、社会争议话题

### Step 3：流量数据筛选

依据 source_strategy.md 素材价值评分标准筛选：

```
Content Signal Score =
  collected × 0.35
  + share × 0.30
  + comment_quality × 0.25
  + liked × 0.10
```

优先级规则：

| 级别 | 分数 | 处理 |
|------|------|------|
| S | ≥ 75 | 优先采集 |
| A | ≥ 50 | 采集 |
| B | ≥ 25 | 可选采集 |
| C | < 25 | 跳过 |

仅采集 A 级及以上素材。

### Step 4：去重检查

采集前检查 note_id 是否已存在于：

```
source_material/xhs/{category}/{content_type}/
```

已存在则跳过，避免重复采集。

### Step 5：执行采集并标准化

对筛选后的笔记执行两阶段采集，然后调用 normalize.py 标准化存储。

### Step 6：更新话题池

将本次新发现的高质量话题写入博主的 creator_registry 记录中：

```json
"topic_pool": [
  {
    "topic": "话题词",
    "avg_signal_score": 68.5,
    "notes_collected": 12,
    "last_collected_at": "2026-09-22T03:00:00Z"
  }
]
```

---

针对特定内容垂类的官方数据来源，存放在 `evidence-sources/` 目录。

采集到素材后，使用对应垂类的证据库验证事实来源。

| 文件 | 垂类 | 说明 |
|---|---|---|
| [finance.md](evidence-sources/finance.md) | 商业财经 | 经验证可访问的官方数据来源，含企业披露平台、政府统计数据、学术来源 |

遇到对应垂类的证据核查任务时，读取该目录下的对应文件后执行。

---

## 视频下载流程（Video Download）

### 背景

小红书视频 CDN URL（`sns-video-qc.xhscdn.com`）需要鉴权签名，且绑定客户端 IP 和时间戳。
Stage 2 采集时存入 meta.json 的视频 URL 在采集完成后很快失效，直接请求返回 403。

### 已验证失败策略（不要重试）

| 方案 | 结果 | 原因 |
|------|------|------|
| 直接请求 CDN URL（`http://sns-video-qc.xhscdn.com/...`） | 403 Forbidden | URL 含时效签名，过期即失效 |
| yt-dlp + Cookie 直接下载 | `No video formats found` | XHS 提取器不支持当前页面结构 |
| Stage 2 response 中的 `media_v2.stream` URL | 403 | 同上，签名已过期 |
| Playwright headless 拦截（含反检测 patch） | 页面返回「你访问的页面不见了」 | 笔记本身被平台限流/下架（code=300031「当前笔记暂时无法浏览」），与下载方案无关 |

### 正确方案：Playwright 实时拦截

对每条视频笔记：
1. 用 Playwright 打开 `https://www.xiaohongshu.com/explore/{note_id}`
2. 注入 Cookie，监听所有 `response` 事件
3. 拦截匹配 `sns-video-bd.xhscdn.com` 或 `sns-video-hw.xhscdn.com` 或含 `/stream/` 的媒体 URL（这些是实时签名的 CDN）
4. 等待视频自动播放触发媒体请求（约 3–5 秒）
5. 提取带签名的实时 URL，交给 ffmpeg 下载

```python
# 关键拦截逻辑
def handle_response(response):
    url = response.url
    if any(cdn in url for cdn in ["sns-video-bd", "sns-video-hw", "sns-video-qc"]) \
       and response.request.resource_type in ("media", "xhr", "fetch"):
        captured_urls.append(url)

page.on("response", handle_response)
page.goto(f"https://www.xiaohongshu.com/explore/{note_id}")
page.wait_for_timeout(5000)  # 等待视频请求触发
```

6. 使用 ffmpeg 下载到 `video/{note_id}/video.mp4`：
```bash
ffmpeg -i "<captured_url>" -c copy output.mp4
```

### 脚本位置

`scripts/download_video_playwright.py`

---

## 视频处理流程（Video Processing）

下载完成后，对视频执行：

### 1. 静态帧提取（ffmpeg）

阈值：连续相同帧 ≥ 1 秒判定为静态帧，提取中间帧：

```bash
ffmpeg -i video.mp4 -vf "select='gt(scene,0.02)',setpts=N/FRAME_RATE/TB" \
  -vsync vfr frames/%06d.jpg
```

输出：`video/{note_id}/frames/{timestamp}.jpg`

### 2. ASR 字幕提取（faster-whisper base）

```python
export HF_ENDPOINT=https://hf-mirror.com  # 国内镜像，可访问
from faster_whisper import WhisperModel
model = WhisperModel('base', device='cpu', compute_type='int8')
segments, _ = model.transcribe('audio.wav', language='zh')
```

- 模型：`base`（中文）
- 下载镜像：`https://hf-mirror.com`（已验证可访问）
- 输出：`video/{note_id}/transcript.json`

格式：
```json
{"segments": [{"start": 0.0, "end": 3.2, "text": "..."}]}
```

---

## 注意事项

- 仅用于数据采集，禁止发布、评论、点赞等写操作
- Cookie 需要定期更新，过期后 Stage 1 会立即终止并提示
- 采集速度受限于页间 2 秒延迟，100 条笔记约需 3-5 分钟
- 输出 JSON 可直接被 source_collector 流程消费
- **视频 CDN URL 有时效性**，不可在 Stage 2 采集后复用，必须用 Playwright 实时提取

---

## 版本

- v1.0.0 (2026-09-18)
- 作者: 蓝厂工程师 Agent
- 基于: ibreez3/xiaohongshu-skill 原始代码
