# 商业财经知识证据来源库 v1.0

收录经百度搜索验证的官方数据源，供小林说内容生产使用。
更新时间：2026-09-22（v1.1，移除不可访问来源：SEC EDGAR browse入口、海关总署、IMF data.imf.org）

---

## 一、企业一手资料（最高优先级）

### A股上市公司

| 来源 | 官方网址 | 用途 |
|------|----------|------|
| 巨潮资讯网 | https://www.cninfo.com.cn/ | A股唯一法定信披平台，年报/季报/公告 |
| 上海证券交易所 | https://www.sse.com.cn/ | 沪市公告、财报披露 |
| 上交所信息披露 | http://www.sse.org.cn/disclosure/listed/notice/index.html | 上市公司公告直接入口 |
| 深圳证券交易所 | https://www.szse.cn/ | 深市公告、财报披露 |
| 深交所信息披露 | https://www.szse.cn/disclosure/ | 深市信披直接入口 |
| 证监会信息披露 | https://www.csrc.gov.cn/ | 监管文件、问询函、行政处罚 |
| 上市公司信披管理办法 | https://www.csrc.gov.cn/csrc/c106256/c1653948/content.shtml | 披露规则参考 |

### 港股上市公司

| 来源 | 官方网址 | 用途 |
|------|----------|------|
| 港交所披露易（简体） | https://sc.hkexnews.hk/TuniS/www.hkexnews.hk/index_c.htm | 港股年报、招股书、公告 |
| 港交所官网 | https://www.hkex.com.hk/ | 上市规则、市场数据 |

### 美股上市公司（含中概股）

| 来源 | 官方网址 | 用途 |
|------|----------|------|
| SEC 官网 | https://sec.gov/ | 全部美股披露文件 |

---

## 二、宏观经济与政府统计数据

| 来源 | 官方网址 | 核心数据 |
|------|----------|----------|
| 国家统计局 | https://www.stats.gov.cn/ | GDP、CPI、工业产值、零售、人口 |
| 国家统计局数据发布 | https://www.stats.gov.cn/sj/zxfb/index.html | 最新统计数据发布入口 |
| 中国人民银行 | https://www.pbc.gov.cn/ | 货币政策、社融、利率、金融数据 |
| 央行金融统计数据 | https://www.pbc.gov.cn/zhifujiesuansi/128525/128545/128643/index.html | 支付体系运行数据 |
| 商务部 | https://www.mofcom.gov.cn/ | 进出口、外资、消费、电商 |
| 商务部统计数据 | https://opendata.mofcom.gov.cn/front/data/topic?type=2 | 商务部开放数据平台 |
| 工业和信息化部 | https://www.miit.gov.cn/ | 工业产业政策 |
| 工信数据 | https://www.miit.gov.cn/gxsj/ | 工信部统计数据直接入口 |
| 财政部 | https://www.mof.gov.cn/ | 财政收支、债务、税收数据 |
| 国家发展改革委 | https://www.ndrc.gov.cn/ | 产业政策、价格监测 |
| 国家外汇管理局 | https://www.safe.gov.cn/ | 外汇储备、跨境资金流动 |
| 国家金融监督管理总局 | https://www.nfra.gov.cn/ | 银行保险业数据、监管政策 |

---

## 三、国际权威数据来源

| 来源 | 官方网址 | 核心数据 |
|------|----------|----------|
| 世界银行 Open Data | https://data.worldbank.org/ | 全球发展指标、产业数据 |

---

## 四、行业研究与专业机构

| 来源 | 官方网址 | 用途 |
|------|----------|------|
| Wind 金融数据 | https://www.wind.com.cn/portal/zh/WFT/index.html | 行业研报、金融终端（需账号） |
| Wind 经济数据库（部分免费） | https://www.wind.com.cn/mobile/EDB/zh.html | 宏观经济数据库 |
| 麦肯锡全球研究院（中文） | https://www.mckinsey.com.cn/McKinsey/ | 行业趋势、商业模式研究 |

---

## 五、学术与商业研究

| 来源 | 官方网址 | 用途 |
|------|----------|------|
| 中国知网 CNKI | https://www.cnki.net/ | 中文学术论文、行业研究 |
| 知网手机版 | https://wap.cnki.net/ | 移动端入口 |
| 哈佛商业评论中文版 | https://www.hbrchina.org/ | 商业管理案例与分析 |
| Google Scholar | https://scholar.google.com/ | 全球学术论文（需翻墙） |
| SSRN | https://www.ssrn.com/ | 金融经济学预印本论文 |

---

## 六、使用规则

### 来源优先级

```
企业官方披露（年报/公告）
> 政府统计数据
> 国际权威机构数据
> 专业研究机构报告
> 学术论文
> 媒体报道（仅用于发现线索，不作为事实依据）
```

### 禁止来源

- 社交平台内容（小红书、微博、抖音等）不得作为事实依据
- 个人博主观点不得作为商业结论
- 未注明来源的行业数据不得直接引用

### 引用要求

每条核心数据或事实陈述必须标注：

- 来源名称
- 来源网址
- 发布时间（如可获取）
