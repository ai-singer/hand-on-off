"""
XHS Video Downloader - Playwright 实时拦截方案
================================================
背景：小红书视频 CDN URL 含时效性签名，Stage 2 存入的 URL 会快速过期（403）。
本脚本通过 Playwright 打开笔记页面，实时拦截浏览器发出的视频媒体请求，
提取带有效签名的 CDN URL，再用 ffmpeg 下载。

已验证失败的方案（不要重试）：
- 直接使用 Stage 2 meta.json 中的 CDN URL → 403
- yt-dlp + Cookie → No video formats found
- media_v2.stream 中的 URL → 403（同样过期）

用法：
  python3 download_video_playwright.py --note-id <note_id> --out-dir <dir>
  python3 download_video_playwright.py --meta-dir <video_dir> --tier S,A
"""

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path


# ── Cookie 加载 ─────────────────────────────────────────────────────────────

def load_cookie_list(cookie_path: str | None = None) -> list[dict]:
    paths = []
    if cookie_path:
        paths.append(Path(cookie_path))
    paths += [
        Path("/home/node/.openclaw/workspace/xiaohongshu_cookies.txt"),
        Path.home() / ".openclaw/workspace/xiaohongshu_cookies.txt",
    ]
    for p in paths:
        if not p.exists():
            continue
        content = p.read_text().strip()
        if "\t" in content:
            cookies = []
            for line in content.splitlines():
                if line.strip() and not line.startswith("#"):
                    parts = line.split("\t")
                    if len(parts) >= 7:
                        cookies.append({
                            "name": parts[5], "value": parts[6],
                            "domain": ".xiaohongshu.com", "path": "/",
                        })
            if cookies:
                return cookies
        else:
            cookies = []
            for pair in content.split(";"):
                pair = pair.strip()
                if "=" in pair:
                    k, v = pair.split("=", 1)
                    cookies.append({
                        "name": k.strip(), "value": v.strip(),
                        "domain": ".xiaohongshu.com", "path": "/",
                    })
            if cookies:
                return cookies
    raise FileNotFoundError("Cookie file not found")


# ── Playwright 拦截 ──────────────────────────────────────────────────────────

VIDEO_CDN_HOSTS = ["sns-video-bd.xhscdn.com", "sns-video-hw.xhscdn.com",
                   "sns-video-qc.xhscdn.com", "sns-video-al.xhscdn.com"]

def intercept_video_url(note_id: str, cookies: list[dict],
                        wait_sec: int = 8) -> str | None:
    """打开笔记页面，拦截视频 CDN 请求，返回实时 URL（含签名）"""
    from playwright.sync_api import sync_playwright

    captured = []

    def on_response(response):
        url = response.url
        if any(h in url for h in VIDEO_CDN_HOSTS):
            # 只取视频流（非缩略图）
            if any(x in url for x in ["/stream/", ".mp4", "video"]) \
               and "thumbnail" not in url and "thumb" not in url:
                if url not in captured:
                    captured.append(url)
                    print(f"  ✓ 拦截到视频 URL: {url[:80]}")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(
            user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                       "AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
        )
        context.add_cookies(cookies)
        page = context.new_page()
        page.on("response", on_response)

        url = f"https://www.xiaohongshu.com/explore/{note_id}"
        print(f"  → 打开页面: {url}")
        try:
            page.goto(url, timeout=30000)
            page.wait_for_timeout(wait_sec * 1000)
        except Exception as e:
            print(f"  ⚠ 页面加载异常: {e}")

        browser.close()

    if not captured:
        return None
    # 优先取最长 URL（通常分辨率最高）
    return max(captured, key=len)


# ── ffmpeg 下载 ───────────────────────────────────────────────────────────────

def download_video(video_url: str, out_path: Path) -> bool:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        "ffmpeg", "-y",
        "-i", video_url,
        "-c", "copy",
        str(out_path),
    ]
    print(f"  → ffmpeg 下载: {out_path.name}")
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    if result.returncode == 0:
        size = out_path.stat().st_size // 1024
        print(f"  ✓ 下载完成: {size} KB")
        return True
    else:
        print(f"  × 下载失败: {result.stderr[-200:]}")
        return False


# ── 批量处理 ──────────────────────────────────────────────────────────────────

def process_note(note_id: str, out_base: Path, cookies: list[dict]) -> dict:
    note_dir = out_base / note_id
    video_path = note_dir / "video.mp4"

    if video_path.exists() and video_path.stat().st_size > 1024:
        print(f"  ↷ 已存在，跳过: {note_id}")
        return {"note_id": note_id, "status": "skip"}

    print(f"\n[{note_id}]")
    video_url = intercept_video_url(note_id, cookies)
    if not video_url:
        print(f"  × 未拦截到视频 URL")
        return {"note_id": note_id, "status": "no_url"}

    ok = download_video(video_url, video_path)
    return {
        "note_id": note_id,
        "status": "ok" if ok else "download_failed",
        "video_url": video_url,
        "video_path": str(video_path),
    }


def batch_process(meta_dir: Path, tiers: list[str], cookies: list[dict],
                  delay: int = 3) -> list[dict]:
    results = []
    for note_dir in sorted(meta_dir.iterdir()):
        meta_path = note_dir / "meta.json"
        if not meta_path.exists():
            continue
        meta = json.loads(meta_path.read_text())
        if meta.get("material_tier") not in tiers:
            continue

        result = process_note(note_dir.name, meta_dir, cookies)
        results.append(result)
        time.sleep(delay)

    return results


# ── CLI ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="XHS 视频 Playwright 下载器")
    parser.add_argument("--note-id", help="单条笔记 note_id")
    parser.add_argument("--meta-dir", help="批量处理：video 目录路径")
    parser.add_argument("--tier", default="S,A", help="批量时筛选评级，逗号分隔（默认 S,A）")
    parser.add_argument("--out-dir", help="输出目录（单条模式）")
    parser.add_argument("--cookie", help="Cookie 文件路径（可选）")
    parser.add_argument("--delay", type=int, default=3, help="批量时请求间隔秒数（默认 3）")
    args = parser.parse_args()

    cookies = load_cookie_list(args.cookie)
    print(f"✓ 加载 {len(cookies)} 个 Cookie")

    if args.note_id:
        out_dir = Path(args.out_dir) if args.out_dir else \
            Path("/home/node/.openclaw/workspace/source_material/xhs/finance/video")
        result = process_note(args.note_id, out_dir, cookies)
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif args.meta_dir:
        tiers = [t.strip() for t in args.tier.split(",")]
        meta_dir = Path(args.meta_dir)
        print(f"批量处理 {meta_dir}，评级: {tiers}")
        results = batch_process(meta_dir, tiers, cookies, args.delay)

        ok     = sum(1 for r in results if r["status"] == "ok")
        skip   = sum(1 for r in results if r["status"] == "skip")
        failed = sum(1 for r in results if r["status"] not in ("ok", "skip"))
        print(f"\n✓ 完成: 成功={ok} 跳过={skip} 失败={failed}")

        # 保存结果日志
        log_path = meta_dir.parent.parent / "logs" / "video_download.json"
        log_path.parent.mkdir(exist_ok=True)
        log_path.write_text(json.dumps(results, ensure_ascii=False, indent=2))
        print(f"✓ 日志保存至 {log_path}")

    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
