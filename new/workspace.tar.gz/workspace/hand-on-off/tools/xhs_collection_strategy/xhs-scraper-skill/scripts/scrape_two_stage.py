#!/usr/bin/env python3
"""Runtime test: 采集指定博主 5 条笔记，输出到 validation/xhs_runtime_test_output/"""
import asyncio
import hashlib
import json
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from urllib.parse import quote
import aiohttp

# ---- Cookie 加载 ----

def _parse_netscape_cookies(content: str) -> str:
    cookies = []
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) >= 7:
            cookies.append(f"{parts[5]}={parts[6]}")
    return "; ".join(cookies)

def _load_cookie():
    txt_file = Path("/home/node/.openclaw/workspace/xiaohongshu_cookies.txt")
    if txt_file.exists():
        content = txt_file.read_text(encoding="utf-8").strip()
        if content:
            if "# Netscape HTTP Cookie File" in content or "\t" in content:
                converted = _parse_netscape_cookies(content)
                if converted:
                    return converted, str(txt_file) + " (Netscape)"
            else:
                return content, str(txt_file)
    ws_env = Path("/home/node/.openclaw/workspace/.env")
    if ws_env.exists():
        with open(ws_env, encoding="utf-8") as f:
            for line in f:
                if line.startswith("XHS_COOKIE="):
                    val = line.split("=", 1)[1].strip().strip('"')
                    if val:
                        return val, str(ws_env)
    bot_env = Path.home() / "xhs-auto-bot" / ".env"
    if bot_env.exists():
        with open(bot_env, encoding="utf-8") as f:
            for line in f:
                if line.startswith("XHS_COOKIE="):
                    val = line.split("=", 1)[1].strip().strip('"')
                    if val:
                        return val, str(bot_env)
    return "", ""

# ---- xhshow patch ----

def _patch_xhshow_a3_hash():
    from xhshow.core.crypto import CryptoProcessor
    _original_build = CryptoProcessor.build_payload_array
    def _patched_build(self, hex_parameter, hex_md5_path, a1_value,
                       app_identifier="xhs-pc-web", string_param="",
                       timestamp=None, sign_state=None):
        payload = _original_build(self, hex_parameter, hex_md5_path, a1_value,
                                  app_identifier, string_param, timestamp, sign_state)
        if "{" not in string_param:
            correct_md5_hex = hashlib.md5(string_param.encode("utf-8")).hexdigest()
            correct_md5_bytes = [int(correct_md5_hex[i:i+2], 16) for i in range(0, 32, 2)]
            seed_byte = payload[4]
            ts_bytes = payload[8:16]
            correct_a3_hash = self._custom_hash_v2(list(ts_bytes) + correct_md5_bytes)
            for i in range(16):
                payload[128+i] = correct_a3_hash[i] ^ seed_byte
        return payload
    CryptoProcessor.build_payload_array = _patched_build

_patch_xhshow_a3_hash()

# ---- 签名 ----

def _build_sign_string(uri, data=None, method="POST"):
    if method.upper() == "POST":
        c = uri
        if data is not None:
            if isinstance(data, dict):
                c += json.dumps(data, separators=(",", ":"), ensure_ascii=False)
            elif isinstance(data, str):
                c += data
        return c
    else:
        if not data or (isinstance(data, dict) and len(data) == 0):
            return uri
        if isinstance(data, dict):
            params = []
            for key in data.keys():
                value = data[key]
                if isinstance(value, list):
                    value_str = ",".join(str(v) for v in value)
                elif value is not None:
                    value_str = str(value)
                else:
                    value_str = ""
                value_str = quote(value_str, safe=',')
                params.append(f"{key}={value_str}")
            return f"{uri}?{'&'.join(params)}"
        elif isinstance(data, str):
            return f"{uri}?{data}"
        return uri

def sign_with_xhshow(uri, data=None, cookie_str="", method="POST"):
    from xhshow import Xhshow
    xhshow_client = Xhshow()
    if method.upper() == "POST":
        headers = xhshow_client.sign_headers_post(
            uri=uri, cookies=cookie_str,
            payload=data if isinstance(data, dict) else {},
        )
    else:
        content_string = _build_sign_string(uri, data, method)
        cookie_dict = xhshow_client._parse_cookies(cookie_str)
        a1_value = cookie_dict.get("a1", "")
        ts = time.time()
        d_value = hashlib.md5(content_string.encode("utf-8")).hexdigest()
        m_value = d_value  # GET: hex_md5_path == d_value
        payload_array = xhshow_client.crypto_processor.build_payload_array(
            d_value, m_value, a1_value, "xhs-pc-web", content_string, ts)
        xor_result = xhshow_client.crypto_processor.bit_ops.xor_transform_array(payload_array)
        config = xhshow_client.config
        x3_b64 = xhshow_client.crypto_processor.b64encoder.encode_x3(xor_result[:config.PAYLOAD_LENGTH])
        sig_data = config.SIGNATURE_DATA_TEMPLATE.copy()
        sig_data["x3"] = config.X3_PREFIX + x3_b64
        x_s = config.XYS_PREFIX + xhshow_client.crypto_processor.b64encoder.encode(
            json.dumps(sig_data, separators=(",", ":"), ensure_ascii=False))
        headers = {
            "x-s": x_s,
            "x-s-common": xhshow_client.sign_xs_common(cookie_dict),
            "x-t": str(xhshow_client.get_x_t(ts)),
            "x-b3-traceid": xhshow_client.get_b3_trace_id(),
        }
    return {
        "x-s": headers.get("x-s", ""),
        "x-t": headers.get("x-t", ""),
        "x-s-common": headers.get("x-s-common", ""),
        "x-b3-traceid": headers.get("x-b3-traceid", ""),
    }

# ---- Stage 1 ----

async def get_note_list(user_id, cookie_str, max_notes=5):
    print("=" * 60)
    print("Stage 1: 获取笔记列表")
    print("=" * 60)
    all_notes = []
    cursor = ""
    base_url = "https://edith.xiaohongshu.com"
    uri = "/api/sns/web/v1/user_posted"
    params = {"num": max_notes, "cursor": cursor, "user_id": user_id, "image_formats": "jpg,webp,avif"}
    signs = sign_with_xhshow(uri=uri, data=params, cookie_str=cookie_str, method="GET")
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Referer": "https://www.xiaohongshu.com/",
        "Origin": "https://www.xiaohongshu.com",
        "Accept": "application/json, text/plain, */*",
        "Cookie": cookie_str,
        "X-S": signs["x-s"],
        "X-T": signs["x-t"],
        "x-S-Common": signs["x-s-common"],
        "X-B3-Traceid": signs["x-b3-traceid"],
    }
    url = f"{base_url}{uri}"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params, headers=headers,
                                   timeout=aiohttp.ClientTimeout(total=30)) as response:
                print(f"  HTTP status: {response.status}")
                if response.status != 200:
                    text = await response.text()
                    print(f"  × 请求失败: {text[:300]}")
                    return []
                result = await response.json()
                if not result.get("success"):
                    print(f"  × API 返回失败: code={result.get('code')} msg={result.get('msg')}")
                    if result.get("code") == -101:
                        print("  Cookie 已过期")
                    return []
                data = result.get("data", {})
                notes = data.get("notes", [])[:max_notes]
                print(f"  ✓ 获取到 {len(notes)} 条笔记")
                for n in notes:
                    print(f"    - note_id: {n.get('note_id')}  xsec_token: {'✓' if n.get('xsec_token') else '×'}  title: {n.get('display_title','')[:20]}")
                return notes
    except Exception as e:
        print(f"  × 出错: {e}")
        return []

# ---- Stage 2 ----

async def get_note_detail(note_id, xsec_token, cookie_str):
    base_url = "https://edith.xiaohongshu.com"
    uri = "/api/sns/web/v1/feed"
    data = {
        "source_note_id": note_id,
        "image_formats": ["jpg", "webp", "avif"],
        "extra": {"need_body_topic": 1},
        "xsec_source": "pc_user",
        "xsec_token": xsec_token,
    }
    signs = sign_with_xhshow(uri=uri, data=data, cookie_str=cookie_str, method="POST")
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Referer": "https://www.xiaohongshu.com/",
        "Origin": "https://www.xiaohongshu.com",
        "Accept": "application/json, text/plain, */*",
        "Content-Type": "application/json;charset=UTF-8",
        "Cookie": cookie_str,
        "X-S": signs["x-s"],
        "X-T": signs["x-t"],
        "x-S-Common": signs["x-s-common"],
        "X-B3-Traceid": signs["x-b3-traceid"],
    }
    url = f"{base_url}{uri}"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=data, headers=headers,
                                    timeout=aiohttp.ClientTimeout(total=30)) as response:
                if response.status != 200:
                    text = await response.text()
                    print(f"    HTTP {response.status}: {text[:200]}")
                    return None
                result = await response.json()
                if not result.get("success"):
                    print(f"    API 失败: code={result.get('code')} msg={result.get('msg')}")
                    return None
                items = result.get("data", {}).get("items", [])
                if items:
                    return items[0].get("note_card", {})
                return None
    except Exception as e:
        print(f"    异常: {e}")
        return None

# ---- 数据契约转换 ----

def to_phanthy_schema(note_card):
    images = note_card.get("image_list", [])
    cover = images[0].get("url", "") if images else ""
    image_urls = [img.get("url", "") for img in images if img.get("url")]
    tags = [t.get("name", "") for t in note_card.get("tag_list", []) if t.get("name")]
    return {
        "source_type": "xiaohongshu",
        "title": note_card.get("title", ""),
        "cover": cover,
        "images": image_urls,
        "text": note_card.get("desc", ""),
        "tags": tags,
        "metadata": {
            "note_id": note_card.get("note_id", ""),
            "liked_count": note_card.get("interact_info", {}).get("liked_count", ""),
            "collected_count": note_card.get("interact_info", {}).get("collected_count", ""),
            "comment_count": note_card.get("interact_info", {}).get("comment_count", ""),
            "author": note_card.get("user", {}).get("nickname", ""),
            "author_id": note_card.get("user", {}).get("user_id", ""),
        }
    }

# ---- main ----

def _parse_args():
    """解析 CLI 参数，支持 --user-id / --creator-name / --max-notes / --output-dir"""
    import argparse
    parser = argparse.ArgumentParser(
        description="两阶段爬取小红书笔记",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""示例:
  python3 scrape_two_stage.py --user-id 5ef2ee2b0000000001002daa --creator-name 中国国家地理 --max-notes 100
  python3 scrape_two_stage.py --user-id 5ef2ee2b0000000001002daa --output-dir ~/workspace/source_material/xhs/raw/"""
    )
    parser.add_argument("--user-id", required=True, help="小红书博主 user_id")
    parser.add_argument("--creator-name", default="", help="博主名称，用于输出文件命名（默认使用 user_id）")
    parser.add_argument("--max-notes", type=int, default=100, help="最大采集笔记数（默认 100）")
    parser.add_argument("--output-dir",
                        default=str(Path.home() / ".openclaw/workspace/source_material/xhs/raw"),
                        help="输出目录（默认 ~/workspace/source_material/xhs/raw/）")
    return parser.parse_args()


async def main():
    args = _parse_args()
    user_id = args.user_id
    creator_name = args.creator_name or user_id
    max_notes = args.max_notes
    output_dir = Path(args.output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)

    cookie, cookie_source = _load_cookie()
    if not cookie:
        print("× Cookie 加载失败")
        sys.exit(1)

    print(f"Cookie source: {cookie_source}")
    print(f"Cookie length: {len(cookie)}")
    print(f"User ID: {user_id}")
    print(f"Creator: {creator_name}")
    print(f"目标采集: {max_notes} 条")
    print(f"输出目录: {output_dir}\n")

    # Stage 1
    note_list = await get_note_list(user_id, cookie, max_notes)
    if not note_list:
        print("\n× Stage 1 失败")
        sys.exit(1)

    # 保存 Stage 1 原始数据
    s1_file = output_dir / "stage1_note_list.json"
    with open(s1_file, "w", encoding="utf-8") as f:
        json.dump(note_list, f, ensure_ascii=False, indent=2)
    print(f"\n  Stage 1 原始数据: {s1_file}")

    # Stage 2
    print("\n" + "=" * 60)
    print("Stage 2: 获取笔记详情")
    print("=" * 60)

    full_notes = []
    phanthy_notes = []

    for i, note in enumerate(note_list, 1):
        note_id = note.get("note_id")
        xsec_token = note.get("xsec_token")
        print(f"\n[{i}/{len(note_list)}] {note.get('display_title','')[:25]}...")

        detail = await get_note_detail(note_id, xsec_token, cookie)
        if detail:
            desc_len = len(detail.get("desc", ""))
            img_count = len(detail.get("image_list", []))
            tag_count = len(detail.get("tag_list", []))
            print(f"  ✓ title: {detail.get('title','')[:30]}")
            print(f"  ✓ desc: {desc_len} 字符")
            print(f"  ✓ images: {img_count} 张")
            print(f"  ✓ tags: {tag_count} 个")
            full_notes.append(detail)
            phanthy_notes.append(to_phanthy_schema(detail))
        else:
            print("  × 获取失败")

        if i < len(note_list):
            await asyncio.sleep(2)

    from datetime import date
    date_str = date.today().strftime("%Y%m%d")

    # 保存 Stage 2 原始数据（按博主+日期命名）
    s2_file = output_dir / f"xhs_{creator_name}_{date_str}.json"
    with open(s2_file, "w", encoding="utf-8") as f:
        json.dump(full_notes, f, ensure_ascii=False, indent=2)

    # 保存 Phanthy 契约格式数据
    phanthy_file = output_dir / f"xhs_{creator_name}_{date_str}_phanthy.json"
    with open(phanthy_file, "w", encoding="utf-8") as f:
        json.dump(phanthy_notes, f, ensure_ascii=False, indent=2)

    print("\n" + "=" * 60)
    print("采集完成")
    print("=" * 60)
    print(f"  原始数据: {s2_file}")
    print(f"  Phanthy 格式: {phanthy_file}")
    print(f"  成功采集: {len(full_notes)}/{max_notes} 条")

if __name__ == "__main__":
    asyncio.run(main())
