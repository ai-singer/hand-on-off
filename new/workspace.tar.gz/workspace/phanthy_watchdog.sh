#!/bin/bash
# 财叔 Phanthy 轮询器保活脚本
# 每60秒检查一次轮询器是否在运行，不在则重启

POLLER="/home/node/.openclaw/workspace/phanthy_poller.py"
PIDFILE="/tmp/phanthy_poller.pid"
LOGFILE="/home/node/.openclaw/workspace/phanthy_poll.log"

while true; do
    # Check if poller is running
    if [ -f "$PIDFILE" ]; then
        PID=$(cat "$PIDFILE")
        if kill -0 "$PID" 2>/dev/null; then
            # Still running
            sleep 60
            continue
        fi
    fi

    # Not running — start it
    echo "$(date -u '+%Y-%m-%d %H:%M:%S') INFO 保活脚本：轮询器未运行，正在重启..." >> "$LOGFILE"
    python3 "$POLLER" &
    echo $! > "$PIDFILE"
    echo "$(date -u '+%Y-%m-%d %H:%M:%S') INFO 保活脚本：轮询器已重启，PID=$(cat $PIDFILE)" >> "$LOGFILE"
    sleep 60
done
