# HEARTBEAT.md


# Proactive Task Scheduler


## Purpose

Define periodic checks and proactive actions.

Heartbeat does not define:

- Content strategy.
- Writing style.
- Visual generation rules.
- Publishing standards.

Related business logic belongs to:

agent_config/


---

# Scheduled Checks


## Content Production Check


Frequency:

Daily


Check:

- Whether there are pending content tasks.
- Whether source materials need processing.
- Whether generated content requires review.


Action:

If pending tasks exist:

Follow:

agent_config/operation.md



---


## Review Feedback Check


Frequency:

Daily


Check:

- New review results.
- Failed publications.
- User feedback.


Action:

Record issues and route them to the responsible review or improvement process.



---


## Operation Status Check


Frequency:

Daily


Check:

- Current production status.
- Published content status.
- Pending tasks.


Action:

Generate operation summary.



---


# Phanthy 私信轮询


Frequency:

每次心跳


Action:

1. GET https://cms.phanthy.com/api/v1/openclaw/messages
   Authorization: Bearer YOUR_PHANTHY_API_KEY

2. 如有消息（messages 数组非空）：
   - 以财叔人设生成回复（财经机制解释型，不提供投资建议，回复200字以内）
   - POST https://cms.phanthy.com/api/v1/openclaw/messages/<delivery_id>/reply
     body: {"content": "<回复内容>", "version": <version>, "leaseToken": "<leaseToken>"}
   - 如有 hasMore=true，继续取下一批

3. GET https://cms.phanthy.com/api/v1/openclaw/comments/unread
   如有评论，同样方式回复（回复限300字以内）

4. 无消息无评论：不输出任何内容，继续正常心跳判断


---


# Source Material Sync


Frequency:

每次心跳（Daily 亦可，视素材更新频率）


Steps:

1. 进入临时克隆目录，拉取最新内容：
   ```
   cd /home/node/.openclaw/workspace/ai-singer/hand-on-off && git pull
   ```

2. 将更新内容合并进本地工作目录（不覆盖已有文件）：
   ```
   cp -rn source_material/. /home/node/.openclaw/workspace/hand-on-off/source_material/
   ```

3. 合并完成后，`ai-singer/hand-on-off/` 仅作为 git 同步中转，不直接用于生产流程。

4. 生产流程读取素材路径：
   `/home/node/.openclaw/workspace/hand-on-off/source_material/`


Notes:

- 如有冲突（同名文件），保留本地版本（`cp -rn` 的 `-n` 保证不覆盖）。
- 如需强制用远端覆盖，需人工确认后执行 `cp -rf`。


---


# Heartbeat Rules


The Agent should:

- Perform lightweight checks.
- Avoid unnecessary actions.
- Follow operation workflow before external actions.


The Agent should not:

- Generate content without a production task.
- Publish content without review.
- Modify configuration without identifying the responsible process.