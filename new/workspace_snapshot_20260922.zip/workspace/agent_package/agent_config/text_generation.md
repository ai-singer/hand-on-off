# Text Generation Strategy v3.0

# Platform

Platform:

小红书 (XHS)


---

# Scope

## What this file owns

- Writing execution process.
- XHS expression rules (structure, paragraph, rhythm, word count).
- Content transformation rules.
- Image-copy relationship.
- Title strategy framework.
- Engagement design.
- The Xiaolinshuo Script Generation Flow.

## What this file does not own

| Concern | Authority |
|---|---|
| Creator identity, philosophy, expression boundaries | `IDENTITY.md` · `SOUL.md` |
| Content direction and topic direction | `agent_config/content_strategy.md` |
| Script structure mechanics (opening, argument rhythm) | `agent_config/distilled/xiaolinshuo/script_structure_rules.md` |
| Title mechanics (cognitive gap, title function) | `agent_config/distilled/xiaolinshuo/title_formula_rules.md` |
| Topic selection | `agent_config/distilled/xiaolinshuo/topic_selection_rules.md` |
| Source gating and verification | `agent_config/source_strategy.md` |
| Visual production | `agent_config/visual_strategy.md` |
| Tag and platform evaluation | `agent_config/content_operation_strategy.md` |
| Publishing verdicts | `agent_config/review_rules.md` · `agent_config/phanthy_review_standard.md` |

## Creator Style Authority

Script structure and title mechanics are **not** defined in this file.

They are defined solely by:

- `agent_config/distilled/xiaolinshuo/script_structure_rules.md`
- `agent_config/distilled/xiaolinshuo/title_formula_rules.md`

This file references them and states when they apply. It does not reproduce their
rule bodies.

> Rationale: `phanthy_creator_configuration_placement_specification_v1.md` §5 —
> "允许引用其他文件，禁止复制相同规则。核心原则：Single Source of Truth。"
> A local copy would silently diverge from the distilled source whenever that source is updated.


---

# 1. Xiaolinshuo Script Generation Flow

This is the writing flow for this Creator. It replaces the previous
externally-bound skill requirement.

## 1.1 Flow

```
Verified Source Material
        ↓
[STEP 1] Information Extraction
        ↓
[STEP 2] Angle Selection        → governed by script_structure_rules.md
        ↓
[STEP 3] Opening Construction   → governed by script_structure_rules.md
        ↓
[STEP 4] Argument Body          → governed by script_structure_rules.md
        ↓
[STEP 5] Title Generation       → governed by title_formula_rules.md
        ↓
[STEP 6] XHS Copy Adaptation    → governed by §4–§6 of this file
        ↓
[STEP 7] Image-Copy Alignment   → governed by §7 of this file
        ↓
[STEP 8] Engagement Layer       → governed by §4.5 of this file
        ↓
[STEP 9] Self Check             → governed by §10 of this file
```

## 1.2 Step Ownership

| Step | Owner |
|---|---|
| STEP 1 Information Extraction | `agent_config/source_strategy.md` (extraction rules) |
| STEP 2 Angle Selection | `script_structure_rules.md` |
| STEP 3 Opening Construction | `script_structure_rules.md` |
| STEP 4 Argument Body | `script_structure_rules.md` |
| STEP 5 Title Generation | `title_formula_rules.md` |
| STEP 6 XHS Copy Adaptation | this file §4–§6 |
| STEP 7 Image-Copy Alignment | this file §7 |
| STEP 8 Engagement Layer | this file §4.5 |
| STEP 9 Self Check | this file §10 |

## 1.3 Mandatory Reads

Before executing this flow, load:

1. `agent_config/distilled/xiaolinshuo/script_structure_rules.md`
2. `agent_config/distilled/xiaolinshuo/title_formula_rules.md`

Both are required. The distilled files govern STEP 2–5; this file governs STEP 1
and STEP 6–9.

## 1.4 Not Permitted

- Executing the flow without loading the two distilled files.
- Substituting a general-purpose or externally-bound writing style for the
  distilled creator style.
- Reproducing distilled rule bodies inside this file or inside generated output.

> **Distilled status note.** The distilled files are `Status: DRAFT — based on
> public video corpus analysis`. Their source evaluation recorded that sample data
> was not collected in real time. Treat the style rules as provisional until
> validated against recent live samples.
> See `validation/candidates/xiaolinshuo_evaluation_report.md` §8.

## 1.5 Domain Adaptation Note

The distilled rules were derived from long-form explanatory **video**. This Agent
produces **image-text carousel notes** on 小红书.

Therefore:

- Rules about cognitive structure, causal chains and explanation order transfer directly.
- Rules expressed in **time units** (e.g. "within 30 seconds", "explainable within
  20 minutes") must be **re-expressed in carousel units** — images and paragraphs,
  not seconds.
- When a distilled rule is time-bound, convert it to an equivalent structural
  constraint (e.g. "the opening must not spend more than the first image and its
  caption before reaching the core question").


---

# 2. Source Dependency

Final publishable content requires:

source_material

provided by:

agent_config/source_strategy.md

Required source information:

``` yaml
source_material:
  source_url:
  creator:
  platform:
  extracted_facts:
  key_points:
  verification_status:
```


---

# 3. Generation Permission

## Valid Source Exists

Allowed:

- Generate final draft.
- Reconstruct structure.
- Improve readability.
- Adapt to XHS expression style.
- Create visual planning information.

## Source Missing

Allowed:

- Topic analysis.
- Outline.
- Research suggestions.

Not allowed:

- Final publishable article.
- Unsupported facts.
- Fake examples presented as real.


---

# 4. XHS Writing Flow

## 4.1 Structure

Generic explanatory structure (not used as the primary structure here):

```
Conclusion → Reason → Evidence → Example → Suggestion
```

XHS carousel structure:

```
Hook
↓
Value Promise
↓
Core Information
↓
Interpretation Layer
↓
Interaction
```

> The **opening** is not produced by this structure alone. The specific opening
> construction — conflict-first ordering, what must not be used as an opening —
> is owned by `script_structure_rules.md`. This section describes the XHS
> container the opening sits in.

## 4.2 Hook

目标：

前 2 行内容决定用户是否继续阅读。

Hook 必须在正文首句完成，且其内容由 `script_structure_rules.md` 的开头结构决定。

XHS 层要求：

- 不得是空洞的引导语（如"今天分享一下..."）。
- 不得以定义、背景铺陈或结论先行开场。
- 必须让读者在首句感到一个尚未解答的问题。

## 4.3 Value Promise

目标：

在 Hook 之后，明确告诉用户"读完你会得到什么"。

格式要求：

- 承诺必须与正文实际交付的解释一致。
- 禁止承诺正文不提供的价值。

格式示例（结构性）：

- "看完这篇，你会知道 [机制] 是怎么运作的"
- "[现象] 的真正原因，和大众叙事不一样"

## 4.4 Core Information

目标：

交付 Value Promise 承诺的内容。

规则：

- 每段只包含一个信息点。
- 信息点之间有逻辑递进。
- 与图片协作表达（不重复图片已表达的内容）。

解释层要求（承接 `IDENTITY.md` Mechanism Explanation First）：

- 说明"为什么发生 / 如何运行"，而非只描述现象。
- 多层因果链优先于单一原因。

## 4.5 Interaction

目标：

引导用户产生互动行为（评论、收藏、关注）。

规则：

- 每篇内容最多一个互动引导。
- 互动引导必须与内容主题相关。
- 不使用强迫性语言（"必须关注"、"不关注会后悔"）。

示例（结构性）：

- "[这个现象] 你怎么看？"
- "你之前是怎么理解这件事的？"
- "如果这个机制解释对你有用，可以收藏。"

> **Removed from v2.0:** the previous "Emotional Connection" layer instructed the
> Agent to share real failure or confusion experiences. That instruction conflicted
> with `SOUL.md` ("Do not invent personal experiences") and `IDENTITY.md`
> (not a real person; no private information). It has been removed rather than
> weakened. Emotional resonance is now pursued through explanation quality and
> the acceptable emotion types listed in
> `agent_config/content_operation_strategy.md` §5.1 — not through claimed biography.


---

# 5. XHS Title Strategy

## 5.1 Title Length Constraint

≤ 20 字

## 5.2 Title Mechanics Authority

What a title must accomplish, its functional layers, and its prohibitions are
defined solely by:

`agent_config/distilled/xiaolinshuo/title_formula_rules.md`

This section defines only the **XHS platform container** for a title:
length ceiling, and the structural title patterns available on the platform.

## 5.3 Title Patterns

### Question Form

格式：

用一个目标用户正在思考的问题作标题。

适用：

内容回答一个明确的机制问题。

> 必须满足 `title_formula_rules.md` 的「真实问题」判据——
> 读者在点击前确实不知道答案。修辞性问句不可用作标题。

### Curiosity Gap

格式：

暗示存在读者不知道、且与直觉预期不符的信息。

适用：

内容揭示反直觉的结构性原因。

### Contrast Form

格式：

用对比制造认知冲突。

适用：

内容分析导致不同结果的关键变量。

> **Removed from v2.0:** the "Number Hook" pattern (e.g. "3 methods to…", "5 steps…")
> and the previous question/contrast examples drawn from video-production topics.
> Numbered list titles conflict with the creator style: the distilled anti-pattern
> list rejects list structures because they weaken causal depth
> (see `topic_selection_rules.md` §5).

## 5.4 Title Prohibitions

Referenced from `title_formula_rules.md`. Summarised here only as a checklist trigger:

- Must not summarise the content.
- Must not reveal the conclusion.
- Must not take a stance.
- Must not rely on emotional shock.

Detailed rules, rationale and exceptions: `title_formula_rules.md`.


---

# 6. Short Copy Rules

## 6.1 段落约束

- 每段最多 4 行。
- 每行最多 25 字。
- 段落之间空一行。
- 禁止大段连续文字。

## 6.2 表达风格

规则：

- 优先使用短句，避免长从句。
- 信息密度优先于修辞装饰。
- 术语首次出现时给出非专业解释。
- 避免过度书面化表达。

禁止：

- "工程角度""工程实践"类表述——该表述属已废弃的旧人设语言。
- 空洞的励志语句。
- 无根据的鼓励性表达。

> **Removed from v2.0:** the instruction to "preserve engineering expression style"
> and the requirement to use first person ("我"、"我们"). The engineering-expression
> framing belonged to a previous persona. First-person **narration of experience**
> is prohibited; first-person **explanation register** is permitted only where it
> does not imply personal history.

## 6.3 阅读节奏控制

规则：

信息段与解释段交替出现，避免连续多段同类内容。

节奏模式：

```
信息段（呈现现象或数据）
解释段（说明机制）
信息段（推进到下一层）
解释段（收束因果链）
互动段（引导参与）
```

## 6.4 正文字数

平台下限（硬性）：

`agent_config/phanthy_review_standard.md` — 正文文字必须大于 500 字，否则审核不通过。

建议范围：

500–1200 字

低于平台下限：

审核不通过。

超过 1200 字：

拆分为系列内容或删减冗余段落。

> **Corrected from v2.0:** the previous range (300–800 字) conflicted with the
> platform hard floor of 500 characters. The floor is authoritative.


---

# 7. Image-Copy Relationship

## 7.1 核心原则

图片承担主要视觉信息。

文字负责：

- 补充图片无法表达的背景信息。
- 解释图片背后的原因或逻辑。
- 提供图片无法传达的因果层次。

## 7.2 禁止行为

禁止：

正文重复图片已经表达的信息。

示例（错误）：

图片已显示：某经济体的增长曲线图

正文重复：

"这条曲线显示，从第一年到第十年，分别是……"

示例（正确）：

图片已显示：某经济体的增长曲线图

正文补充：

"这条曲线真正的信息不在涨幅，在于它在第三年那次转折——多数人把它解释为外部冲击，
实际触发点是内部的一个结构性约束。"

## 7.3 图片文字生成规则

每张图的覆盖文字独立生成，不依赖正文截断。

约束：

- 封面标题文字：≤ 15 字
- 图片说明文字：≤ 30 字
- 每张图最多 2 层文字

图片文字与正文形成互补，不重复。

> 封面与图片的具体视觉规则归 `agent_config/visual_strategy.md` 与
> `agent_config/distilled/xiaolinshuo/visual_pattern_rules.md`。
> 本节只定义文字与图片的**信息分工**。


---

# 8. Content Reconstruction

The Agent should not perform simple rewriting.

Preserve:

- Verified facts.
- Original meaning.
- Important limitations.
- Source context.

Adjust:

- Narrative structure → conflict-first structure per `script_structure_rules.md`.
- Explanation order → mechanism before conclusion.
- Expression style → short paragraph, plain language, XHS-readable.
- Audience adaptation → readers who want complex topics explained clearly
  (per `agent_config/content_strategy.md` §3).

Avoid:

- Inventing experiences.
- Adding unsupported data.
- Creating fake quotations.
- Changing source conclusions without explanation.


---

# 9. Fact Expression Rules

When information is:

## Verified Fact

Can be stated directly.

## Agent Interpretation

Use analysis language:

Examples:

- "这意味着..."
- "可以理解为..."
- "真正起作用的是..."

> **Removed from v2.0:** "从工程角度看..." — superseded persona language.

## Uncertain Information

Use cautious expressions:

Examples:

- "可能"
- "通常情况下"
- "需要进一步验证"


---

# 10. Quality Check Before Output

Verify:

## Source

□ Source material exists.

□ Important claims can be traced.

□ Evidence quality per `agent_config/source_strategy.md`.

## Script Structure

□ Opening follows `script_structure_rules.md` — conflict-first, no forbidden openings.

□ Causal chain is present and traceable.

□ No list-structure content that weakens causal depth.

## Title

□ Title follows `title_formula_rules.md`.

□ Title poses a real question (not rhetorical).

□ Title ≤ 20 characters.

□ Title does not summarise, conclude, or take a stance.

## Structure

□ Hook is present in the first 2 lines.

□ Value Promise is stated and is actually delivered.

□ Core Information delivers the promise.

□ Interpretation layer explains mechanism, not just phenomenon.

□ Interaction element is present (max 1).

## Copy Rules

□ Each paragraph ≤ 4 lines.

□ Total word count ≥ 500 (platform hard floor).

□ No paragraph duplicates image information.

□ Image text: title ≤ 15 chars, caption ≤ 30 chars.

□ No legacy persona language ("工程角度" etc.).

## Authenticity

□ No fabricated experience.

□ No first-person narration of personal history.

□ No unsupported claims.

□ No false attribution.


---

# 11. Responsibility Boundary

text_generation.md defines:

- Writing execution process.
- Xiaolinshuo Script Generation Flow orchestration.
- XHS expression rules.
- Content transformation.
- Image-copy relationship.
- Title strategy framework.
- Engagement design.

text_generation.md does not define:

- Creator identity or persona.
- Source selection.
- Script structure mechanics (owned by `script_structure_rules.md`).
- Title mechanics (owned by `title_formula_rules.md`).
- Topic selection.
- Visual generation.
- Platform evaluation and tags.
- Publishing permission.


---

# Version

v3.0

Changes from v2.0:

- **Removed external skill binding.** The mandatory `mediastorm-text-generation`
  skill requirement was removed. It bound this workspace to an external,
  out-of-workspace skill that was also creator-mismatched.

- **Removed legacy persona assumptions.**
  - "preserve engineering expression style" (§6.2) — superseded persona.
  - "从工程角度看..." interpretation example (§9) — superseded persona.
  - Requirement to use first person "我/我们" as a persona device.
  - Requirement to share real failure or confusion experiences
    (previous "Emotional Connection" layer) — conflicted with `SOUL.md`
    "Do not invent personal experiences".

- **Added Xiaolinshuo Script Generation Flow** (§1) — a 9-step flow with explicit
  step ownership, mandatory reads, and a domain adaptation note converting
  video-time rules into carousel-structure rules.

- **Wired distilled knowledge.** `script_structure_rules.md` and
  `title_formula_rules.md` are now the declared authorities for STEP 2–5.
  Their rule bodies are referenced, not copied.

- **Removed legacy vertical examples.** Video-production title examples,
  completion-rate examples, numbered-list title pattern, and workflow-diagram
  image examples were removed or replaced with domain-appropriate structural examples.

- **Corrected audience reference.** "XHS creator community" → readers who want
  complex topics explained clearly.

- **Corrected word count.** 300–800 → ≥500 (platform hard floor) with a
  recommended 500–1200 range.

- **Added platform floor to the quality check** and added script/title
  distilled-compliance checks.
