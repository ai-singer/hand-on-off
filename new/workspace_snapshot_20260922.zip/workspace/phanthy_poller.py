#!/usr/bin/env python3
"""
财叔 Phanthy 私聊轮询器
每 30 秒轮询一次消息，有消息时调用 OpenClaw session 处理回复
"""
import time
import json
import subprocess
import logging
import os
from datetime import datetime

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s',
    handlers=[
        logging.FileHandler('/home/node/.openclaw/workspace/phanthy_poll.log'),
        logging.StreamHandler()
    ]
)

API_KEY = "YOUR_PHANTHY_API_KEY"
BASE = "https://cms.phanthy.com/api/v1/openclaw"
POLL_INTERVAL = 30

def api_get(path):
    r = subprocess.run([
        "curl", "-s", "--max-time", "15",
        f"{BASE}{path}",
        "-H", f"Authorization: Bearer {API_KEY}"
    ], capture_output=True, text=True)
    return json.loads(r.stdout) if r.stdout else {}

def api_post(path, body):
    r = subprocess.run([
        "curl", "-s", "--max-time", "15",
        "-X", "POST",
        f"{BASE}{path}",
        "-H", f"Authorization: Bearer {API_KEY}",
        "-H", "Content-Type: application/json",
        "-d", json.dumps(body, ensure_ascii=False)
    ], capture_output=True, text=True)
    return json.loads(r.stdout) if r.stdout else {}

def build_reply(latest_content, history):
    """
    财叔人设：财经知识内容创作者，机制解释型，不讲故事讲结构。
    根据用户消息生成回复。
    """
    # Build a simple context string for the model
    ctx = ""
    if history:
        for m in history[-6:]:  # last 6 messages
            role = "用户" if m.get("role") == "user" else "财叔"
            ctx += f"{role}：{m.get('content','')}\n"
    ctx += f"用户：{latest_content}\n财叔："

    r = subprocess.run([
        "curl", "-s", "--max-time", "45",
        "-X", "POST",
        "https://router.phanthy.com/v1beta/models/gemini-3-pro-image:generateContent",
        "-H", "x-goog-api-key: YOUR_API_KEY",
        "-H", "Content-Type: application/json",
        "-d", json.dumps({
            "contents": [{"parts": [{"text": (
                "你是财叔，一个财经知识内容创作者。\n"
                "风格：机制解释型，不讲故事讲结构，用清晰简洁的语言解释商业财经背后的逻辑。\n"
                "不提供投资建议。回复控制在200字以内。\n\n"
                f"对话记录：\n{ctx}"
            )}]}],
            "generationConfig": {
                "responseModalities": ["TEXT"],
                "maxOutputTokens": 500
            }
        }, ensure_ascii=False)
    ], capture_output=True, text=True)

    if r.stdout:
        try:
            resp = json.loads(r.stdout)
            parts = resp.get("candidates", [{}])[0].get("content", {}).get("parts", [])
            for p in parts:
                if p.get("text"):
                    return p["text"].strip()
        except Exception:
            pass
    return "感谢你的消息，我稍后回复你。"

def process_messages():
    data = api_get("/messages")
    messages = data.get("messages", [])
    has_more = data.get("hasMore", False)

    for msg in messages:
        delivery_id = msg["id"]
        version = msg["version"]
        lease_token = msg["leaseToken"]
        latest_content = msg.get("latestContent", "")
        history = msg.get("history", [])

        logging.info(f"New message [{delivery_id}]: {latest_content[:80]}")

        reply_text = build_reply(latest_content, history)
        logging.info(f"Reply: {reply_text[:80]}")

        result = api_post(f"/messages/{delivery_id}/reply", {
            "content": reply_text,
            "version": version,
            "leaseToken": lease_token
        })
        if result.get("success"):
            logging.info(f"Reply sent OK [{delivery_id}]")
        else:
            logging.warning(f"Reply failed: {result}")

    if has_more:
        process_messages()

def process_comments():
    data = api_get("/comments/unread")
    comments = data.get("comments", [])

    for c in comments:
        delivery_id = c["id"]
        version = c["version"]
        lease_token = c["leaseToken"]
        latest_content = c.get("latestContent", "")

        logging.info(f"New comment [{delivery_id}]: {latest_content[:80]}")

        reply_text = build_reply(latest_content, [])
        # Comments max 300 chars
        reply_text = reply_text[:290]

        result = api_post(f"/comments/{delivery_id}/reply", {
            "content": reply_text,
            "version": version,
            "leaseToken": lease_token
        })
        if result.get("success"):
            logging.info(f"Comment reply sent OK [{delivery_id}]")
        else:
            logging.warning(f"Comment reply failed: {result}")

def main():
    logging.info("财叔 Phanthy 轮询器启动")
    while True:
        try:
            process_messages()
            process_comments()
        except Exception as e:
            logging.error(f"Poll error: {e}")
        time.sleep(POLL_INTERVAL)

if __name__ == "__main__":
    main()


# Write PID file on startup
import atexit
_PIDFILE = '/tmp/phanthy_poller.pid'
with open(_PIDFILE, 'w') as _f:
    _f.write(str(os.getpid()))

def _cleanup():
    try:
        os.unlink(_PIDFILE)
    except Exception:
        pass
atexit.register(_cleanup)
