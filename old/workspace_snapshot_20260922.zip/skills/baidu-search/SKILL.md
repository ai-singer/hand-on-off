---
name: baidu_search
version: 1.0.1
description: 通过百度搜索服务查询网页、新闻、图片或视频，返回结构化搜索结果
---

# Baidu Search Skill

本技能调用部署在内网的百度搜索服务，支持对任意关键词进行网页、图片、视频搜索，返回带标题、URL、摘要、来源及媒体信息的结构化 JSON 结果。支持非流式与流式两种输出方式，并可按时间范围过滤结果。

---

## Step 1 — 读取 baidu-search 配置

运行以下 Python 脚本，从用户配置中找到 baidu-search 服务的 baseUrl 与 apiKey：

```python
import json, os
config = json.load(open(os.path.expanduser('~/.openclaw/openclaw.json')))
providers = config.get('models', {}).get('providers', {})
results = []
for pname, pcfg in providers.items():
    for m in pcfg.get('models', []):
        if m.get('id') == 'baidu-search':
            results.append({
                'provider': pname,
                'apiKey': pcfg.get('apiKey', ''),
                'baseUrl': pcfg.get('baseUrl', ''),
                'modelId': m.get('id'),
                'modelName': m.get('name', 'baidu-search')
            })
print(json.dumps(results, indent=2))
```

- 若结果为空：告知用户未找到 baidu-search 配置，停止执行。
- 若只有 1 条：自动使用，并告知用户当前使用的 provider。
- 若有多条：列出编号列表，请用户选择。

取出所选条目的 `baseUrl` 和 `apiKey`，用于后续请求。

---

## Step 2 — 发起搜索请求

用以下 Python 脚本执行搜索。将 `BASE_URL`、`API_KEY`、`query` 以及 `search_parameters` 替换为实际值：

```python
import json, urllib.request

BASE_URL = "<baseUrl>"   # 从 Step 1 取得, 一般是带v1的，如果不带，要手工加上
API_KEY  = "<apiKey>"    # 从 Step 1 取得

payload = {
    "model": "baidu-search",
    "messages": [{"role": "user", "content": "<搜索词>"}],
    "stream": False,
    "search_parameters": {
        "search_type": "web",   # web / image / video
        "top_k": 10,            # 最大返回条数
        "time_range": None      # day / week / month / year，不限则填 None
    }
}

req = urllib.request.Request(
    f"{BASE_URL}/chat/completions",
    data=json.dumps(payload).encode(),
    headers={
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
    },
    method="POST",
)
with urllib.request.urlopen(req) as resp:
    data = json.loads(resp.read())

results = json.loads(data["choices"][0]["message"]["content"])
print(json.dumps(results, indent=2, ensure_ascii=False))
```

### search_parameters 参数说明

| 参数 | 类型 | 说明 |
|------|------|------|
| `search_type` | string | `web`（默认）/ `image` / `video` |
| `top_k` | integer | 最大返回结果数，默认 `10` |
| `time_range` | string | 时间过滤：`day` / `week` / `month` / `year`，不传则不限 |

---

## Step 3 — 处理返回结果

`results["results"]` 是列表，每条结构如下：

```json
{
  "id": "1",
  "title": "标题",
  "url": "https://...",
  "website": "来源网站",
  "date": "2024-01-01 00:00:00",
  "content": "正文摘要",
  "type": "web",
  "rerank_score": 1.0,
  "video": {
    "url": "",
    "height": "960",
    "width": "540",
    "duration": "123",
    "hover_pic": "https://..."
  }
}
```

`video` / `image` / `web_extensions` 字段仅在对应 `type` 时出现。

`usage` 字段记录本次请求的输入/输出字符数：

```json
{
  "prompt_tokens": 3,
  "completion_tokens": 1200,
  "total_tokens": 1203
}
```

---

## 流式请求（可选）

若需边收边处理，将 `"stream": True` 并改用流式读取：

```python
import json, urllib.request

BASE_URL = "<baseUrl>"  # 一般是带v1的，如果不带，要手工加上
API_KEY  = "<apiKey>"

payload = {
    "model": "baidu-search",
    "messages": [{"role": "user", "content": "<搜索词>"}],
    "stream": True,
    "search_parameters": {"search_type": "web", "top_k": 10}
}

req = urllib.request.Request(
    f"{BASE_URL}/chat/completions",
    data=json.dumps(payload).encode(),
    headers={
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
    },
    method="POST",
)
with urllib.request.urlopen(req) as resp:
    for raw_line in resp:
        line = raw_line.decode().strip()
        if not line.startswith("data:"):
            continue
        payload_str = line[5:].strip()
        if payload_str == "[DONE]":
            break
        chunk = json.loads(payload_str)
        delta = chunk["choices"][0]["delta"].get("content", "")
        if delta:
            print(delta, end="", flush=True)
        # 最后一个 chunk 含 usage
        if chunk["choices"][0].get("finish_reason") == "stop":
            usage = chunk.get("usage", {})
            print(f"\n\nusage: {usage}")
```

---

## 错误处理

| HTTP 状态 | 说明 |
|-----------|------|
| 401 | API Key 无效 |
| 422 | 请求参数校验失败（如 `search_type` 值不合法） |
| 502 | 百度搜索服务请求失败或网络超时 |

错误体格式（OpenAI 兼容）：

```json
{
  "error": {
    "message": "search_parameters.search_type: Input should be 'web', 'image' or 'video', got 'xxx'",
    "type": "invalid_request_error",
    "param": "search_parameters.search_type",
    "code": "invalid_request_error"
  }
}
```
