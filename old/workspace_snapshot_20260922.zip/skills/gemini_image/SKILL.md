---
name: gemini_image
version: 1.0.3
description: 使用 Google Gemini 图像模型生成或编辑图片（upload by pocari_fans）
---

You are an image generation assistant that uses Google Gemini image models via the OpenClaw config.

When invoked, perform the following steps:

## Step 1 — Discover available image models

Run this Python script to find Gemini image providers in the user's config:

```python
import json, re
import os; config = json.load(open(os.path.expanduser('~/.openclaw/openclaw.json')))
providers = config.get('models', {}).get('providers', {})
results = []
for pname, pcfg in providers.items():
    if pcfg.get('api') != 'google-generative-ai':
        continue
    for m in pcfg.get('models', []):
        mid = m.get('id', '')
        inputs = m.get('input', [])
        if 'image' in inputs or re.search(r'image', mid, re.IGNORECASE):
            results.append({
                'provider': pname,
                'apiKey': pcfg['apiKey'],
                'baseUrl': pcfg['baseUrl'],
                'modelId': mid,
                'modelName': m.get('name', mid)
            })
print(json.dumps(results, indent=2))
```

- If 0 results: inform the user that no Gemini image models are configured and stop.
- If 1 result: use it automatically and tell the user which model you're using.
- If multiple results: display a numbered list and ask the user to choose one.

## Step 2 — Determine the task

Ask the user:
- **Generate**: create a new image from a text prompt
- **Edit**: modify an existing image file using instructions

## Step 3 — Collect inputs

**For Generate:**
- Text prompt (required)
- Aspect ratio (optional, default `1:1`) — valid values: `1:1`, `16:9`, `9:16`, `4:3`, `3:4`, `2:3`, `3:2`, `4:1`, `1:4`, `5:4`, `21:9`
- Image size (optional, default `1K`) — valid values: `512` (Flash models only), `1K`, `2K`, `4K`

**For Edit:**
- Path to source image file (required)
- Edit instructions (required)
- Image size (optional, default `1K`)

## Step 4 — Build and send the API request

Use Python to build the JSON body and pipe it to curl to avoid shell escaping issues.

**Text-to-image generation:**

```bash
python3 -c "
import json
body = {
  'contents': [{'parts': [{'text': 'YOUR_PROMPT_HERE'}]}],
  'generationConfig': {
    'responseModalities': ['TEXT', 'IMAGE'],
    'imageConfig': {'aspectRatio': 'ASPECT_RATIO', 'imageSize': 'IMAGE_SIZE'}
  }
}
print(json.dumps(body))
" | curl -s --max-time 120 -X POST \
  "BASEURL/models/MODEL_ID:generateContent" \
  -H "x-goog-api-key: APIKEY" \
  -H "Content-Type: application/json" \
  -d @-
```

Replace `YOUR_PROMPT_HERE`, `ASPECT_RATIO`, `IMAGE_SIZE`, `BASEURL`, `MODEL_ID`, and `APIKEY` with the actual values.

**Image editing (include source image as base64):**

```bash
python3 -c "
import json, base64
img_b64 = base64.b64encode(open('SOURCE_IMAGE_PATH', 'rb').read()).decode()
body = {
  'contents': [{'parts': [
    {'text': 'EDIT_INSTRUCTIONS'},
    {'inlineData': {'mimeType': 'image/png', 'data': img_b64}}
  ]}],
  'generationConfig': {
    'responseModalities': ['TEXT', 'IMAGE'],
    'imageConfig': {'imageSize': 'IMAGE_SIZE'}
  }
}
print(json.dumps(body))
" | curl -s --max-time 120 -X POST \
  "BASEURL/models/MODEL_ID:generateContent" \
  -H "x-goog-api-key: APIKEY" \
  -H "Content-Type: application/json" \
  -d @-
```

Replace placeholders with actual values. If the source image is JPEG, use `'mimeType': 'image/jpeg'` instead.

Save the full curl output to a temporary file for processing in the next step:

```bash
... | curl ... -o /tmp/gemini_response.json
```

## Step 5 — Extract and save output images

Run this Python script to parse the response and save any images:

```python
import json, base64, os, sys
from datetime import datetime

with open('/tmp/gemini_response.json') as f:
    response = json.load(f)

# Check for errors
if 'error' in response:
    print(f"API error: {response['error'].get('message', response['error'])}")
    sys.exit(1)

os.makedirs(os.path.expanduser('~/generated_images'), exist_ok=True)
timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')

parts = response.get('candidates', [{}])[0].get('content', {}).get('parts', [])
saved = []
for i, part in enumerate(parts):
    inline = part.get('inlineData') or part.get('inline_data')
    if inline:
        data = base64.b64decode(inline['data'])
        mime = inline.get('mimeType') or inline.get('mime_type', 'image/png')
        ext = 'jpg' if 'jpeg' in mime else 'png'
        path = os.path.expanduser(f'~/generated_images/{timestamp}_{i}.{ext}')
        open(path, 'wb').write(data)
        saved.append(path)
        print(f'Image saved: {path}')
    elif part.get('text'):
        print(f'Model note: {part["text"]}')

if not saved:
    print('No images were returned. Full response:')
    print(json.dumps(response, indent=2))
```

## Step 6 — Report results

Tell the user:
- The path(s) where images were saved (e.g. `~/.openclaw/generated_images/2026-04-17_12-30-00_0.png`)
- Any text the model returned alongside the image
- If no images were generated, show the full API response so the user can diagnose the issue

## API Parameters Reference

| Parameter | Values | Default |
|-----------|--------|---------|
| `aspectRatio` | `1:1`, `16:9`, `9:16`, `4:3`, `3:4`, `2:3`, `3:2`, `4:1`, `1:4`, `5:4`, `21:9` | `1:1` |
| `imageSize` | `512` (Flash only), `1K`, `2K`, `4K` | `1K` |
| `responseModalities` | `["TEXT","IMAGE"]`, `["IMAGE"]` | `["TEXT","IMAGE"]` |
