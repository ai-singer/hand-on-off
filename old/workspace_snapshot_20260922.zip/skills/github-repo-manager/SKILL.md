---
name: github-repo-manager
description: Manage the GitHub repository ai-singer/hand-on-off via GitHub API. Use when asked to upload files, delete files, create directories, list repo contents, or perform any file operations on this repository. Triggers on phrases like "上传到github", "删除github文件", "创建目录", "github仓库", "push to repo", "delete from repo".
---

# GitHub Repo Manager

Manages the repository `ai-singer/hand-on-off` via GitHub REST API.

## Config

- **Repo**: `ai-singer/hand-on-off`
- **API base**: `https://api.github.com/repos/ai-singer/hand-on-off`
- **Auth**: Read `GITHUB_KEY` from `/home/node/.openclaw/workspace/.env`
- **Branch**: `main` (default)

Load the key at runtime:
```bash
GITHUB_KEY=$(grep GITHUB_KEY /home/node/.openclaw/workspace/.env | cut -d'=' -f2)
```

## Common Operations

### List contents
```bash
curl -s -H "Authorization: Bearer $GITHUB_KEY" \
  "https://api.github.com/repos/ai-singer/hand-on-off/contents/<path>"
```

### Get file SHA (required before update/delete)
```bash
curl -s -H "Authorization: Bearer $GITHUB_KEY" \
  "https://api.github.com/repos/ai-singer/hand-on-off/contents/<path>" \
  | python3 -c "import json,sys; print(json.load(sys.stdin)['sha'])"
```

### Upload / update a file
```bash
CONTENT=$(base64 -w0 < <file>)
curl -s -X PUT \
  -H "Authorization: Bearer $GITHUB_KEY" \
  -H "Content-Type: application/json" \
  -d "{\"message\":\"<commit msg>\",\"content\":\"$CONTENT\"}" \
  "https://api.github.com/repos/ai-singer/hand-on-off/contents/<path>"
```
For update, add `"sha":"<sha>"` to the JSON body.

### Create a directory
GitHub has no empty directories — create a placeholder file:
```bash
curl -s -X PUT \
  -H "Authorization: Bearer $GITHUB_KEY" \
  -H "Content-Type: application/json" \
  -d '{"message":"create <dir>","content":""}' \
  "https://api.github.com/repos/ai-singer/hand-on-off/contents/<dir>/.gitkeep"
```

### Delete a file
```bash
curl -s -X DELETE \
  -H "Authorization: Bearer $GITHUB_KEY" \
  -H "Content-Type: application/json" \
  -d "{\"message\":\"<commit msg>\",\"sha\":\"<sha>\"}" \
  "https://api.github.com/repos/ai-singer/hand-on-off/contents/<path>"
```

## Directory Structure

| Directory | Purpose |
|---|---|
| `finance-materials/` | 财经素材 — financial source material |

## Notes

- Always verify with a list call before reporting success.
- Use English for commit messages and directory names.
- Never echo the token value in responses.
