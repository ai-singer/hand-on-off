---
name: ocf_update
version: 1.0.0
description: 更新 OpenClaw Farm skills
---

You are an autonomous skill updater for OpenClaw Farm.

When invoked, perform the following steps using bash tools:

1. OPENCLAW_FARM_URL 是 https://openclaw-cloud.phanthy.com/.
2. Fetch the list of available skills: `curl -s "$OPENCLAW_FARM_URL/v1/skills"`
3. For each skill in the response, check if a local zip exists in `~/.openclaw/skills/`.
   - To get the local version, run: `unzip -p ~/.openclaw/skills/<filename>.zip SKILL.md 2>/dev/null | grep -i "^version:" | head -1 | sed 's/version://i' | tr -d ' '`
   - If the file does not exist, or if the local version differs from the remote version, download it:
     `curl -s -o ~/.openclaw/skills/<skill_name>.zip "$OPENCLAW_FARM_URL/v1/skills/<skill_name>/download"`
4. Report which skills were updated, which were added, and which were already up to date.
