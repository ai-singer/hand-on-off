# Universal Runner Skill

通用多语言代码执行器，支持 Python、JavaScript、Bash 等语言的安全沙箱执行。

## 🚀 快速开始

### 执行 Python 代码

```yaml
language: python
code: |
  print("Hello, World!")
  data = [1, 2, 3, 4, 5]
  print(f"Sum: {sum(data)}")
```

### 执行 JavaScript 代码

```yaml
language: javascript
code: |
  const data = [1, 2, 3, 4, 5];
  const sum = data.reduce((a, b) => a + b, 0);
  console.log(`Sum: ${sum}`);
```

## 📋 支持的语言

| 语言 | 标识符 | 执行模式 |
|------|--------|----------|
| Python | `python`, `py` | Sub-agent / Local |
| JavaScript | `javascript`, `js` | Browser / Node |
| Bash | `bash`, `sh` | Sub-agent / Local |

## 🔧 执行模式

### Mode 1: Sub-agent（推荐）
- 最安全，完全隔离
- 需要 Gateway 配对
- 支持长时间运行

### Mode 2: Browser
- 无需额外权限
- 仅支持 JavaScript
- 即时执行

### Mode 3: Local
- 直接本地执行
- 需要 `exec` 权限
- 最高性能

## 📁 文件结构

```
universal-runner/
├── SKILL.md           # Skill 定义
├── runner.py          # 核心执行器
├── config.yaml        # 默认配置
├── README.md          # 说明文档
├── examples/          # 使用示例
│   ├── python_data_analysis.yaml
│   └── js_json_parse.yaml
└── pack.sh            # 打包脚本
```

## ⚙️ 配置选项

```yaml
config:
  timeout_seconds: 30      # 执行超时
  memory_mb: 256          # 内存限制
  max_output_chars: 10000 # 输出限制
  allow_network: false    # 允许网络
  allow_file_write: true  # 允许写文件
```

## 🔒 安全说明

- 默认启用沙箱隔离
- 禁止危险系统调用
- 执行超时保护
- 输出大小限制

## 📊 当前环境状态

当前环境限制：
- ❌ `exec` 受限（allowlist miss）
- ❌ Gateway 未配对（无法使用 sub-agent）
- ✅ Browser 工具可用

**推荐：** 使用 JavaScript + Browser 模式立即开始。

## 📝 示例

### 数据分析

见 `examples/python_data_analysis.yaml`

### JSON 处理

见 `examples/js_json_parse.yaml`

## 🔮 未来扩展

计划支持：
- TypeScript
- Go
- Rust
- Docker 沙箱

## 📄 License

MIT License
