---
name: universal_runner
version: 1.0.0
description: 通用多语言代码执行器 - 支持 Python、JavaScript、Bash 等语言的沙箱执行
---

# Universal Runner Skill

通用代码执行器，支持多种编程语言的安全沙箱执行。

## 支持的语言

| 语言 | 标识符 | 执行方式 | 状态 |
|------|--------|----------|------|
| Python | `python`, `py` | Sub-agent / Local | ✅ |
| JavaScript | `javascript`, `js` | Browser / Node | ✅ |
| Bash/Shell | `bash`, `sh` | Sub-agent / Local | ⚠️ 受限 |
| TypeScript | `typescript`, `ts` | Browser / Node | 🔄 计划中 |
| Go | `go` | Remote | 🔄 计划中 |

## 执行模式

### 模式 A: Sub-agent 执行（推荐）

使用 `sessions_spawn` 创建隔离的执行环境。

**优点：**
- 完全隔离，不影响主进程
- 支持长时间运行
- 资源可控

**限制：**
- 需要 Gateway 配对

### 模式 B: Browser 执行（JavaScript 专用）

使用 `browser` 工具的 `evaluate` 在浏览器上下文执行。

**优点：**
- 无需额外权限
- 即时执行

**限制：**
- 仅支持 JavaScript
- 无法访问文件系统

### 模式 C: 在线沙箱（Fallback）

使用外部在线代码执行服务。

**优点：**
- 支持多种语言
- 无需本地配置

**限制：**
- 依赖网络
- 数据离开本地

---

## 使用方法

### 执行 Python 代码

```yaml
language: python
code: |
  def fibonacci(n):
      if n <= 1:
          return n
      return fibonacci(n-1) + fibonacci(n-2)
  
  result = fibonacci(10)
  print(f"Fibonacci(10) = {result}")
```

### 执行 JavaScript 代码

```yaml
language: javascript
code: |
  const data = [1, 2, 3, 4, 5];
  const sum = data.reduce((a, b) => a + b, 0);
  console.log(`Sum: ${sum}`);
```

### 带输入参数的执行

```yaml
language: python
input:
  name: "World"
  count: 5
code: |
  import json
  import sys
  
  # 读取输入
  input_data = json.loads(sys.argv[1])
  name = input_data.get("name", "Anonymous")
  count = input_data.get("count", 1)
  
  for i in range(count):
      print(f"Hello, {name}! ({i+1}/{count})")
```

### 带文件操作的执行

```yaml
language: python
files:
  input.txt: |
    Line 1
    Line 2
    Line 3
code: |
  with open('input.txt', 'r') as f:
      lines = f.readlines()
  
  print(f"Total lines: {len(lines)}")
  for i, line in enumerate(lines, 1):
      print(f"{i}: {line.strip()}")
```

---

## 执行流程

```
User Request
    ↓
Parse Language & Code
    ↓
Select Execution Mode
    ↓
┌─────────┬─────────┬─────────┐
│ Sub-agent│ Browser │ Online  │
└─────────┴─────────┴─────────┘
    ↓         ↓         ↓
Prepare Environment
    ↓
Execute Code
    ↓
Capture Output
    ↓
Return Result
```

---

## 输出格式

```json
{
  "status": "success" | "error" | "timeout",
  "language": "python",
  "stdout": "...",
  "stderr": "...",
  "exit_code": 0,
  "execution_time_ms": 1234,
  "files": {
    "output.txt": "..."
  }
}
```

---

## 安全限制

### 默认限制

- **执行超时**: 30 秒
- **内存限制**: 256 MB
- **输出限制**: 10,000 字符
- **禁止网络**: 默认禁止外部网络访问
- **禁止系统调用**: 禁止危险系统调用

### 可配置选项

```yaml
limits:
  timeout_seconds: 30
  memory_mb: 256
  max_output_chars: 10000
  allow_network: false
  allow_file_write: true
```

---

## 实现说明

### 当前环境适配

由于当前 `exec` 受限，skill 提供以下适配：

1. **自动检测**: 检查可用执行方式
2. **降级策略**: 优先使用可用方式
3. **错误提示**: 清晰说明限制和替代方案

### 执行优先级

1. 如果 Gateway 配对 → 使用 `sessions_spawn`
2. 如果是 JavaScript → 使用 `browser.evaluate`
3. 如果允许网络 → 使用在线沙箱
4. 否则 → 返回错误 + 配置建议

---

## 使用示例

### 运行单元测试

```yaml
language: python
task: test
working_dir: /home/node/.openclaw/workspace/source_collector
command: pytest tests/test_bilibili_collector.py -v
```

### 数据分析

```yaml
language: python
code: |
  import json
  
  # 读取选题库
  with open('选题库/topics.json') as f:
      data = json.load(f)
  
  topics = data.get('topics', [])
  pending = [t for t in topics if t.get('status') == 'pending']
  
  print(f"Total topics: {len(topics)}")
  print(f"Pending: {len(pending)}")
```

### 文件处理

```yaml
language: bash
code: |
  find /home/node/.openclaw/workspace -name "*.md" | wc -l
```

---

## 故障排除

### "exec denied: allowlist miss"

**原因:** 当前环境限制命令执行

**解决:**
1. 使用 `sessions_spawn` 模式（需要 Gateway 配对）
2. 使用 Browser 模式（仅 JavaScript）
3. 配置 `tools.exec.allowlist`

### "Gateway pairing required"

**原因:** 需要 Gateway 配对才能使用 sub-agent

**解决:**
1. 运行 `openclaw pair` 配对
2. 或使用 Browser/在线模式

---

## 版本历史

- v1.0.0: 初始版本，支持 Python/JavaScript/Bash
