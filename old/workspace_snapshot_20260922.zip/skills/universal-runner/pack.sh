#!/bin/bash
# Universal Runner Skill 打包脚本

SKILL_NAME="universal-runner"
SKILL_VERSION="1.0.0"
OUTPUT_DIR="$HOME/.openclaw/skills"

echo "📦 打包 Universal Runner Skill..."

# 创建临时目录
TMP_DIR=$(mktemp -d)
trap "rm -rf $TMP_DIR" EXIT

# 复制文件
cp SKILL.md "$TMP_DIR/"
cp runner.py "$TMP_DIR/"
cp config.yaml "$TMP_DIR/"

# 复制示例目录
if [ -d "examples" ]; then
    cp -r examples "$TMP_DIR/"
fi

# 创建 skill 包
cd "$TMP_DIR"
zip -r "$OUTPUT_DIR/${SKILL_NAME}.skill" .

echo "✅ Skill 已打包: $OUTPUT_DIR/${SKILL_NAME}.skill"
echo ""
echo "使用方法:"
echo "  1. Skill 将自动在 ~/.openclaw/skills/ 中可用"
echo "  2. 系统启动时会加载"
echo ""
echo "文件结构:"
find . -type f | head -20
