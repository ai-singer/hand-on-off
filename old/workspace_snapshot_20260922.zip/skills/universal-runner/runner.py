#!/usr/bin/env python3
"""
Universal Runner - 多语言代码执行器核心
支持多种执行后端
"""

import json
import os
import sys
from typing import Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class ExecutionResult:
    """代码执行结果"""
    status: str  # success, error, timeout
    language: str
    stdout: str
    stderr: str
    exit_code: int
    execution_time_ms: int
    files: Optional[Dict[str, str]] = None
    error_message: Optional[str] = None


class BaseRunner:
    """执行器基类"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.timeout = config.get('timeout_seconds', 30)
        self.max_output = config.get('max_output_chars', 10000)
    
    def execute(self, code: str, input_data: Dict = None) -> ExecutionResult:
        raise NotImplementedError


class SubAgentRunner(BaseRunner):
    """
    使用 sessions_spawn 执行代码
    需要 Gateway 配对
    """
    
    def execute(self, code: str, input_data: Dict = None) -> ExecutionResult:
        # 构建 sub-agent 任务
        task = self._build_task(code, input_data)
        
        # 返回 sub-agent 配置（实际执行需要 sessions_spawn）
        return {
            "mode": "subagent",
            "task": task,
            "requires_spawn": True
        }
    
    def _build_task(self, code: str, input_data: Dict) -> str:
        """构建 sub-agent 执行脚本"""
        return f"""
Execute the following Python code and return JSON output:

```python
import json
import sys
import io
import traceback

# Capture output
old_stdout = sys.stdout
old_stderr = sys.stderr
sys.stdout = io.StringIO()
sys.stderr = io.StringIO()

try:
{self._indent_code(code)}
    
    stdout = sys.stdout.getvalue()
    stderr = sys.stderr.getvalue()
    
    result = {{
        "status": "success",
        "stdout": stdout,
        "stderr": stderr,
        "exit_code": 0
    }}
except Exception as e:
    stdout = sys.stdout.getvalue()
    stderr = sys.stderr.getvalue()
    
    result = {{
        "status": "error",
        "stdout": stdout,
        "stderr": stderr,
        "exit_code": 1,
        "error": str(e),
        "traceback": traceback.format_exc()
    }}
finally:
    sys.stdout = old_stdout
    sys.stderr = old_stderr

print(json.dumps(result))
```

Return the JSON result only.
"""
    
    def _indent_code(self, code: str) -> str:
        """缩进代码块"""
        lines = code.strip().split('\n')
        return '\n'.join('    ' + line for line in lines)


class BrowserRunner(BaseRunner):
    """
    使用 browser evaluate 执行 JavaScript
    无需额外权限
    """
    
    def execute(self, code: str, input_data: Dict = None) -> ExecutionResult:
        # 包装代码以捕获输出
        wrapped_code = f"""
(function() {{
    const originalLog = console.log;
    const originalError = console.error;
    const logs = [];
    const errors = [];
    
    console.log = (...args) => logs.push(args.join(' '));
    console.error = (...args) => errors.push(args.join(' '));
    
    let result = null;
    let error = null;
    
    try {{
{self._indent_js(code)}
        result = {self._get_last_expression(code)};
    }} catch (e) {{
        error = e.message + '\\n' + e.stack;
    }}
    
    console.log = originalLog;
    console.error = originalError;
    
    return JSON.stringify({{
        status: error ? 'error' : 'success',
        result: result,
        logs: logs.join('\\n'),
        errors: errors.join('\\n'),
        error: error
    }});
}})()
"""
        
        return {
            "mode": "browser",
            "code": wrapped_code,
            "requires_browser": True
        }
    
    def _indent_js(self, code: str) -> str:
        """缩进 JS 代码"""
        lines = code.strip().split('\n')
        return '\n'.join('        ' + line for line in lines)
    
    def _get_last_expression(self, code: str) -> str:
        """尝试提取最后一个表达式"""
        lines = code.strip().split('\n')
        last_line = lines[-1].strip()
        
        # 如果最后一行是赋值或控制流，返回 undefined
        if any(last_line.startswith(kw) for kw in ['var ', 'let ', 'const ', 'if ', 'for ', 'while ', 'return']):
            return 'undefined'
        
        return last_line if last_line else 'undefined'


class MockRunner(BaseRunner):
    """
    Mock 执行器 - 用于演示和测试
    不实际执行代码，返回模拟结果
    """
    
    def execute(self, code: str, input_data: Dict = None) -> ExecutionResult:
        return ExecutionResult(
            status="mock",
            language=self.config.get('language', 'unknown'),
            stdout=f"[MOCK] Would execute:\n{code[:200]}...",
            stderr="",
            exit_code=0,
            execution_time_ms=0,
            error_message="This is a mock execution. Real execution requires Gateway pairing or exec permissions."
        )


class UniversalRunner:
    """
    通用代码执行器
    自动选择最佳执行方式
    """
    
    LANGUAGE_MAP = {
        'python': ['python', 'py', 'python3'],
        'javascript': ['javascript', 'js', 'node', 'nodejs'],
        'bash': ['bash', 'sh', 'shell'],
        'typescript': ['typescript', 'ts'],
    }
    
    def __init__(self):
        self.runners = {}
        self._detect_capabilities()
    
    def _detect_capabilities(self):
        """检测可用执行能力"""
        self.capabilities = {
            'subagent': False,  # 需要 Gateway 配对
            'browser': True,    # browser 工具可用
            'exec': False,      # 当前受限
            'online': False,    # 网络未配置
        }
    
    def get_runner(self, language: str, config: Dict = None) -> BaseRunner:
        """获取适合语言的执行器"""
        config = config or {}
        normalized_lang = self._normalize_language(language)
        config['language'] = normalized_lang
        
        # 执行优先级
        if normalized_lang == 'javascript' and self.capabilities['browser']:
            return BrowserRunner(config)
        
        if self.capabilities['subagent']:
            return SubAgentRunner(config)
        
        # Fallback: Mock
        return MockRunner(config)
    
    def _normalize_language(self, language: str) -> str:
        """标准化语言标识符"""
        lang_lower = language.lower()
        
        for norm_lang, aliases in self.LANGUAGE_MAP.items():
            if lang_lower in aliases:
                return norm_lang
        
        return lang_lower
    
    def execute(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """
        执行代码
        
        输入格式:
        {
            "language": "python",
            "code": "print('Hello')",
            "input": {...},
            "config": {...}
        }
        """
        language = request.get('language', 'python')
        code = request.get('code', '')
        input_data = request.get('input', {})
        config = request.get('config', {})
        
        runner = self.get_runner(language, config)
        result = runner.execute(code, input_data)
        
        # 如果是 dict（配置），转换为 ExecutionResult
        if isinstance(result, dict):
            if result.get('requires_spawn') or result.get('requires_browser'):
                return {
                    "status": "needs_execution",
                    "mode": result.get('mode'),
                    "message": f"Code ready for {result.get('mode')} execution",
                    "payload": result
                }
        
        return result.__dict__ if hasattr(result, '__dict__') else result
    
    def get_capabilities(self) -> Dict[str, Any]:
        """返回当前可用能力"""
        return {
            "capabilities": self.capabilities,
            "supported_languages": list(self.LANGUAGE_MAP.keys()),
            "recommendations": self._get_recommendations()
        }
    
    def _get_recommendations(self) -> list:
        """获取使用建议"""
        recs = []
        
        if not self.capabilities['subagent']:
            recs.append({
                "type": "warning",
                "message": "Sub-agent execution unavailable (Gateway pairing required)",
                "action": "Run: openclaw pair"
            })
        
        if not self.capabilities['exec']:
            recs.append({
                "type": "warning", 
                "message": "Local command execution unavailable (exec allowlist restricted)",
                "action": "Check config: tools.exec.allowlist"
            })
        
        if self.capabilities['browser']:
            recs.append({
                "type": "info",
                "message": "JavaScript execution available via browser"
            })
        
        return recs


# 命令行接口
if __name__ == '__main__':
    runner = UniversalRunner()
    
    if len(sys.argv) > 1 and sys.argv[1] == '--capabilities':
        print(json.dumps(runner.get_capabilities(), indent=2))
    else:
        # 示例执行
        request = {
            "language": "python",
            "code": "print('Hello from Universal Runner!')"
        }
        result = runner.execute(request)
        print(json.dumps(result, indent=2, default=str))
