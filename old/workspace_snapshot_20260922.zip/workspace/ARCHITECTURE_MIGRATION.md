# Architecture Migration Plan v1.4

# Purpose

Migrate the workspace from the previous flat business configuration
structure to the v1.4 layered architecture.

Goal:

    Old Structure

    ↓

    Separated Configuration + Knowledge + Runtime Architecture

    ↓

    Stable Agent Operation

------------------------------------------------------------------------

# Migration Principle

Separate:

## Configuration

Defines how the Agent works.

Location:

    agent_config/

## Knowledge

Stores learned reusable patterns.

Location:

    template_library/

## Runtime Data

Stores temporary and production data.

Locations:

    source_material/
    posts/
    covers/
    memory/

------------------------------------------------------------------------

# File Migration

## Keep in agent_config/

Move or keep:

    agent_config/

    content_strategy.md

    source_strategy.md

    text_generation.md

    visual_strategy.md

    review_rules.md

    operation.md

    content_distillation.md

    visual_distillation.md

    template_retrieval.md

    template_feedback.md

    VERSION.md

Reason:

These files define behavior and workflow rules.

------------------------------------------------------------------------

# Move to template_library/

Move:

    template_library.md

Convert into:

    template_library/README.md

Move:

    template_library_template_index.json

Into:

    template_library/metadata/template_index.json

Reason:

These are knowledge management data, not execution rules.

------------------------------------------------------------------------

# Create Directory Structure

Required:

    template_library/

    ├── README.md

    ├── content_templates/

    ├── visual_templates/

    ├── metadata/

    │   └── template_index.json

    └── feedback/

------------------------------------------------------------------------

# Create Source Material Structure

Required:

    source_material/

    ├── raw/

    ├── extracted/

    └── verified/

Purpose:

Store:

-   Original creator materials.
-   Extraction results.
-   Verification records.

------------------------------------------------------------------------

# Reference Update

Update references:

## AGENTS.md

Change:

Old:

    agent_config contains all business files

New:

    agent_config = rules

    template_library = learned knowledge

------------------------------------------------------------------------

## VERSION.md

Record:

-   Architecture migration.
-   New knowledge layer.
-   Directory separation.

------------------------------------------------------------------------

# Validation

After migration check:

□ Agent rules remain in agent_config.

□ Templates are stored in template_library.

□ Runtime files are separated.

□ AGENTS routing points to new locations.

□ No duplicated configuration exists.

------------------------------------------------------------------------

# Version

Version:

v1.0

Status:

Architecture Migration Preparation
