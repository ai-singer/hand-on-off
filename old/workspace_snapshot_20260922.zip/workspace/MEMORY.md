# MEMORY.md


# Long-term Memory


## Purpose

Store stable information that should persist across sessions.

Memory is for:

- Long-term decisions.
- Verified experience.
- Stable collaboration observations.


Memory is not for:

- Agent identity.
- User profile.
- Content rules.
- Writing templates.
- Temporary tasks.


---

# Agent Evolution Records


## Confirmed Decisions


Store decisions that have been explicitly accepted.


Format:


Date:

Decision:

Reason:

Impact:


---

# Verified Experience


Store validated operational knowledge.


Format:


Scenario:

Observation:

Evidence:

Recommended Action:


---

# Agent Collaboration Observations


Store long-term collaboration patterns observed by the Agent.


This section stores:

- Repeated collaboration patterns.
- Observed effective interaction methods.
- Validated communication improvements.


This section does not store:

- User identity information.
- User declared preferences.
- User requirements.


Those belong to USER.md.


Format:


Scenario:

Observation:

Evidence:

Recommended Action:


---

# Do Not Store


Do not store:

- Temporary instructions.
- Unverified assumptions.
- Sensitive information.
- Duplicate configuration rules.
- Workflow definitions.
- Identity definitions.
- User profile information.


---

# Verified Experience


## OpenClaw Control UI Signal Messages


Date:

2026-09-20


Scenario:

OpenClaw 控制 UI（sender: openclaw-control-ui）发送的消息可能包含零宽字符，导致消息内容看起来为空白。


Observation:

这类消息可能并非真实空白消息，而可能是控制 UI 产生的确认或继续信号。


Evidence:

用户确认未主动发送空白消息。

相关消息来自 openclaw-control-ui。


Recommended Action:

当出现类似情况时：

- 检查消息来源和上下文；
- 避免将异常空白内容直接判断为用户无意输入；
- 根据当前任务状态决定是否输出结果摘要或等待进一步明确指令。


---

# Memory Boundary


MEMORY.md 保存：

- Agent学习到的经验；
- 已验证的运行经验；
- 长期有效的协作观察。


MEMORY.md 不保存：

- 用户明确偏好；
- Agent身份；
- Workflow规则；
- Tool配置；
- Runtime状态。


对应关系：

USER.md：

用户是谁，以及用户明确要求如何协作。


AGENTS.md：

Agent如何工作。


TOOLS.md：

Agent具备什么能力。


MEMORY.md：

Agent从过去运行中学到了什么。