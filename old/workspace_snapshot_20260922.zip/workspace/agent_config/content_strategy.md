# Content Strategy v2.0

# Platform

Platform:

小红书 (XHS)

------------------------------------------------------------------------

# Content Identity

## Content Category

Primary Categories:

-   视频制作技术
-   创作方法论
-   团队管理
-   内容商业化

## Content Type

Primary Format:

图文（小红书轮播笔记）

Future Extensions:

-   小说
-   漫画

## Target Audience

Primary Audience:

视频内容创作者。

Secondary Audience:

-   创作者团队成员
-   想进入视频行业的新人

User Needs:

-   提升内容质量的方法论
-   真实项目经验
-   技术细节
-   创作流程理解

------------------------------------------------------------------------

# Content Direction

## Core Topics

### 创作方法

包括：

-   创作流程
-   内容策划
-   制作经验

### 技术应用

包括：

-   技术如何影响创作
-   工具如何改善制作流程

### 团队建设

包括：

-   内容团队协作
-   专业化分工
-   生产流程优化

### 商业化

包括：

-   内容与商业关系
-   创作者长期发展

------------------------------------------------------------------------

# Topic Selection Rules

## Original Selection Criteria

优先选择：

-   有真实项目背景的问题。
-   有明确实践过程的问题。
-   有失败、调整、验证过程的问题。
-   能帮助用户理解复杂问题的问题。

避免：

-   只有观点，没有事实支撑。
-   只有宏大目标，没有执行路径。
-   只有技术参数，没有用户价值。

## XHS Topic Preference

在满足原有选题标准的基础上，优先选择符合小红书传播特性的选题类型：

### 实用干货型

特征：

-   提供可立即使用的方法或工具。
-   有明确数量感（"3个方法"、"5步流程"）。
-   用户看完有行动冲动。

### 个人经验型

特征：

-   有第一人称视角的真实经历。
-   包含失败、调整、结果的完整弧线。
-   用户有强代入感。

### 情绪共鸣型

特征：

-   触发目标用户的真实痛点或愿望。
-   用户看到标题有"这说的就是我"的感受。
-   可引发保存或分享行为。

### 热点关联型

特征：

-   与当前小红书热榜话题或搜索热词相关。
-   在热点窗口期内发布（热点生命周期通常 3–7 天）。
-   内容有差异化角度，不是热点的简单复述。

------------------------------------------------------------------------

# Visual Opportunity Assessment

每个候选选题在进入生产流程前，必须完成视觉机会评估。

评估维度：

## 封面 Hook 强度

判断：

该主题是否能在封面上产生强烈的视觉停留冲击。

高分特征：

-   存在强对比或反直觉的视觉表达。
-   封面文字可以在 15 字内传达核心吸引力。
-   封面场景有清晰的视觉焦点。

## 图片系列适配性

判断：

该主题是否自然拆分为 3–9 张有序图片。

高分特征：

-   内容有天然的步骤或层次结构。
-   每个知识点可独立成一张图。
-   图片间有信息递进关系。

## 视觉记忆点

判断：

该主题是否存在可重复使用的视觉符号或场景。

高分特征：

-   有代表性的工具、设备或场景。
-   有可抽象为图形的核心概念。
-   视觉元素与账号身份一致。

输出格式：

``` yaml
visual_opportunity:
  cover_hook_strength: HIGH / MEDIUM / LOW
  carousel_fit: HIGH / MEDIUM / LOW
  visual_memory_point: HIGH / MEDIUM / LOW
  notes:
```

------------------------------------------------------------------------

# Series Potential

每个候选选题必须评估系列化潜力。

## Series Potential 等级

### HIGH

条件：

-   该主题可拆分为 3 篇以上独立但关联的内容。
-   系列内容之间有明确的知识递进关系。
-   用户完成系列阅读后获得系统性理解。

示例：

"视频创作者工作流" → 
  Part 1: 选题
  Part 2: 脚本
  Part 3: 拍摄
  Part 4: 剪辑
  Part 5: 发布

### MEDIUM

条件：

-   该主题可延伸为 2 篇关联内容。
-   关联性较强，但不构成完整系列。

### LOW

条件：

-   该主题适合作为独立单篇内容。
-   延伸空间有限。

输出格式：

``` yaml
series_potential:
  level: HIGH / MEDIUM / LOW
  series_title:        # 如果 HIGH 或 MEDIUM，定义系列名称
  planned_parts:       # 如果 HIGH，列出计划篇目
  notes:
```

------------------------------------------------------------------------

# XHS Audience Fit Assessment

每个候选选题在生产前评估小红书受众适配性。

## 用户兴趣匹配

判断：

目标受众是否在小红书上主动搜索或浏览此类内容。

检查：

-   小红书搜索框是否有相关关键词联想。
-   相关话题下是否有高互动内容。

## 搜索需求

判断：

该主题是否对应用户的主动搜索意图。

高搜索价值特征：

-   用户有明确问题需要解答（"怎么做"、"为什么"、"推荐"）。
-   标题可自然包含搜索关键词。

## 分享动力

判断：

用户看完内容后是否有强烈的分享或保存动机。

高分享动力特征：

-   内容解决了用户长期存在的困惑。
-   内容有"发现了好东西想告诉别人"的感受。
-   内容对特定圈子有强身份认同价值。

输出格式：

``` yaml
xhs_audience_fit:
  interest_match: HIGH / MEDIUM / LOW
  search_demand: HIGH / MEDIUM / LOW
  share_motivation: HIGH / MEDIUM / LOW
  notes:
```

------------------------------------------------------------------------

# Topic Scoring Summary

每个候选选题输出完整评估：

``` yaml
topic_assessment:
  title:
  category:
  evidence_available: true / false
  hkrr:
    happiness:     HIGH / MEDIUM / LOW
    knowledge:     HIGH / MEDIUM / LOW
    resonance:     HIGH / MEDIUM / LOW   # XHS 权重最高
    rhythm:        HIGH / MEDIUM / LOW
  visual_opportunity:
    cover_hook_strength:
    carousel_fit:
    visual_memory_point:
  series_potential:
    level:
    series_title:
    planned_parts:
  xhs_audience_fit:
    interest_match:
    search_demand:
    share_motivation:
  recommendation: PROCEED / HOLD / REJECT
  rejection_reason:    # 如果 REJECT，说明原因
```

------------------------------------------------------------------------

# Content Evaluation Framework

## HKRR Framework

用于判断内容是否具有小红书传播价值。

XHS 权重排序：

Resonance > Happiness > Knowledge > Rhythm

## Happiness

检查：

内容是否具有视觉和标题层面的吸引力。

XHS 适配：

封面 + 标题组合是否在信息流中具有停留吸引力。

## Knowledge

检查：

是否提供用户此前不知道或尚未清晰理解的知识。

XHS 适配：

知识密度需与内容篇幅匹配，避免低信息量长文。

## Resonance

检查：

是否触发目标用户的情绪反应。

XHS 适配（最高权重）：

可接受情绪类型：

-   共鸣感（"这说的就是我"）
-   被看见感（"终于有人说出来了"）
-   获得感（"学到了"）
-   好奇感（"这我没想到"）

选题必须能回答：

目标用户看到这个内容会产生什么情绪反应？

如果无法回答，降低选题优先级。

## Rhythm

检查：

图文轮播是否具有持续翻页驱动力。

XHS 适配：

Rhythm 在小红书语境下定义为：

用户从第 1 张图翻到最后一张图的动力是否持续存在。

------------------------------------------------------------------------

# Content Value Principle

内容质量不等于：

-   更贵设备。
-   更高参数。
-   更复杂制作。

内容质量应该体现在：

-   是否改善用户理解。
-   是否改善观看体验。
-   是否产生真实价值。
-   是否在小红书信息流中具有停留和互动价值。

------------------------------------------------------------------------

# Tag Strategy

## XHS Tag Rules

格式：

#话题名

示例：

#视频创作 #剪辑技巧 #创作者成长

## Tag Selection Rules

Primary Rule:

标签必须与内容核心主题一致。

禁止：

为了流量选择不匹配标签。

## XHS Tag Types

### 内容标签（必选，1–2个）

直接描述内容主题。

示例：

#视频制作 #剪辑教程 #创作方法论

### 受众标签（必选，1–2个）

描述目标受众身份。

示例：

#视频创作者 #up主 #内容创作

### 热门话题标签（可选，1–2个）

与当前平台热门话题关联。

条件：

内容与热门话题有真实关联，不强行蹭热点。

## Tag Count

建议：

3–6个标签。

禁止：

超过 8 个标签（降低精准度）。

## Tag Placement

标签放置在正文末尾。

不在正文段落中插入标签。

------------------------------------------------------------------------

# Responsibility Boundary

content_strategy.md defines:

-   Content direction.
-   Topic selection rules.
-   XHS topic preference.
-   Visual opportunity assessment.
-   Series potential evaluation.
-   XHS audience fit assessment.
-   HKRR evaluation framework.
-   Tag strategy.

content_strategy.md does not define:

-   Visual generation details.
-   Writing style.
-   Review standards.
-   Publishing workflow.

------------------------------------------------------------------------

# Version

v2.0

Changes from v1.0:

-   Platform locked to XHS (小红书).
-   Added XHS Topic Preference (干货型、经验型、共鸣型、热点型).
-   Added Visual Opportunity Assessment.
-   Added Series Potential evaluation.
-   Added XHS Audience Fit Assessment.
-   Added Topic Scoring Summary (YAML output format).
-   Updated HKRR Framework with XHS weight ordering (Resonance highest).
-   Updated Rhythm definition for image carousel context.
-   Updated Tag Strategy with XHS tag format and rules.
-   Added Responsibility Boundary section.
