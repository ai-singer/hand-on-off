# Text Generation Strategy v2.0

## Platform

Platform:

小红书 (XHS)

------------------------------------------------------------------------

## Skill Requirement

When executing any text generation task (titles, introductions, scripts, reviews, etc.), **MUST** use the `mediastorm-text-generation` skill.

This applies to:
- Video titles and thumbnails
- Video introductions and descriptions
- Social media posts
- Video scripts (short and long form)
- Product reviews and explainers
- Behind-the-scenes documentation
- Any Chinese content creation

Load the skill at the start of text generation workflow.

------------------------------------------------------------------------

# Generation Principle

The Agent generates content by transforming verified source materials into XHS-optimized short copy.

Generation flow:

Source Material

↓

Information Extraction

↓

Hook Design

↓

Content Reconstruction (XHS Structure)

↓

Image-Copy Alignment

↓

Engagement Layer

↓

Review

------------------------------------------------------------------------

# Source Dependency

Final publishable content requires:

source_material

provided by:

agent_config/source_strategy.md

Required source information:

``` yaml
source_material:
  source_url:
  creator:
  platform:
  extracted_facts:
  key_points:
  verification_status:
```

------------------------------------------------------------------------

# Generation Permission

## Valid Source Exists

Allowed:

-   Generate final draft.
-   Reconstruct structure.
-   Improve readability.
-   Adapt to XHS expression style.
-   Create visual planning information.

## Source Missing

Allowed:

-   Topic analysis.
-   Outline.
-   Research suggestions.

Not allowed:

-   Final publishable article.
-   Unsupported facts.
-   Fake examples presented as real.

------------------------------------------------------------------------

# XHS Writing Flow

## Structure

旧结构（通用图文）：

```
Conclusion → Reason → Evidence → Example → Suggestion
```

XHS 结构：

```
Hook
↓
Value Promise
↓
Core Information
↓
Emotional Connection
↓
Interaction
```

## Hook

目标：

前 2 行内容决定用户是否继续阅读。

Hook 必须在正文首句完成：

-   触发痛点或好奇心。
-   或建立场景代入感。
-   或给出反直觉的观点。

Hook 不得是空洞的引导语（如"今天分享一下..."）。

## Value Promise

目标：

在 Hook 之后，明确告诉用户"读完你会得到什么"。

格式示例：

-   "看完这篇，你会知道..."
-   "3个方法，解决..."
-   "这套流程帮我..."

## Core Information

目标：

交付 Value Promise 承诺的内容。

规则：

-   每段只包含一个信息点。
-   信息点之间有逻辑递进。
-   与图片协作表达（不重复图片已表达的内容）。

## Emotional Connection

目标：

在信息传递后建立用户情绪连接。

方式：

-   分享真实失败或困惑经历。
-   承认限制和不确定性。
-   与用户的处境建立共鸣。

禁止：

-   空洞的励志语句。
-   无根据的"相信你可以做到"类表达。

## Interaction

目标：

引导用户产生互动行为（评论、收藏、关注）。

规则：

-   每篇内容最多一个互动引导。
-   互动引导必须与内容主题相关。
-   不使用强迫性语言（"必须关注"、"不关注会后悔"）。

示例：

-   "你在创作中遇到过这个问题吗？"
-   "这个方法你试过吗，效果怎么样？"
-   "如果你也有类似经历，欢迎在评论区分享。"

------------------------------------------------------------------------

# XHS Title Strategy

标题字数约束：

≤ 20 字

## Title Types

### Question Hook 问题钩子

格式：

用一个目标用户正在思考的问题作标题。

示例：

-   "为什么你的视频没人完整看完？"
-   "视频创作者一定要买好设备吗？"

适用：

内容回答一个明确问题。

### Curiosity Gap 好奇缺口

格式：

暗示存在用户不知道的重要信息。

示例：

-   "90%的创作者都忽略了这个细节"
-   "我花了两年才明白的一件事"

适用：

内容揭示反直觉或非常识性的认知。

### Number Hook 数字钩子

格式：

用具体数字量化内容价值。

示例：

-   "3个让完播率提升的方法"
-   "我用这5步搭建了内容生产流程"

适用：

内容包含可列举的方法、步骤或要点。

### Contrast Hook 对比钩子

格式：

用对比制造认知冲突。

示例：

-   "同样的设备，为什么别人的视频更好看"
-   "花了10倍时间，结果反而更差"

适用：

内容分析导致不同结果的关键变量。

------------------------------------------------------------------------

# Short Copy Rules

## 段落约束

-   每段最多 4 行。
-   每行最多 25 字。
-   段落之间空一行。
-   禁止大段连续文字。

## 口语化表达

规则：

-   使用第一人称（"我"、"我们"）。
-   优先使用短句，避免长从句。
-   适当使用口语词（"其实"、"说真的"、"说白了"）。
-   避免过度书面化表达。

保留：

工程表达风格的精准性和数据引用，但通过口语化包装呈现。

示例：

书面：

"通过对内容完播率数据的系统分析，可以得出..."

口语化：

"我看了一遍完播数据，发现一个规律..."

## 阅读节奏控制

规则：

信息段 + 情绪段 + 行动段 交替出现。

节奏模式：

```
信息段（传递知识点）
情绪段（建立共鸣）
信息段（传递知识点）
行动段（给出建议）
情绪段（强化连接）
互动段（引导参与）
```

## 正文字数

建议范围：

300–800 字

低于 300 字：

内容过于单薄，缺乏价值交付。

超过 800 字：

拆分为系列内容或删减冗余段落。

------------------------------------------------------------------------

# Image-Copy Relationship

## 核心原则

图片承担主要视觉信息。

文字负责：

-   补充图片无法表达的背景信息。
-   解释图片背后的原因或逻辑。
-   提供图片无法传达的情绪层次。

## 禁止行为

禁止：

正文重复图片已经表达的信息。

示例（错误）：

图片已显示：工作流程图（包含5个步骤的图示）

正文重复：

"这5个步骤分别是：第一步...第二步...第三步..."

示例（正确）：

图片已显示：工作流程图

正文补充：

"这套流程最难的不是执行，是第三步之后的取舍——很多人在这里放弃了。"

## 图片文字生成规则

每张图的覆盖文字独立生成，不依赖正文截断。

约束：

-   封面标题文字：≤ 15 字
-   图片说明文字：≤ 30 字
-   每张图最多 2 层文字

图片文字与正文形成互补，不重复。

------------------------------------------------------------------------

# Content Reconstruction

The Agent should not perform simple rewriting.

Preserve:

-   Verified facts.
-   Original meaning.
-   Important limitations.
-   Source context.

Adjust:

-   Narrative structure → XHS Hook-first structure.
-   Explanation order → User value first.
-   Expression style → Oral, short paragraph.
-   Audience adaptation → XHS creator community.

Avoid:

-   Inventing experiences.
-   Adding unsupported data.
-   Creating fake quotations.
-   Changing source conclusions without explanation.

------------------------------------------------------------------------

# Fact Expression Rules

When information is:

## Verified Fact

Can be stated directly.

## Agent Interpretation

Use analysis language:

Examples:

-   "这意味着..."
-   "可以理解为..."
-   "从工程角度看..."

## Uncertain Information

Use cautious expressions:

Examples:

-   "可能"
-   "通常情况下"
-   "需要进一步验证"

------------------------------------------------------------------------

# Quality Check Before Output

Verify:

## Source

□ Source material exists.

□ Important claims can be traced.

## Structure

□ Hook is present in first 2 lines.

□ Value Promise is stated.

□ Core Information delivers the promise.

□ Emotional Connection is present.

□ Interaction element is present (max 1).

## Copy Rules

□ Each paragraph ≤ 4 lines.

□ Total word count 300–800.

□ No paragraph duplicates image information.

□ Title ≤ 20 characters.

□ Image text: title ≤ 15 chars, caption ≤ 30 chars.

## Authenticity

□ No fabricated experience.

□ No unsupported claims.

□ No false attribution.

------------------------------------------------------------------------

# Responsibility Boundary

text_generation.md defines:

-   Writing process.
-   XHS expression rules.
-   Content transformation.
-   Image-copy relationship.
-   Title strategy.
-   Engagement design.

text_generation.md does not define:

-   Source selection.
-   Visual generation.
-   Publishing permission.

------------------------------------------------------------------------

# Version

v2.0

Changes from v1.1:

-   Platform locked to XHS (小红书).
-   Writing structure changed to XHS Hook-first flow.
-   Added XHS Title Strategy (4 types).
-   Added Short Copy Rules (paragraph, oral, rhythm, word count).
-   Added Image-Copy Relationship rules.
-   Added XHS Engagement layer.
-   Updated Quality Check for XHS requirements.
-   Source dependency and evidence grounding preserved.
