# Visual Strategy v2.0

# Platform

Platform:

小红书 (XHS)

Image Ratio:

3:4 (1080×1440px) — Primary
1:1 (1080×1080px) — Secondary

------------------------------------------------------------------------

# Visual Production Principle

Visual assets are the primary content entry point on XHS.

Visual planning precedes copy generation.

Production flow:

Visual Opportunity Identification

↓

Series Visual Planning

↓

Image Role Assignment

↓

Image Generation

↓

Copy Generation

↓

Visual Review

The Agent should generate visuals based on:

-   Content meaning.
-   Target audience.
-   Account visual identity.
-   XHS platform requirements.

------------------------------------------------------------------------

# Cover First Strategy

The cover image is the sole traffic entry point on XHS.

User decision chain:

```
Cover → Dwell → Read → Engage → Distribution
```

Cover responsibilities:

-   User dwell motivation.
-   Click motivation.
-   Core visual expression.

Cover must deliver within 2 seconds:

-   What this content is about.
-   Why the user should care.
-   What they will get from reading.

Cover design requirements:

-   Large title text (dominant hierarchy).
-   High contrast color scheme.
-   Minimal clutter — one visual focus.
-   Text area: reserve top 1/3 or center for title.
-   Font size: title text must be readable at thumbnail scale.

------------------------------------------------------------------------

# Carousel Series Design

Every XHS post is a carousel series (3–9 images).

Each image must have:

-   A defined role (see Image Role Definition).
-   A clear information unit.
-   An emotional progression contribution.

Series structure:

Image 1 (Hook)

↓

Image 2–N (Content Expansion)

↓

Final Image (Call to Action / Conclusion)

Series rules:

-   Information must progress across images.
-   Emotion must build or resolve across images.
-   Users must have motivation to swipe from each image to the next.
-   Recommended count: 3–6 images for focused posts; up to 9 for detailed guides.

------------------------------------------------------------------------

# Image Role Definition

Every image in a post must declare one of the following roles:

| Role | Purpose |
|---|---|
| Hook | Capture attention, establish the problem or curiosity |
| Context | Provide background, explain the situation |
| Detail | Expand on a specific point with depth |
| Explanation | Break down a concept or process |
| Result | Show outcome, data, or transformation |
| CTA | Direct user to save, follow, comment, or continue |

Rules:

-   Each image must have exactly one primary role.
-   No two adjacent images may share the same role.
-   A single post must not have more than 2 images with the same role.

Forbidden:

Multiple images in the same post performing identical functions.

------------------------------------------------------------------------

# Image Non-Redundancy Rule

Before finalizing an image set, check:

□ No two images convey the same information.

□ Each image adds a new point not present in other images.

□ No similar composition repeated with only minor variation.

□ Removing any image would reduce the post's informational or emotional value.

Reject criteria:

-   High visual similarity between images (same scene, same angle, minor crop difference).
-   Information duplication (same data point shown twice).
-   Filler images that exist only to reach a count target.

------------------------------------------------------------------------

# Series Visual Identity

Maintain visual consistency across a content series:

-   Consistent color palette per series.
-   Consistent layout template per series.
-   Consistent recurring visual elements (color band, corner mark, icon style).
-   Recognizable series identifier in cover image.

Series identity allows users to recognize related content instantly.

------------------------------------------------------------------------

# Visual Workflow

Complete visual workflow:

Content Opportunity

↓

Series Visual Planning

↓

Image Role Assignment

↓

Cover Concept Design

↓

Image Prompt Generation

↓

Image Generation

↓

Non-Redundancy Check

↓

Visual Review

------------------------------------------------------------------------

# Visual Requirement Analysis

Before generating images, identify:

## Content Theme

Input:

{{CONTENT_THEME}}

Purpose:

Understand the core topic.

## Main Message per Image

For each image in the series, define:

-   Image role.
-   Information unit this image carries.
-   Emotional tone this image contributes.

## Target Audience

Reference:

agent_config/content_strategy.md

------------------------------------------------------------------------

# Cover Output Protocol

Every cover generation task should produce:

``` yaml
visual_output:
  cover_concept:
  main_subject:
  scene:
  style:
  composition:
  text_requirement:
  title_text:        # ≤15 characters, display text on cover
  prompt:
```

------------------------------------------------------------------------

# Carousel Output Protocol

Every carousel generation task should produce:

``` yaml
carousel_output:
  series_identity:
    color_palette:
    layout_template:
    series_marker:
  images:
    - index: 1
      role: Hook
      information_unit:
      emotional_tone:
      text_overlay:    # ≤15 chars title + ≤30 chars subtitle
      prompt:
    - index: 2
      role: Context
      information_unit:
      emotional_tone:
      text_overlay:
      prompt:
    # repeat for each image
```

------------------------------------------------------------------------

# Cover Strategy

The cover should:

-   Communicate the topic within 2 seconds.
-   Match account visual identity.
-   Improve user dwell motivation.
-   Support content discovery via visual search.

The cover should not:

-   Misrepresent content.
-   Use unrelated visual elements.
-   Prioritize decoration over meaning.
-   Use small unreadable text.

------------------------------------------------------------------------

# Image Prompt Structure

Prompt should include:

Account Visual Identity

-   

Content Theme

-   

Image Role

-   

Main Subject

-   

Scene

-   

Visual Style

-   

Composition

-   

Text Overlay Requirement

-   

XHS Platform Ratio (3:4 or 1:1)

-   

------------------------------------------------------------------------

# Visual Identity

Maintain consistency through:

-   Similar visual language.
-   Stable composition principles.
-   Recognizable design patterns.
-   Series-level color and layout consistency.

If recurring characters exist:

Maintain:

-   Appearance.
-   Clothing.
-   Identity features.
-   Visual style.

------------------------------------------------------------------------

# XHS Visual Constraints

Platform-specific requirements:

## Ratio

Primary: 3:4 (1080×1440px)

Secondary: 1:1 (1080×1080px)

Forbidden: 16:9 (video ratio — poor XHS feed performance)

## Text Overlay

-   Cover title: ≤15 characters.
-   Supporting text: ≤30 characters per line.
-   Maximum 2 text layers per image.
-   Text must be readable at 375px wide thumbnail.

## Carousel Count

Minimum: 3 images.

Maximum: 9 images.

Recommended: 4–6 images for standard posts.

## Visual Tone

XHS users respond to:

-   Warm, approachable aesthetics.
-   High contrast, clear focal point.
-   Clean layout with intentional white space.
-   Cinematic or documentary visual language (fits account identity).

------------------------------------------------------------------------

# Visual Review

Before publishing check:

## Relevance

□ Cover image matches article topic.

□ Each image's role is fulfilled.

□ Main message is understandable per image.

## Series Integrity

□ Images have clear progression order.

□ No redundant images (non-redundancy rule passed).

□ Series visual identity is consistent.

## Quality

□ No obvious artifacts.

□ Visual logic is consistent within each image.

□ Text overlay is readable at thumbnail scale.

□ Image ratio matches XHS requirements (3:4 or 1:1).

## Identity

□ Matches Agent visual style.

□ Does not conflict with content positioning.

□ Series marker present if part of a series.

------------------------------------------------------------------------

# Responsibility Boundary

visual_strategy.md defines:

-   Visual planning.
-   Image generation requirements.
-   Cover standards.
-   XHS carousel design rules.
-   Image role definitions.
-   Non-redundancy requirements.

visual_strategy.md does not define:

-   Content topic.
-   Writing style.
-   Publishing permission.

------------------------------------------------------------------------

# Version

v2.0

Changes from v1.1:

-   Platform locked to XHS (小红书).
-   Production flow changed to Visual-first (Visual → Copy).
-   Added Cover First Strategy.
-   Added Carousel Series Design rules.
-   Added Image Role Definition.
-   Added Image Non-Redundancy Rule.
-   Added Series Visual Identity.
-   Added Carousel Output Protocol.
-   Added XHS Visual Constraints (ratio, text, count, tone).
-   Updated Visual Review checklist for XHS.
-   `{{PLATFORM}}` placeholder replaced with XHS specifications.
