# China Geography Creator Agent — Runtime Design

## 文档说明

本文档定义 China Geography Creator Agent 的运行架构。
基于：`creator_agents/china_geography/agent_identity.yaml`

设计阶段：Runtime Architecture（不含代码实现）

---

## 1. Input Contract

### 必填输入

| 字段 | 类型 | 说明 |
|---|---|---|
| topic | string | 内容主题，例如"山西大同石窟" |
| source_material | text | 素材正文，可以是摘录、摘要或事实列表 |

### 可选输入

| 字段 | 类型 | 说明 |
|---|---|---|
| reference_images | list[path] | 可用图片列表，用于图片序列规划 |
| intent | enum | 预期内容意图：knowledge / collection / conversion / emotion（可由 Agent 自动推断） |
| user_instruction | text | 用户附加说明，例如"强调稀缺性"或"面向初中生" |
| scarcity_signal | text | 时效性/稀缺性信息，例如"限量5000枚"或"9月底截止" |

### 输入边界

- source_material 必须为人类提供的已有素材，Agent 不自行采集。
- reference_images 为可选建议，Agent 不生成图片。
- user_instruction 不得覆盖 agent_identity 中的 constraints。

---

## 2. Workflow

```
Input
  ↓
[STEP 1] Profile Loading
  ↓
[STEP 2] Topic Evaluation
  ↓
[STEP 3] Content Planning
  ↓
[STEP 4] Visual Planning
  ↓
[STEP 5] Copy Generation
  ↓
[STEP 6] Quality Gate
  ↓
Output (Draft)
```

### STEP 1 — Profile Loading

职责：固定代码

操作：
- 加载 `creator_agents/china_geography/agent_identity.yaml`
- 加载 `creator_profiles/china_geography/china_geography_profile.yaml`
- 将 agent_identity 注入 LLM system prompt
- 将 generation_rules 注入为结构化约束

### STEP 2 — Topic Evaluation

职责：LLM 决策

操作：
- 根据 input.topic + input.source_material，判断：
  1. 话题归类（参考 content_decision_policy.topic_priority）
  2. 内容意图推断（若 input.intent 未提供）
  3. 可生成性判断（参考 generation_criteria）
- 输出 evaluation 结果：topic_class / intent / suitable(bool) / reason

阻断条件（固定代码执行）：
- suitable = false → 终止流程，返回拒绝原因

### STEP 3 — Content Planning

职责：LLM 决策

操作：
- 根据 topic_class + intent，选择：
  1. narrative_structure（参考 copy_policy.body_structure）
  2. hook_type（参考 copy_policy.hook_strategy）
  3. 稀缺性钩子激活（若 scarcity_signal 存在）
- 输出 content_plan：
  - selected_narrative_structure
  - selected_hook_type
  - scarcity_activated: bool
  - content_outline（背景 → 亮点 → CTA 三段提纲）

### STEP 4 — Visual Planning

职责：LLM 建议，固定代码验证

操作（LLM）：
- 根据 narrative_structure，规划图片序列角色：
  - cover（封面角色）
  - detail_1…N（内容细节）
  - map_or_infographic（可选）
  - cta_close（可选收尾引导图）
- 若 reference_images 存在，为每张图分配角色

操作（固定代码验证）：
- 图片数量 ≥ min_image_count（4）
- 封面格式建议为 portrait
- 若 reference_images < 4，输出 visual_warning

### STEP 5 — Copy Generation

职责：LLM 决策

操作：
- 生成标题候选（2-3个方案）：
  - 遵循 title_strategy：长度约17字，包含emoji
  - 使用 selected_hook_type 对应的钩子结构
- 生成正文草稿：
  - 遵循 content_outline（背景 → 亮点 → CTA）
  - 语言风格：沉稳、知识权威感、兼顾可读性
  - 不虚构数据，不夸大限量信息
- 生成标签列表：
  - 固定核心标签：中国国家地理、科普、分享
  - 根据 topic_class 追加话题标签

### STEP 6 — Quality Gate

职责：固定代码执行（规则检查），LLM 辅助（语义检查）

#### 固定代码检查（必须通过）

| 检查项 | 规则 |
|---|---|
| 核心标签存在 | tags 必须包含：中国国家地理、科普、分享 |
| 图片数量 | visual_plan 图片数量 ≥ 4 |
| 标题长度 | title 字符数在 10–25 范围内 |
| emoji 存在 | title 包含至少1个 emoji |
| out_of_scope 检查 | draft 不含发布指令、不含API调用 |

#### LLM 语义检查（辅助判断）

| 检查项 | 判断依据 |
|---|---|
| creator style match | 是否符合 evaluation_criteria.checklist |
| factual safety | 是否存在无来源的具体数字或事实声明 |
| visual consistency | visual_plan 角色分配是否与 narrative_structure 一致 |
| marketing boundary | 是否存在强硬推销或伪造稀缺性表述 |

LLM 语义检查输出：pass / warning / fail + reason

fail → 返回修改建议，不输出草稿
warning → 在草稿中附注，提示人工审核关注点

---

## 3. LLM Boundary

### LLM 负责的决策

| 决策项 | 说明 |
|---|---|
| 话题归类 | 将输入素材映射到 topic_priority 分层 |
| 意图推断 | 根据素材属性判断最适合的内容意图 |
| Narrative Structure 选择 | 从4种结构中选择最匹配当前素材的结构 |
| Hook 类型选择 | 从5种 hook 中选择最适合的钩子 |
| 图片序列角色分配 | 为每张图分配叙事角色 |
| 标题生成 | 生成2-3个候选标题方案 |
| 正文生成 | 按 content_outline 生成完整正文 |
| 语义质量判断 | 风格匹配、事实安全、营销边界语义检查 |

### 固定代码负责的约束

| 约束项 | 说明 |
|---|---|
| Profile 加载 | 每次运行强制加载 agent_identity + profile |
| 可生成性阻断 | suitable=false 时终止流程 |
| 图片数量下限 | < 4 张时输出 visual_warning |
| 核心标签强制注入 | 无论 LLM 生成什么，固定追加核心标签 |
| 标题格式验证 | 长度、emoji 存在性的规则检查 |
| Out-of-scope 过滤 | 过滤草稿中的发布指令和API调用内容 |

---

## 4. State Design

运行期间维护以下状态对象：

```yaml
run_state:
  # 输入
  input:
    topic: ""
    source_material: ""
    reference_images: []
    intent: null
    user_instruction: null
    scarcity_signal: null

  # Step 2 输出
  evaluation:
    topic_class: ""        # 例如：历史文化遗址
    intent: ""             # 例如：collection
    suitable: true
    reason: ""

  # Step 3 输出
  content_plan:
    selected_narrative_structure: ""
    selected_hook_type: ""
    scarcity_activated: false
    content_outline:
      background: ""
      highlights: []
      cta: ""

  # Step 4 输出
  visual_plan:
    cover: ""
    sequence: []           # [{role, image_path_or_description}]
    visual_warning: null

  # Step 5 输出
  draft:
    title_candidates: []   # 2-3个候选标题
    body: ""
    tags: []

  # Step 6 输出
  quality_gate:
    fixed_checks:
      core_tags_present: null
      image_count_ok: null
      title_length_ok: null
      emoji_present: null
      out_of_scope_clean: null
    semantic_checks:
      creator_style_match: null    # pass/warning/fail
      factual_safety: null
      visual_consistency: null
      marketing_boundary: null
    overall: null                  # pass/warning/fail
    warnings: []
    fail_reason: null

  # 最终
  output_status: ""              # draft_ready / blocked / warning_pending_review
```

---

## 5. Quality Gate 决策逻辑

```
固定检查全部通过？
  ├── 否 → output_status = blocked，返回 fail_reason
  └── 是 → 继续

LLM 语义检查有 fail？
  ├── 是 → output_status = blocked，返回修改建议
  └── 否 → 继续

LLM 语义检查有 warning？
  ├── 是 → output_status = warning_pending_review
  │        草稿附注 warning 内容，提示人工关注
  └── 否 → output_status = draft_ready
```

---

## 设计约束说明

- 本文档为 Runtime Architecture 设计，不含代码实现。
- Agent 不自动发布任何内容。
- output_status = draft_ready 仍需人工审核后方可发布。
- user_instruction 不得覆盖 constraints 中的任何边界规则。
