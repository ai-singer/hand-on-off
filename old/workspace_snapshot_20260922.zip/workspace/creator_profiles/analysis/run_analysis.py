import json, re, os
from collections import Counter, defaultdict

# ── Load & deduplicate ──────────────────────────────────────
base = '/home/node/.openclaw/workspace/source_material/xhs/normalized/'
with open(base + 'xhs_中国国家地理·_20260918_normalized.json') as f:
    data1 = json.load(f)
with open(base + 'xhs_中国国家地理_20260918_normalized.json') as f:
    data2 = json.load(f)

seen = set()
posts = []
for p in data1 + data2:
    if p['post_id'] not in seen:
        seen.add(p['post_id'])
        posts.append(p)

# ── Helpers ─────────────────────────────────────────────────
def to_int(v):
    try: return int(str(v).replace(',','').strip())
    except: return 0

def engagement(p):
    m = p['metrics']
    return (to_int(m.get('liked_count')) + to_int(m.get('collected_count')) +
            to_int(m.get('comment_count')) + to_int(m.get('share_count')))

def classify_intent(title, text, tags):
    conv_kw  = ['购买','预售','下单','现货','下架','赠完','抽奖','招幕','市集','限量','送完']
    coll_kw  = ['位置图','路线图','分布图','地图','索引','清单']
    event_kw = ['国庆专场','活动','开幕','开放','展览']
    emo_kw   = ['老照片','震撼','绝美','仙气','奇观','感动','壮观']
    know_kw  = ['科普','知识','历史','文化','遗址','盘点','解析','节选自','摄影','读懂']
    t = title; body = text[:200]
    if any(k in t    for k in conv_kw):  return 'conversion'
    if any(k in t    for k in event_kw): return 'event'
    if any(k in t    for k in coll_kw):  return 'collection'
    if any(k in t    for k in emo_kw):   return 'emotion'
    if any(k in body for k in conv_kw):  return 'conversion'
    if any(k in body for k in coll_kw):  return 'collection'
    if any(k in body for k in know_kw):  return 'knowledge'
    if any(k in body for k in emo_kw):   return 'emotion'
    return 'knowledge'

def classify_topic(title, text, tags):
    t = title
    tag_str = ' '.join(tags)
    body_hint = text[:150]

    # 自然科普（标题直接出现动植物/自然现象）
    if any(k in t for k in ['霸王龙','恐龙','䴓','候鸟','扎布耶','盐池','蝗虫','鱼','动物']): return '自然科普'
    # 历史文化遗址
    if any(k in t for k in ['山西','大同','龙门寺','稷益庙','大足石刻','王屋山',
                              '石刻','壁画','古建','遗迹','北魏','赤足']): return '历史文化遗址'
    # 中国最美景观（选美系列或景观地图）
    if any(k in t for k in ['选美','最美名山','最美湖泊','最美湿地','鄱阳湖','西溪湿地',
                              '幺妹峰','景观']): return '中国最美景观'
    # 地理探索
    if any(k in t for k in ['太行','三峡','巫峡','长江','地名','圩','垸','青藏','西藏','第三极']): return '地理探索'
    # 民俗文化
    if any(k in t for k in ['神仙','道教','儒释道','三教','信仰','民俗']): return '民俗文化'
    # 文化知识（名字/图案/器物）
    if any(k in t for k in ['名字','图案','香料','法印','女子名','汉代']): return '文化知识'
    # 产品/电商（标题明确提产品/活动）
    if any(k in t for k in ['增刊','行李牌','抽奖','预售','招幕','市集','博物来啦',
                              '下架','送完','可购']): return '产品/电商'
    # 最美景观（靠tag补充）
    if any(k in tag_str for k in ['选美','景观']): return '中国最美景观'
    # 正文辅助（低置信度兜底）
    if any(k in body_hint for k in ['霸王龙','恐龙','蝗虫']): return '自然科普'
    if any(k in body_hint for k in ['选美中国','最美']): return '中国最美景观'
    return '其他'

def cover_pattern(images):
    if not images: return 'no_image'
    w, h = images[0].get('width',0), images[0].get('height',0)
    ratio = h/w if w else 1
    if ratio >= 1.3: return 'portrait'
    if ratio <= 0.8: return 'landscape'
    return 'square'

def title_patterns(title):
    pts = []
    if re.search(r'[\U0001F300-\U0001FFFF]', title): pts.append('emoji_marker')
    if re.search(r'No\.\d|第\d|最\w{1,4}[的地]', title): pts.append('ranking')
    if re.search(r'[\u4e00-\u9fa5]{1,5}[📍🌟⛰️]', title): pts.append('location_tag')
    if re.search(r'选美\d{2}周年', title): pts.append('anniversary_series')
    if re.search(r'抽奖|赠|送完|下架|预售|购买|招幕', title): pts.append('conversion_cta')
    if re.search(r'\d{4}年|\d+月\d+日', title): pts.append('time_anchor')
    if not pts: pts.append('plain')
    return pts

# ── Enrich ──────────────────────────────────────────────────
enriched = []
for p in posts:
    enriched.append({
        'post_id':        p['post_id'],
        'title':          p['title'],
        'text_len':       len(p['text']),
        'topic':          classify_topic(p['title'], p['text'], p['tags']),
        'intent':         classify_intent(p['title'], p['text'], p['tags']),
        'cover_pattern':  cover_pattern(p.get('images',[])),
        'title_patterns': title_patterns(p['title']),
        'image_count':    len(p.get('images',[])),
        'tags':           p['tags'],
        'liked':          to_int(p['metrics'].get('liked_count')),
        'collected':      to_int(p['metrics'].get('collected_count')),
        'commented':      to_int(p['metrics'].get('comment_count')),
        'shared':         to_int(p['metrics'].get('share_count')),
        'engagement':     engagement(p),
    })
enriched.sort(key=lambda x: x['engagement'], reverse=True)

# DEBUG: print per-post topic/intent to verify
print("=== Per-post classification ===")
for e in enriched:
    print(f"  [{e['topic']:<12}|{e['intent']:<12}] {e['title'][:35]}")

# ── 1. Topic analysis ────────────────────────────────────────
topic_cnt = Counter(e['topic'] for e in enriched)
topic_eng = defaultdict(list); topic_ex = defaultdict(list)
for e in enriched:
    topic_eng[e['topic']].append(e['engagement'])
    if len(topic_ex[e['topic']]) < 2: topic_ex[e['topic']].append(e['title'])

topic_analysis = {"high_frequency_topics": [
    {"topic": t, "count": c, "percentage": round(c/len(enriched)*100,1),
     "avg_engagement": round(sum(topic_eng[t])/len(topic_eng[t]),1),
     "examples": topic_ex[t]}
    for t, c in topic_cnt.most_common()
]}

# ── 2. Intent analysis ───────────────────────────────────────
intent_cnt = Counter(e['intent'] for e in enriched)
intent_eng = defaultdict(list); intent_ex = defaultdict(list)
for e in enriched:
    intent_eng[e['intent']].append(e['engagement'])
    if len(intent_ex[e['intent']]) < 2: intent_ex[e['intent']].append(e['title'])

intent_analysis = {"distribution": [
    {"intent": i, "count": c, "percentage": round(c/len(enriched)*100,1),
     "avg_engagement": round(sum(intent_eng[i])/len(intent_eng[i]),1),
     "examples": intent_ex[i]}
    for i, c in intent_cnt.most_common()
]}

# ── 3. Visual analysis ──────────────────────────────────────
cp_cnt = Counter(e['cover_pattern'] for e in enriched)
cp_eng = defaultdict(list)
for e in enriched: cp_eng[e['cover_pattern']].append(e['engagement'])
img_counts = [e['image_count'] for e in enriched]

visual_analysis = {
    "cover_pattern_distribution": [
        {"pattern": p, "count": c,
         "avg_engagement": round(sum(cp_eng[p])/len(cp_eng[p]),1)}
        for p, c in cp_cnt.most_common()
    ],
    "avg_image_count": round(sum(img_counts)/len(img_counts),1),
    "image_count_distribution": {str(k): v for k, v in sorted(Counter(img_counts).items())},
    "visual_characteristics": [
        "竖版(portrait)封面占主流，符合小红书竖屏浏览习惯",
        "高互动内容多用专业摄影图片（含摄影师署名），视觉权威感强",
        "多图组合（4-6张）比单图更常见，增加用户浏览深度",
        "图片分辨率普遍1280px+，画质是品牌核心资产",
        "地图/信息图类内容有独立收藏驱动力，不依赖高互动也能积累收藏",
    ]
}

# ── 4. Copy analysis ─────────────────────────────────────────
tp_all = []
for e in enriched: tp_all.extend(e['title_patterns'])
tp_cnt = Counter(tp_all)

hooks = {
    "地点标注型（📍+地名）": [e['title'] for e in enriched if 'location_tag'      in e['title_patterns']][:3],
    "数字/排名型":           [e['title'] for e in enriched if 'ranking'            in e['title_patterns']][:3],
    "周年系列型":            [e['title'] for e in enriched if 'anniversary_series' in e['title_patterns']][:3],
    "时间锚点型":            [e['title'] for e in enriched if 'time_anchor'        in e['title_patterns']][:3],
    "转化CTA型":             [e['title'] for e in enriched if 'conversion_cta'     in e['title_patterns']][:3],
}

narrative_structures = {
    "图片摘录+产品导流": {
        "description": "头图用杂志级摄影，正文节选自杂志原文，结尾自然导流增刊购买",
        "examples": ["中华遗产的最后一本增刊，国宝山西来了", "带着它，去打卡中国最美的地方🔥"]
    },
    "知识科普+地图可视化": {
        "description": "主题知识介绍，搭配位置图/路线图，信息密度高，收藏驱动强",
        "examples": ["选美20周年💧中国最美湖泊位置图", "选美中国📍太行八陉路线图"]
    },
    "稀缺叙事+情感收尾": {
        "description": "强调限量/休刊/最后一次，用情感语言强化紧迫感，触发决策",
        "examples": ["中华遗产的最后一本增刊，国宝山西来了"]
    },
    "活动通知型": {
        "description": "直接告知活动信息，时间/地点/参与方式三要素齐全",
        "examples": ["抽奖🎁泉州有戏！9月24日起连开三天"]
    }
}

copy_analysis = {
    "title_pattern_frequency": dict(tp_cnt.most_common()),
    "hooks": hooks,
    "narrative_structures": narrative_structures,
    "avg_title_length": round(sum(len(e['title']) for e in enriched)/len(enriched), 1),
    "emoji_usage_rate_pct": round(
        sum(1 for e in enriched if 'emoji_marker' in e['title_patterns'])/len(enriched)*100, 1),
    "tag_strategy": {
        "core_tags": ["中国国家地理", "科普", "分享"],
        "topic_tags": ["山西", "西藏", "中华遗产", "杂志", "文化", "知识"],
        "notes": "标签策略保守稳定：核心品牌标签固定出现，话题标签随内容灵活切换"
    }
}

# ── 5. Performance analysis ──────────────────────────────────
eng_list = sorted(e['engagement'] for e in enriched)
top5    = enriched[:5]
bottom5 = enriched[-5:]

performance_analysis = {
    "high_engagement": {
        "posts": [
            {"title": e['title'], "engagement": e['engagement'],
             "liked": e['liked'], "collected": e['collected'],
             "commented": e['commented'], "shared": e['shared'],
             "intent": e['intent'], "topic": e['topic']}
            for e in top5
        ],
        "common_patterns": [
            "时间节点感强（休刊前最后一本、20周年），制造稀缺与纪念价值",
            "具体数字支撑内容价值（47篇文章、296页、4幅地图）",
            "情感语言+知识权威双轨并行：既触达情绪又建立信任",
            "封面图为杂志级专业摄影，视觉冲击力高",
            "正文结构完整：背景介绍 → 内容亮点 → 购买/参与引导",
        ]
    },
    "low_engagement": {
        "posts": [
            {"title": e['title'], "engagement": e['engagement'],
             "intent": e['intent'], "topic": e['topic']}
            for e in bottom5
        ],
        "possible_reasons": [
            "最新发布内容（post_id前缀6aac），互动尚未累积，非内容质量问题",
            "纯知识科普帖缺乏稀缺性/时效性钩子",
            "无明确CTA，用户浏览后不知道下一步行动",
            "标题平铺直叙，缺乏悬念或强烈情绪触点",
        ]
    },
    "engagement_distribution": {
        "max":    eng_list[-1],
        "min":    eng_list[0],
        "median": eng_list[len(eng_list)//2],
        "p75":    eng_list[int(len(eng_list)*0.75)],
        "total_posts": len(enriched),
        "note": "极度长尾分布：top 2帖贡献约80%总互动量，其余帖均值约60"
    }
}

# ── Write output ─────────────────────────────────────────────
result = {
    "creator": "中国国家地理·",
    "platform": "xiaohongshu",
    "analysis_date": "2026-09-18",
    "total_posts_analyzed": len(enriched),
    "topic_analysis":          topic_analysis,
    "content_intent_analysis": intent_analysis,
    "visual_analysis":         visual_analysis,
    "copy_analysis":           copy_analysis,
    "performance_analysis":    performance_analysis,
}

out = '/home/node/.openclaw/workspace/creator_profiles/analysis/china_geography_content_analysis.json'
with open(out, 'w', encoding='utf-8') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)

print("\n=== Summary ===")
print(f"Posts: {len(enriched)}")
print("\nIntent:")
for i, c in intent_cnt.most_common(): print(f"  {c:>3}x  {i}")
print("\nTopic:")
for t, c in topic_cnt.most_common(): print(f"  {c:>3}x  {t}")
print(f"\nEngagement: min={eng_list[0]}  median={eng_list[len(eng_list)//2]}  max={eng_list[-1]}")
print(f"\nFile written: {out}")
