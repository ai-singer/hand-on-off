# Manifest

Generated: 2026-09-21T05:05:00Z

Phase: Phase 1 — Creator Instance Refactoring / Phase 1.3-A Identity Layer Refactoring

---

| File Name | Original Path | Handoff Path | Size (bytes) | Generated At |
|---|---|---|---|---|
| IDENTITY.md | workspace/IDENTITY.md | handoff/current_request/files/IDENTITY.md | 2236 | 2026-09-21T05:05:00Z |
| script_structure_rules.md | workspace/agent_config/distilled/xiaolinshuo/script_structure_rules.md | handoff/current_request/files/agent_config/distilled/xiaolinshuo/script_structure_rules.md | 9503 | 2026-09-21T05:05:00Z |
| title_formula_rules.md | workspace/agent_config/distilled/xiaolinshuo/title_formula_rules.md | handoff/current_request/files/agent_config/distilled/xiaolinshuo/title_formula_rules.md | 8857 | 2026-09-21T05:05:00Z |
| topic_pattern_examples.md | workspace/agent_config/distilled/xiaolinshuo/topic_pattern_examples.md | handoff/current_request/files/agent_config/distilled/xiaolinshuo/topic_pattern_examples.md | 5021 | 2026-09-21T05:05:00Z |
| topic_selection_rules.md | workspace/agent_config/distilled/xiaolinshuo/topic_selection_rules.md | handoff/current_request/files/agent_config/distilled/xiaolinshuo/topic_selection_rules.md | 6879 | 2026-09-21T05:05:00Z |
| visual_pattern_rules.md | workspace/agent_config/distilled/xiaolinshuo/visual_pattern_rules.md | handoff/current_request/files/agent_config/distilled/xiaolinshuo/visual_pattern_rules.md | 8147 | 2026-09-21T05:05:00Z |

---

Total files: 6
