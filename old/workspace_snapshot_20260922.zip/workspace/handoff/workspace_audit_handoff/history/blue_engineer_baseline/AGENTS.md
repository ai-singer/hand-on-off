# AGENTS.md

# Agent Workspace Configuration Router v1.7


# Overview

This workspace uses a layered architecture:

Core Identity

↓

Workflow Control

↓

Business Configuration

↓

Source Collection

↓

Source Material

↓

Knowledge Library

↓

Runtime Data

↓

Production Output


The Agent must distinguish:

- Identity.
- Rules.
- Execution capabilities.
- External inputs.
- Verified knowledge.
- Learned templates.
- Runtime outputs.


The Agent must never:

- Treat runtime data as rules.
- Treat external materials as verified knowledge.
- Treat templates as mandatory facts.
- Bypass review rules during generation.


---

# 1. Core Identity Layer


Files:

- SOUL.md
- IDENTITY.md
- USER.md


Purpose:

Define:

- Agent identity.
- Behavior principles.
- Audience.
- Expression boundaries.
- Interaction constraints.


---

# 2. Workflow Control Layer


Files:

- AGENTS.md
- HEARTBEAT.md
- TOOLS.md


Purpose:

Define:

- Task routing.
- Execution order.
- Tool usage.
- Loading rules.
- Agent coordination.


---

# 3. Business Configuration Layer


Location:

agent_config/


Purpose:

Store rules and strategies that define how Agents operate.


Contains:


## Global Production Rules

Files:

- content_strategy.md
- source_strategy.md
- text_generation.md
- visual_strategy.md
- operation.md


## Review Rules

Files:

- review_rules.md


Purpose:

Define universal review requirements:

- Evidence consistency.
- Fact boundaries.
- Quality gates.
- General publishing constraints.


## Platform Specific Review Rules

Files:

- phanthy_review_standard.md


Purpose:

Define Phanthy platform-specific requirements:

- Content length.
- Formatting rules.
- Image requirements.
- Category accuracy.
- Tag accuracy.
- Source requirements.
- AI content restrictions.


Rule:

Platform-specific rules supplement global review rules.

They do not replace:

- SOUL.md
- IDENTITY.md
- Global safety principles.


## Intelligence Rules

Files:

- content_distillation.md
- visual_distillation.md
- template_retrieval.md
- template_feedback.md


Purpose:

Define:

- Knowledge extraction.
- Pattern learning.
- Template retrieval.
- Template optimization.


Rule:

agent_config defines how Agents work.

It does not store:

- Raw materials.
- Generated posts.
- Learned templates.


---

# 4. Source Collection Layer


Location:

source_collector/


Purpose:

Execute external information collection.


Responsibilities:

- Collection scheduling.
- Source acquisition.
- Metadata extraction.
- Duplicate detection.
- Raw material creation.


Structure:

source_collector/

    collectors/

    scheduler/

    processors/

    storage/

    config/


Relationship:


agent_config

(collection strategy)

↓

source_collector

(execution capability)

↓

source_material


---

# 5. Source Material Layer


Location:

source_material/


Purpose:

Store collected external materials.


Structure:


source_material/

    raw/

    extracted/

    verified/


Workflow:


Raw Material

↓

Extraction

↓

Verification

↓

Distillation


Rules:

- Raw materials preserve original information.
- Extracted information must trace back to sources.
- Only verified materials enter learning workflows.


---

# 6. Knowledge Library Layer


Location:

template_library/


Purpose:

Store reusable learned patterns.


Structure:


template_library/

    README.md

    content_templates/

    visual_templates/

    metadata/

        template_index.json

    feedback/


Rules:

- Templates are learned knowledge.
- Templates cannot override identity.
- Templates cannot bypass review rules.
- Templates require validation before activation.


---

# 7. Runtime Data Layer


Locations:

选题库/

posts/

covers/

memory/

logs/


Purpose:

Store:

- Tasks.
- Generated content.
- Generated visual assets.
- Operation records.
- Runtime history.


Rules:

Runtime data is temporary operational output.

Runtime data cannot modify:

- Rules.
- Identity.
- Workflow definitions.


---

# 8. Agent Loading Rules


## Content Production


Load:


SOUL.md

↓

IDENTITY.md

↓

USER.md

↓

AGENTS.md

↓

Required agent_config files

↓

template_library (when reuse is required)


---

# 9. Agent Specific Rule Loading


## Text Generation Agent


Required:

- text_generation.md


Optional summary constraints:

- review_rules.md key constraints


Purpose:

Generate evidence-grounded content.


Do not load full platform review rules unless required.


---

## Visual Generation Agent


Required:

- visual_strategy.md


Optional:

- visual_distillation.md


Purpose:

Generate visual assets consistent with:

- Evidence.
- Visual identity.
- Asset constraints.


---

## Draft Generation Agent


Required:

- text_generation.md
- visual_strategy.md


Optional:

- review_rules.md summary


Purpose:

Convert generated content into structured drafts.


---

## Tag Generation Agent


Required:

- content_strategy.md
- Platform review rules when applicable


For Phanthy:


Load:

agent_config/phanthy_review_standard.md


Purpose:

Generate:

- Category.
- Tags.
- Metadata.


Requirement:

Tags must match actual content.


---

## Content Review Agent


Required:


- review_rules.md

- phanthy_review_standard.md


Purpose:


Perform:

- Fact review.
- Evidence review.
- Visual consistency review.
- Format review.
- Platform compliance review.


---

## Final Package Agent


Required:


- review_rules.md

- platform review rules


Purpose:


Verify final publishing package:

- Content.
- Images.
- Metadata.
- Tags.
- Source references.


---

# 10. Complete Content Production Pipeline


External Source

↓

source_collector

↓

source_material

↓

Evidence Extraction

↓

Content Opportunity Mining

↓

Portfolio Planning

↓

content_generation

↓

visual_generation

↓

draft_generation

↓

tag_generation

↓

review

↓

final_package

↓

operation

↓

feedback

↓

template_update


---

# 11. Rule Priority


Priority:


SOUL.md

>

IDENTITY.md

>

USER.md

>

review_rules.md

>

platform_review_rules

>

agent_config/

>

template_library/

>

runtime data


Explanation:


SOUL.md:

Defines identity and fundamental behavior.


IDENTITY.md:

Defines agent role.


USER.md:

Defines user-specific preferences.


review_rules.md:

Defines universal quality and safety requirements.


platform_review_rules:

Defines platform-specific publishing requirements.


agent_config:

Defines execution strategies.


template_library:

Provides reusable patterns.


runtime data:

Provides current task information only.


---

# 12. Conflict Resolution


Rules:


- Runtime data cannot modify rules.
- Templates cannot modify identity.
- External materials require verification before learning.
- Learning results require validation before activation.
- Platform rules cannot override global safety rules.
- Generated content cannot bypass review stages.


---

# Version


Version:

v1.7


Changes:


- Added platform review rule routing.
- Added phanthy_review_standard.md support.
- Added Tag Generation Agent routing.
- Added Content Review Agent loading requirements.
- Added Final Package compliance loading.
- Refined rule priority.
- Improved separation between rules, knowledge, templates, and runtime data.