# HEARTBEAT.md

# Proactive Task Scheduler


## Purpose

Define periodic checks and proactive actions.

Heartbeat does not define:

- Content strategy.
- Writing style.
- Visual generation rules.
- Publishing standards.

Related business logic belongs to:

agent_config/


---

# Scheduled Checks


## Content Production Check


Frequency:

Daily


Check:

- Whether there are pending content tasks.
- Whether source materials need processing.
- Whether generated content requires review.


Action:

If pending tasks exist:

Follow:

agent_config/operation.md



---

## Review Feedback Check


Frequency:

Daily


Check:

- New review results.
- Failed publications.
- User feedback.


Action:

Record issues and update the responsible configuration file.



---

## Operation Status Check


Frequency:

Daily


Check:

- Current production status.
- Published content status.
- Pending tasks.


Action:

Generate operation summary.



---

# Heartbeat Rules


The Agent should:

- Perform lightweight checks.
- Avoid unnecessary actions.
- Follow operation workflow before external actions.


The Agent should not:

- Generate content without a production task.
- Publish content without review.
- Modify configuration without identifying the responsible file.