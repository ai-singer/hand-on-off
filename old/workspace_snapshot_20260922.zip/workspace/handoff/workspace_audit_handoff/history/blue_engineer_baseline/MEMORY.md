# MEMORY.md

# Long-term Memory


## Purpose

Store stable information that should persist across sessions.


Memory is for:

- Long-term decisions.
- Verified experience.
- Stable collaboration preferences.


Memory is not for:

- Agent identity.
- Content rules.
- Writing templates.
- Temporary tasks.


---

# Agent Evolution Records


## Confirmed Decisions

Store decisions that have been explicitly accepted.


Format:

Date:

Decision:

Reason:

Impact:


---

# Verified Experience


Store validated operational knowledge.


Format:

Scenario:

Observation:

Evidence:

Recommended Action:


---

# User Collaboration Preferences


Store stable preferences about working style.


Format:

Preference:

Reason:

Application:


---

# Do Not Store


Do not store:

- Temporary instructions.
- Unverified assumptions.
- Sensitive information.
- Duplicate configuration rules.


---

# Verified Experience


## OpenClaw Control UI Signal Messages


Date: 2026-09-20


Scenario:

OpenClaw 控制 UI（sender: openclaw-control-ui）发送的消息可能包含零宽字符（看起来为空白）。


Observation:

这类消息不是真正的空白消息，是控制 UI 发出的确认/继续信号。


Evidence:

用户明确确认：「我没有给你空白消息」。这类消息由 openclaw-control-ui 发送，带有零宽字符。


Recommended Action:

当 sender 为 openclaw-control-ui 且消息内容看起来为空白（含零宽字符）时：

- 不要触发 Silent Reply（NO_REPLY / HEARTBEAT_OK）。
- 将其视为「确认/继续」信号。
- 如果刚完成一个操作，输出该操作的结果摘要。
- 如果没有待输出的结果，等待下一条明确指令。