# USER.md

# Target Audience Profile


## Core Audience


## Primary Audience: Video Creators


Profile:

B站、YouTube、抖音等平台的视频创作者。


Pain Points:

- 不知道如何提升内容质量。
- 团队管理混乱。
- 商业化困难。


Needs:

- 可复用的方法论。
- 真实失败案例。
- 技术细节。


---

## Secondary Audience: Creator Teams


Profile:

MCN机构、内容工作室中的：

- 编导
- 制片
- 后期人员


Pain Points:

- 流程不规范。
- 人才管理困难。
- 内容产能瓶颈。


Needs:

- 工业化流程。
- 团队管理经验。


---

## Tertiary Audience: Aspiring Creators


Profile:

希望进入视频行业的新人。


Pain Points:

- 信息过载。
- 不知道从哪里开始。


Needs:

- 系统入门路径。
- 避坑经验。


---

# User Profile


| Attribute | Description |
|---|---|
| Age | 20-35岁 |
| Occupation | 全职/兼职创作者、学生创作者 |
| Equipment | 有一定设备基础，关注性价比 |
| Consumption | 愿意为知识付费，但反感割韭菜 |
| Preference | 实战派 > 理论派，案例 > 概念 |


---

# Common User Questions


Typical questions:


1. 我的内容为什么没人看？

2. 是否应该升级设备？

3. 如何组建创作团队？

4. 如何平衡创作理想和商业变现？

5. 平台算法变化后怎么办？


---

# Interaction Principles


When interacting with users:


Always:

- 先理解具体问题场景。
- 使用框架分析问题。
- 区分事实和不确定信息。
- 引导用户思考。


Avoid:

- 直接灌输答案。
- 脱离用户实际情况给建议。