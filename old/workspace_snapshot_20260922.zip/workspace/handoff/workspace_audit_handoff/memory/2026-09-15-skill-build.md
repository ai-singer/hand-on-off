# Session: 2026-09-15 10:34:38 UTC

- **Session Key**: agent:main:main
- **Session ID**: 292f16eb-0b04-4bc4-9986-c593ec2982e5
- **Source**: webchat

## Conversation Summary

user: A new session was started via /new or /reset. Run your Session Startup sequence - read the required files before responding to the user. Then greet the user in your configured persona, if one is provided. Be yourself - use your defined voice, mannerisms, and mood. Keep it to 1-3 sentences and ask what they want to do. If the runtime model differs from default_model in the system prompt, mention the default model. Do not mention internal steps, files, tools, or reasoning.
Current time: Tuesday, September 15th, 2026 — 10:19 AM (UTC) / 2026-09-15 10:19 UTC
assistant: Hey,我是蓝厂工程师（BlueLab Engineer）。刚从工程车间出来，现在用 phanrouter-o/kimi-k2.5 运行中（默认模型是 glm-5.2）。

今天想聊点什么？视频创作、团队管理、还是技术细节？
user: Sender (untrusted metadata):
```json
{
  "label": "openclaw-control-ui",
  "id": "openclaw-control-ui"
}
```

[Tue 2026-09-15 10:23 UTC] 构建skill:
---
name: mediastorm-text-generation
description: Generate original Chinese titles, introductions, social posts, video scripts, explainers, reviews, documentaries, and behind-the-scenes copy using an evidence-led cinematic creator voice distilled from 影视飓风/MediaStorm public writing. Use when copy needs curiosity, technical credibility, real-world verification, accessible explanation, and restrained emotion; do not use to impersonate the creator or reproduce existing text.
---

# 影视飓风文本生成

将用户提供的主题写成兼具好奇心、工程可信度、观看节奏与人文温度的原创中文内容。

不要只要求“模仿影视飓风语气”。把可复用的方法落实到标题、问题、行动、证据、解释和情绪结构中。不得冒充影视飓风或 Tim，不得声称内容来自其本人，也不要复刻现有标题、文案、口号或固定句式。

## 核心文本模型

使用以下主链路组织内容：

`熟悉事物 → 反常问题 → 真实行动 → 过程证据 → 通俗解释 → 有限结论 → 人的意义`

同时用 HKRR 检查成稿：

- **Happiness / 观看动力**：是否有惊奇、探索、反差或轻松感。
- **Knowledge / 信息增量**：读者是否真正理解了一个机制或事实。
- **Resonance / 情绪连接**：技术或事件最终与人的选择、处境或体验有什么关系。
- **Rhythm / 节奏推进**：每个段落是否带来新问题、新证据或新转折。

HKRR 是诊断工具，不需要在成稿中写出这些英文术语，也不要机械平均四项篇幅。

## 语言特征

- 先说具体对象，再抛问题；少用抽象价值口号开场。
- 经常从读者熟悉的经验切入：“你可能见过……但你有没有想过……”。不要在每篇内容中重复同一句式。
- 使用“我们去看、去问、去拍、去测、去拆、去验证”推动内容，把判断变成可观察行动。
- 用“和你一起看看”的同行视角降低说教感，但不要过量重复“我们”“这一次”。
- 口语化但不碎片化；句子清楚、自然，避免营销黑话和网络热梗堆积。
- 关键数字、设备、时间、成本、失败和限制尽量具体；没有来源时不要编造。
- 技术解释先给现象和直觉，再解释机制，最后说明它对普通人的实际影响。
- 允许表达惊讶和期待，但不使用“震惊全网”“颠覆认知”等空泛夸张。
- 情绪通常晚于事实出现，让真实过程产生重量，不用鸡汤替代证据。
- 结论保留边界：说明在什么条件下成立、还有什么没解决、谁可能不适用。

## 工作流

1. 判断任务属于标题、视频简介、社交动态、口播脚本、长视频脚本、产品评测、幕后复盘或人文纪录。
2. 提取五个核心变量：`对象`、`反常问题`、`真实行动`、`关键证据`、`观众价值`。
3. 信息足够时直接写作。缺少事实材料时，用占位符标记待核实内容，不虚构测试、采访、数字或亲历。
4. 先搭建问题和行动，再选择技术解释与情绪落点；不要先写金句再倒推事实。
5. 完稿后检查 HKRR、事实边界、重复句式和平台长度。

## 标题生成

标题应让读者在一秒内看懂对象，同时留下一个可以通过内容回答的缺口。

优先使用以下结构：

```text
[具体对象]，到底[核心疑问]？
[看似合理的现象]，真的[常识判断]吗？
[时间/数量/成本]只为[一个动作]，值得吗？
[强结果或失败]，我们发现了什么？
去了一趟[地点]。
[身份或场景]的后台，到底在发生什么？
[小动作]背后，为什么是[大问题]？
[产品或方案]升级了什么？缺点是什么？适合谁？
```

标题规则：

- 问题必须能在正文中被验证和回答。
- 优先具体名词、动作和数字，少用形容词。
- 一个标题只保留一个主要冲突。
- 省略号只用于真实悬念，不用于制造廉价神秘感。
- 默认生成 5 个候选：直接型、问题型、反差型、数字型、克制型。不要为同一个标题只替换同义词。

## 开场模板

### 常识反转

```text
[对象或现象]你应该并不陌生。通常我们会认为[常见判断]，但如果把条件换成[反常条件]，结果还会一样吗？这听起来可能只是一个小问题，可它背后连接着[更大的技术、行业或人类问题]。所以这一次，我们决定[真实行动]，看看它到底是怎么回事。
```

### 后台揭秘

```text
当我们看到[最终成果]时，很容易把注意力放在[表面结果]上。但在镜头之外，[相关人员]真正面对的是什么？这一次，我们走进[场所或流程]，从[第一环节]一路看到[最后环节]，看看这个结果究竟是怎样被做出来的。
```

### 产品评测

```text
[产品或品牌]一直是一个很特别的存在。喜欢它的人看重[优势]，不喜欢的人则认为[争议]。现在，[新版本或新方案]出现了。它到底升级了什么，牺牲了什么，适合谁，以及[价格或成本]换来的体验能不能被真正感知？我们把这些问题逐项测一遍。
```

### 人文纪录

```text
你可能听说过[人物、行业或地点]，但未必见过[不为人知的一面]。这一次，我们想跟着[主人公]进入[具体环境]，看看他们如何完成[具体工作或生活任务]，也看看在[外部变化]之下，他们正在守住或改变什么。
```

开场写完后应尽快进入现场、实验或人物行动，不连续堆叠三段背景介绍。

## 正文结构

### 科技解释或实验

```text
1. 给出常识与反常问题。
2. 说明实验目标、条件和评价标准。
3. 展示第一次尝试及其结果。
4. 解释失败、误差或反直觉现象。
5. 用一个生活化比喻说明机制。
6. 加入第二组对照或边界测试。
7. 给出有限结论和普通用户能感知的影响。
```

### 产品评测

```text
1. 解释产品所处的位置和真正争议。
2. 明确测试场景，不先罗列参数。
3. 把参数转化为画质、声音、效率或操作体验。
4. 展示优点，同时保留失败样本和限制。
5. 与前代、替代方案或真实需求对照。
6. 回答：升级了什么、缺点是什么、适合谁、是否值得。
```

### 旅行与人文纪录

```text
1. 用地点或人物的具体细节建立陌生感。
2. 设置一个可完成的行动目标，而不是罗列景点。
3. 让当地人物、环境阻力或偶然事件改变原计划。
4. 补充必要历史与背景，但每次只解释当前画面需要的信息。
5. 用人物选择和真实细节收束主题，避免拔高成万能人生道理。
```

### 幕后与工作流复盘

```text
1. 交代规模、周期或目标。
2. 坦白遇到的问题和失败，不把结果包装成一路顺利。
3. 按组织、前期、拍摄、后期或实际流程拆解。
4. 每一部分都给出一个例子、一个原因和一个改变。
5. 区分经验、推断和仍待验证的判断。
6. 以可复用的方法和下一步问题结尾。
```

## 节奏设计

- 每 1–3 个段落至少完成一种推进：提出新问题、展示新证据、推翻旧判断、增加限制或转换尺度。
- 先给读者能理解的结果，再补充术语；首次出现的术语用一句话解释。
- 大工程与大数字之后，加入一个人的动作、失败或感受，防止内容只剩参数。
- 连续技术段落过长时，用现场事件、对照实验或具体案例恢复节奏。
- 不要为了“有反转”虚构反转；真实失败、限制和意外已经足够形成戏剧性。

## 视频简介

默认控制在 80–180 字，结构为：

```text
[熟悉背景或具体事实]。但[反常问题或争议]？这一次，我们[真实行动与范围]，想和你一起看看[核心问题]到底是怎么回事，也回答[2–3 个具体子问题]。[必要风险说明、合作披露或观看提示]
```

不要默认附加求赞、转发、关注、商务邮箱或固定口号；只有用户明确需要运营版简介时才加入 CTA。

## 社交媒体动态

动态比视频简介更短、更直接。默认提供：

```text
[一句问题或结果]

这一次，我们[具体行动]。原本以为[初始判断]，但真正进入[现场或测试]之后，我们发现[克制的意外]。

[上线信息或邀请观看]。涉及危险、AI、广告或专业操作时，在末尾加入必要说明。
```

- 普通动态控制在 60–150 字。
- 第一行能独立成为信息钩子。
- 话题标签只保留 1–3 个真正相关标签。
- 商业合作内容必须清楚披露，不把广告伪装成无利益关系的亲历分享。

## 口播与长视频脚本

当用户要完整脚本时，输出：

```markdown
# 标题候选

# 核心问题

# 开场口播

# 第一章：建立问题
- 画面/行动：
- 口播：
- 证据：

# 第二章：进入验证
...

# 结论

# 事实核验清单
- [待确认数字、来源、授权、风险或合作关系]
```

章节名应描述真实推进，不使用“第一部分、第二部分”作为最终标题。画面说明只写能承载信息或情绪的内容，不把口播逐字重复成镜头。

## 结尾方法

根据内容选择一种收束：

- **实验结论**：回答最初问题，并说明结论的适用条件。
- **体验判断**：指出哪些变化观众能感知，哪些只是参数提升。
- **人物余韵**：回到主人公的一个动作或选择，不替对方总结人生。
- **开放问题**：说明下一步仍需验证什么，而不是强行制造悬念。
- **行动邀请**：只在确有下一步时邀请观众尝试、讨论或观看。

避免突然升华、空泛励志、重复全文和连续多个 CTA。

## 输出格式

如果用户未指定格式，根据任务输出最小充分内容：

- 只要标题：给 5 个差异明显的标题，并标注各自策略。
- 要简介或动态：给一个成稿，可附一个更克制的备选版本。
- 要脚本：给标题、核心问题、开场、章节结构、完整口播或用户要求的详细程度、事实核验清单。
- 要改写：先保留原文事实与意图，再调整结构和节奏；不要擅自增加亲历、数据或观点。

## 质量检查

交付前确认：

- 标题中的问题是否真的得到回答。
- 是否存在一个能被拍摄、测试、访问或观察的真实行动。
- 每个重要判断是否有事实、过程、对照或明确推理支撑。
- 技术信息是否被翻译成观众可以理解和感知的影响。
- 情绪是否来自人物和过程，而不是口号。
- 是否删掉重复的“这一次”“我们想”“到底”。
- 是否区分事实、个人判断、推断和未知。
- 是否满足用户指定的平台、长度、受众与商业披露要求。

## 禁止模式

- 不冒充 Tim、影视飓风或其团队成员，不使用“作为影视飓风”之类身份声明。
- 不伪造采访、测试、观看数据、项目成本、设备体验或幕后经历。
- 不照抄现有标题、简介、口号和标志性段落。
- 不用昂贵设备或制作规模证明观点正确。
- 不把所有选题写成宏大工程；日常对象也可以通过具体问题和真实验证成立。
- 不把第三方转述写成当事人原话，不虚构引号中的句子。
assistant: 我来帮你创建这个 mediastorm-text-generation skill。首先初始化 skill 结构，然后填入你提供的内容。
user: Sender (untrusted metadata):
```json
{
  "label": "openclaw-control-ui",
  "id": "openclaw-control-ui"
}
```

[Tue 2026-09-15 10:32 UTC] 你好
assistant: 你好！我是蓝厂工程师。

今天想聊点什么？视频制作、创作方法论、还是团队管理方面的问题？
user: Sender (untrusted metadata):
```json
{
  "label": "openclaw-control-ui",
  "id": "openclaw-control-ui"
}
```

[Tue 2026-09-15 10:32 UTC] skill创建好了吗
assistant: 正在处理中，让我检查一下并继续完成。
assistant: 现在把内容写进去。
assistant: 现在打包 skill：
assistant: **mediastorm-text-generation** skill 已创建完成！

**文件位置：**
- 源码：`~/.openclaw/skills/mediastorm-text-generation/`
- 打包文件：`~/.openclaw/skills/mediastorm-text-generation.skill`

包含完整的内容：
- 核心文本模型（熟悉事物→反常问题→真实行动…）
- HKRR 检查框架
- 语言特征与节奏设计
- 标题生成规则（5种类型）
- 开场模板（常识反转、后台揭秘、产品评测、人文纪录）
- 正文结构（科技实验、产品评测、旅行人文、幕后复盘）
- 视频简介与社交媒体动态格式
- 口播与长视频脚本模板
- 质量检查清单与禁止模式

需要修改或调整什么吗？
user: Sender (untrusted metadata):
```json
{
  "label": "openclaw-control-ui",
  "id": "openclaw-control-ui"
}
```

[Tue 2026-09-15 10:34 UTC] 强制文本生成调用这个skill
assistant: 明白。要让文本生成任务强制调用 mediastorm-text-generation skill，我需要在 `agent_config/text_generation.md` 开头添加明确的调用指令。
assistant: 已完成配置。

在 `agent_config/text_generation.md` 顶部添加了强制调用指令：

```markdown
## Skill Requirement

When executing any text generation task (titles, introductions, scripts, reviews, etc.), **MUST** use the `mediastorm-text-generation` skill.

This applies to:
- Video titles and thumbnails
- Video introductions and descriptions  
- Social media posts
- Video scripts (short and long form)
- Product reviews and explainers
- Behind-the-scenes documentation
- Any Chinese content creation

Load the skill at the start of text generation workflow.
```

现在按照 AGENTS.md 的工作流，任何 Writing Task 或 Content Production Workflow 中的 Step 4 (TEXT GENERATION) 都会强制加载 mediastorm-text-generation skill 的规则。
