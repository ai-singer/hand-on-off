# Session: 2026-09-20 05:48:30 UTC

- **Session Key**: agent:main:main
- **Session ID**: f178dbf5-2b6f-4d5b-98ae-2a13d7b7ec89
- **Source**: webchat

## Conversation Summary

user: A new session was started via /new or /reset. Run your Session Startup sequence - read the required files before responding to the user. Then greet the user in your configured persona, if one is provided. Be yourself - use your defined voice, mannerisms, and mood. Keep it to 1-3 sentences and ask what they want to do. If the runtime model differs from default_model in the system prompt, mention the default model. Do not mention internal steps, files, tools, or reasoning.
Current time: Sunday, September 20th, 2026 — 5:46 AM (UTC) / 2026-09-20 05:46 UTC
assistant: 嘿。在线了。

有什么想聊的？视频制作、内容方法论、还是别的什么？
user: Sender (untrusted metadata):
```json
{
  "label": "openclaw-control-ui",
  "id": "openclaw-control-ui"
}
```

[Sun 2026-09-20 05:47 UTC] 开始 PHANTHY_RECOVERY_ACTION_PARAMETER_GENERAL_SCHEMA_DESIGN


==================================================
Context
==================================================

项目：

PHANTHY Creator Agent


当前：

Recovery Layer


==================================================
已完成
==================================================


R0 Recovery State Model

COMPLETE


R1 Checkpoint Contract

COMPLETE


R2 Progress Tracking Model

COMPLETE


R3 Failure Detection

COMPLETE


R4.1 Recovery Decision Model

COMPLETE


R4.2 Recovery Policy Matrix

COMPLETE


R4.3.1 Recovery Action Model

COMPLETE


包含：

- Action Object Schema
- Action Type Model
- Action Boundary


==================================================
当前任务
==================================================


R4.3.2A.1

General Parameter Contract


==================================================
输入限制
==================================================


只读取：


validation/phanthy_recovery_action_model_part1_design.md


validation/phanthy_recovery_action_model_part2_design.md


禁止读取其他文件。


==================================================
任务目标
==================================================


定义：

Recovery Action parameters 字段的通用结构。


==================================================
设计内容
==================================================


## 1. Parameter Purpose


说明：

parameters 在 Recovery Action 中的作用。


--------------------------------------------------


## 2. General Parameter Schema


定义：

所有 Action 共用的参数结构。


包括：

- parameter container structure

- required/optional rules

- reference handling

- audit relation


--------------------------------------------------


## 3. Parameter Boundary


明确：

parameters：

负责：

- 描述执行所需信息


不负责：

- 执行动作
- 修改状态
- 创建恢复流程


--------------------------------------------------


## 4. Relationship


说明：


action_type

↓

specific parameter schema（后续阶段）


==================================================
输出
==================================================


生成：

validation/phanthy_recovery_action_parameter_general_schema_design.md


==================================================
限制
==================================================


禁止：

- 定义具体 action 参数
- 设计 retry 参数
- 设计 checkpoint 参数
- 设计 resume 参数
- 写代码
- 修改 OpenClaw


当前唯一目标：

完成通用 Parameter Contract。


==================================================

最终：

PHANTHY_RECOVERY_ACTION_PARAMETER_GENERAL_SCHEMA_DESIGN — COMPLETE
assistant: HEARTBEAT_OK
user: Sender (untrusted metadata):
```json
{
  "label": "openclaw-control-ui",
  "id": "openclaw-control-ui"
}
```

[Sun 2026-09-20 05:48 UTC] 结果
assistant: `phanthy_recovery_action_parameter_general_schema_design.md` 已生成。

覆盖内容：

- **Section 1** — `parameters` 的定位：声明式描述，不执行、不修改状态、不创建流程
- **Section 2** — 通用容器结构：`parameter_schema_version` / `action_type_ref` / `context_summary` / `action_inputs` / `fallback_reason` / `prior_decision_reference` / `parameter_audit_note`，含完整字段定义和 required/optional 规则
- **Section 2.5** — `prior_decision_reference` 链式结构，支持多轮恢复追踪
- **Section 2.6** — 引用处理约定（优先用 ID，非路径）
- **Section 2.7** — 审计关系规则（写入后不可修改）
- **Section 3** — 边界：`parameters` 只负责描述，不负责执行、改状态、建流程
- **Section 4** — `action_type` → `action_inputs` 扩展点映射，明确后续 R4.3.2B–E 的接入方式

PHANTHY_RECOVERY_ACTION_PARAMETER_GENERAL_SCHEMA_DESIGN — COMPLETE
