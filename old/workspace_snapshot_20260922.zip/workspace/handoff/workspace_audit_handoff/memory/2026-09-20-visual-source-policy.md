# Session: 2026-09-20 07:01:01 UTC

- **Session Key**: agent:main:main
- **Session ID**: 0f538646-e928-4f04-b553-0009cd1190ac
- **Source**: webchat

## Conversation Summary

user: A new session was started via /new or /reset. Run your Session Startup sequence - read the required files before responding to the user. Then greet the user in your configured persona, if one is provided. Be yourself - use your defined voice, mannerisms, and mood. Keep it to 1-3 sentences and ask what they want to do. If the runtime model differs from default_model in the system prompt, mention the default model. Do not mention internal steps, files, tools, or reasoning.
Current time: Sunday, September 20th, 2026 — 6:58 AM (UTC) / 2026-09-20 06:58 UTC
assistant: NO_REPLY
user: Sender (untrusted metadata):
```json
{
  "label": "openclaw-control-ui",
  "id": "openclaw-control-ui"
}
```

[Sun 2026-09-20 06:58 UTC] 开始 PHANTHY_CREATOR_AGENT_CHINA_NATIONAL_GEOGRAPHIC_VISUAL_SOURCE_POLICY_DESIGN


==================================================
Context
==================================================

项目：

Phanthy Creator Agent


Creator：

中国国家地理 Creator Agent


当前内容：

兵马俑图文稿


当前阶段：

Phase 2 Visual Strategy Alignment


==================================================
已完成
==================================================


Visual Requirement Analysis

COMPLETE


6张图片类型已确定：

REAL / AI_ILLUSTRATION


当前风险：

REAL图片 Image 2 / Image 5

copyright risk HIGH


==================================================
当前任务
==================================================


设计 Visual Source Policy。


==================================================
目标
==================================================


定义：

真实图片如何获取和使用。

==================================================
设计内容
==================================================


## 1. REAL Image Source Hierarchy


定义真实图片来源优先级。


--------------------------------------------------


## 2. Authorization Boundary


定义：

哪些来源可直接使用。

哪些需要授权确认。


--------------------------------------------------


## 3. AI Illustration Boundary


定义：

AI图片允许范围。

禁止范围。


--------------------------------------------------


## 4. Source Decision Rule


定义：

当真实图片不可用时：

如何决策：

- 替代来源
- 调整视觉需求
- 使用AI解释图


==================================================
输出
==================================================


生成：

validation/phanthy_creator_agent_visual_source_policy_design.md


==================================================
限制
==================================================


禁止：

- 采购图片
- 生成图片
- 发布内容
- 修改文案


当前唯一目标：

完成视觉素材来源治理。


最终：

PHANTHY_CREATOR_AGENT_VISUAL_SOURCE_POLICY — COMPLETE
assistant: Now I have a clear picture of the existing configuration. The visual_strategy.md and review_rules.md have no image source policy at all — no REAL vs AI_ILLUSTRATION boundary, no copyright rules, no source hierarchy. This is exactly what the task asks to design.

Let me look at the draft to confirm which images are REAL vs AI_ILLUSTRATION and which ones carry copyright risk.
assistant: Good. Now I have everything I need:

- Image 1 (cover_hook): AI_ILLUSTRATION → low risk
- Image 2 (contrast_photo): REAL → copyright risk HIGH (archaeological site photos, likely museum/institution-owned)
- Image 3 (infographic_structure): AI_ILLUSTRATION → low risk
- Image 4 (infographic_mechanism): AI_ILLUSTRATION → low risk
- Image 5 (documentary_photo): REAL → copyright risk HIGH (research team field photos, likely institution-owned)
- Image 6 (detail_photo): REAL → potential risk (could be museum-controlled)
assistant: **PHANTHY_CREATOR_AGENT_VISUAL_SOURCE_POLICY — COMPLETE**

已生成：`validation/phanthy_creator_agent_visual_source_policy_design.md`

---

**设计摘要：**

**Section 1 — REAL Image Source Hierarchy（4层优先级）**
- Tier 1：开放授权 / 公有领域（Wikimedia Commons、官方开放资源）
- Tier 2：平台授权图库（图虫创意、视觉中国）
- Tier 3：新闻通讯社图片（新华社、人民视觉）— 需明确授权
- Tier 4：博物馆 / 机构摄影 — 视为不可用，除非取得书面许可

**Section 2 — Authorization Boundary**
可直接使用 vs 需要确认授权 vs 禁止使用，三类边界清晰定义。

**Section 3 — AI Illustration Boundary**
允许：cover_hook、infographic 系列、示意图类角色。
禁止：冒充考古现场纪实、真实人物、以未标注 AI 图替代 documentary_photo。
强制披露规则：需在图片上叠加「示意图」或「复原示意」文字。

**Section 4 — Source Decision Rule（5步决策树）**
Tier 1 → Tier 2 → 替代真实图源 → 调整视觉需求（AI 替代 + 标注）→ 升级人工审核。

**当前草稿风险处置建议：**
- Image 2（对比照）：优先搜 Wikimedia Commons；无结果则 AI 复原示意图 + 「复原示意」标注
- Image 5（纪录片照）：直接替换为 AI 固色工艺流程示意图 + 「示意图」标注（Tier 4 机构照片不可直接使用）
- Image 6（细节照）：Wikimedia Commons 有大量 CC 授权兵马俑残存彩绘图，优先走 Tier 1
