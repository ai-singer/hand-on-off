#!/usr/bin/env python3
"""
蓝厂工程师私信轮询服务 (方案 B - 纯 Python)
每分钟检查一次未读消息并自动回复
"""

import time
import schedule
import sys
import os
from pathlib import Path

# 添加 scripts 目录到路径
sys.path.insert(0, str(Path(__file__).parent))

from smart_reply import (
    get_unread_count, 
    get_messages, 
    reply_message,
    load_env,
    test_api_connection
)

def check_and_reply():
    """检查消息并回复"""
    from datetime import datetime
    
    timestamp = datetime.now().strftime('%H:%M:%S')
    print(f"[{timestamp}] 检查私信...")
    
    try:
        # 获取未读消息数
        unread = get_unread_count()
        
        if unread == 0:
            return
        
        print(f"  发现 {unread} 条未读消息")
        
        # 获取消息列表
        data = get_messages()
        if not data:
            return
        
        # 处理每条未回复的消息
        messages = data.get('messages', [])
        replied_count = 0
        
        for msg in messages:
            if msg.get('status') == 'DELIVERED' and msg.get('replyId') is None:
                delivery_id = msg['id']
                version = msg['version']
                lease_token = msg['leaseToken']
                user_content = msg.get('latestContent', '')
                
                print(f"  处理消息 [{msg['messageId'][:8]}]: {user_content[:30]}...")
                
                # 生成并发送回复
                if reply_message(delivery_id, version, lease_token, user_content):
                    print("  ✓ 回复成功")
                    replied_count += 1
                else:
                    print("  ✗ 回复失败")
        
        print(f"  总计: 处理了 {len(messages)} 条, 成功回复 {replied_count} 条")
        
    except Exception as e:
        print(f"  [错误] {e}")

def main():
    """主函数"""
    from datetime import datetime
    
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 启动蓝厂工程师私信轮询服务")
    print("  检查频率: 每分钟")
    print("  实现方式: 纯 Python (无子进程)")
    print()
    
    # 加载配置
    load_env()
    
    # 测试 API 连接
    if not test_api_connection():
        print("API 连接失败，退出")
        sys.exit(1)
    
    # 设置定时任务 - 每分钟执行
    schedule.every(1).minutes.do(check_and_reply)
    
    print("轮询服务已启动，按 Ctrl+C 停止")
    print()
    
    # 立即执行一次
    check_and_reply()
    
    # 保持运行
    while True:
        schedule.run_pending()
        time.sleep(1)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n服务已停止")
        sys.exit(0)
