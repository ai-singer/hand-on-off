#!/bin/bash
# 蓝厂工程师私信自动回复脚本
# 运行：bash /home/node/.openclaw/workspace/scripts/message_poller.sh

API_KEY="phanthy_5a30b2259c3d36357f556240cabe10f4"
BASE_URL="https://cms.phanthy.com/api/v1/openclaw"
LOG_FILE="/home/node/.openclaw/workspace/logs/message_poller.log"

mkdir -p /home/node/.openclaw/workspace/logs

echo "[$(date '+%Y-%m-%d %H:%M:%S')] 开始轮询消息..." >> $LOG_FILE

# 获取未读消息数
UNREAD=$(curl -s "${BASE_URL}/messages/unread-count" \
  -H "Authorization: Bearer ${API_KEY}" | python3 -c "import json,sys; print(json.load(sys.stdin).get('count', 0))")

echo "[$(date '+%Y-%m-%d %H:%M:%S')] 未读消息: $UNREAD" >> $LOG_FILE

if [ "$UNREAD" -gt 0 ]; then
    # 获取消息列表
    curl -s "${BASE_URL}/messages" \
      -H "Authorization: Bearer ${API_KEY}" > /tmp/messages.json
    
    # 处理每条消息
    python3 << 'PYEOF'
import json
import urllib.request

API_KEY = "phanthy_5a30b2259c3d36357f556240cabe10f4"
BASE_URL = "https://cms.phanthy.com/api/v1/openclaw"

with open('/tmp/messages.json') as f:
    data = json.load(f)

for msg in data.get('messages', []):
    if msg.get('status') == 'DELIVERED' and msg.get('replyId') is None:
        delivery_id = msg['id']
        lease_token = msg['leaseToken']
        version = msg['version']
        user_content = msg.get('latestContent', '')
        
        # 生成回复（基于蓝厂工程师身份）
        reply_content = f"收到你的消息：「{user_content[:50]}」\n\n我是蓝厂工程师，专注视频创作方法论。请具体描述你的问题，我会用工程思维帮你分析。"
        
        # 发送回复
        url = f"{BASE_URL}/messages/{delivery_id}/reply"
        payload = {
            "content": reply_content,
            "version": version,
            "leaseToken": lease_token
        }
        
        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode(),
            headers={
                "Authorization": f"Bearer {API_KEY}",
                "Content-Type": "application/json"
            },
            method="POST"
        )
        
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                result = json.load(resp)
                print(f"[回复成功] 消息ID: {msg['messageId'][:8]}... 状态: {result.get('success')}")
        except Exception as e:
            print(f"[回复失败] 错误: {e}")
PYEOF
fi

echo "[$(date '+%Y-%m-%d %H:%M:%S')] 轮询完成" >> $LOG_FILE
