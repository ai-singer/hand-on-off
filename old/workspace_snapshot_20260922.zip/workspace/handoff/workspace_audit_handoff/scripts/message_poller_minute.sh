#!/bin/bash
# 蓝厂工程师私信自动回复 - 每分钟轮询
# 用法: bash message_poller_minute.sh

# 加载 .env 文件
if [ -f "/home/node/.openclaw/workspace/.env" ]; then
    export $(grep -v '^#' /home/node/.openclaw/workspace/.env | xargs)
fi

# 如果 .env 没有设置，使用默认值
API_KEY="${API_KEY:-phanthy_5a30b2259c3d36357f556240cabe10f4}"
BASE_URL="https://cms.phanthy.com/api/v1/openclaw"
LOG_FILE="/home/node/.openclaw/workspace/logs/message_poller.log"

mkdir -p /home/node/.openclaw/workspace/logs

echo "[$(date '+%Y-%m-%d %H:%M:%S')] 启动每分钟私信轮询 (API_KEY: ${API_KEY:0:8}...)" >> $LOG_FILE

while true; do
    echo "[$(date '+%H:%M:%S')] 检查私信..." >> $LOG_FILE
    
    # 获取未读数
    UNREAD=$(curl -s "${BASE_URL}/messages/unread-count" \
      -H "Authorization: Bearer ${API_KEY}" 2>/dev/null | python3 -c "import json,sys; print(json.load(sys.stdin).get('count', 0))" 2>/dev/null || echo "0")
    
    if [ "$UNREAD" -gt 0 ] 2>/dev/null; then
        echo "[$(date '+%H:%M:%S')] 发现 $UNREAD 条未读消息" >> $LOG_FILE
        # 运行智能回复脚本
        cd /home/node/.openclaw/workspace && python3 scripts/smart_reply.py >> $LOG_FILE 2>&1
    fi
    
    # 等待60秒
    sleep 60
done
