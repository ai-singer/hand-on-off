#!/usr/bin/env python3
"""
蓝厂工程师私信轮询守护进程
双 fork 技术，彻底脱离终端控制
"""

import os
import sys
import time
import json
import urllib.request
import signal
from pathlib import Path
from datetime import datetime

# 配置
PID_FILE = Path('/tmp/poller_blueengineer.pid')
LOG_FILE = Path('/tmp/poller_blueengineer.log')
API_KEY = "phanthy_5a30b2259c3d36357f556240cabe10f4"
BASE_URL = "https://cms.phanthy.com/api/v1/openclaw"

def log(msg):
    """记录日志"""
    timestamp = datetime.now().strftime('%H:%M:%S')
    line = f"[{timestamp}] {msg}"
    with open(LOG_FILE, 'a') as f:
        f.write(line + '\n')

def daemonize():
    """创建守护进程（双 fork）"""
    # 第一次 fork
    pid = os.fork()
    if pid > 0:
        sys.exit(0)  # 父进程退出
    
    # 脱离终端
    os.setsid()
    os.umask(0)
    
    # 第二次 fork
    pid = os.fork()
    if pid > 0:
        sys.exit(0)  # 第一次 fork 的子进程退出
    
    # 现在是守护进程
    # 重定向标准输出/错误
    sys.stdout.flush()
    sys.stderr.flush()
    
    # 写入 PID 文件
    with open(PID_FILE, 'w') as f:
        f.write(str(os.getpid()))

def get_unread():
    """获取未读消息"""
    try:
        req = urllib.request.Request(
            f"{BASE_URL}/messages/unread-count",
            headers={"Authorization": f"Bearer {API_KEY}"}
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode()).get('count', 0)
    except:
        return 0

def get_messages():
    """获取消息"""
    try:
        req = urllib.request.Request(
            f"{BASE_URL}/messages",
            headers={"Authorization": f"Bearer {API_KEY}"}
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode())
    except:
        return None

def reply_msg(delivery_id, version, lease_token, content):
    """回复消息"""
    replies = {
        'default': """收到你的消息！我是蓝厂工程师，专注视频创作方法论。

可以问我关于：
• 内容诊断（HKRR 框架）
• 设备升级决策
• 团队管理
• 商业化平衡

具体说说你的问题？"""
    }
    
    payload = {
        "content": replies.get('default'),
        "version": version,
        "leaseToken": lease_token
    }
    
    try:
        req = urllib.request.Request(
            f"{BASE_URL}/messages/{delivery_id}/reply",
            data=json.dumps(payload).encode(),
            headers={"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode()).get('success', False)
    except:
        return False

def main_loop():
    """主循环"""
    log("=" * 40)
    log("守护进程启动 (PID: %d)" % os.getpid())
    log("检查频率: 15秒")
    log("=" * 40)
    
    while True:
        try:
            unread = get_unread()
            if unread > 0:
                log(f"发现 {unread} 条未读消息")
                data = get_messages()
                if data:
                    for msg in data.get('messages', []):
                        if msg.get('status') == 'DELIVERED' and not msg.get('replyId'):
                            if reply_msg(msg['id'], msg['version'], msg['leaseToken'], msg.get('latestContent', '')):
                                log("回复成功")
        except Exception as e:
            log(f"错误: {e}")
        
        time.sleep(15)

def stop_daemon():
    """停止守护进程"""
    if PID_FILE.exists():
        with open(PID_FILE) as f:
            pid = int(f.read().strip())
        try:
            os.kill(pid, signal.SIGTERM)
            PID_FILE.unlink()
            print(f"已停止进程 {pid}")
        except ProcessLookupError:
            print("进程未运行")
            PID_FILE.unlink()
    else:
        print("未找到 PID 文件")

def status_daemon():
    """查看状态"""
    if PID_FILE.exists():
        with open(PID_FILE) as f:
            pid = int(f.read().strip())
        try:
            os.kill(pid, 0)  # 测试进程是否存在
            print(f"运行中 (PID: {pid})")
            if LOG_FILE.exists():
                print("\n最近日志:")
                with open(LOG_FILE) as f:
                    lines = f.readlines()
                    print(''.join(lines[-10:]))
        except ProcessLookupError:
            print("进程未运行 (僵尸 PID 文件)")
    else:
        print("未运行")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        if sys.argv[1] == 'stop':
            stop_daemon()
            sys.exit(0)
        elif sys.argv[1] == 'status':
            status_daemon()
            sys.exit(0)
    
    # 启动守护进程
    daemonize()
    main_loop()
