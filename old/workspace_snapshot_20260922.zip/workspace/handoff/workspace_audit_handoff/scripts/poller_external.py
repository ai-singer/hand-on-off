#!/usr/bin/env python3
"""
蓝厂工程师私信轮询服务 (External Poll 模式)
无子进程设计，彻底避免僵尸进程
"""

import time
import json
import urllib.request
import urllib.error
import sys
import os
from pathlib import Path
from datetime import datetime

# 配置
ENV_FILE = Path(__file__).parent.parent / '.env'
API_KEY = None
BASE_URL = "https://cms.phanthy.com/api/v1/openclaw"
LOG_FILE = Path(__file__).parent.parent / 'logs' / 'poller_external.log'

def log(msg):
    """记录日志"""
    timestamp = datetime.now().strftime('%H:%M:%S')
    line = f"[{timestamp}] {msg}"
    print(line)
    # 写入日志文件
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, 'a') as f:
        f.write(line + '\n')

def load_env():
    """加载 API KEY"""
    global API_KEY
    
    # 从系统环境变量读取
    API_KEY = os.environ.get('API_KEY')
    
    # 从 .env 文件读取
    if not API_KEY and ENV_FILE.exists():
        try:
            with open(ENV_FILE, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        key, value = line.split('=', 1)
                        if key.strip() == 'API_KEY':
                            API_KEY = value.strip()
                            break
        except Exception as e:
            log(f"[警告] 读取 .env 失败: {e}")
    
    # 使用默认值
    if not API_KEY:
        API_KEY = "phanthy_5a30b2259c3d36357f556240cabe10f4"
    
    log(f"API KEY: {API_KEY[:8]}...{API_KEY[-8:]}")

def get_unread_count():
    """获取未读消息数"""
    try:
        req = urllib.request.Request(
            f"{BASE_URL}/messages/unread-count",
            headers={"Authorization": f"Bearer {API_KEY}"}
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            return data.get('count', 0)
    except Exception as e:
        log(f"[错误] 获取未读数失败: {e}")
        return 0

def get_messages():
    """获取消息列表"""
    try:
        req = urllib.request.Request(
            f"{BASE_URL}/messages",
            headers={"Authorization": f"Bearer {API_KEY}"}
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        log(f"[错误] 获取消息失败: {e}")
        return None

def generate_reply(user_content):
    """生成回复内容"""
    content_lower = user_content.lower()
    
    if any(kw in content_lower for kw in ['你好', '嗨', 'hello', 'hi', '是谁']):
        return """嗨，我是蓝厂工程师 👋

一个用工程思维解构视频创作的 AI 助手。专注领域：

• 内容诊断（HKRR 框架）
• 设备与技术决策
• 团队建设与管理
• 创作与商业化平衡

有什么创作相关的问题？直接问！"""
    
    elif any(kw in content_lower for kw in ['播放', '没人看', '流量', '推荐']):
        return """播放量少？先用 HKRR 框架自检：

**快乐(H)**：画面清晰吗？声音清楚吗？
**知识(K)**：观众能学到新东西吗？
**共鸣(R)**：内容真实有温度吗？
**节奏(R)**：全程无尿点吗？

具体说说你的视频类型和当前数据？"""
    
    elif any(kw in content_lower for kw in ['设备', '相机', '镜头', '买']):
        return """设备升级前做三个验证：

1. **双盲对比**：新旧设备盲测，观众能分辨吗？
2. **平台链路验证**：上传后平台压缩了多少？
3. **ROI 计算**：投入成本 vs 预期收益

你目前在考虑什么设备？"""
    
    else:
        return f"""收到你的问题：「{user_content[:50]}」

我是蓝厂工程师，用工程思维帮创作者解决实际问题。

能具体描述一下你的创作阶段和遇到的痛点吗？这样我可以给你更有针对性的建议。"""

def reply_message(delivery_id, version, lease_token, user_content):
    """回复消息"""
    reply_content = generate_reply(user_content)
    
    payload = {
        "content": reply_content,
        "version": version,
        "leaseToken": lease_token
    }
    
    try:
        req = urllib.request.Request(
            f"{BASE_URL}/messages/{delivery_id}/reply",
            data=json.dumps(payload).encode('utf-8'),
            headers={
                "Authorization": f"Bearer {API_KEY}",
                "Content-Type": "application/json"
            },
            method="POST"
        )
        
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode())
            return result.get('success', False)
    except Exception as e:
        log(f"[错误] 回复失败: {e}")
        return False

def check_and_reply():
    """检查并回复消息"""
    unread = get_unread_count()
    
    if unread == 0:
        return
    
    log(f"发现 {unread} 条未读消息")
    
    data = get_messages()
    if not data:
        return
    
    messages = data.get('messages', [])
    replied_count = 0
    
    for msg in messages:
        if msg.get('status') == 'DELIVERED' and msg.get('replyId') is None:
            delivery_id = msg['id']
            version = msg['version']
            lease_token = msg['leaseToken']
            user_content = msg.get('latestContent', '')
            
            log(f"处理消息 [{msg['messageId'][:8]}]: {user_content[:30]}...")
            
            if reply_message(delivery_id, version, lease_token, user_content):
                log("✓ 回复成功")
                replied_count += 1
            else:
                log("✗ 回复失败")
    
    log(f"总计: 处理了 {len(messages)} 条, 成功回复 {replied_count} 条")

def main():
    """主循环"""
    log("=" * 50)
    log("蓝厂工程师私信轮询服务启动 (External Poll)")
    log("检查频率: 15秒 (External Poll 模式)")
    log("进程类型: 纯 Python 单进程")
    log("=" * 50)
    
    # 加载配置
    load_env()
    
    # 测试 API
    try:
        req = urllib.request.Request(
            f"{BASE_URL}/status",
            headers={"Authorization": f"Bearer {API_KEY}"}
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            log(f"✓ API 连接正常，Agent 状态: {data.get('status', 'unknown')}")
    except Exception as e:
        log(f"✗ API 连接失败: {e}")
        return
    
    log("轮询服务已启动")
    log("")
    
    # 主循环 - 每15秒检查一次 (符合 External Poll 最佳实践)
    check_interval = 15
    
    while True:
        try:
            check_and_reply()
        except Exception as e:
            log(f"[错误] 检查异常: {e}")
        
        time.sleep(check_interval)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        log("\n服务已停止")
        sys.exit(0)
