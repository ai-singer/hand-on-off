#!/usr/bin/env python3
"""
蓝厂工程师私信自动回复系统
基于角色设定自动回复 Phanthy 私信
"""

import json
import urllib.request
import urllib.error
import sys
import os
from pathlib import Path

# 加载 .env 文件
ENV_FILE = Path(__file__).parent.parent / '.env'
API_KEY = None
BASE_URL = "https://cms.phanthy.com/api/v1/openclaw"

def load_env():
    """从 .env 文件加载环境变量"""
    global API_KEY
    
    # 首先尝试从系统环境变量读取
    API_KEY = os.environ.get('API_KEY')
    
    # 如果系统环境变量没有，尝试从 .env 文件读取
    if not API_KEY and ENV_FILE.exists():
        try:
            with open(ENV_FILE, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        key, value = line.split('=', 1)
                        if key.strip() == 'API_KEY':
                            API_KEY = value.strip()
                            break
        except Exception as e:
            print(f"[警告] 读取 .env 文件失败: {e}")
    
    # 使用硬编码作为后备
    if not API_KEY:
        API_KEY = "phanthy_5a30b2259c3d36357f556240cabe10f4"
        print(f"[信息] 使用内置 API KEY")
    else:
        print(f"[信息] 从 .env 加载 API KEY: {API_KEY[:8]}...{API_KEY[-8:]}")
    
    return API_KEY

def get_unread_count():
    """获取未读消息数"""
    try:
        req = urllib.request.Request(
            f"{BASE_URL}/messages/unread-count",
            headers={"Authorization": f"Bearer {API_KEY}"}
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            return data.get('count', 0)
    except Exception as e:
        print(f"[错误] 获取未读数失败: {e}")
        return 0

def get_messages():
    """获取消息列表"""
    try:
        req = urllib.request.Request(
            f"{BASE_URL}/messages",
            headers={"Authorization": f"Bearer {API_KEY}"}
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        print(f"[错误] 获取消息失败: {e}")
        return None

def generate_reply(user_content):
    """基于蓝厂工程师身份生成回复"""
    content_lower = user_content.lower()
    
    # 识别常见问题类型
    if any(kw in content_lower for kw in ['你好', '嗨', 'hello', 'hi', '是谁']):
        return """嗨，我是蓝厂工程师 👋

一个用工程思维解构视频创作的 AI 助手。专注领域：

• 内容诊断（HKRR 框架）
• 设备与技术决策
• 团队建设与管理
• 创作与商业化平衡

我的观点基于公开的行业访谈和案例整理，不代表任何具体个人或机构。

有什么创作相关的问题？直接问，不绕弯子。"""
    
    elif any(kw in content_lower for kw in ['播放', '没人看', '流量', '推荐']):
        return """播放量少的问题，建议先用 HKRR 框架自检：

**快乐(H)**：画面清晰吗？声音清楚吗？剪辑流畅吗？
**知识(K)**：观众能学到新东西吗？
**共鸣(R)**：内容真实有温度吗？
**节奏(R)**：全程无尿点吗？

具体问题具体分析，你能描述一下你的视频类型和当前数据吗？"""
    
    elif any(kw in content_lower for kw in ['设备', '相机', '镜头', '买']):
        return """设备升级前，先做三个验证：

1. **双盲对比**：新旧设备盲测，观众能分辨吗？
2. **平台链路验证**：上传后平台压缩了多少？
3. **ROI 计算**：投入成本 vs 预期收益

记住：技术服务于内容，参数服务于体验。

你目前在考虑什么设备？"""
    
    elif any(kw in content_lower for kw in ['团队', '招人', '管理', '工作室']):
        return """从个人到团队的三个原则：

1. **先招解决最大瓶颈的人**（不是按顺序招）
2. **专业 > 全能 > 热情**
3. **小团队先试，3-5人跑通再扩张**

你目前卡在哪个环节？剪辑？拍摄？运营？"""
    
    elif any(kw in content_lower for kw in ['广告', '商单', '恰饭', '变现']):
        return """内容与商业化的核心：**分离耦合**

• 内容负责建立信任和需求发现
• 商业负责现金流和规模
• 商单必须能同时服务观众和客户

三条红线：
❌ 不能让广告透支频道信誉
❌ 不能为了恰饭牺牲内容质量
❌ 不能接自己都不信的产品

你目前的商业化模式是什么？"""
    
    else:
        return f"""收到你的问题：「{user_content[:50]}」

我是蓝厂工程师，用工程思维帮创作者解决实际问题。

你能具体描述一下：
1. 你目前的创作阶段（个人/团队）？
2. 遇到的具体痛点是什么？
3. 尝试过什么解决方法？

这样我可以给你更有针对性的建议。"""

def reply_message(delivery_id, version, lease_token, user_content):
    """回复消息"""
    reply_content = generate_reply(user_content)
    
    payload = {
        "content": reply_content,
        "version": version,
        "leaseToken": lease_token
    }
    
    try:
        req = urllib.request.Request(
            f"{BASE_URL}/messages/{delivery_id}/reply",
            data=json.dumps(payload).encode('utf-8'),
            headers={
                "Authorization": f"Bearer {API_KEY}",
                "Content-Type": "application/json"
            },
            method="POST"
        )
        
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode())
            return result.get('success', False)
    except urllib.error.HTTPError as e:
        error_body = e.read().decode()
        print(f"[HTTP错误 {e.code}] {error_body}")
        return False
    except Exception as e:
        print(f"[错误] 回复失败: {e}")
        return False

def test_api_connection():
    """测试 API 连接"""
    try:
        req = urllib.request.Request(
            f"{BASE_URL}/status",
            headers={"Authorization": f"Bearer {API_KEY}"}
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            print(f"[✓] API 连接正常，Agent 状态: {data.get('status', 'unknown')}")
            return True
    except urllib.error.HTTPError as e:
        error_body = e.read().decode()
        print(f"[✗] API 连接失败 [{e.code}]: {error_body}")
        return False
    except Exception as e:
        print(f"[✗] API 连接错误: {e}")
        return False

def main():
    """主函数"""
    from datetime import datetime
    
    print(f"[{datetime.now().strftime('%H:%M:%S')}] 蓝厂工程师私信自动回复系统启动")
    
    # 加载 API KEY
    load_env()
    
    # 测试 API 连接
    if not test_api_connection():
        print("API 连接测试失败，请检查 API KEY 是否正确")
        return
    
    # 获取未读消息数
    unread = get_unread_count()
    print(f"未读消息: {unread}")
    
    if unread == 0:
        print("没有新消息")
        return
    
    # 获取消息列表
    data = get_messages()
    if not data:
        return
    
    # 处理每条未回复的消息
    messages = data.get('messages', [])
    replied_count = 0
    
    for msg in messages:
        if msg.get('status') == 'DELIVERED' and msg.get('replyId') is None:
            delivery_id = msg['id']
            version = msg['version']
            lease_token = msg['leaseToken']
            user_content = msg.get('latestContent', '')
            
            print(f"\n处理消息 [{msg['messageId'][:8]}]: {user_content[:30]}...")
            
            # 生成并发送回复
            if reply_message(delivery_id, version, lease_token, user_content):
                print("✓ 回复成功")
                replied_count += 1
            else:
                print("✗ 回复失败")
    
    print(f"\n总计: 处理了 {len(messages)} 条消息, 成功回复 {replied_count} 条")

if __name__ == "__main__":
    main()
