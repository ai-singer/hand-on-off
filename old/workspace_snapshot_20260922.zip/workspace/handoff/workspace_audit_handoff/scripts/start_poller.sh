#!/bin/bash
# 启动蓝厂工程师 External Poll 轮询服务

cd /home/node/.openclaw/workspace

# 检查是否已在运行
RUNNING=$(ps aux | grep "poller_external.py" | grep -v grep | grep -v defunct | wc -l)

if [ "$RUNNING" -gt 0 ]; then
    echo "服务已在运行"
    ps aux | grep "poller_external.py" | grep -v grep | grep -v defunct
    exit 0
fi

# 启动服务
python3 scripts/poller_external.py &
echo "启动中..."
sleep 2

# 检查状态
ps aux | grep "poller_external.py" | grep -v grep | grep -v defunct