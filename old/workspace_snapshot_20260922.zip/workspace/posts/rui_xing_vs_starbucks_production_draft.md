# 瑞幸 vs 星巴克 — 小红书图文稿 Production Draft

**Topic:** 为什么瑞幸能在中国挑战星巴克？
**Creator Style:** xiaolinshuo
**Evidence Contract:** C01-R / C02 / C03-R (ALL VERIFIED)
**Status:** DRAFT — NOT FOR PUBLICATION

---

## PART 1 — TEXT GENERATION

---

### 标题

**选定标题（Question Hook 类型）：**

> 瑞幸和星巴克，到底在卖什么不同的东西？

字数：18字 ✅（≤20字）

备用标题（Contrast Hook 类型）：

> 同样是咖啡，为什么两家店的逻辑完全不同？

---

### 正文

---

**【封面/首图文字】**

主标题覆盖文字：`两杯咖啡，两套逻辑`（9字 ✅）

副标题覆盖文字：`不是谁打败谁，是市场分成了两半`（≤30字 ✅）

---

**【正文内容】**

---

你有没有想过——

同样是咖啡，为什么有人专门绕路去星巴克，
有人却随手在瑞幸下单，5分钟取走就走？

这两种行为，背后是两种完全不同的消费逻辑。

---

**先说星巴克在卖什么。**

它卖的不只是咖啡，是一个"待着的理由"。

选址大、座位多、装修有调性——
这是有意设计的：让你愿意在这里开会、等人、发呆。

行业里叫"第三空间"：
家和公司之外，一个你可以停下来的地方。

---

**瑞幸卖的是另一种东西。**

它的大多数门店面积很小，有的甚至没有堂食座位。

核心动作是：手机下单 → 到店自提 → 走人。

这套模型降低了门店面积需求，
也让它可以快速在更多位置开店、更贴近用户。

它不是在让你"待下来"，
而是在让你"顺路取走"。

---

**两种逻辑，对应两种消费场景。**

当你需要一个安静工作的地方，
当你要请客户喝咖啡、谈项目——
星巴克的"空间价值"是真实存在的。

当你只是早上通勤路上需要提神，
当你在写字楼里下午三点需要一杯续命——
你要的不是空间，是咖啡本身。

这两种需求，都是真实存在的市场。

---

**中国咖啡市场发生的事情，**
其实是这两种场景都在同步增长。

功能型消费——"我需要一杯咖啡"——
正在成为越来越多人的日常选择。

社交空间消费——"我们去咖啡馆坐坐"——
依然有它稳定的用户群体。

两个市场没有互相消灭，只是越来越清楚地分开了。

---

**所以，不是"瑞幸打败了星巴克"。**

更准确的说法是：
瑞幸找到并放大了一个原来被忽视的消费场景，
然后用一套专门为这个场景设计的运营模型来服务它。

两家公司在做的，本质上是两件不同的事。

---

如果你也在分析消费行业的案例，
有没有觉得"谁打败了谁"这种说法，
往往掩盖了更有意思的东西？

欢迎在评论聊聊你怎么看。

---

**【正文字数统计】**

约 520 字 ✅（300–800字范围内）

---

### 自检清单

| 项目 | 状态 |
|---|---|
| Hook 在前2行 | ✅ |
| Value Promise 已给出 | ✅ |
| Core Information 交付承诺内容 | ✅ |
| Emotional Connection 存在 | ✅ |
| 互动引导（最多1个） | ✅（1个，末尾） |
| 标题 ≤20字 | ✅ |
| 每段 ≤4行 | ✅ |
| 字数 300–800 | ✅ |
| 无虚构事实 | ✅ |
| 无单因素胜负归因 | ✅ |
| 无"瑞幸打败星巴克"表述 | ✅ |
| 无"低价决定胜负"表述 | ✅ |

---

## PART 2 — VISUAL GENERATION PLAN

**Series Identity:**
- Color Palette: 深靛蓝 + 暖白 + 橙黄点缀（中性、分析感、避免品牌色直接套用）
- Layout Template: 左对齐信息块 + 右侧视觉图示
- Series Marker: 左上角小标签「场景分析」
- Ratio: 3:4 (1080×1440px)

---

### 图片规划

---

**Image 1 — Cover / Hook**

| 字段 | 内容 |
|---|---|
| Image Purpose | 建立问题感，驱动用户停留 |
| Visual Type | AI_ILLUSTRATION |
| Role | Hook |
| Core Information | 两杯咖啡，两种场景，两套逻辑 |
| Main Subject | 左侧：小店取走咖啡的人；右侧：坐在咖啡馆工作的人。两人背对背，分割构图 |
| Scene | 城市日常场景，简洁线条风格 |
| Emotional Tone | 好奇、轻松 |
| Text Overlay | 主：`两杯咖啡，两套逻辑`（封面大字） / 副：`不是谁打败谁，是市场分成了两半` |
| Asset Classification | AI_ILLUSTRATION — 无真实素材需求，概念性对比构图适合AI生成 |

---

**Image 2 — Context**

| 字段 | 内容 |
|---|---|
| Image Purpose | 解释星巴克"第三空间"模型 |
| Visual Type | AI_ILLUSTRATION |
| Role | Context |
| Core Information | 星巴克核心价值 = 空间体验，不只是咖啡 |
| Main Subject | 宽敞、有调性的咖啡馆内部，有人在工作、谈话 |
| Scene | 室内，暖光，木质感，留白充足 |
| Emotional Tone | 舒适、质感 |
| Text Overlay | 主：`它卖的是"待着的理由"` / 副：`第三空间：家和公司之外` |
| Asset Classification | AI_ILLUSTRATION — 场景概念图，无需真实门店素材 |

---

**Image 3 — Explanation**

| 字段 | 内容 |
|---|---|
| Image Purpose | 说明瑞幸小店自提模型的运营特征 |
| Visual Type | AI_ILLUSTRATION |
| Role | Explanation |
| Core Information | 手机下单→到店自提→走人，小面积门店，高频次覆盖 |
| Main Subject | 简洁流程图：手机图标 → 小型门店图标 → 行走人物图标 |
| Scene | 扁平化信息图风格，干净背景 |
| Emotional Tone | 高效、直接 |
| Text Overlay | 主：`下单→自提→走人` / 副：`不是让你待下来，是让你顺路取走` |
| Asset Classification | AI_ILLUSTRATION — 流程示意图，适合AI生成 |

---

**Image 4 — Detail**

| 字段 | 内容 |
|---|---|
| Image Purpose | 对比两种消费场景的具体情境 |
| Visual Type | AI_ILLUSTRATION |
| Role | Detail |
| Core Information | 场景A：通勤提神 / 场景B：商务会面。两种需求都真实存在 |
| Main Subject | 分屏对比：左 = 地铁/通勤路上捧杯咖啡；右 = 两人在咖啡馆会面 |
| Scene | 城市场景，写实风格线条插画 |
| Emotional Tone | 真实、共鸣 |
| Text Overlay | 主：`两种需求，都是真实市场` / 副：`场景决定你选哪一家` |
| Asset Classification | AI_ILLUSTRATION — 场景插画，无需真实人物素材 |

---

**Image 5 — Explanation（市场分化）**

| 字段 | 内容 |
|---|---|
| Image Purpose | 解释中国咖啡市场的双轨并行结构 |
| Visual Type | AI_ILLUSTRATION |
| Role | Explanation |
| Core Information | 功能型消费 + 社交空间消费，两个细分市场同步增长，未互相消灭 |
| Main Subject | 两条平行上升曲线图，分别标注"功能型"和"空间型"，无胜负关系 |
| Scene | 简洁信息图，深色背景，浅色线条 |
| Emotional Tone | 理性、分析 |
| Text Overlay | 主：`两个市场，同步在长` / 副：`不是替代，是分化` |
| Asset Classification | AI_ILLUSTRATION — 数据趋势示意图，适合AI生成（注：曲线为趋势示意，非精确数据图，不标注具体数字） |

---

**Image 6 — Result**

| 字段 | 内容 |
|---|---|
| Image Purpose | 点明核心结论：瑞幸的增长来自找到并放大了新场景，非击败竞争对手 |
| Visual Type | AI_ILLUSTRATION |
| Role | Result |
| Core Information | 瑞幸放大了功能型消费场景 + 用专门模型服务它 = 两家做的是不同的事 |
| Main Subject | 两个圆形区域，交集极小，分别标注核心价值主张（空间体验 vs 便利获取） |
| Scene | 概念图，维恩图风格，简洁 |
| Emotional Tone | 清晰、豁然 |
| Text Overlay | 主：`他们在做两件不同的事` / 副：`找到被忽视的场景，然后专门服务它` |
| Asset Classification | AI_ILLUSTRATION — 概念关系图，适合AI生成 |

---

**Image 7 — CTA**

| 字段 | 内容 |
|---|---|
| Image Purpose | 引导互动，强化内容价值，鼓励评论 |
| Visual Type | AI_ILLUSTRATION |
| Role | CTA |
| Core Information | 邀请用户分享自己的消费场景偏好或行业观察 |
| Main Subject | 简洁排版卡片，问题文字为主视觉 |
| Scene | 纯色背景（深靛蓝），大字排版，温和互动感 |
| Emotional Tone | 开放、邀请 |
| Text Overlay | 主：`你怎么选咖啡？` / 副：`评论区聊聊你的场景` |
| Asset Classification | AI_ILLUSTRATION — 纯排版卡片，适合AI生成 |

---

### 视觉系列自检

| 项目 | 状态 |
|---|---|
| 图片数量 3–9 张 | ✅（7张） |
| 每张图有明确角色 | ✅ |
| 相邻图片角色不重复 | ✅（Hook→Context→Explanation→Detail→Explanation→Result→CTA） |
| 同一角色 ≤2张 | ✅（Explanation出现2次，符合规则） |
| 信息无重复 | ✅ |
| 视觉无冗余图 | ✅ |
| 封面2秒内传达主题 | ✅ |
| 封面文字 ≤15字 | ✅ |
| 图片比例 3:4 | ✅ |

---

## PART 3 — ASSET CLASSIFICATION SUMMARY

| 图片 | 类型 | 说明 |
|---|---|---|
| Image 1 (Cover) | AI_ILLUSTRATION | 概念性对比构图，无真实人物/门店需求 |
| Image 2 (Context) | AI_ILLUSTRATION | 空间感场景插画，无需真实星巴克素材 |
| Image 3 (Explanation) | AI_ILLUSTRATION | 流程示意图，纯图形化 |
| Image 4 (Detail) | AI_ILLUSTRATION | 场景对比插画，无需真实人物素材 |
| Image 5 (Explanation) | AI_ILLUSTRATION | 趋势示意图，为概念图非数据图，不标注具体数字 |
| Image 6 (Result) | AI_ILLUSTRATION | 概念关系图，维恩图风格 |
| Image 7 (CTA) | AI_ILLUSTRATION | 纯排版卡片 |

**REAL素材需求：无**

所有图片均适合AI生成。无需真实品牌素材，避免商标使用风险，同时符合内容定位（分析视角，非品牌宣传）。

---

## EVIDENCE CONTRACT 合规声明

| Claim ID | 使用位置 | 合规状态 |
|---|---|---|
| C03-R：小店模型、数字化运营、联营扩张 | 正文第3段（自提模型描述）、Image 3 | ✅ 在验证范围内使用 |
| C02：星巴克=空间体验 / 瑞幸=便利消费 | 正文第2、3、4段，Image 2、4、6 | ✅ 直接对应验证结论 |
| C01-R：市场消费场景分化，功能型+社交型共存 | 正文第5段，Image 5 | ✅ 在验证范围内使用 |

**未使用未验证数据：✅**
**未修改 Evidence Contract：✅**
**未发布：✅**

---

*Draft generated: 2026-09-20*
*Status: DRAFT — Awaiting review before publication*
