#!/usr/bin/env python3
"""
XHS Creator Discovery Runner — P1
读取 candidate_registry.json，批量执行采集 → normalize 流水线
"""
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

WORKSPACE = Path("/home/node/.openclaw/workspace")
REGISTRY_FILE = WORKSPACE / "source_material/xhs/creator_registry/candidate_registry.json"
COLLECTOR_SCRIPT = Path.home() / ".openclaw/skills/xhs-scraper-skill/scripts/scrape_two_stage.py"
NORMALIZE_SCRIPT = WORKSPACE / "source_material/xhs/schema/normalize.py"
RAW_DIR = WORKSPACE / "source_material/xhs/raw"
NORMALIZED_DIR = WORKSPACE / "source_material/xhs/normalized"


def load_registry() -> list:
    with open(REGISTRY_FILE, encoding="utf-8") as f:
        return json.load(f)


def save_registry(records: list):
    with open(REGISTRY_FILE, "w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)


def now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def collect_creator(record: dict) -> tuple[bool, str]:
    """执行 Collector CLI，返回 (success, raw_file_path)"""
    user_id = record.get("user_id", "")
    creator_name = record.get("creator_name", user_id)
    max_notes = record.get("collection_config", {}).get("max_notes", 100)

    if not user_id:
        return False, "user_id 未填写，跳过"

    date_str = datetime.now().strftime("%Y%m%d")
    expected_file = RAW_DIR / f"xhs_{creator_name}_{date_str}.json"

    cmd = [
        "python3", str(COLLECTOR_SCRIPT),
        "--user-id", user_id,
        "--creator-name", creator_name,
        "--max-notes", str(max_notes),
        "--output-dir", str(RAW_DIR),
    ]

    print(f"\n  执行: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)

    if result.returncode != 0:
        print(f"  × 采集失败:\n{result.stderr[:500]}")
        return False, ""

    print(result.stdout)

    if expected_file.exists():
        return True, str(expected_file)

    # 容错：查找最新创建的匹配文件
    candidates = sorted(RAW_DIR.glob(f"xhs_{creator_name}_*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    candidates = [c for c in candidates if "_phanthy" not in c.name]
    if candidates:
        return True, str(candidates[0])

    return False, "输出文件未找到"


def normalize_file(raw_file: str) -> tuple[bool, str]:
    """对单个 raw 文件执行标准化"""
    raw_path = Path(raw_file)
    if not raw_path.exists():
        return False, f"文件不存在: {raw_file}"

    date_str = raw_path.stem.split("_")[-1]
    out_name = raw_path.stem + "_normalized.json"
    out_path = NORMALIZED_DIR / out_name

    # 内联标准化逻辑（复用 schema/normalize.py 的 normalize_note）
    sys.path.insert(0, str(WORKSPACE / "source_material/xhs/schema"))
    from normalize import normalize_note

    with open(raw_path, encoding="utf-8") as f:
        raw_notes = json.load(f)

    normalized = [
        normalize_note(note, raw_ref=f"raw/{raw_path.name}")
        for note in raw_notes
    ]

    NORMALIZED_DIR.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(normalized, f, ensure_ascii=False, indent=2)

    return True, str(out_path)


def run_pipeline(target_statuses: list = None, dry_run: bool = False):
    """主流水线"""
    if target_statuses is None:
        target_statuses = ["verified"]

    records = load_registry()
    candidates = [r for r in records if r.get("status") in target_statuses and r.get("user_id")]

    print("=" * 60)
    print(f"XHS Discovery Runner — P1")
    print("=" * 60)
    print(f"注册表: {REGISTRY_FILE}")
    print(f"目标状态: {target_statuses}")
    print(f"候选博主: {len(candidates)} 个")
    if dry_run:
        print("【DRY RUN 模式，不执行实际采集】")
    print()

    if not candidates:
        print("无符合条件的博主，退出。")
        return

    results = []

    for record in sorted(candidates, key=lambda r: -r.get("collect_priority", 0)):
        name = record["creator_name"]
        uid = record["user_id"]
        print(f"\n{'─'*60}")
        print(f"博主: {name} ({uid})")
        print(f"优先级: {record.get('collect_priority', 0)}")

        if dry_run:
            print("  [DRY RUN] 跳过实际执行")
            results.append({"name": name, "status": "dry_run"})
            continue

        # Step 1: 更新状态为 collecting
        for r in records:
            if r["creator_id"] == record["creator_id"]:
                r["status"] = "collecting"
        save_registry(records)

        # Step 2: 采集
        print(f"\n  [Step 1] 采集...")
        ok, raw_file = collect_creator(record)

        if not ok:
            print(f"  × 采集失败: {raw_file}")
            for r in records:
                if r["creator_id"] == record["creator_id"]:
                    r["status"] = "candidate"  # 回滚
            save_registry(records)
            results.append({"name": name, "status": "collect_failed", "error": raw_file})
            continue

        # 统计采集数量
        try:
            with open(raw_file, encoding="utf-8") as f:
                notes_count = len(json.load(f))
        except Exception:
            notes_count = 0

        print(f"  ✓ 采集成功: {raw_file} ({notes_count}条)")

        # Step 3: 标准化
        print(f"\n  [Step 2] 标准化...")
        ok2, normalized_file = normalize_file(raw_file)

        if not ok2:
            print(f"  × 标准化失败: {normalized_file}")
        else:
            print(f"  ✓ 标准化完成: {normalized_file}")

        # Step 4: 更新注册表
        for r in records:
            if r["creator_id"] == record["creator_id"]:
                r["status"] = "normalized" if ok2 else "collected"
                r["notes_count"] = notes_count
                r["last_collection"] = {
                    "collected_at": now_iso(),
                    "notes_count": notes_count,
                    "raw_file": Path(raw_file).name,
                    "normalized_file": Path(normalized_file).name if ok2 else None,
                }
        save_registry(records)

        results.append({
            "name": name,
            "status": "normalized" if ok2 else "collected",
            "notes_count": notes_count,
            "raw_file": raw_file,
            "normalized_file": normalized_file if ok2 else None,
        })

    # 汇总
    print(f"\n{'='*60}")
    print("Pipeline 完成")
    print(f"{'='*60}")
    for r in results:
        icon = "✓" if r["status"] in ("normalized", "collected", "dry_run") else "×"
        print(f"  {icon} {r['name']}: {r['status']}")

    return results


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="XHS Creator Discovery Runner")
    parser.add_argument("--status", nargs="+", default=["candidate"],
                        help="目标状态过滤（默认: candidate）")
    parser.add_argument("--dry-run", action="store_true", help="仅显示计划，不执行采集")
    args = parser.parse_args()
    run_pipeline(target_statuses=args.status, dry_run=args.dry_run)
