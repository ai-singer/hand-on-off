#!/usr/bin/env python3
"""
XHS Creator Identity Validator
用 user_posted API 获取账号真实 nickname，与 creator_name 对比验证身份
"""
import asyncio
import hashlib
import json
import sys
import time
from pathlib import Path
from urllib.parse import quote
from typing import Optional
import aiohttp

WORKSPACE = Path("/home/node/.openclaw/workspace")
REGISTRY_FILE = WORKSPACE / "source_material/xhs/creator_registry/candidate_registry.json"
COLLECTOR_SCRIPT = Path.home() / ".openclaw/skills/xhs-scraper-skill/scripts/scrape_two_stage.py"

# ---- Cookie 加载（与 scrape_two_stage.py 保持一致）----

def _parse_netscape_cookies(content: str) -> str:
    cookies = []
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) >= 7:
            cookies.append(f"{parts[5]}={parts[6]}")
    return "; ".join(cookies)

def _load_cookie():
    txt_file = Path("/home/node/.openclaw/workspace/xiaohongshu_cookies.txt")
    if txt_file.exists():
        content = txt_file.read_text(encoding="utf-8").strip()
        if content:
            if "# Netscape HTTP Cookie File" in content or "\t" in content:
                converted = _parse_netscape_cookies(content)
                if converted:
                    return converted, str(txt_file) + " (Netscape)"
            else:
                return content, str(txt_file)
    ws_env = Path("/home/node/.openclaw/workspace/.env")
    if ws_env.exists():
        with open(ws_env, encoding="utf-8") as f:
            for line in f:
                if line.startswith("XHS_COOKIE="):
                    val = line.split("=", 1)[1].strip().strip('"')
                    if val:
                        return val, str(ws_env)
    bot_env = Path.home() / "xhs-auto-bot" / ".env"
    if bot_env.exists():
        with open(bot_env, encoding="utf-8") as f:
            for line in f:
                if line.startswith("XHS_COOKIE="):
                    val = line.split("=", 1)[1].strip().strip('"')
                    if val:
                        return val, str(bot_env)
    return "", ""

# ---- xhshow patch ----

def _patch_xhshow():
    from xhshow.core.crypto import CryptoProcessor
    _orig = CryptoProcessor.build_payload_array
    def _patched(self, hex_parameter, hex_md5_path, a1_value,
                 app_identifier="xhs-pc-web", string_param="", timestamp=None, sign_state=None):
        payload = _orig(self, hex_parameter, hex_md5_path, a1_value,
                        app_identifier, string_param, timestamp, sign_state)
        if "{" not in string_param:
            correct_md5_hex = hashlib.md5(string_param.encode("utf-8")).hexdigest()
            correct_md5_bytes = [int(correct_md5_hex[i:i+2], 16) for i in range(0, 32, 2)]
            seed_byte = payload[4]
            ts_bytes = payload[8:16]
            correct_a3 = self._custom_hash_v2(list(ts_bytes) + correct_md5_bytes)
            for i in range(16):
                payload[128+i] = correct_a3[i] ^ seed_byte
        return payload
    CryptoProcessor.build_payload_array = _patched

_patch_xhshow()

# ---- 签名 ----

def _sign_get(uri: str, params: dict, cookie_str: str) -> dict:
    from xhshow import Xhshow
    from urllib.parse import quote as _quote
    xhs = Xhshow()
    parts = []
    for k, v in params.items():
        if isinstance(v, list):
            v = ",".join(str(i) for i in v)
        elif v is None:
            v = ""
        parts.append(f"{k}={_quote(str(v), safe=',')}")
    content_string = f"{uri}?{'&'.join(parts)}"
    cookie_dict = xhs._parse_cookies(cookie_str)
    a1 = cookie_dict.get("a1", "")
    ts = time.time()
    d_value = hashlib.md5(content_string.encode("utf-8")).hexdigest()
    m_value = d_value
    payload_array = xhs.crypto_processor.build_payload_array(
        d_value, m_value, a1, "xhs-pc-web", content_string, ts)
    xor_result = xhs.crypto_processor.bit_ops.xor_transform_array(payload_array)
    config = xhs.config
    x3_b64 = xhs.crypto_processor.b64encoder.encode_x3(xor_result[:config.PAYLOAD_LENGTH])
    import json as _json
    sig_data = config.SIGNATURE_DATA_TEMPLATE.copy()
    sig_data["x3"] = config.X3_PREFIX + x3_b64
    x_s = config.XYS_PREFIX + xhs.crypto_processor.b64encoder.encode(
        _json.dumps(sig_data, separators=(",", ":"), ensure_ascii=False))
    return {
        "x-s": x_s,
        "x-s-common": xhs.sign_xs_common(cookie_dict),
        "x-t": str(xhs.get_x_t(ts)),
        "x-b3-traceid": xhs.get_b3_trace_id(),
    }

# ---- 核心验证函数 ----

async def fetch_real_nickname(user_id: str, cookie_str: str) -> Optional[str]:
    """请求 user_posted 拿第一条笔记的 user.nickname"""
    uri = "/api/sns/web/v1/user_posted"
    params = {"num": 1, "cursor": "", "user_id": user_id, "image_formats": "jpg"}
    signs = _sign_get(uri, params, cookie_str)
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Referer": "https://www.xiaohongshu.com/",
        "Origin": "https://www.xiaohongshu.com",
        "Accept": "application/json, text/plain, */*",
        "Cookie": cookie_str,
        "X-S": signs["x-s"],
        "X-T": signs["x-t"],
        "x-S-Common": signs["x-s-common"],
        "X-B3-Traceid": signs["x-b3-traceid"],
    }
    url = f"https://edith.xiaohongshu.com{uri}"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params, headers=headers,
                                   timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status != 200:
                    return None
                result = await resp.json()
                if not result.get("success"):
                    return None
                notes = result.get("data", {}).get("notes", [])
                if notes:
                    return notes[0].get("user", {}).get("nickname") or \
                           notes[0].get("user", {}).get("nick_name")
                return None
    except Exception as e:
        print(f"    fetch error: {e}")
        return None

def name_matches(expected: str, actual: str) -> bool:
    """宽松匹配：去除常见后缀符号后比较"""
    def normalize(s):
        return s.strip().rstrip("·。·.").strip().lower()
    return normalize(expected) == normalize(actual) or \
           normalize(expected) in normalize(actual) or \
           normalize(actual) in normalize(expected)

async def validate_creator(record: dict, cookie_str: str) -> dict:
    """验证单个博主身份，返回验证结果"""
    from datetime import datetime, timezone
    user_id = record.get("user_id", "")
    creator_name = record.get("creator_name", "")

    print(f"\n  验证: {creator_name} ({user_id})")

    if not user_id:
        return {
            "verified": False,
            "checked_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "returned_name": "",
            "reason": "user_id 为空"
        }

    real_name = await fetch_real_nickname(user_id, cookie_str)

    if real_name is None:
        return {
            "verified": False,
            "checked_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "returned_name": "",
            "reason": "API 请求失败或账号无笔记"
        }

    matched = name_matches(creator_name, real_name)
    print(f"    期望: {creator_name}")
    print(f"    实际: {real_name}")
    print(f"    匹配: {'✓' if matched else '×'}")

    return {
        "verified": matched,
        "checked_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "returned_name": real_name,
        "reason": "nickname 匹配" if matched else f"nickname 不匹配: 期望 '{creator_name}'，实际 '{real_name}'"
    }

# ---- 主流程 ----

async def run_validation(target_statuses=None):
    from datetime import datetime, timezone
    if target_statuses is None:
        target_statuses = ["candidate", "verified", "identity_failed"]

    cookie, cookie_source = _load_cookie()
    if not cookie:
        print("× Cookie 加载失败")
        sys.exit(1)

    with open(REGISTRY_FILE, encoding="utf-8") as f:
        records = json.load(f)

    targets = [r for r in records if r.get("status") in target_statuses]

    print("=" * 60)
    print("XHS Creator Identity Validator")
    print("=" * 60)
    print(f"Cookie: {cookie_source} (len={len(cookie)})")
    print(f"目标状态: {target_statuses}")
    print(f"候选数量: {len(targets)}")

    results = []

    for record in targets:
        # 更新状态为 checking
        for r in records:
            if r["creator_id"] == record["creator_id"]:
                r["status"] = "identity_checking"
        with open(REGISTRY_FILE, "w", encoding="utf-8") as f:
            json.dump(records, f, ensure_ascii=False, indent=2)

        check_result = await validate_creator(record, cookie)

        new_status = "verified" if check_result["verified"] else "identity_failed"
        for r in records:
            if r["creator_id"] == record["creator_id"]:
                r["status"] = new_status
                r["identity_check"] = check_result
        with open(REGISTRY_FILE, "w", encoding="utf-8") as f:
            json.dump(records, f, ensure_ascii=False, indent=2)

        results.append({
            "creator_name": record["creator_name"],
            "user_id": record["user_id"],
            "status": new_status,
            **check_result,
        })

        await asyncio.sleep(1)

    print(f"\n{'='*60}")
    print("验证完成")
    print(f"{'='*60}")
    for r in results:
        icon = "✓" if r["verified"] else "×"
        print(f"  {icon} {r['creator_name']}: {r['status']} — {r['reason']}")

    return results

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="XHS Creator Identity Validator")
    parser.add_argument("--status", nargs="+",
                        default=["candidate"],
                        help="目标状态（默认: candidate）")
    args = parser.parse_args()
    asyncio.run(run_validation(target_statuses=args.status))
