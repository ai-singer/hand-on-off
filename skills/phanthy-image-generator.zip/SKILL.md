---
name: phanthy-image-generator
description: Generate structured image sets for content posts using a Gemini image API. Implements Series Binding Protocol to produce 5 thematically consistent images per post (cover/mechanism/case/data/quote roles). Use when you need to generate a full 5-image series for a post, bind them to a visual series identity, validate role uniqueness and content requirements before upload.
---

# Phanthy Image Generator

Generates a bound series of 5 images per post using the Gemini image API, enforcing role uniqueness, visual consistency, and pre-upload validation.

## Prerequisites

Discover the Gemini image model config at startup:

```python
import json, re, os
config = json.load(open(os.path.expanduser('~/.openclaw/openclaw.json')))
providers = config.get('models', {}).get('providers', {})
results = []
for pname, pcfg in providers.items():
    if pcfg.get('api') != 'google-generative-ai':
        continue
    for m in pcfg.get('models', []):
        mid = m.get('id', '')
        if 'image' in m.get('input', []) or re.search(r'image', mid, re.IGNORECASE):
            results.append({'provider': pname, 'apiKey': pcfg['apiKey'],
                            'baseUrl': pcfg['baseUrl'], 'modelId': mid})
print(json.dumps(results, indent=2))
```

If no results: stop and inform the user. Use the first result automatically if only one exists.

## Step 1 — Series Binding (once per post, before any image is generated)

Generate and record the series binding parameters. See `references/series-binding-protocol.md` for the full protocol including template mappings and prompt format.

Required parameters:
```yaml
series_id: <post title first 6 chars>_<UTC timestamp last 4 digits>
visual_template: Template 0X        # see references/series-binding-protocol.md
accent_color: "#XXXXXX"            # single accent color, all 5 images
bg_color: "#XXXXXX"               # single background color, all 5 images
font_weight: bold | regular
series_label: "<theme> series"
```

## Step 2 — Generate 5 Images Sequentially (never parallel)

Generate images in fixed role order. See `references/series-binding-protocol.md` for role requirements and prompt structure.

| Index | Role      | Key constraint |
|-------|-----------|----------------|
| 1     | cover     | Question/hook only — no answer text |
| 2     | mechanism | Must include arrows or hierarchy structure |
| 3     | case      | Must include specific numbers or org names |
| 4     | data      | Must include numeric comparison or timeline |
| 5     | quote     | ≤ 2 sentences, pure text, max visual contrast |

Use `scripts/generate_image.py` for each image. Pass the series binding params and role-specific prompt content.

**Retry policy**: On empty response, timeout, or JSON parse failure — retry every 15s indefinitely. Exception: if the API returns `IMAGE_SAFETY` or `IMAGE_OTHER`, rewrite the prompt with more neutral language and retry once.

## Step 3 — Post-Generation Validation

After all 5 images are generated, run `scripts/validate_series.py` before proceeding to upload.

Any failed check requires regenerating only the failing image (not the full series).

**Never allow upload with fewer than 5 images.**

## Step 4 — Output

Return: list of 5 local file paths, series_id, and validation result. These are ready for the caller's upload flow.
