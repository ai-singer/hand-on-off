# Series Binding Protocol v1.0

## Visual Template Selection

Map your post's content type to a visual template before generating any images:

| Content Type | Visual Template | Recommended Color Scheme |
|---|---|---|
| Contrast/anti-intuition | Template 03 (Minimal Quote Card) or Template 01 (Comparison Chart) | Dark (black/deep blue) |
| Analogy/mechanism explanation | Template 01 (Comparison Chart) | Blue tones |
| Case stacking | Template 02 (Case Card Flow) | Warm (orange/yellow) |
| Finance explainer / plain language | Template 04 (Finance Diagram) | Green/red/gray tricolor |
| Roundup/reveal | Template 05 (Collage Grid) | Dark tones |

## Series Binding Parameters

Once template is selected, lock the following for all 5 images (no variation allowed):

```yaml
series_id: <post title first 6 chars>_<UTC timestamp last 4 digits>
# Example: 平台被罚35亿_8e17

visual_template: Template 0X
accent_color: "#XXXXXX"     # single hex, e.g. "#1A73E8"
bg_color: "#XXXXXX"         # single hex, e.g. "#0D1B2A"
font_weight: bold            # or regular
series_label: "<theme> series"
```

## Role Definitions and Requirements

| Image | Role | Must Include | Must Exclude |
|---|---|---|---|
| 1 (cover) | Hook | Title + core conflict/question | Any answer or resolution text |
| 2 (mechanism) | Root cause | Arrows or hierarchical structure | Duplicate text blocks |
| 3 (case) | Reality anchor | Specific numbers or org names | Info already in image 2 |
| 4 (data/extension) | Deep support | Numeric comparison or timeline | Info already in images 2–3 |
| 5 (quote/close) | Insight | ≤ 2 sentences, text-dominant | Visual repetition of prior images |

## Prompt Structure per Image

Each image prompt **must** open with the tracking comment block (this is internal metadata; it must NOT be rendered as visible text in the image output):

```
[Agent tracking only — do not render in image] series_id={series_id} | Image {N}/5 | Role={role} | Accent={accent_color} | BG={bg_color}

[This image's content]
{role-specific prompt content here}

[Series consistency constraint]
Use accent color {accent_color} and background color {bg_color} uniformly.
Font weight: {font_weight} throughout.
Do not reproduce any text blocks or layout structure from Image {N-1}.
The image MUST NOT display any metadata text including: series_id, "Image N/5", series labels, or any bottom annotations.
No series/episode labels anywhere in the image.
```

## Validation Checklist (run after all 5 images generated)

```
□ All 5 images have distinct roles (no duplicate roles)
□ Image 1 (cover): no answer text visible
□ Image 2 (mechanism): contains arrows or hierarchy structure description
□ Image 3 (case): contains specific number or org name
□ Image 4 (data): contains numeric comparison or timeline
□ Image 5 (quote): text ≤ 2 sentences
□ All 5 prompts opened with series_id tracking block
□ All 5 images use the same accent_color and bg_color
```

Any failure → regenerate that image only; do not reset others.

## Standard Image Dimensions (portrait/square formats)

| Use | Dimensions | Ratio |
|-----|-----------|-------|
| Cover/single | 1080×1350 | 4:5 |
| Square | 1080×1080 | 1:1 |
| Long | 1080×1920 | 9:16 |
| Landscape | 1080×608 | 16:9 |
