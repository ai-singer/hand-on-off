#!/usr/bin/env python3
"""
generate_image.py — Generate a single image via the Gemini image API.

Usage:
    python3 generate_image.py \
        --base-url <BASEURL> \
        --model-id <MODEL_ID> \
        --api-key <APIKEY> \
        --prompt-file <path_to_prompt.txt> \
        --output <output_path.jpg> \
        [--aspect-ratio 4:5] \
        [--image-size 1K]

Exit codes:
    0   Image saved successfully
    1   API error (message printed to stderr)
    2   Safety rejection (IMAGE_SAFETY or IMAGE_OTHER — caller should rewrite prompt)
    3   Empty response / no image in response
"""

import argparse
import base64
import json
import os
import subprocess
import sys
import tempfile
import time

VALID_ASPECT_RATIOS = {"1:1", "16:9", "9:16", "4:3", "3:4", "2:3", "3:2",
                       "4:1", "1:4", "5:4", "21:9", "4:5"}
VALID_IMAGE_SIZES = {"512", "1K", "2K", "4K"}


def parse_args():
    p = argparse.ArgumentParser(description="Generate a single image via Gemini image API")
    p.add_argument("--base-url", required=True)
    p.add_argument("--model-id", required=True)
    p.add_argument("--api-key", required=True)
    p.add_argument("--prompt-file", required=True, help="Path to plain-text prompt file")
    p.add_argument("--output", required=True, help="Output image path (.jpg or .png)")
    p.add_argument("--aspect-ratio", default="4:5")
    p.add_argument("--image-size", default="1K")
    p.add_argument("--max-retries", type=int, default=0,
                   help="Max retries on transient failure (0 = infinite)")
    p.add_argument("--retry-delay", type=int, default=15,
                   help="Seconds between retries")
    return p.parse_args()


def build_request_body(prompt: str, aspect_ratio: str, image_size: str) -> dict:
    return {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "responseModalities": ["TEXT", "IMAGE"],
            "imageConfig": {
                "aspectRatio": aspect_ratio,
                "imageSize": image_size,
            },
        },
    }


def call_api(base_url: str, model_id: str, api_key: str, body: dict) -> dict:
    """Call the API and return parsed JSON. Raises RuntimeError on curl failure."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as bf:
        json.dump(body, bf)
        body_path = bf.name

    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as rf:
        resp_path = rf.name

    try:
        url = f"{base_url.rstrip('/')}/models/{model_id}:generateContent"
        result = subprocess.run(
            [
                "curl", "-s", "--max-time", "180",
                "-X", "POST", url,
                "-H", f"x-goog-api-key: {api_key}",
                "-H", "Content-Type: application/json",
                "-d", f"@{body_path}",
                "-o", resp_path,
            ],
            capture_output=True, text=True
        )
        if result.returncode != 0:
            raise RuntimeError(f"curl failed (code {result.returncode}): {result.stderr}")

        with open(resp_path) as f:
            text = f.read().strip()
        if not text:
            raise RuntimeError("Empty response from API")
        return json.loads(text)
    finally:
        for p in (body_path, resp_path):
            try:
                os.unlink(p)
            except OSError:
                pass


def extract_image(response: dict) -> tuple[bytes, str]:
    """
    Extract image bytes and mime type from a Gemini generateContent response.
    Returns (image_bytes, mime_type) or raises ValueError.
    """
    if "error" in response:
        msg = response["error"].get("message", str(response["error"]))
        raise ValueError(f"API error: {msg}")

    candidates = response.get("candidates", [])
    if not candidates:
        raise ValueError("No candidates in response")

    parts = candidates[0].get("content", {}).get("parts", [])
    for part in parts:
        inline = part.get("inlineData") or part.get("inline_data")
        if inline:
            data = base64.b64decode(inline["data"])
            mime = inline.get("mimeType") or inline.get("mime_type", "image/png")
            return data, mime

    # Print any text notes
    for part in parts:
        if part.get("text"):
            print(f"[model note] {part['text']}", file=sys.stderr)

    raise ValueError("No image data in response")


def is_safety_rejection(response: dict) -> bool:
    """Return True if the response is a content-policy rejection."""
    raw = json.dumps(response).upper()
    return "IMAGE_SAFETY" in raw or "IMAGE_OTHER" in raw


def main():
    args = parse_args()

    if args.aspect_ratio not in VALID_ASPECT_RATIOS:
        print(f"Invalid aspect ratio: {args.aspect_ratio}", file=sys.stderr)
        sys.exit(1)
    if args.image_size not in VALID_IMAGE_SIZES:
        print(f"Invalid image size: {args.image_size}", file=sys.stderr)
        sys.exit(1)

    with open(args.prompt_file) as f:
        prompt = f.read()

    body = build_request_body(prompt, args.aspect_ratio, args.image_size)

    attempt = 0
    while True:
        attempt += 1
        try:
            response = call_api(args.base_url, args.model_id, args.api_key, body)
        except (RuntimeError, json.JSONDecodeError) as e:
            print(f"[attempt {attempt}] Transient error: {e}", file=sys.stderr)
            if args.max_retries and attempt >= args.max_retries:
                print("Max retries reached.", file=sys.stderr)
                sys.exit(1)
            time.sleep(args.retry_delay)
            continue

        if is_safety_rejection(response):
            print("[safety] Content rejected by API.", file=sys.stderr)
            sys.exit(2)

        try:
            image_data, mime_type = extract_image(response)
        except ValueError as e:
            print(f"[attempt {attempt}] {e}", file=sys.stderr)
            if args.max_retries and attempt >= args.max_retries:
                sys.exit(3)
            time.sleep(args.retry_delay)
            continue

        # Save image
        ext = "jpg" if "jpeg" in mime_type.lower() else "png"
        out_path = args.output
        if not out_path.endswith(f".{ext}"):
            # Append correct extension if needed
            out_path = os.path.splitext(out_path)[0] + f".{ext}"

        os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
        with open(out_path, "wb") as f:
            f.write(image_data)

        print(f"saved: {out_path}")
        sys.exit(0)


if __name__ == "__main__":
    main()
