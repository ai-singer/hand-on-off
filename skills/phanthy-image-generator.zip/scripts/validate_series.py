#!/usr/bin/env python3
"""
validate_series.py — Validate a 5-image series before upload.

Usage:
    python3 validate_series.py \
        --series-id <series_id> \
        --images img1.jpg img2.jpg img3.jpg img4.jpg img5.jpg \
        --prompts p1.txt p2.txt p3.txt p4.txt p5.txt \
        --accent-color "#1A73E8" \
        --bg-color "#0D1B2A"

Exit codes:
    0   All checks passed
    1   One or more checks failed (details printed to stdout)

Output (JSON):
    {
        "passed": true | false,
        "checks": [
            {"id": "count", "passed": true, "detail": "5 images provided"},
            ...
        ],
        "failures": [...]
    }
"""

import argparse
import json
import os
import re
import sys


ROLES = ["cover", "mechanism", "case", "data", "quote"]

ROLE_REQUIREMENTS = {
    "cover":     {"must_not_contain": ["answer", "conclusion", "result", "therefore", "so "],
                  "description": "cover: question/hook only, no answer text"},
    "mechanism": {"must_contain_pattern": r"arrow|→|→|hierarchy|flow|step|→|layer|level|structure",
                  "description": "mechanism: must describe arrows or hierarchy"},
    "case":      {"must_contain_pattern": r"\d+[%亿万千百]?|\d+\.\d+|[A-Z][a-z]+ (Corp|Inc|Ltd|Bank|Fund)|[A-Z]{2,}",
                  "description": "case: must include specific numbers or org names"},
    "data":      {"must_contain_pattern": r"\d{4}|\d+%|\d+ vs |\d+x|timeline|compare|contrast|\d+[亿万]",
                  "description": "data: must include numeric comparison or timeline"},
    "quote":     {"max_sentences": 2,
                  "description": "quote: ≤ 2 sentences"},
}


def parse_args():
    p = argparse.ArgumentParser(description="Validate a 5-image post series")
    p.add_argument("--series-id", required=True)
    p.add_argument("--images", nargs=5, metavar="IMG", required=True,
                   help="5 image file paths in order: cover mechanism case data quote")
    p.add_argument("--prompts", nargs=5, metavar="PROMPT", required=True,
                   help="5 prompt text files in matching order")
    p.add_argument("--accent-color", required=True)
    p.add_argument("--bg-color", required=True)
    return p.parse_args()


def count_sentences(text: str) -> int:
    # Simple sentence counter: split on . ! ? followed by whitespace or end
    sentences = re.split(r'[.!?。！？]+\s*', text.strip())
    return len([s for s in sentences if s.strip()])


def check_prompt_has_series_id(prompt_text: str, series_id: str) -> bool:
    return series_id in prompt_text


def check_prompt_has_role_content(prompt_text: str, role: str) -> tuple[bool, str]:
    req = ROLE_REQUIREMENTS.get(role, {})

    if "must_contain_pattern" in req:
        if not re.search(req["must_contain_pattern"], prompt_text, re.IGNORECASE):
            return False, f"Prompt does not satisfy: {req['description']}"

    if "max_sentences" in req:
        # For quote role, check the actual content lines (skip tracking comment block)
        content_lines = [l for l in prompt_text.splitlines()
                         if not l.startswith("[Agent tracking") and
                         not l.startswith("[Series consistency") and
                         l.strip()]
        content_text = " ".join(content_lines)
        n = count_sentences(content_text)
        if n > req["max_sentences"]:
            return False, f"Quote prompt has {n} sentences (max {req['max_sentences']})"

    return True, "ok"


def validate(args) -> dict:
    checks = []
    failures = []

    def add_check(id_, passed, detail):
        checks.append({"id": id_, "passed": passed, "detail": detail})
        if not passed:
            failures.append({"id": id_, "detail": detail})

    # 1. File existence
    for i, (img_path, role) in enumerate(zip(args.images, ROLES), 1):
        exists = os.path.isfile(img_path)
        add_check(f"file_exists_{i}_{role}", exists,
                  f"Image {i} ({role}): {'found' if exists else 'NOT FOUND'} at {img_path}")

    # 2. Count
    existing = [p for p in args.images if os.path.isfile(p)]
    add_check("count", len(existing) == 5,
              f"{len(existing)}/5 image files exist")

    # 3. Series ID in each prompt
    for i, (prompt_path, role) in enumerate(zip(args.prompts, ROLES), 1):
        if not os.path.isfile(prompt_path):
            add_check(f"series_id_{i}_{role}", False,
                      f"Prompt file {i} not found: {prompt_path}")
            continue
        text = open(prompt_path).read()
        ok = check_prompt_has_series_id(text, args.series_id)
        add_check(f"series_id_{i}_{role}", ok,
                  f"Image {i} ({role}) prompt {'contains' if ok else 'MISSING'} series_id")

    # 4. Role content requirements
    for i, (prompt_path, role) in enumerate(zip(args.prompts, ROLES), 1):
        if not os.path.isfile(prompt_path):
            continue
        text = open(prompt_path).read()
        ok, detail = check_prompt_has_role_content(text, role)
        add_check(f"role_content_{i}_{role}", ok,
                  f"Image {i} ({role}): {'ok' if ok else detail}")

    # 5. Color consistency — check prompts mention the same accent/bg colors
    for i, (prompt_path, role) in enumerate(zip(args.prompts, ROLES), 1):
        if not os.path.isfile(prompt_path):
            continue
        text = open(prompt_path).read()
        accent_ok = args.accent_color.lower() in text.lower()
        bg_ok = args.bg_color.lower() in text.lower()
        add_check(f"colors_{i}_{role}", accent_ok and bg_ok,
                  f"Image {i} ({role}) prompt {'has' if (accent_ok and bg_ok) else 'MISSING'} "
                  f"accent/bg color references")

    result = {
        "passed": len(failures) == 0,
        "series_id": args.series_id,
        "checks": checks,
        "failures": failures,
    }
    return result


def main():
    args = parse_args()
    result = validate(args)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    sys.exit(0 if result["passed"] else 1)


if __name__ == "__main__":
    main()
