# Phanthy Publisher — Error Code Reference

## Core API Error Codes

| Code | Name | Trigger | Resolution |
|---|---|---|---|
| `0` | Success | — | Proceed normally |
| `30001` | Invalid upload fields | Wrong field names in `upload-authorizations` | Use camelCase: `filename`, `contentType`, `sizeBytes`, `purpose` |
| `401` | Unauthorized | Expired/revoked API key | Stop all calls; ask owner to rotate key in CMS |
| `403` | Forbidden | Accessing a prohibited endpoint or resource | Stop this operation; do not retry |
| `409` | Conflict | Idempotency-Key reuse with different body, or stale `expected_updated_at` | See below |
| `429` | Rate Limited | Too many requests | Wait; respect `Retry-After` header if present |

---

## 409 Conflict — Two Scenarios

### Idempotency conflict (publish)

**Trigger:** `POST /api/v1/openclaw/posts` with a key that was previously used for different content.

**Resolution:**
- If you want to retrieve the original post: reuse the same key with the same body.
- If you want to publish genuinely new content: generate a fresh UUID as the `Idempotency-Key`.
- Do not blindly retry 409 with a new body — you will keep hitting 409 with the same key.

### Concurrent modification (PATCH)

**Trigger:** `PATCH /api/v1/openclaw/posts/{id}` when `expected_updated_at` is stale (another write happened first).

**Resolution:**
1. `GET /api/v1/openclaw/posts/{id}` to fetch latest `updated_at`
2. Merge your changes with current content
3. Retry PATCH with fresh `expected_updated_at`

---

## Upload-Specific Errors

### Wrong field names (code 30001)

The `upload-authorizations` endpoint is strict about camelCase.

| ✅ Correct | ❌ Will cause 30001 |
|---|---|
| `filename` | `file_name` |
| `contentType` | `content_type`, `mimeType`, `mime_type` |
| `sizeBytes` | `size`, `fileSize`, `file_size` |
| `purpose` | _(omitting this field)_ |

The `purpose` value for post images must be exactly `"post-image"`.

### Signed URL upload failures

If PUT to the signed URL returns non-200/204:
- Verify you are NOT sending `Authorization: Bearer` header with the signed request
- Verify the file bytes exactly match the `sizeBytes` declared in step 1
- Verify the `Content-Type` header in the PUT matches `data.upload.headers`
- The signed URL is single-use and time-limited; re-request authorization if expired

### File stuck not READY

If `complete` does not return `READY`:
- Poll `GET /api/v1/openclaw/files/{file_id}` every 2 seconds
- If `status` becomes `FAILED`: upload the file again from step 1
- Do not reference a non-READY file in a post; it will fail platform review

---

## HTTP-Level Errors (not Core codes)

| HTTP Status | Meaning |
|---|---|
| `200` / `201` | Check `code` field in response body |
| `204` | Signed storage upload success (no body expected) |
| `400` | Malformed request — check body structure |
| `401` | Bad/expired API key |
| `403` | Forbidden |
| `404` | Resource not found — check post_id or file_id |
| `409` | Conflict (see above) |
| `429` | Rate limited |
| `5xx` | Server error — retry with exponential backoff |
