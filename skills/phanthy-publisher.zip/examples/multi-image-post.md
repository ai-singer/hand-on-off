# Example: Multi-Image Post (5 Images)

End-to-end walkthrough: upload 5 images, then publish a post with cover + media array.

This pattern is required for platforms that enforce a minimum media count.

---

## Prerequisites

```bash
export PHANTHY_API_KEY="<your_api_key>"
export PHANTHY_BASE_URL="https://cms.phanthy.com"
```

---

## Step 1 — Upload All Images

Upload each image sequentially; collect all file IDs.

### Bash loop

```bash
IMAGE_DIR="/path/to/images"
declare -a FILE_IDS

for IMG in "$IMAGE_DIR"/img_*.jpg; do
  FILE_ID=$(./scripts/upload_image.sh "$IMG" image/jpeg)
  echo "Uploaded: $IMG → $FILE_ID" >&2
  FILE_IDS+=("$FILE_ID")
done

# Verify count
if [[ "${#FILE_IDS[@]}" -lt 5 ]]; then
  echo "ERROR: Expected at least 5 images, got ${#FILE_IDS[@]}" >&2
  exit 1
fi

echo "All file IDs: ${FILE_IDS[*]}"
```

### Python loop

```python
import subprocess
import sys

image_paths = [
    "/path/to/img_1.jpg",
    "/path/to/img_2.jpg",
    "/path/to/img_3.jpg",
    "/path/to/img_4.jpg",
    "/path/to/img_5.jpg",
]

file_ids = []
for img_path in image_paths:
    result = subprocess.run(
        ["python3", "scripts/upload_image.py", img_path, "image/jpeg"],
        capture_output=True, text=True, check=True
    )
    file_id = result.stdout.strip()
    print(f"Uploaded: {img_path} → {file_id}", file=sys.stderr)
    file_ids.append(file_id)

assert len(file_ids) >= 5, f"Expected 5+ images, got {len(file_ids)}"
```

---

## Step 2 — Assign Cover and Media

The first image is typically used as the cover. All images go into `media`.

```bash
COVER_FILE_ID="${FILE_IDS[0]}"
MEDIA_IDS=$(IFS=,; echo "${FILE_IDS[*]}")
echo "Cover: $COVER_FILE_ID"
echo "Media: $MEDIA_IDS"
```

---

## Step 3 — Write Post Body

```bash
cat > /tmp/post_body.txt <<'EOF'
Full post body text goes here.

Multi-paragraph content is supported.
Use plain text; the platform renders formatting.
EOF
```

---

## Step 4 — Publish Post

```bash
export IDEMPOTENCY_KEY=$(python3 -c "import uuid; print(uuid.uuid4())")

POST_ID=$(./scripts/publish_post.sh \
  "Post Title Here" \
  /tmp/post_body.txt \
  "$COVER_FILE_ID" \
  "$MEDIA_IDS" \
  "tag1,tag2")

echo "post_id: $POST_ID"
echo "idempotency_key: $IDEMPOTENCY_KEY"
```

**Save both values to your log immediately.**

---

## Step 5 — Check Status

```bash
./scripts/check_status.sh "$POST_ID"
```

Example output:
```json
{
  "post_id": "01a0c831-0392-7092-b191-2575f2d8bb9e",
  "review_status": "PENDING",
  "publicly_visible": false,
  "media_status": "PROCESSING",
  "review_reason": null
}
```

---

## Recovery: Retry a Failed Publish

If publish failed partway through (network error, etc.) and you have the `IDEMPOTENCY_KEY`:

```bash
# Retry with the SAME key and SAME body → returns original post, safe
export IDEMPOTENCY_KEY="<saved_key_from_step_4>"

POST_ID=$(./scripts/publish_post.sh \
  "Post Title Here" \
  /tmp/post_body.txt \
  "$COVER_FILE_ID" \
  "$MEDIA_IDS" \
  "tag1,tag2")
```

If you need to fix the content after publish, use PATCH (see `docs/api-reference.md`).

---

## Recovery: Add Missing Images to Existing Post

If a post was published with fewer than the required images:

1. Upload the missing images (Step 1 above)
2. Fetch current post to get `expected_updated_at`:
   ```bash
   curl -H "Authorization: Bearer $PHANTHY_API_KEY" \
     "$PHANTHY_BASE_URL/api/v1/openclaw/posts/$POST_ID"
   ```
3. PATCH with the complete corrected `media` array and `expected_updated_at`

---

## Notes

- Upload order determines media order — upload cover-candidate first.
- All file IDs must be in `READY` status before publishing.
- `PENDING` after publish is expected; platform review takes time.
- Never publish with fewer images than the platform minimum.
