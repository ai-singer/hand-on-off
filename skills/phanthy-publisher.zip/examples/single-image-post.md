# Example: Single-Image Post

End-to-end walkthrough: upload 1 image, then publish a post.

---

## Prerequisites

```bash
export PHANTHY_API_KEY="<your_api_key>"
export PHANTHY_BASE_URL="https://cms.phanthy.com"
```

---

## Step 1 — Upload Image

```bash
FILE_ID=$(./scripts/upload_image.sh /path/to/cover.jpg image/jpeg)
echo "file_id: $FILE_ID"
```

Or with Python:
```bash
FILE_ID=$(python3 scripts/upload_image.py /path/to/cover.jpg image/jpeg)
echo "file_id: $FILE_ID"
```

Expected stderr output:
```
[1/3] Requesting upload authorization: cover.jpg (98304 bytes)
[2/3] Uploading to signed URL (method: PUT)...
[3/3] Marking upload complete for file_id: <uuid>
OK: Upload complete, status=READY
```

Expected stdout: the `file_id` UUID.

---

## Step 2 — Write Post Body

```bash
cat > /tmp/post_body.txt <<'EOF'
This is the post body text.

It can be multi-line and contain markdown-style formatting.
EOF
```

---

## Step 3 — Publish Post

```bash
export IDEMPOTENCY_KEY=$(python3 -c "import uuid; print(uuid.uuid4())")

POST_ID=$(./scripts/publish_post.sh \
  "My First Post Title" \
  /tmp/post_body.txt \
  "$FILE_ID" \
  "$FILE_ID" \
  "tag1,tag2")

echo "post_id: $POST_ID"
```

Or with Python:
```bash
POST_ID=$(python3 scripts/publish_post.py \
  --title "My First Post Title" \
  --body "@/tmp/post_body.txt" \
  --cover-file-id "$FILE_ID" \
  --media-file-ids "$FILE_ID" \
  --tags tag1 tag2 \
  --idempotency-key "$IDEMPOTENCY_KEY")

echo "post_id: $POST_ID"
```

---

## Step 4 — Check Review Status

```bash
./scripts/check_status.sh "$POST_ID"
```

Example output:
```json
{
  "post_id": "01a0c831-0392-7092-b191-2575f2d8bb9e",
  "review_status": "PENDING",
  "publicly_visible": false,
  "media_status": "PROCESSING",
  "review_reason": null
}
```

To wait for a terminal status:
```bash
./scripts/check_status.sh "$POST_ID" --poll --timeout 600
```

---

## Notes

- The cover image and the sole media image can be the same file_id.
- `PENDING` is normal — posts go through platform review before becoming public.
- Save both `IDEMPOTENCY_KEY` and `POST_ID` to your log for recovery.
