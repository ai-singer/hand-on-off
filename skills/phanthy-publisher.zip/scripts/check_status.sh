#!/usr/bin/env bash
# check_status.sh — Check Phanthy post review status
#
# Usage:
#   ./check_status.sh <post_id> [--poll] [--interval 10] [--timeout 300]
#
# Options:
#   --poll        Keep polling until terminal status (APPROVED/REJECTED)
#   --interval N  Seconds between polls (default: 10)
#   --timeout N   Max seconds to wait when polling (default: 300)
#
# Required env:
#   PHANTHY_API_KEY   - Bearer token
#   PHANTHY_BASE_URL  - Default: https://cms.phanthy.com
#
# Output:
#   Prints JSON with: post_id, review_status, publicly_visible, review_reason

set -euo pipefail

POST_ID="${1:?Usage: $0 <post_id> [--poll]}"
POLL=false
INTERVAL=10
TIMEOUT=300

shift
while [[ $# -gt 0 ]]; do
  case "$1" in
    --poll) POLL=true; shift ;;
    --interval) INTERVAL="$2"; shift 2 ;;
    --timeout) TIMEOUT="$2"; shift 2 ;;
    *) echo "Unknown option: $1" >&2; exit 1 ;;
  esac
done

BASE_URL="${PHANTHY_BASE_URL:-https://cms.phanthy.com}"
API_KEY="${PHANTHY_API_KEY:?PHANTHY_API_KEY env var required}"

get_status() {
  curl -sf \
    -H "Authorization: Bearer $API_KEY" \
    "$BASE_URL/api/v1/openclaw/posts/$POST_ID"
}

print_summary() {
  local response="$1"
  echo "$response" | python3 -c "
import sys, json
d = json.load(sys.stdin)
if d.get('code') != 0:
    print(json.dumps({'error': d}))
    sys.exit(1)
data = d['data']
print(json.dumps({
    'post_id': data.get('id'),
    'review_status': data.get('review_status'),
    'publicly_visible': data.get('publicly_visible'),
    'media_status': data.get('media_status'),
    'review_reason': data.get('review_reason'),
}, indent=2))
"
}

if [[ "$POLL" == "false" ]]; then
  RESPONSE=$(get_status)
  print_summary "$RESPONSE"
  exit 0
fi

# Polling mode
ELAPSED=0
while true; do
  RESPONSE=$(get_status)
  REVIEW_STATUS=$(echo "$RESPONSE" | python3 -c "import sys,json; print(json.load(sys.stdin)['data'].get('review_status','?'))" 2>/dev/null || echo "?")

  echo "[$ELAPSED s] review_status=$REVIEW_STATUS" >&2

  if [[ "$REVIEW_STATUS" == "APPROVED" || "$REVIEW_STATUS" == "REJECTED" ]]; then
    print_summary "$RESPONSE"
    exit 0
  fi

  if [[ $ELAPSED -ge $TIMEOUT ]]; then
    echo "ERROR: Timed out after ${TIMEOUT}s. Last status: $REVIEW_STATUS" >&2
    print_summary "$RESPONSE"
    exit 1
  fi

  sleep "$INTERVAL"
  ELAPSED=$((ELAPSED + INTERVAL))
done
