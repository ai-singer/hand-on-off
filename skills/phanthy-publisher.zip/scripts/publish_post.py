#!/usr/bin/env python3
"""
publish_post.py — Publish a post to Phanthy CMS

Usage:
    python3 publish_post.py \\
        --title "Post title" \\
        --body "Post body text or @path/to/file.txt" \\
        --cover-file-id <uuid> \\
        --media-file-ids <uuid1> <uuid2> ... \\
        [--tags tag1 tag2] \\
        [--idempotency-key <uuid>]

Required env:
    PHANTHY_API_KEY   - Bearer token
    PHANTHY_BASE_URL  - Default: https://cms.phanthy.com

Output:
    Prints post_id to stdout on success.
    Exits non-zero on error.

Notes:
    - Body field must be "body" (not "content")
    - Cover must be a file UUID (not a URL)
    - Idempotency-Key is auto-generated if omitted; persist it for safe retries
    - Same key + same body = safe retry; same key + different body = 409
"""

import argparse
import json
import os
import sys
import uuid as uuid_mod
from pathlib import Path

try:
    import urllib.request as urllib_request
    import urllib.error as urllib_error
except ImportError:
    print("ERROR: urllib not available", file=sys.stderr)
    sys.exit(1)

BASE_URL = os.environ.get("PHANTHY_BASE_URL", "https://cms.phanthy.com").rstrip("/")
API_KEY = os.environ.get("PHANTHY_API_KEY", "")


def die(msg):
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


def api_post(path, body, idempotency_key=None):
    """POST to Phanthy API with Bearer auth and optional idempotency key."""
    url = BASE_URL + path
    data = json.dumps(body).encode()
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
    }
    if idempotency_key:
        headers["Idempotency-Key"] = idempotency_key

    req = urllib_request.Request(url, data=data, headers=headers, method="POST")
    try:
        with urllib_request.urlopen(req) as resp:
            return json.loads(resp.read()), resp.status
    except urllib_error.HTTPError as e:
        body_text = e.read().decode(errors="replace")
        # 409 is a handled state, not a crash
        if e.code == 409:
            return json.loads(body_text) if body_text else {"code": 409}, 409
        die(f"HTTP {e.code} on POST {path}: {body_text}")


def publish_post(title, body_text, cover_file_id, media_file_ids, tags=None, idempotency_key=None):
    if not idempotency_key:
        idempotency_key = str(uuid_mod.uuid4())
        print(f"INFO: Generated Idempotency-Key: {idempotency_key}", file=sys.stderr)

    tags = tags or []
    media = [{"file_id": fid} for fid in media_file_ids]

    print(f"INFO: Publishing post with {len(media)} media file(s)", file=sys.stderr)
    print(f"INFO: Cover file_id: {cover_file_id}", file=sys.stderr)
    print(f"INFO: Idempotency-Key: {idempotency_key}", file=sys.stderr)

    payload = {
        "title": title,
        "body": body_text,          # Field is "body", NOT "content"
        "tags": tags,
        "cover_file_id": cover_file_id,  # UUID, NOT a URL
        "media": media,
    }

    resp, http_status = api_post(
        "/api/v1/openclaw/posts",
        payload,
        idempotency_key=idempotency_key,
    )

    code = resp.get("code")

    if code == 0:
        post_id = resp["data"]["id"]
        review_status = resp["data"].get("review_status", "?")
        print(f"OK: Post published. post_id={post_id} review_status={review_status}", file=sys.stderr)
        return post_id

    elif http_status == 409 or code == 409:
        die(
            "409 Conflict: Idempotency-Key already used with different content.\n"
            "  To retrieve original post: use same key + same body.\n"
            "  To publish new version: generate a new Idempotency-Key."
        )

    else:
        die(f"Publish failed (code={code}): {resp}")


def resolve_body(body_arg):
    """If body starts with @, read from file path."""
    if body_arg.startswith("@"):
        file_path = Path(body_arg[1:])
        if not file_path.exists():
            die(f"Body file not found: {file_path}")
        return file_path.read_text(encoding="utf-8")
    return body_arg


if __name__ == "__main__":
    if not API_KEY:
        die("PHANTHY_API_KEY environment variable is required")

    parser = argparse.ArgumentParser(description="Publish a post to Phanthy CMS")
    parser.add_argument("--title", required=True, help="Post title")
    parser.add_argument(
        "--body",
        required=True,
        help='Post body text, or @path/to/file.txt to read from file',
    )
    parser.add_argument("--cover-file-id", required=True, help="READY file UUID for cover image")
    parser.add_argument(
        "--media-file-ids",
        required=True,
        nargs="+",
        help="READY file UUIDs for media (space-separated)",
    )
    parser.add_argument("--tags", nargs="*", default=[], help="Tags (space-separated)")
    parser.add_argument(
        "--idempotency-key",
        default=None,
        help="Stable UUID for this job (auto-generated if omitted)",
    )

    args = parser.parse_args()

    body_text = resolve_body(args.body)

    post_id = publish_post(
        title=args.title,
        body_text=body_text,
        cover_file_id=args.cover_file_id,
        media_file_ids=args.media_file_ids,
        tags=args.tags,
        idempotency_key=args.idempotency_key,
    )

    print(post_id)  # stdout: only the post_id
