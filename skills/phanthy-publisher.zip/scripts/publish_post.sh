#!/usr/bin/env bash
# publish_post.sh — Publish a post to Phanthy CMS
#
# Usage:
#   ./publish_post.sh <title> <body_file> <cover_file_id> <media_file_ids_comma_separated> [tags_comma_separated]
#
# Arguments:
#   title                    - Post title
#   body_file                - Path to plain text file containing post body
#   cover_file_id            - READY file UUID for the cover image
#   media_file_ids           - Comma-separated list of READY file UUIDs for media
#   tags                     - Optional comma-separated tags (default: empty)
#
# Required env:
#   PHANTHY_API_KEY   - Bearer token
#   PHANTHY_BASE_URL  - Default: https://cms.phanthy.com
#   IDEMPOTENCY_KEY   - Stable UUID for this publish job (auto-generated if not set)
#
# Output:
#   Prints post_id to stdout on success.
#   Exits non-zero on error.

set -euo pipefail

TITLE="${1:?Usage: $0 <title> <body_file> <cover_file_id> <media_ids_csv> [tags_csv]}"
BODY_FILE="${2:?body_file required}"
COVER_FILE_ID="${3:?cover_file_id required}"
MEDIA_CSV="${4:?media_file_ids required}"
TAGS_CSV="${5:-}"

BASE_URL="${PHANTHY_BASE_URL:-https://cms.phanthy.com}"
API_KEY="${PHANTHY_API_KEY:?PHANTHY_API_KEY env var required}"

# Generate idempotency key if not provided
if [[ -z "${IDEMPOTENCY_KEY:-}" ]]; then
  IDEMPOTENCY_KEY=$(python3 -c "import uuid; print(uuid.uuid4())")
  echo "INFO: Generated Idempotency-Key: $IDEMPOTENCY_KEY" >&2
fi

if [[ ! -f "$BODY_FILE" ]]; then
  echo "ERROR: body_file not found: $BODY_FILE" >&2
  exit 1
fi

BODY_TEXT=$(cat "$BODY_FILE")

# Build media array
MEDIA_JSON=$(echo "$MEDIA_CSV" | python3 -c "
import sys, json
ids = [x.strip() for x in sys.stdin.read().split(',') if x.strip()]
print(json.dumps([{'file_id': i} for i in ids]))
")

# Build tags array
TAGS_JSON=$(echo "$TAGS_CSV" | python3 -c "
import sys, json
raw = sys.stdin.read().strip()
if raw:
    tags = [t.strip() for t in raw.split(',') if t.strip()]
else:
    tags = []
print(json.dumps(tags))
")

MEDIA_COUNT=$(echo "$MEDIA_JSON" | python3 -c "import sys,json; print(len(json.load(sys.stdin)))")
echo "INFO: Publishing post with $MEDIA_COUNT media file(s)" >&2
echo "INFO: Cover: $COVER_FILE_ID" >&2
echo "INFO: Idempotency-Key: $IDEMPOTENCY_KEY" >&2

PAYLOAD=$(python3 -c "
import json, sys
title = sys.argv[1]
body = open(sys.argv[2]).read()
cover = sys.argv[3]
media = json.loads(sys.argv[4])
tags = json.loads(sys.argv[5])
print(json.dumps({
    'title': title,
    'body': body,
    'tags': tags,
    'cover_file_id': cover,
    'media': media
}))
" "$TITLE" "$BODY_FILE" "$COVER_FILE_ID" "$MEDIA_JSON" "$TAGS_JSON")

RESPONSE=$(curl -sf \
  -X POST \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -H "Idempotency-Key: $IDEMPOTENCY_KEY" \
  "$BASE_URL/api/v1/openclaw/posts" \
  -d "$PAYLOAD")

CODE=$(echo "$RESPONSE" | python3 -c "import sys,json; print(json.load(sys.stdin).get('code','?'))")

if [[ "$CODE" == "0" ]]; then
  POST_ID=$(echo "$RESPONSE" | python3 -c "import sys,json; print(json.load(sys.stdin)['data']['id'])")
  REVIEW_STATUS=$(echo "$RESPONSE" | python3 -c "import sys,json; print(json.load(sys.stdin)['data'].get('review_status','?'))")
  echo "OK: Post published. post_id=$POST_ID review_status=$REVIEW_STATUS" >&2
  echo "$POST_ID"
elif [[ "$CODE" == "409" ]]; then
  # Same idempotency key with different body — reload and inspect
  echo "ERROR: 409 Conflict — Idempotency-Key already used with different content." >&2
  echo "  Reuse the same key + same body to retrieve original, or use a new key." >&2
  exit 1
else
  echo "ERROR: Publish failed (code=$CODE): $RESPONSE" >&2
  exit 1
fi
