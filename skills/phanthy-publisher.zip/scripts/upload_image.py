#!/usr/bin/env python3
"""
upload_image.py — Phanthy CMS 3-step image upload

Usage:
    python3 upload_image.py <image_path> [content_type]

Required env:
    PHANTHY_API_KEY   - Bearer token
    PHANTHY_BASE_URL  - Default: https://cms.phanthy.com

Returns:
    Prints file_id to stdout on success.
    Exits non-zero on failure.

Flow:
    Step 1: POST /api/v1/openclaw/files/upload-authorizations
    Step 2: PUT bytes to signed URL (no Authorization header)
    Step 3: POST /api/v1/openclaw/files/{file_id}/complete
"""

import json
import os
import sys
import time
from pathlib import Path

try:
    import urllib.request as urllib_request
    import urllib.error as urllib_error
except ImportError:
    print("ERROR: urllib not available", file=sys.stderr)
    sys.exit(1)

BASE_URL = os.environ.get("PHANTHY_BASE_URL", "https://cms.phanthy.com").rstrip("/")
API_KEY = os.environ.get("PHANTHY_API_KEY", "")


def die(msg):
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


def api_call(method, path, body=None, extra_headers=None, base=None):
    """Call the Phanthy API with Bearer auth. Returns parsed JSON."""
    url = (base or BASE_URL) + path
    data = json.dumps(body).encode() if body is not None else None
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
    }
    if extra_headers:
        headers.update(extra_headers)
    req = urllib_request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib_request.urlopen(req) as resp:
            return json.loads(resp.read())
    except urllib_error.HTTPError as e:
        body_text = e.read().decode(errors="replace")
        die(f"HTTP {e.code} on {method} {path}: {body_text}")


def signed_put(url, file_bytes, headers):
    """PUT file bytes to signed URL. Must NOT include Authorization header."""
    req = urllib_request.Request(url, data=file_bytes, headers=headers, method="PUT")
    try:
        with urllib_request.urlopen(req) as resp:
            status = resp.status
    except urllib_error.HTTPError as e:
        die(f"Signed PUT failed HTTP {e.code}: {e.read().decode(errors='replace')}")
    if status not in (200, 204):
        die(f"Signed PUT returned unexpected status {status}")


def upload_image(image_path, content_type="image/jpeg"):
    path = Path(image_path)
    if not path.exists():
        die(f"File not found: {image_path}")

    file_bytes = path.read_bytes()
    size_bytes = len(file_bytes)
    filename = path.name

    print(f"[1/3] Requesting upload authorization: {filename} ({size_bytes} bytes)", file=sys.stderr)

    auth_resp = api_call(
        "POST",
        "/api/v1/openclaw/files/upload-authorizations",
        body={
            "filename": filename,
            "contentType": content_type,
            "sizeBytes": size_bytes,
            "purpose": "post-image",
        },
    )

    if auth_resp.get("code") != 0:
        die(f"upload-authorizations failed: {auth_resp}")

    file_id = auth_resp["data"]["file"]["id"]
    upload = auth_resp["data"]["upload"]
    upload_url = upload["url"]
    upload_method = upload.get("method", "PUT").upper()
    upload_headers = upload.get("headers", {})

    print(f"[2/3] Uploading to signed URL (method: {upload_method})...", file=sys.stderr)

    if upload_method == "PUT":
        signed_put(upload_url, file_bytes, upload_headers)
    else:
        die(f"Unsupported upload method: {upload_method}")

    print(f"[3/3] Completing upload for file_id: {file_id}", file=sys.stderr)

    complete_resp = api_call("POST", f"/api/v1/openclaw/files/{file_id}/complete")

    if complete_resp.get("code") != 0:
        die(f"complete failed: {complete_resp}")

    status = complete_resp["data"].get("status", "UNKNOWN")
    print(f"    Status after complete: {status}", file=sys.stderr)

    # Poll if not immediately READY
    if status != "READY":
        print("    Polling for READY status...", file=sys.stderr)
        for attempt in range(1, 11):
            time.sleep(2)
            poll_resp = api_call("GET", f"/api/v1/openclaw/files/{file_id}")
            status = poll_resp["data"].get("status", "UNKNOWN")
            print(f"    Poll {attempt}: status={status}", file=sys.stderr)
            if status == "READY":
                break
            if status == "FAILED":
                die("File processing failed")

    if status != "READY":
        die("File never reached READY status after polling")

    print(f"OK: Upload complete, status=READY, file_id={file_id}", file=sys.stderr)
    return file_id


if __name__ == "__main__":
    if not API_KEY:
        die("PHANTHY_API_KEY environment variable is required")
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <image_path> [content_type]", file=sys.stderr)
        sys.exit(1)

    img_path = sys.argv[1]
    ctype = sys.argv[2] if len(sys.argv) > 2 else "image/jpeg"

    file_id = upload_image(img_path, ctype)
    print(file_id)  # stdout: only the file_id
