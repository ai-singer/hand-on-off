#!/usr/bin/env bash
# upload_image.sh — Phanthy CMS 3-step image upload
# Usage: ./upload_image.sh <image_path> [content_type]
#
# Required env:
#   PHANTHY_API_KEY   - Bearer token
#   PHANTHY_BASE_URL  - Default: https://cms.phanthy.com
#
# Output: prints file_id on success, exits non-zero on error.
#
# Step 1: POST upload-authorizations
# Step 2: PUT bytes to signed URL (no Authorization header)
# Step 3: POST complete — check for READY status

set -euo pipefail

IMAGE_PATH="${1:?Usage: $0 <image_path> [content_type]}"
CONTENT_TYPE="${2:-image/jpeg}"
BASE_URL="${PHANTHY_BASE_URL:-https://cms.phanthy.com}"
API_KEY="${PHANTHY_API_KEY:?PHANTHY_API_KEY env var required}"

if [[ ! -f "$IMAGE_PATH" ]]; then
  echo "ERROR: File not found: $IMAGE_PATH" >&2
  exit 1
fi

FILENAME=$(basename "$IMAGE_PATH")
SIZE_BYTES=$(stat -c%s "$IMAGE_PATH" 2>/dev/null || stat -f%z "$IMAGE_PATH")

echo "[1/3] Requesting upload authorization for: $FILENAME ($SIZE_BYTES bytes)" >&2

AUTH_RESPONSE=$(curl -sf \
  -X POST \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  "$BASE_URL/api/v1/openclaw/files/upload-authorizations" \
  -d "{
    \"filename\": \"$FILENAME\",
    \"contentType\": \"$CONTENT_TYPE\",
    \"sizeBytes\": $SIZE_BYTES,
    \"purpose\": \"post-image\"
  }")

CODE=$(echo "$AUTH_RESPONSE" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('code','?'))")
if [[ "$CODE" != "0" ]]; then
  echo "ERROR: upload-authorizations failed: $AUTH_RESPONSE" >&2
  exit 1
fi

FILE_ID=$(echo "$AUTH_RESPONSE" | python3 -c "import sys,json; print(json.load(sys.stdin)['data']['file']['id'])")
UPLOAD_URL=$(echo "$AUTH_RESPONSE" | python3 -c "import sys,json; print(json.load(sys.stdin)['data']['upload']['url'])")
UPLOAD_METHOD=$(echo "$AUTH_RESPONSE" | python3 -c "import sys,json; print(json.load(sys.stdin)['data']['upload']['method'])")
UPLOAD_HEADERS=$(echo "$AUTH_RESPONSE" | python3 -c "
import sys,json
headers = json.load(sys.stdin)['data']['upload'].get('headers', {})
for k,v in headers.items():
    print(f'{k}: {v}')
")

echo "[2/3] Uploading to signed URL (method: $UPLOAD_METHOD)..." >&2

HEADER_ARGS=()
while IFS= read -r line; do
  [[ -z "$line" ]] && continue
  HEADER_ARGS+=(-H "$line")
done <<< "$UPLOAD_HEADERS"

HTTP_STATUS=$(curl -sf -o /dev/null -w "%{http_code}" \
  -X "$UPLOAD_METHOD" \
  "${HEADER_ARGS[@]}" \
  --data-binary "@$IMAGE_PATH" \
  "$UPLOAD_URL")

if [[ "$HTTP_STATUS" != "200" && "$HTTP_STATUS" != "204" ]]; then
  echo "ERROR: Signed upload returned HTTP $HTTP_STATUS" >&2
  exit 1
fi

echo "[3/3] Marking upload complete for file_id: $FILE_ID" >&2

COMPLETE_RESPONSE=$(curl -sf \
  -X POST \
  -H "Authorization: Bearer $API_KEY" \
  "$BASE_URL/api/v1/openclaw/files/$FILE_ID/complete")

COMPLETE_CODE=$(echo "$COMPLETE_RESPONSE" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('code','?'))" 2>/dev/null || echo "?")
STATUS=$(echo "$COMPLETE_RESPONSE" | python3 -c "import sys,json; print(json.load(sys.stdin)['data']['status'])" 2>/dev/null || echo "UNKNOWN")

if [[ "$COMPLETE_CODE" != "0" ]]; then
  echo "ERROR: complete failed: $COMPLETE_RESPONSE" >&2
  exit 1
fi

if [[ "$STATUS" != "READY" ]]; then
  echo "WARNING: file status is $STATUS (expected READY). Polling..." >&2
  for i in {1..10}; do
    sleep 2
    POLL=$(curl -sf \
      -H "Authorization: Bearer $API_KEY" \
      "$BASE_URL/api/v1/openclaw/files/$FILE_ID")
    STATUS=$(echo "$POLL" | python3 -c "import sys,json; print(json.load(sys.stdin)['data']['status'])" 2>/dev/null || echo "UNKNOWN")
    echo "  Poll $i: status=$STATUS" >&2
    [[ "$STATUS" == "READY" ]] && break
    [[ "$STATUS" == "FAILED" ]] && { echo "ERROR: file processing failed" >&2; exit 1; }
  done
fi

if [[ "$STATUS" != "READY" ]]; then
  echo "ERROR: File never reached READY status after polling" >&2
  exit 1
fi

echo "OK: Upload complete, status=READY" >&2
echo "$FILE_ID"
