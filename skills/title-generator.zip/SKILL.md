---
name: title-generator
version: 1.0.0
description: Generate high-quality titles for explanatory content based on core mechanism, conflict structure, and target audience. Use when: producing a title for an article, video, post, or any explanatory content; optimizing an existing title; validating a title against quality criteria; or selecting from multiple title formula types. Triggers on phrases like "generate a title", "write a title for", "make me a title", "title this", "suggest titles", "improve this title", "validate this title".
---

# Title Generator

Generate titles that create an unavoidable curiosity gap — the reader cannot close it without consuming the content.

## Core Principle

A title is not a summary. It is not a conclusion. It is a question that the audience **genuinely cannot answer** before engaging, combined with an implied promise that the content will explain it completely.

Three-layer model:
1. **Problem Identification** — audience recognizes "I don't know why this happens"
2. **Cognitive Conflict Trigger** — audience feels "this contradicts my expectation"
3. **Explanation Promise** — title implies "engage and I will explain fully"

## Workflow

### Step 1: Gather Inputs

Collect from the user (all optional except `topic`):

```yaml
topic: "what the content is about"
core_mechanism: "the causal or structural mechanism the content explains"
content_type: "article | video | post | carousel | other"
audience: "who this is for (optional)"
constraints: "length, language, platform, tone (optional)"
```

If `core_mechanism` is missing, infer it from `topic` and state your inference.

### Step 2: Select Formula Type

Choose the pattern that best fits the mechanism:

| Pattern | Best for |
|---|---|
| P1 Anti-intuition Question | Subject is familiar; behavior/result is counter-intuitive |
| P2 Capability Contrast | The "why can / cannot" gap is the core tension |
| P3 System Consequence | Result is known; transmission path is not |
| P4 Comparison | Same starting point, divergent outcomes |
| P5 Paradox | Two apparently contradictory facts coexist |

See `references/title-formulas.md` for full pattern descriptions and constraints.

### Step 3: Generate Candidates

Produce 3 title candidates:
- One per the selected pattern
- One from an adjacent pattern that also fits
- One stretch variant (higher tension, same accuracy)

### Step 4: Validate Each Candidate

Run the 8-item checklist before returning results:

| # | Check | Pass criterion |
|---|---|---|
| 1 | Question form | Is it a question, not a statement? |
| 2 | Concrete subject | Is the subject specific and real? |
| 3 | Verifiable phenomenon | Can the described phenomenon be confirmed? |
| 4 | Real question | Would the target audience genuinely not know the answer before engaging? |
| 5 | Promise match | Can the content fully answer the question posed? |
| 6 | No emotional words | Does it use mechanism language, not emotional/fear language? |
| 7 | No conclusion | Does the title withhold the answer? |
| 8 | Scope accuracy | Does the title's implied scope match the content's actual scope? |

Any candidate that fails must be revised or dropped.

### Step 5: Return Output

Return for each validated candidate:

```yaml
title: "the title text"
formula_type: "P1 | P2 | P3 | P4 | P5"
reasoning: "why this pattern fits the mechanism"
validation_result:
  passed: true
  failed_checks: []   # list any failures (should be empty)
```

## Prohibited Title Behaviors

These apply regardless of domain:

- ❌ Summarizing the content
- ❌ Stating the conclusion
- ❌ Taking a position or stance
- ❌ Emotional shock language (collapse, crisis, exposed, shocking)
- ❌ Insider/exclusive claims (insiders revealed, confidential)
- ❌ Rhetorical questions the audience already knows the answer to
- ❌ Numbered list form ("5 reasons why…", "3 ways to…") — list structure weakens causal depth
- ❌ Exaggerating scope beyond what the content delivers

## Length Guidance

No universal ceiling. Aim for: **subject + behavior/result + question form**, nothing redundant.
If a platform constraint applies (e.g., 20 chars for a specific surface), apply it via `constraints` input.

## Input/Output Schema

See `schemas/title_request.yaml` for the machine-readable contract.

## Examples

See `examples/examples.md` for worked examples across different domains and content types.
