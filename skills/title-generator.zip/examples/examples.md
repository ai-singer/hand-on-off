# Title Generator — Worked Examples

Domain-agnostic examples demonstrating all five formula types across different content categories.

---

## Example 1: Technology (P1 — Anti-intuition Question)

**Input:**
```yaml
topic: "AI Agent memory architecture"
core_mechanism: "state persistence reduces repeated reasoning cost across sessions"
content_type: "article"
audience: "software developers building production AI systems"
```

**Output candidates:**

```yaml
- title: "Why do AI agents forget everything between sessions?"
  formula_type: P1
  reasoning: >
    'AI agents' is familiar to this audience. Forgetting between sessions is
    counter-intuitive for software that claims to assist with complex tasks.
    The mechanism (no persistent state) is the content's core explanation.
  validation_result:
    passed: true
    failed_checks: []

- title: "Why does adding memory to an AI agent make it slower to deploy?"
  formula_type: P1
  reasoning: >
    Counter-intuitive result (more capability → more operational cost).
    Familiar subject. Mechanism: storage architecture trade-offs.
  validation_result:
    passed: true
    failed_checks: []

- title: "Why do AI agents that 'remember' still repeat the same mistakes?"
  formula_type: P1
  reasoning: >
    Stretch variant. Familiar subject with high-tension counter-intuitive behavior.
    Assumes content addresses memory retrieval quality, not just presence.
  validation_result:
    passed: true
    failed_checks: []
```

---

## Example 2: Education / Policy (P3 — System Consequence)

**Input:**
```yaml
topic: "standardized testing and student performance"
core_mechanism: "optimizing for test metrics displaces learning behaviors that build long-term competence"
content_type: "article"
audience: "general readers interested in education policy"
```

**Output candidates:**

```yaml
- title: "How did the push for higher test scores end up lowering student capability?"
  formula_type: P3
  reasoning: >
    Result (lower capability despite higher scores) is observable and widely discussed.
    Mechanism (metric displacement) is the content's explanatory core.
    Audience knows the result; they don't know the transmission path.
  validation_result:
    passed: true
    failed_checks: []

- title: "How does measuring learning more precisely make students learn less?"
  formula_type: P3
  reasoning: >
    Alternate framing of the same paradox. 'Measuring more → learning less' is
    the counter-intuitive system consequence.
  validation_result:
    passed: true
    failed_checks: []

- title: "Same curriculum, same teachers — why do test-focused schools produce weaker graduates?"
  formula_type: P4
  reasoning: >
    Comparison variant. Highlights the divergent outcome from the same inputs
    when the differentiating variable is test optimization.
  validation_result:
    passed: true
    failed_checks: []
```

---

## Example 3: Biology / Science (P5 — Paradox)

**Input:**
```yaml
topic: "antibiotic resistance"
core_mechanism: "widespread antibiotic use selects for resistant strains, making individual treatments less effective at the population level"
content_type: "video"
audience: "general science audience"
```

**Output candidates:**

```yaml
- title: "The more we use antibiotics, the less they work — how is this possible?"
  formula_type: P5
  reasoning: >
    Two facts coexist that appear contradictory: increased use of a treatment →
    treatment becomes less effective. Classic paradox structure.
    Mechanism (evolutionary selection) is the content's explanation.
  validation_result:
    passed: true
    failed_checks: []

- title: "Why does treating one patient make it harder to treat the next?"
  formula_type: P1
  reasoning: >
    Anti-intuition question. Individual treatment is familiar; the systemic
    consequence (harming future patients) is counter-intuitive.
  validation_result:
    passed: true
    failed_checks: []
```

---

## Example 4: Organizational Design (P2 — Capability Contrast)

**Input:**
```yaml
topic: "why large organizations move slowly"
core_mechanism: "coordination overhead scales super-linearly with headcount; decision latency compounds across layers"
content_type: "post"
audience: "managers and operators in mid-to-large companies"
```

**Output candidates:**

```yaml
- title: "Why can't a 50,000-person company move as fast as a 5-person startup?"
  formula_type: P2
  reasoning: >
    'Cannot' variant. The subject (large company) appears more capable in resources
    but less capable in speed. Familiar to this audience.
    Mechanism: coordination cost scaling.
  validation_result:
    passed: true
    failed_checks: []

- title: "Why does hiring more people make an organization slower?"
  formula_type: P1
  reasoning: >
    Anti-intuition: more resources → lower speed. Mechanism is directly the content.
  validation_result:
    passed: true
    failed_checks: []

- title: "Same resources, same talent — why do some teams execute faster than others?"
  formula_type: P4
  reasoning: >
    Comparison variant. Differentiating variable is organizational structure and
    coordination overhead.
  validation_result:
    passed: true
    failed_checks: []
```

---

## Example 5: Title Revision (Existing title improvement)

**Input:**
```yaml
topic: "remote work productivity"
core_mechanism: "async communication reduces interruption cost but increases coordination latency for time-sensitive decisions"
content_type: "article"
constraints:
  original_title: "The truth about remote work productivity"
```

**Analysis of original title:**

```
Failures:
- no_conclusion: States there is a "truth" — implies it will be revealed (approaches conclusion-statement)
- real_question: "The truth about X" is a rhetorical framing, not a genuine question
- concrete_subject: "productivity" is abstract — no specific mechanism signaled
```

**Improved candidates:**

```yaml
- title: "Why does remote work make focused tasks faster but urgent decisions slower?"
  formula_type: P5
  reasoning: >
    Paradox: same environment, opposite effects on different task types.
    Concrete mechanism visible in title. Genuine question.
  validation_result:
    passed: true
    failed_checks: []

- title: "Why do remote teams produce more output but miss more deadlines?"
  formula_type: P1
  reasoning: >
    Anti-intuition: higher output yet worse deadline performance.
    Familiar subject, verifiable phenomenon, mechanism hidden inside content.
  validation_result:
    passed: true
    failed_checks: []
```

---

## Common Validation Failures (Reference)

| Failure | Example (bad) | Fix |
|---|---|---|
| Conclusion stated | "Why remote work actually hurts productivity" | Remove conclusion; pose the question only |
| Rhetorical question | "Is remote work really good for you?" | Reframe around a specific mechanism |
| Emotional words | "The shocking truth about remote work" | Replace with specific counter-intuitive fact |
| Abstract subject | "Why productivity is complex" | Name a specific entity or system |
| Scope exaggeration | "How remote work is changing all of human civilization" | Match scope to content |
| Numbered list | "5 reasons remote work fails" | Reframe as a mechanism question |
