# Title Formula Reference

Detailed descriptions of all five title patterns, their structural constraints, and usage guidance.

---

## Pattern 1 — Anti-intuition Question (Highest frequency)

**Structure:**
```
Why does [familiar subject] [counter-intuitive behavior/result]?
```

**Characteristics:**
- Subject is familiar to the target audience
- The behavior or result violates intuitive expectations
- The question cannot be answered in one sentence

**Subject requirements:**
- Must be something the audience already recognizes
- Familiarity reduces friction; the counter-intuitive result creates tension

**When to use:**
- When the content's core value is explaining a mechanism that produces a surprising outcome
- When the audience has a wrong prior belief the content will correct

**Example structure (domain-neutral):**
- "Why does [well-known system] [produce the opposite of what you'd expect]?"
- "Why do [familiar entities] [behave in a way that contradicts common assumption]?"

---

## Pattern 2 — Capability Contrast

**Structure:**
```
Why can [subject] [exceed expected performance]?
Why cannot [subject] [do what seems obvious]?
```

**Characteristics:**
- The capability gap is the tension source
- "Can" variant: subject is more powerful than expected
- "Cannot" variant: subject is more constrained than expected

**When to use:**
- When the content explains structural enablers or structural blockers
- When the audience's default assumption is the opposite of reality

**Example structure (domain-neutral):**
- "Why can [entity] [perform well beyond normal expectations]?"
- "Why can't [seemingly capable entity] [do the straightforward thing]?"

---

## Pattern 3 — System Consequence

**Structure:**
```
How did [decision / system / event] lead to [unexpected result]?
```

**Characteristics:**
- The result is already known to the audience
- The transmission path (mechanism) is not known
- Title promises to reveal the causal chain

**When to use:**
- When the content's primary value is the causal mechanism, not the outcome
- When the audience is already aware of the result but doesn't understand why

**Example structure (domain-neutral):**
- "How did [policy / rule / system] end up causing [counter-intuitive downstream effect]?"
- "How does [routine practice] lead to [unexpected structural consequence]?"

---

## Pattern 4 — Comparison

**Structure:**
```
Same [X], why did [A] and [B] end up with completely different outcomes?
```

**Characteristics:**
- Similar starting conditions + divergent endpoints
- The contrast creates cognitive tension
- Implies the content will identify the differentiating variable

**When to use:**
- When the content's argument is about a single differentiating factor
- When parallel cases make the mechanism legible

**Example structure (domain-neutral):**
- "Same [starting condition], why did [case A] succeed while [case B] failed?"
- "Both [entities] faced [same challenge] — why did they end up so differently?"

---

## Pattern 5 — Paradox

**Structure:**
```
[Contradictory phenomenon A] and [contradictory phenomenon B] — how can both be true?
```

**Characteristics:**
- The title itself presents a logical contradiction
- Audience is compelled to click to resolve the apparent paradox
- Content must deliver a mechanism that reconciles the paradox — not just acknowledge it

**When to use:**
- When two observable facts appear mutually exclusive
- When the resolution requires understanding a structural mechanism

**Example structure (domain-neutral):**
- "More [resource] yet worse [outcome] — how is this possible?"
- "[Entity] is both [characteristic A] and [characteristic B] — which is real?"

---

## Shared Structural Properties

All five patterns share these requirements:

| Property | Requirement |
|---|---|
| Question form | Interrogative, not declarative |
| Concrete subject | At least one specific, identifiable subject |
| Concrete result | Phenomenon/result is perceivable, not vague |
| Unpredictable answer | Audience cannot guess the answer before engaging |
| Credible promise | Implies "I can explain" — not "I have insider info" |

---

## Click Motivation Model

### Primary Driver: Curiosity Gap

Curiosity Gap = distance between **what the audience already knows** and **what they want to know**

Three sources of curiosity gap:

**Source A — Result known, cause unknown**
> Audience knows "what happened" but not "why"
> Title asks "why" — gap opens immediately

**Source B — Subject familiar, mechanism unknown**
> Audience recognizes the subject but has never understood how it works
> Title reveals that this gap exists

**Source C — Counter-intuitive result**
> Audience has an intuitive expectation
> Title implies reality differs from expectation
> Audience must engage to repair cognitive dissonance

### Secondary Drivers

| Driver | Manifestation | Strength |
|---|---|---|
| Intellectual advantage expectation | Implies "you'll understand more than others" | Medium |
| Timeliness | Subject is related to a current event | High (while timely) |
| Scale sense | Subject is a large system or widespread phenomenon | Medium |

### Prohibited Click Drivers

- ❌ Fear/anxiety amplification ("X is collapsing", "your Y is at risk")
- ❌ Insider/exclusive promises ("insiders revealed", "classified")
- ❌ Extreme polarization ("X is completely wrong", "Y is the real truth")
- ❌ Number stacking ("5 reasons", "10 truths")
- ❌ Celebrity/authority bait (using a name to attract clicks rather than the question itself)

---

## Title Boundary Rules (Detail)

### Boundary 1 — Question must be fully answerable by the content

The content must provide a complete mechanism explanation for the question posed.
If the content only partially answers, the title must constrain its scope accordingly.

Verification: Use the content's core argument to answer the title question. If the answer is complete, the title qualifies. If there is a significant gap, the title over-promises.

### Boundary 2 — Subject and phenomenon must be real and verifiable

The subject and phenomenon described in the title must be confirmable in publicly available information.
Distorting reality to create conflict is not permitted.

### Boundary 3 — Title must pose a genuine question, not a rhetorical one

The audience must **genuinely not know the answer** before engaging.
If most of the target audience already knows the answer, the question is rhetorical — do not use it.

### Boundary 4 — No conclusion-statement titles

Even if the conclusion is counter-intuitive, it must not appear in the title.

❌ Conclusion form (prohibited): "The real reason X works is Y"
✅ Question form (correct): "Why does X [produce this result]?"

Rationale: A stated conclusion allows the audience to skip the content. A question requires engagement to resolve.

### Boundary 5 — Do not exaggerate scope or urgency

Title scope must not exceed the content's actual scope.

❌ Exaggerated: "This could reshape the entire global order" (content discusses one regional case)
✅ Accurate: Title scope = content scope

---

## Mechanism Vocabulary vs Emotional Vocabulary

| Avoid (emotional) | Use instead (mechanism) |
|---|---|
| collapse, crisis, explode, crash | why, how, leads to, causes |
| shocking, unbelievable | [specific counter-intuitive result] |
| secret, insider | mechanism, reason, logic |
| you must, urgent | [structural question] |
