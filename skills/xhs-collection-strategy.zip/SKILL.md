---
name: xhs-collection-strategy
version: 1.1.0
description: 小红书内容采集完整策略。涵盖两阶段博主笔记采集、关键词搜索（Playwright XHR拦截）、图片/视频下载、ASR字幕提取、素材标准化与分级评分、话题候选提取的端到端流程。适用于任意内容垂类。
allowed-tools: Bash, Read
---

# XHS Collection Strategy Skill

从小红书采集结构化内容素材的完整端到端流程，覆盖博主主页采集、关键词发现、媒体下载、素材标准化与话题池构建。

---

## 用途

- 采集指定博主的全部笔记元数据和详情
- 通过关键词搜索发现指定垂类的高质量笔记
- 下载图片和视频（CDN 鉴权绕过方案）
- 从视频中提取 ASR 字幕
- 标准化素材、评分分级、风险过滤
- 构建话题候选池

---

## 外部依赖

### Python 包
```bash
pip install aiohttp xhshow playwright faster-whisper
```

### 系统工具
- `ffmpeg`（视频下载与帧提取）
- `Chromium`（Playwright 驱动）

### 浏览器安装
```bash
# 默认路径
playwright install chromium

# 指定路径（服务器环境）
PLAYWRIGHT_BROWSERS_PATH=/home/node/.playwright playwright install chromium
```

### Cookie 要求
- 格式：Netscape HTTP Cookie File（`# Netscape HTTP Cookie File` 头）或纯 cookie string
- 来源：浏览器登录小红书后导出（EditThisCookie / Cookie Editor 等插件）
- 有效期：约 30 天
- 失效特征：API 返回 `code=-101`

### 随包分发的 Cookie（v1.1.0 新增）

本 Skill **内置** `xiaohongshu_cookies.txt`（Netscape 格式），解压即用，无需另配。

| 项目 | 说明 |
|------|------|
| 内置路径 | `<skill_dir>/xiaohongshu_cookies.txt` |
| 快照版本 | 2026-09-30 |
| 更新方式 | 直接用新导出的 cookie 覆盖该文件，无需改代码 |
| 失效处理 | API 返回 `code=-101` 时替换该文件 |

> ⚠️ 内置 cookie 是**部署时快照**，会随时间失效。优先于宿主机路径被读取，
> 因此更新时务必覆盖内置文件，否则旧快照会遮蔽宿主机上更新的 cookie。

Cookie 文件路径（脚本读取顺序，v1.1.0）：
1. `<skill_dir>/xiaohongshu_cookies.txt`（Netscape 格式，随包分发）
2. `~/workspace/xiaohongshu_cookies.txt`
3. `~/.openclaw/workspace/xiaohongshu_cookies.txt`
4. `./xiaohongshu_cookies.txt`
5. `~/.openclaw/workspace/.env` 中 `XHS_COOKIE=...`
6. `~/xhs-auto-bot/.env` 中 `XHS_COOKIE=...`

显式指定：`--cookie /path/to/xiaohongshu_cookies.txt`

---

## 速率限制（必须遵守）

| 操作 | 最小间隔 | 单次上限 |
|------|---------|---------|
| Stage 1 翻页 | ≥ 3s | — |
| Stage 2 每条详情 | ≥ 3s | — |
| Playwright 笔记页访问 | ≥ 5s | ≤ 20 条/session |
| 图片下载（批量） | ≥ 3s/张 | ≤ 10 张/批 |
| 关键词搜索页 | ≥ 6s/关键词 | — |
| Stage 1+2 完成后再做 Playwright | 间隔 ≥ 30min | — |

---

## 模块概览

```
A. 博主采集       → scrape_two_stage.py
B. 关键词搜索     → search_playwright.py
C. 图片下载       → download_images_playwright.py
D. 视频下载       → download_video_playwright.py
E. ASR 提取       → extract_asr.py
F. 标准化分级     → normalize.py
G. 话题候选提取   → build_topic_pool.py
```

---

## A. 博主笔记两阶段采集

### 输入
- `user_id`：博主小红书用户 ID（从主页 URL 提取）
- Cookie（自动加载，见上方 Cookie 要求）
- `max_notes`：最大采集数（默认 100）

### 输出
- `raw/stage1_note_list.json`：note_id + xsec_token 列表
- `raw/xhs_{creator_name}_{date}.json`：完整笔记详情
- `raw/xhs_{creator_name}_{date}_schema.json`：标准化格式版本

### 执行
```bash
python3 scripts/scrape_two_stage.py \
  --user-id <user_id> \
  --creator-name <name> \
  --max-notes 100 \
  --output-dir ./source_material/xhs/raw/
```

### 流程说明
**Stage 1**：调用 `GET /api/sns/web/v1/user_posted`，分页获取笔记列表
- 每页 30 条，自动翻页
- 获取：`note_id` + `xsec_token` + 标题预览

**Stage 2**：调用 `POST /api/sns/web/v1/feed`，获取笔记完整详情
- 字段：`title`、`desc`、`image_list`、`tag_list`、`interact_info`、`user`
- 每条间隔 ≥ 3 秒

---

## B. 关键词搜索（Playwright XHR 拦截）

> ⚠️ 重要：`/api/sns/web/v1/search/notes` 直接调用返回 404，必须通过 Playwright 拦截页面 XHR 响应。

### 输入
- `keywords`：关键词列表（如 `["商业分析", "企业经营"]`）
- Cookie（自动加载）

### 输出
- `raw/xhs_{垂类}_image_candidates_{date}.json`：候选笔记列表（note_id + xsec_token）

### 执行
```bash
python3 scripts/search_playwright.py \
  --keywords "商业分析,企业经营,财务知识" \
  --output-dir ./source_material/xhs/raw/ \
  --wait-sec 6
```

### 拦截逻辑
```python
def on_response(resp):
    if "search/notes" in resp.url and resp.status == 200:
        data = resp.json()
        items = data.get("data", {}).get("items", [])
        for item in items:
            note_card = item.get("note_card", {})
            if note_card.get("type") != "video":   # 仅采集图文
                candidates.append({
                    "note_id": item.get("id") or note_card.get("note_id"),
                    "xsec_token": item.get("xsec_token", ""),
                    "display_title": note_card.get("display_title", ""),
                })

page.on("response", on_response)
page.goto(f"https://www.xiaohongshu.com/search_result?keyword={keyword}&type=51")
page.wait_for_timeout(wait_sec * 1000)
```

### 实测数据
- 5 个关键词 × 约 27 条/页 ≈ 107 候选
- Stage 2 成功率约 90%

---

## C. 图片下载（Playwright 同 Context）

> ⚠️ CDN 域名（`sns-webpic-qc.xhscdn.com`）绑定浏览器 IP，`curl` / `requests` 直接请求一律 403。**必须在同一 Playwright browser context 内请求。**

### 已验证失败方案（禁止重试）
| 方案 | 结果 |
|------|------|
| curl 直接请求 CDN URL | 403（IP 白名单） |
| curl + Cookie | 403（CDN 不验证 Cookie） |
| curl + Referer | 403 |
| Stage 2 存储的 URL 延迟请求 | 403（签名过期） |

### 执行
```bash
python3 scripts/download_images_playwright.py \
  --tier S,A \
  --source-dir ./source_material/xhs/finance/image_text/ \
  --output-dir ./source_material/xhs/finance/image_text_imgs/ \
  --max 20
```

### 输出
```
source_material/xhs/{category}/image_text_imgs/{note_id}/
  img_00.jpg
  img_01.jpg
  ...
```

### IP 限流恢复
- 触发特征：所有 `/explore/{note_id}` 返回「你访问的页面不见了」
- 恢复方法：等待 12–24h / 更换 Cookie / 更换 IP

---

## D. 视频下载（Playwright 实时 CDN 拦截 + ffmpeg）

> ⚠️ 视频 CDN URL 含时效签名，Stage 2 后即过期。**必须 Playwright 实时拦截**，不可复用 meta.json 中的 URL。

### 已验证失败方案（禁止重试）
| 方案 | 结果 |
|------|------|
| 直接请求 meta.json 中的 CDN URL | 403（签名过期） |
| yt-dlp + Cookie | No video formats found |
| media_v2.stream URL | 403（同样过期） |

### 执行
```bash
# 单条
python3 scripts/download_video_playwright.py \
  --note-id <note_id> \
  --out-dir ./source_material/xhs/finance/video/

# 批量（按评级过滤）
python3 scripts/download_video_playwright.py \
  --meta-dir ./source_material/xhs/finance/video/ \
  --tier S,A \
  --delay 5
```

### 输出
```
source_material/xhs/{category}/video/{note_id}/video.mp4
```

### 拦截目标 CDN 域名
- `sns-video-bd.xhscdn.com`
- `sns-video-hw.xhscdn.com`
- `sns-video-qc.xhscdn.com`
- `sns-video-al.xhscdn.com`

---

## E. ASR 字幕提取

### 依赖
```bash
pip install faster-whisper
# HuggingFace 镜像（huggingface.co 不可达时）
export HF_ENDPOINT=https://hf-mirror.com
```

### 执行
```bash
python3 scripts/extract_asr.py \
  --video-dir ./source_material/xhs/finance/video/ \
  --tier S,A
```

### 输出
```
source_material/xhs/{category}/video/{note_id}/transcript.json
```

格式：
```json
{
  "note_id": "...",
  "language": "zh",
  "segments": [
    {"start": 0.0, "end": 3.2, "text": "..."},
    {"start": 3.5, "end": 7.1, "text": "..."}
  ],
  "full_text": "..."
}
```

### 模型参数
- 模型：`base`（中文精度良好，CPU 可运行）
- 设备：`cpu`，计算类型：`int8`

---

## F. 标准化、评分与分级

### 执行
```bash
# 批量标准化
python3 scripts/normalize.py \
  raw/xhs_{creator_name}_{date}.json \
  {category} \
  --xhs-base ./source_material/xhs/

# 建立 Benchmark + 重新分级 + 风险过滤
python3 scripts/build_benchmark.py \
  --data-dir ./source_material/xhs/{category}/ \
  --registry-dir ./source_material/xhs/creator_registry/
```

### Content Signal Score 公式
```
score = log1p(collected) × 0.35
      + log1p(share)     × 0.30
      + log1p(comment)   × 0.25
      + log1p(liked)     × 0.10

归一化：score / log1p(10000) × 100  （映射到 0–100）
```

### 分级阈值（绝对值模式）
| 级别 | 收藏数阈值 | 说明 |
|------|-----------|------|
| S | ≥ P95 | 优先采集 |
| A | ≥ P90 | 采集 |
| B | ≥ P75 | 可选 |
| C | < P75 | 跳过 |

P 值基于同一博主 100 条笔记建立的 Benchmark。

### 跨账号归一化（外部账号）
```
Account Factor = 外部账号平均收藏数 / 基准账号平均收藏数
Adjusted Collected = 原始收藏数 ÷ Account Factor
```

### 内容格式分类
- `video` → `discovery_role: topic_discovery`（只提取话题，不做内容蒸馏）
- `image_text` → `discovery_role: knowledge_distillation`

---

## G. 话题候选提取

### 执行
```bash
python3 scripts/build_topic_pool.py \
  --video-dir ./source_material/xhs/{category}/video/ \
  --pool-path ./source_material/xhs/creator_registry/topic_pool.json \
  --tier S,A
```

### topic_pool.json 条目格式
```json
{
  "note_id": "...",
  "material_tier": "S",
  "signal_score": 88.5,
  "source_title": "原始笔记标题",
  "metrics": {"liked": 0, "collected": 0, "comment": 0, "share": 0},
  "topic": "话题词",
  "angle": "切入视角",
  "mechanism": "核心机制描述",
  "content_hook": "内容钩子",
  "tags": ["tag1", "tag2"],
  "source_url": "https://www.xiaohongshu.com/explore/{note_id}",
  "extracted_at": "2026-09-22T00:00:00Z"
}
```

### 入池规则
- 仅 A 级及以上笔记进入话题池
- video 类：从 title + tags + transcript 提取话题
- image_text 类：可直接进入内容蒸馏，不经话题池

---

## 完整采集顺序

```
1.  验证 Cookie（调用 Stage 1 接口测试）
2.  Stage 1：获取博主笔记列表（≥3s/页）
3.  Stage 2：获取笔记详情（≥3s/条）
4.  normalize.py：标准化 + 格式分类
5.  build_benchmark.py：建立 P 值基准 + 分级 + 风险过滤
6.  download_images_playwright.py：S/A 级图文图片（≥5s/笔记）
7.  download_video_playwright.py：S/A 级视频（≥5s/笔记）
8.  extract_asr.py：视频 ASR 字幕
9.  build_topic_pool.py：视频 S/A → 话题候选
10. （可选）search_playwright.py：关键词扩展采集
```

---

## 错误处理

| 错误 | 原因 | 处理 |
|------|------|------|
| `code=-101` | Cookie 已过期 | 重新导出 Cookie |
| 图片 403 | 不在同一 Context | 确认使用 Playwright context 内请求 |
| 视频 403 | CDN 签名过期 | 使用 Playwright 实时拦截，不复用 URL |
| 页面「不见了」 | IP 被临时封禁 | 等待 12–24h 或更换 Cookie/IP |
| ASR 下载失败 | HuggingFace 不可达 | 设置 `HF_ENDPOINT=https://hf-mirror.com` |
| `search/notes` 404 | 接口不对外开放 | 必须 Playwright XHR 拦截 |

---

## 安全限制

- 本 Skill **仅执行只读采集**，禁止发布、评论、点赞等写操作
- API Key / Token 不得写入任何 Skill 文件
- **Cookie 例外（v1.1.0）**：`xiaohongshu_cookies.txt` 由部署方明确决定随包分发，
  作为解压即用的部署快照。该文件视为**敏感凭证**：
  - 不得上传到公开仓库 / 公开共享渠道
  - 不得转发给第三方
  - 失效后直接覆盖，无需保留历史版本
- 禁止将采集数据用于违反小红书服务条款的用途
- 采集速率必须遵守上方速率限制，不得批量并发

---

## 输出目录结构（推荐）

```
source_material/xhs/
  raw/                                   # 原始 JSON（不修改）
  {category}/
    video/{note_id}/
      meta.json                          # 标准化元数据
      video.mp4                          # 下载的视频文件
      transcript.json                    # ASR 字幕
      frames/                            # 关键帧（可选）
    image_text/
      {note_id}.json                     # 标准化元数据
    image_text_imgs/{note_id}/           # 图片文件
      img_00.jpg
      ...
    image_text_blocked/                  # 风险过滤移出（不删除）
  creator_registry/
    {creator}_benchmark.json             # 账号基准分位数
    candidate_registry.json              # 博主注册表
    topic_pool.json                      # 话题候选池
```

---

## 版本

### v1.1.0 — 2026-09-30

- **新增随包分发 cookie**：内置 `xiaohongshu_cookies.txt`，解压即用
- 全部 cookie 加载器新增 **skill 目录优先**查找，支持 `__file__` 与 `XHS_SKILL_DIR` 两种定位（PyInstaller / 符号链接场景可用）
- manifest 新增 `cookieConfig.bundledFile` / `cookieConfig.version`

### v1.0.0 — 2026-09-29

基于生产实例验证结果整合，覆盖完整采集链路。
