# 已验证失败方案文档

本文档记录在生产实例中验证失败的技术方案，防止重复尝试。

---

## 1. 图片下载：curl / requests 直接请求

**方案：**
```bash
curl "https://sns-webpic-qc.xhscdn.com/..." -o image.jpg
```

**结果：** `403 Forbidden`

**原因：** XHS 图片 CDN 对外部 IP 实施白名单控制，仅允许浏览器 IP 访问。Cookie 在 CDN 层不生效。

**正确方案：** 必须在 Playwright 同一 browser context 内新建 page 请求图片 URL。

---

## 2. 图片下载：curl + Cookie

**方案：**
```bash
curl "https://sns-webpic-qc.xhscdn.com/..." \
  -H "Cookie: a1=xxx; web_session=xxx" -o image.jpg
```

**结果：** `403 Forbidden`

**原因：** CDN 层不验证 Cookie，鉴权逻辑在浏览器 Session 层。

---

## 3. 图片下载：复用 Stage 2 存储的 URL（延迟请求）

**方案：** 采集完成后，将 meta.json 中的图片 URL 离线下载。

**结果：** `403 Forbidden`

**原因：** 图片 URL 含时效签名，采集完成后通常在数分钟至数小时内过期。

---

## 4. 视频下载：使用 Stage 2 meta.json 中的 CDN URL

**方案：**
```bash
ffmpeg -i "http://sns-video-qc.xhscdn.com/..." -c copy video.mp4
```

**结果：** `403 Forbidden`

**原因：** 视频 CDN URL 含时效签名（时间戳 + IP 绑定），Stage 2 采集后即开始倒计时，几分钟内失效。

---

## 5. 视频下载：yt-dlp + Cookie

**方案：**
```bash
yt-dlp --cookies xiaohongshu_cookies.txt \
  "https://www.xiaohongshu.com/explore/{note_id}"
```

**结果：** `ERROR: No video formats found`

**原因：** yt-dlp 的 XHS 提取器不支持当前页面结构（2026年测试）。

---

## 6. 视频下载：media_v2.stream URL

**方案：** 提取 Stage 2 响应中 `media_v2.stream` 字段的 URL 下载。

**结果：** `403 Forbidden`

**原因：** 同 Stage 2 CDN URL，签名已过期。

---

## 7. 搜索：直接调用 /api/sns/web/v1/search/notes

**方案：**
```python
aiohttp.get("https://edith.xiaohongshu.com/api/sns/web/v1/search/notes?keyword=...")
```

**结果：** `404 Not Found`

**原因：** 该 API 不对外部直接调用开放。必须通过 Playwright 打开搜索结果页，拦截页面自动发出的 XHR 响应。

---

## 8. Playwright 批量访问后 IP 被封

**现象：** 所有 `/explore/{note_id}` 返回「你访问的页面不见了」。

**原因：** 短时间内通过 Playwright 访问大量笔记页面，触发小红书风控。

**恢复方法：**
1. 停止所有访问，等待 12–24 小时
2. 更换浏览器 Cookie（重新登录导出）
3. 更换 IP（代理 / VPN）

**预防措施：**
- Stage 1+2 采集完成后，等待 ≥30 分钟再启动 Playwright 下载
- Playwright 每条笔记页面间隔 ≥5 秒
- 每次 Playwright session 处理笔记 ≤20 条
