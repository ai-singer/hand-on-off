# IP 封禁恢复指南

## 触发条件

以下操作可能导致 IP 被临时封禁：

1. Stage 1+2 采集后立即启动 Playwright 下载（未等待 ≥30min）
2. Playwright session 内访问超过 20 条笔记页面
3. 短时间内重复访问同一笔记 URL
4. 并发多个 Playwright 实例访问小红书

---

## 封禁症状

- 所有 `/explore/{note_id}` 页面显示「你访问的页面不见了」
- Playwright 拦截不到任何图片/视频 CDN URL
- 页面 `page.title()` 返回含「不见了」或「404」的字符串

---

## 分级恢复方法

### 轻度封禁（通常 2–4 小时）

- 停止所有 Playwright 操作
- 等待 2–4 小时后用 `scrape_two_stage.py` 测试 API 是否恢复

### 中度封禁（通常 12–24 小时）

- 停止所有操作，等待 12–24 小时
- 恢复后先测试 API，再做 Playwright 操作

### 严重封禁（可能持续更长）

1. **更换 Cookie**：从浏览器重新登录小红书后导出
2. **更换 IP**：使用代理或 VPN（需更换后同时更换 Cookie）
3. **两者都换**：IP 封禁通常绑定 IP+Cookie 组合

---

## Cookie 更新步骤

1. 在浏览器打开 `https://www.xiaohongshu.com` 并登录
2. 安装 Cookie 导出插件（EditThisCookie / Cookie Editor）
3. 导出为 **Netscape 格式**（含 `# Netscape HTTP Cookie File` 头）
4. 覆盖本地 `xiaohongshu_cookies.txt`
5. 用 `scrape_two_stage.py --user-id <any> --max-notes 1` 验证

Cookie 关键字段（确保存在）：
- `a1`（用户标识）
- `web_session`（会话 token）
- `webId`（设备 ID）

---

## 验证恢复

```bash
# API 测试（任意博主 user_id，只取 1 条）
python3 scripts/scrape_two_stage.py \
  --user-id 5abf90244eacab2c32c7c5e6 \
  --max-notes 1 \
  --output-dir /tmp/xhs_test/

# 期望输出：
# ✓ Stage 1 完成，共 1 条
# [1/1] ✓ ...
```

若 Stage 1 成功返回数据，表示 IP + Cookie 正常。
