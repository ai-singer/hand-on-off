# 速率限制指南

小红书对自动化访问有严格的频率控制。违反以下限制将导致 IP 临时封禁（12–24h）或 Cookie 失效。

> ⚠️ **固定间隔本身就是机器特征。** 本 Skill 自 v1.2.0 起内置真人化节奏模块
> `scripts/human_pacing.py`，在下方所有最小间隔之上叠加随机抖动、长尾停顿、
> 批次休息与日额度四层保护。详见文末「真人化节奏」。

---

## API 调用速率

| 操作 | 最小间隔 | 说明 |
|------|---------|------|
| Stage 1 翻页 | ≥ 3s | `/api/sns/web/v1/user_posted` 分页 |
| Stage 2 单条 | ≥ 3s | `/api/sns/web/v1/feed` 每条详情 |
| Stage 2 批量 | ≤ 100条/次 | 超出后建议休息 ≥10min |

## Playwright 浏览器操作速率

| 操作 | 最小间隔 | 单次上限 | 备注 |
|------|---------|---------|------|
| 笔记页面访问 | ≥ 5s/条 | ≤ 20条/session | 超出后需重建浏览器实例 |
| 图片下载 | ≥ 3s/张 | ≤ 10张/批 | 在同一 context 内 |
| 关键词搜索页 | ≥ 6s/关键词 | — | 每个关键词独立 page |
| Stage 1+2 → Playwright | 间隔 ≥ 30min | — | 切换操作类型前必须等待 |

---

## 风险信号

| 现象 | 含义 | 处理 |
|------|------|------|
| API 返回 `code=-101` | Cookie 已过期 | 重新从浏览器导出 Cookie |
| 页面显示「你访问的页面不见了」 | IP 被临时封禁 | 等待 12–24h，或更换 IP/Cookie |
| Stage 2 成功率骤降 | 接近触发风控 | 立即暂停，等待 ≥30min |
| 图片全部 403 | Cookie 过期 或 不在同一 context | 检查 Cookie / 检查下载代码 |

---

## 推荐作业窗口

建议分阶段操作，两阶段之间留足等待时间：

```
T+0:00  Stage 1+2 采集（100条，约8-10分钟）
T+0:40  normalize + build_benchmark（本地处理，无网络请求）
T+1:10  图片下载（Playwright，≤20条）
T+1:50  视频下载（Playwright，≤10条）
T+2:30  extract_asr（本地处理）
T+2:40  build_topic_pool（本地处理）
```

---

## 批量采集建议

- **单日采集上限（同一 IP + Cookie）：** ≤300条 Stage 2 请求
- **Playwright 图片下载：** ≤50条/天（保守估计）
- **跨日重复采集：** 等待 ≥8h 后再开始新一轮

---

## 真人化节奏（Human Pacing）

**原则：真人不会以等间隔访问。固定间隔是最容易被识别的机器特征。**

模块：`scripts/human_pacing.py`（4 个采集脚本已接入）

### 四层保护

| 层 | 机制 | 参数 | 作用 |
|----|------|------|------|
| 1. 抖动间隔 | 基础间隔上叠加随机上浮 | `base × [1.0, 1.9]` | 打破等间隔特征 |
| 2. 长尾停顿 | 小概率插入「走神」式长停顿 | 概率 7%，`base × [2, 6]` | 模拟真人注意力波动 |
| 3. 批次休息 | 连续 N 次请求后强制长休 | 每 12 次，休 60–240s | 模拟「看完一批去干别的」 |
| 4. 日额度 | 单日硬上限，超出即停 | 见下表 | 避免单日过度采集 |

### 日额度（`DAILY_LIMITS`）

| 类型 | 上限 |
|------|------|
| `stage1` | 60 次 |
| `stage2` | 300 次 |
| `playwright_note` | 50 次 |
| `image` | 400 次 |
| `search` | 60 次 |

### 附加机制

- **会话启动抖动**：每次运行前随机延迟 1.5–6s，避免固定时间点启动
- **活跃时段**：默认建议 08:00–23:00 之内作业；`--enforce-window` 可强制退出
- **状态持久化**：计数写入 `.xhs_pacing_state.json`，跨进程累计，按日自动重置
  （路径可用 `XHS_PACING_STATE` 覆盖）

### 生效方式

所有 4 个采集脚本已自动接入，无需额外配置：

| 脚本 | 接入点 |
|------|--------|
| `scrape_two_stage.py` | Stage 1 翻页、Stage 2 每条详情 |
| `search_playwright.py` | 每个关键词搜索 |
| `download_images_playwright.py` | 每张图片、每条笔记 |
| `download_video_playwright.py` | 每条笔记 |

### 查看当日额度

```bash
python3 scripts/human_pacing.py --report    # 额度与请求统计
python3 scripts/human_pacing.py --window    # 活跃时段判断
python3 scripts/human_pacing.py --reset     # 重置当日状态
```

### 调整建议

- **被风控过一次后**：把 `JITTER_MAX` 提到 1.5、`BATCH_SIZE` 降到 6、
  `DAILY_LIMITS` 砍半，观察 2–3 天再恢复
- **同一 IP 跑多个任务**：日额度是全局共享的（按 state 文件累计），无需分别限制
- **严禁**为了避免等待而把 `JITTER_MIN` 设为负数——那会突破下方速率下限
