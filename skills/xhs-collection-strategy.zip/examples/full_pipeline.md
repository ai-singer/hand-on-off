# 完整采集流程示例（通用垂类）

本示例演示对一个博主执行完整采集，垂类为 `finance`。

---

## 前置准备

```bash
# 安装依赖
pip install aiohttp xhshow playwright faster-whisper

# 安装浏览器
playwright install chromium
# 服务器环境指定路径：
# PLAYWRIGHT_BROWSERS_PATH=/home/user/.playwright playwright install chromium

# 配置 Cookie
# 本 Skill 已内置：<skill_dir>/xiaohongshu_cookies.txt（Netscape 格式，解压即用）
# 如需更新，用新导出的 cookie 覆盖该文件即可；
# 或放入宿主机路径 ~/workspace/xiaohongshu_cookies.txt（内置文件优先）。

# 创建工作目录
mkdir -p ./output/creator_registry
```

---

## Step 1：两阶段采集

```bash
python3 scripts/scrape_two_stage.py \
  --user-id <博主user_id> \
  --creator-name myCreator \
  --max-notes 100 \
  --output-dir ./output/raw/
```

输出：
- `./output/raw/stage1_note_list.json`
- `./output/raw/xhs_myCreator_20260922.json`

---

## Step 2：标准化

```bash
python3 scripts/normalize.py \
  ./output/raw/xhs_myCreator_20260922.json \
  finance \
  --output-base ./output/
```

输出：
- `./output/finance/image_text/{note_id}.json`
- `./output/finance/video/{note_id}/meta.json`

---

## Step 3：建立 Benchmark + 分级 + 风险过滤

```bash
python3 scripts/build_benchmark.py \
  --data-dir ./output/finance/ \
  --registry-dir ./output/creator_registry/ \
  --creator-name myCreator \
  --risk-filter
```

输出：
- `./output/creator_registry/myCreator_benchmark.json`
- 更新所有 meta.json 中的 `material_tier` 和 `signal_score`
- 命中风险关键词的笔记移至 `./output/finance/image_text_blocked/`

---

## Step 4：下载 S/A 级图文图片（需等待 ≥30min 后再执行）

```bash
PLAYWRIGHT_BROWSERS_PATH=/home/user/.playwright \
python3 scripts/download_images_playwright.py \
  --source-dir ./output/finance/image_text/ \
  --output-dir ./output/finance/image_text_imgs/ \
  --tier S,A \
  --max 20
```

输出：
- `./output/finance/image_text_imgs/{note_id}/img_00.jpg` ...

---

## Step 5：下载 S/A 级视频

```bash
PLAYWRIGHT_BROWSERS_PATH=/home/user/.playwright \
python3 scripts/download_video_playwright.py \
  --meta-dir ./output/finance/video/ \
  --tier S,A \
  --delay 5
```

输出：
- `./output/finance/video/{note_id}/video.mp4`

---

## Step 6：ASR 字幕提取

```bash
# 如需镜像（HuggingFace 不可达）
export HF_ENDPOINT=https://hf-mirror.com

python3 scripts/extract_asr.py \
  --video-dir ./output/finance/video/ \
  --tier S,A
```

输出：
- `./output/finance/video/{note_id}/transcript.json`

---

## Step 7：构建话题候选池

```bash
python3 scripts/build_topic_pool.py \
  --video-dir ./output/finance/video/ \
  --pool-path ./output/creator_registry/topic_pool.json \
  --tier S,A
```

输出：
- `./output/creator_registry/topic_pool.json`

---

## 关键词扩展采集（可选）

当需要通过关键词发现更多同垂类笔记时：

```bash
# Step A：关键词搜索获取候选
python3 scripts/search_playwright.py \
  --keywords "关键词1,关键词2,关键词3" \
  --output-dir ./output/raw/ \
  --category finance

# Step B：对候选执行 Stage 2 采集
# 在脚本内配合 scrape_two_stage.get_note_detail() 批量获取详情

# Step C：标准化（同 Step 2）
python3 scripts/normalize.py \
  ./output/raw/xhs_finance_candidates_20260922.json \
  finance \
  --output-base ./output/

# Step D：重新分级（同 Step 3，注意跨账号归一化）
python3 scripts/build_benchmark.py \
  --data-dir ./output/finance/ \
  --registry-dir ./output/creator_registry/ \
  --creator-name external \
  --risk-filter
```

> 跨账号归一化说明：外部博主与基准博主粉丝基数不同，需计算 Account Factor：
> `Adjusted Collected = 原始收藏数 ÷ (外部均值 / 基准均值)`

---

## 最终目录结构

```
output/
  raw/
    stage1_note_list.json
    xhs_myCreator_20260922.json
    xhs_finance_candidates_20260922.json
  finance/
    video/{note_id}/
      meta.json          ← 标准化元数据
      video.mp4          ← 下载的视频
      transcript.json    ← ASR 字幕
    image_text/
      {note_id}.json     ← 标准化元数据
    image_text_imgs/{note_id}/
      img_00.jpg
      img_01.jpg
    image_text_blocked/  ← 风险过滤移出
  creator_registry/
    myCreator_benchmark.json
    topic_pool.json
```
