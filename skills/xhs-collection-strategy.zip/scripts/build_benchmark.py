#!/usr/bin/env python3
"""
build_benchmark.py
基于已采集笔记建立 Account Benchmark（P50/P75/P90/P95），
然后对所有笔记重新分级，并执行风险关键词过滤。

用法:
  python3 build_benchmark.py \
    --data-dir ./output/{category}/ \
    --registry-dir ./output/creator_registry/ \
    --creator-name <name> \
    [--risk-filter]

输出:
  {registry_dir}/{creator_name}_benchmark.json   Benchmark 文件
  重新写入所有 meta.json（含 material_tier + signal_score）
  风险笔记移至 {category}/image_text_blocked/

风险过滤关键词（内置，可通过 --risk-keywords-file 覆盖）:
  股票、炒股、A股、投资建议、理财产品、暴富、财务自由 等
"""

import argparse
import json
import math
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


# ── 内置风险关键词 ─────────────────────────────────────────────────────────────

DEFAULT_RISK_KEYWORDS = [
    "股票", "炒股", "A股", "选股", "个股", "持仓", "仓位",
    "投资建议", "投资推荐", "交易策略", "买卖信号",
    "理财产品", "基金推荐", "证券", "期货操作",
    "暴富", "一夜暴富", "躺赚", "被动收入",
    "财务自由", "财富自由",
]


# ── 工具函数 ───────────────────────────────────────────────────────────────────

def _to_int(val) -> int:
    try:
        return int(str(val).replace(",", "").replace("+", "").strip())
    except (ValueError, TypeError):
        return 0


def percentile(data: list, p: float) -> float:
    if not data:
        return 0.0
    s = sorted(data)
    idx = (len(s) - 1) * p / 100
    lo, hi = int(idx), min(int(idx) + 1, len(s) - 1)
    return s[lo] + (s[hi] - s[lo]) * (idx - lo)


def signal_score(collected: int, share: int, comment: int, liked: int) -> float:
    return (
        math.log1p(collected) * 0.35 +
        math.log1p(share)     * 0.30 +
        math.log1p(comment)   * 0.25 +
        math.log1p(liked)     * 0.10
    )


def risk_check(note: dict, keywords: list[str]) -> Optional[str]:
    text = (note.get("title", "") + note.get("text", "") + note.get("desc", ""))
    for kw in keywords:
        if kw in text:
            return kw
    return None


# ── 笔记加载 ───────────────────────────────────────────────────────────────────

def load_notes(data_dir: Path) -> list[dict]:
    notes = []
    video_dir      = data_dir / "video"
    image_text_dir = data_dir / "image_text"

    if video_dir.exists():
        for note_dir in sorted(video_dir.iterdir()):
            meta_path = note_dir / "meta.json"
            if meta_path.exists():
                d = json.loads(meta_path.read_text())
                d["_path"] = str(meta_path)
                d["_type"] = "video"
                d["_note_id"] = note_dir.name
                notes.append(d)

    if image_text_dir.exists():
        for f in sorted(image_text_dir.glob("*.json")):
            d = json.loads(f.read_text())
            d["_path"] = str(f)
            d["_type"] = "image_text"
            d["_note_id"] = f.stem
            notes.append(d)

    return notes


# ── Benchmark 建立 ─────────────────────────────────────────────────────────────

def build_benchmark(notes: list[dict], creator_name: str, user_id: str = "") -> dict:
    def get_metrics(note):
        m = note.get("metrics", note.get("interact_info", {}))
        return {
            "liked":     _to_int(m.get("liked_count", 0)),
            "collected": _to_int(m.get("collected_count", 0)),
            "comment":   _to_int(m.get("comment_count", 0)),
            "share":     _to_int(m.get("share_count", 0)),
        }

    all_metrics = [get_metrics(n) for n in notes]
    collecteds = [m["collected"] for m in all_metrics]
    shareds    = [m["share"]     for m in all_metrics]
    comments   = [m["comment"]   for m in all_metrics]
    likeds     = [m["liked"]     for m in all_metrics]

    def pcts(data):
        return {
            "p50": round(percentile(data, 50)),
            "p75": round(percentile(data, 75)),
            "p90": round(percentile(data, 90)),
            "p95": round(percentile(data, 95)),
        }

    def avg(data):
        return round(sum(data) / len(data)) if data else 0

    return {
        "creator": creator_name,
        "user_id": user_id,
        "computed_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "sample_size": len(notes),
        "benchmark": {
            "collected": pcts(collecteds),
            "liked":     pcts(likeds),
            "comment":   pcts(comments),
            "share":     pcts(shareds),
            "avg": {
                "collected": avg(collecteds),
                "liked":     avg(likeds),
                "comment":   avg(comments),
                "share":     avg(shareds),
            },
        },
    }


# ── 重新分级 ───────────────────────────────────────────────────────────────────

def tier_by_benchmark(collected: int, bm: dict) -> str:
    b = bm["benchmark"]["collected"]
    if collected >= b["p95"]: return "S"
    if collected >= b["p90"]: return "A"
    if collected >= b["p75"]: return "B"
    return "C"


def rerate_notes(notes: list[dict], bm: dict) -> dict:
    tier_counts = {"S": 0, "A": 0, "B": 0, "C": 0}

    for note in notes:
        m = note.get("metrics", note.get("interact_info", {}))
        collected = _to_int(m.get("collected_count", 0))
        share     = _to_int(m.get("share_count", 0))
        comment   = _to_int(m.get("comment_count", 0))
        liked     = _to_int(m.get("liked_count", 0))

        sc    = signal_score(collected, share, comment, liked)
        tier  = tier_by_benchmark(collected, bm)
        norm  = round(sc / 9.21 * 100, 1)

        note["material_tier"]        = tier
        note["signal_score"]         = norm
        note["metrics"] = {
            "liked_count":     str(liked),
            "collected_count": str(collected),
            "comment_count":   str(comment),
            "share_count":     str(share),
        }
        tier_counts[tier] += 1

        # 写回文件
        path = Path(note["_path"])
        out  = {k: v for k, v in note.items() if not k.startswith("_")}
        path.write_text(json.dumps(out, ensure_ascii=False, indent=2))

    return tier_counts


# ── 风险过滤 ───────────────────────────────────────────────────────────────────

def run_risk_filter(notes: list[dict], blocked_dir: Path, risk_keywords: list[str]) -> int:
    blocked_dir.mkdir(parents=True, exist_ok=True)
    blocked = 0

    for note in notes:
        if note.get("_type") != "image_text":
            continue
        hit = risk_check(note, risk_keywords)
        if hit:
            src = Path(note["_path"])
            dst = blocked_dir / src.name
            shutil.move(str(src), str(dst))
            meta = json.loads(dst.read_text())
            meta["material_tier"]  = "blocked"
            meta["blocked_reason"] = hit
            dst.write_text(json.dumps(meta, ensure_ascii=False, indent=2))
            print(f"  → blocked: {src.name} (命中: {hit})")
            blocked += 1

    return blocked


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="建立 Benchmark + 重新分级 + 风险过滤")
    parser.add_argument("--data-dir", required=True, help="{category}/ 目录（含 video/ image_text/）")
    parser.add_argument("--registry-dir", default="./output/creator_registry/", help="Benchmark 输出目录")
    parser.add_argument("--creator-name", default="unknown", help="博主名称")
    parser.add_argument("--user-id", default="", help="博主 user_id")
    parser.add_argument("--risk-filter", action="store_true", help="执行风险关键词过滤")
    parser.add_argument("--risk-keywords-file", default=None, help="自定义风险关键词文件（每行一个）")
    args = parser.parse_args()

    data_dir     = Path(args.data_dir).expanduser()
    registry_dir = Path(args.registry_dir).expanduser()
    registry_dir.mkdir(parents=True, exist_ok=True)

    # 加载笔记
    notes = load_notes(data_dir)
    print(f"✓ 加载 {len(notes)} 条笔记")
    if not notes:
        print("无笔记，退出")
        return

    # Benchmark
    bm = build_benchmark(notes, args.creator_name, args.user_id)
    bm_path = registry_dir / f"{args.creator_name}_benchmark.json"
    bm_path.write_text(json.dumps(bm, ensure_ascii=False, indent=2))
    b = bm["benchmark"]["collected"]
    print(f"✓ Benchmark: P50={b['p50']} P75={b['p75']} P90={b['p90']} P95={b['p95']}")

    # 重新分级
    tier_counts = rerate_notes(notes, bm)
    print(f"✓ 分级: S={tier_counts['S']} A={tier_counts['A']} B={tier_counts['B']} C={tier_counts['C']}")

    # 风险过滤
    if args.risk_filter:
        risk_keywords = DEFAULT_RISK_KEYWORDS
        if args.risk_keywords_file:
            kf = Path(args.risk_keywords_file)
            if kf.exists():
                risk_keywords = [l.strip() for l in kf.read_text().splitlines() if l.strip()]
                print(f"✓ 使用自定义风险关键词: {len(risk_keywords)} 个")
        blocked_dir = data_dir / "image_text_blocked"
        blocked = run_risk_filter(notes, blocked_dir, risk_keywords)
        print(f"✓ 风险过滤: {blocked} 条移至 image_text_blocked/")
    else:
        print("（风险过滤已跳过，使用 --risk-filter 启用）")


if __name__ == "__main__":
    main()
