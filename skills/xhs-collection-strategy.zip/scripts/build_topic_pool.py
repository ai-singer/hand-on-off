#!/usr/bin/env python3
"""
build_topic_pool.py
从视频 S/A 级笔记提取话题候选，追加到 topic_pool.json

话题池条目包含：
  topic        话题词
  angle        切入视角
  mechanism    核心机制描述
  content_hook 内容钩子文案
  source_url   原始笔记 URL

视频笔记处理原则：
  - 视频 = topic_discovery 角色（发现用户痛点和热度信号）
  - 不对视频做内容蒸馏，只提取话题结构
  - 如有 transcript.json，优先从字幕提取话题

用法:
  python3 build_topic_pool.py \
    --video-dir ./output/{category}/video/ \
    --pool-path ./output/creator_registry/topic_pool.json \
    --tier S,A
"""

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


# ── 话题推断（基于 title + tags + transcript）─────────────────────────────────

def infer_topic_from_text(title: str, tags: list[str], transcript: str = "") -> dict:
    """
    从标题、标签、字幕中提取话题结构。
    优先使用 title 作为话题词，transcript 辅助补充 mechanism。

    返回: {topic, angle, mechanism, content_hook}
    """
    combined = title + " " + " ".join(tags) + " " + transcript[:200]

    # 基于 title 生成话题结构
    topic = title[:20].strip() if title else "未知话题"
    angle = "机制解释视角"
    mechanism = "详见笔记正文"
    content_hook = f"{title[:25]}，背后是什么逻辑？" if title else "背后是什么逻辑？"

    # 简单语义模式匹配（可扩展）
    if any(kw in combined for kw in ["为什么", "怎么", "如何", "原因", "逻辑"]):
        angle = "问题机制拆解"
        content_hook = title[:30] if title else content_hook

    elif any(kw in combined for kw in ["真相", "秘密", "内幕", "背后"]):
        angle = "反直觉揭秘视角"

    elif any(kw in combined for kw in ["多少钱", "赚钱", "收入", "利润", "成本"]):
        angle = "利益结构分析"

    # 从 transcript 补充 mechanism（取前两句）
    if transcript:
        sentences = [s.strip() for s in transcript.replace("。", "。\n").split("\n") if s.strip()]
        if sentences:
            mechanism = sentences[0][:60]

    return {
        "topic":        topic,
        "angle":        angle,
        "mechanism":    mechanism,
        "content_hook": content_hook,
    }


# ── 单条处理 ───────────────────────────────────────────────────────────────────

def process_video_note(note_dir: Path) -> Optional[dict]:
    meta_path       = note_dir / "meta.json"
    transcript_path = note_dir / "transcript.json"

    if not meta_path.exists():
        return None

    meta = json.loads(meta_path.read_text())

    # 加载字幕（如有）
    transcript_text = ""
    if transcript_path.exists():
        try:
            t = json.loads(transcript_path.read_text())
            transcript_text = t.get("full_text", "")
        except Exception:
            pass

    title = meta.get("title", "")
    tags  = meta.get("tags", [])
    inferred = infer_topic_from_text(title, tags, transcript_text)

    m = meta.get("metrics", {})

    return {
        "note_id":       note_dir.name,
        "material_tier": meta.get("material_tier", "?"),
        "signal_score":  meta.get("signal_score", 0),
        "source_title":  title,
        "metrics": {
            "liked":     int(str(m.get("liked_count", 0)).replace(",", "") or 0),
            "collected": int(str(m.get("collected_count", 0)).replace(",", "") or 0),
            "comment":   int(str(m.get("comment_count", 0)).replace(",", "") or 0),
            "share":     int(str(m.get("share_count", 0)).replace(",", "") or 0),
        },
        "topic":        inferred["topic"],
        "angle":        inferred["angle"],
        "mechanism":    inferred["mechanism"],
        "content_hook": inferred["content_hook"],
        "tags":         tags,
        "has_transcript": bool(transcript_text),
        "source_url":   f"https://www.xiaohongshu.com/explore/{note_dir.name}",
        "extracted_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="视频 S/A 级笔记 → 话题候选池")
    parser.add_argument("--video-dir", required=True, help="video/{note_id}/ 目录")
    parser.add_argument("--pool-path", required=True, help="topic_pool.json 路径（追加模式）")
    parser.add_argument("--tier", default="S,A", help="筛选评级（默认 S,A）")
    args = parser.parse_args()

    video_dir = Path(args.video_dir).expanduser()
    pool_path = Path(args.pool_path).expanduser()
    tiers = [t.strip() for t in args.tier.split(",")]

    # 加载已有 topic pool
    if pool_path.exists():
        pool = json.loads(pool_path.read_text())
        existing_ids = {e["note_id"] for e in pool}
    else:
        pool = []
        existing_ids = set()

    pool_path.parent.mkdir(parents=True, exist_ok=True)
    added = 0

    for note_dir in sorted(video_dir.iterdir()):
        if not note_dir.is_dir():
            continue
        if note_dir.name in existing_ids:
            continue

        meta_path = note_dir / "meta.json"
        if not meta_path.exists():
            continue
        meta = json.loads(meta_path.read_text())
        if meta.get("material_tier") not in tiers:
            continue

        entry = process_video_note(note_dir)
        if not entry:
            continue

        pool.append(entry)
        existing_ids.add(note_dir.name)
        added += 1
        print(f"  [{entry['material_tier']}] {entry['source_title'][:40]}")
        print(f"       topic: {entry['topic']}")
        print(f"       hook:  {entry['content_hook']}")
        print()

    pool_path.write_text(json.dumps(pool, ensure_ascii=False, indent=2))
    print(f"✓ topic_pool.json 更新: 新增 {added} 条，共 {len(pool)} 条")
    print(f"  路径: {pool_path}")


if __name__ == "__main__":
    main()
