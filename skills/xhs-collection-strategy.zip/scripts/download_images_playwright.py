#!/usr/bin/env python3
"""
download_images_playwright.py
小红书图片下载器（Playwright 同 Context 方案）

重要：XHS CDN（sns-webpic-qc.xhscdn.com）绑定浏览器 IP。
curl/requests 直接请求一律 403，必须在 Playwright 同一 browser context 内下载。

用法:
  python3 download_images_playwright.py \
    --source-dir ./source_material/{category}/image_text/ \
    --output-dir ./source_material/{category}/image_text_imgs/ \
    --tier S,A \
    --max 20

依赖:
  pip install playwright
  playwright install chromium

失败方案（不要重试）:
  - curl 直接请求 CDN URL → 403（IP 白名单）
  - curl + Cookie → 403（CDN 不验证 Cookie）
  - Stage 2 存储的 URL 延迟请求 → 403（签名过期）
"""

import argparse
import json
import time
from pathlib import Path
from typing import Optional


# ── Cookie 加载（Playwright 格式）─────────────────────────────────────────────

def load_cookie_list(cookie_path: Optional[str] = None) -> list[dict]:
    candidates = []
    if cookie_path:
        candidates.append(Path(cookie_path))
    for p in [
        Path.home() / "workspace" / "xiaohongshu_cookies.txt",
        Path.home() / ".openclaw" / "workspace" / "xiaohongshu_cookies.txt",
        Path("xiaohongshu_cookies.txt"),
    ]:
        candidates.append(p)

    for p in candidates:
        if not p.exists():
            continue
        content = p.read_text(encoding="utf-8").strip()
        if not content:
            continue
        if "\t" in content:
            cookies = []
            for line in content.splitlines():
                if line.strip() and not line.startswith("#"):
                    parts = line.split("\t")
                    if len(parts) >= 7:
                        cookies.append({
                            "name": parts[5], "value": parts[6],
                            "domain": ".xiaohongshu.com", "path": "/",
                        })
            if cookies:
                return cookies
        else:
            cookies = []
            for pair in content.split(";"):
                pair = pair.strip()
                if "=" in pair:
                    k, v = pair.split("=", 1)
                    cookies.append({
                        "name": k.strip(), "value": v.strip(),
                        "domain": ".xiaohongshu.com", "path": "/",
                    })
            if cookies:
                return cookies

    raise FileNotFoundError("Cookie file not found")


# ── 下载逻辑 ───────────────────────────────────────────────────────────────────

def get_live_img_urls(page, note_id: str, wait_sec: int = 5) -> list[str]:
    """打开笔记页，拦截实时图片 URL"""
    captured = []

    def on_response(resp):
        url = resp.url
        if "sns-webpic" in url and resp.status == 200:
            # 过滤非内容图片
            skip_patterns = ["avatar", "icon", "fe-static", "spectrum"]
            if not any(s in url for s in skip_patterns):
                captured.append(url)

    page.on("response", on_response)
    try:
        page.goto(
            f"https://www.xiaohongshu.com/explore/{note_id}?xsec_source=pc_feed",
            referer="https://www.xiaohongshu.com/explore",
            timeout=20000,
        )
        time.sleep(wait_sec)
    except Exception as e:
        print(f"  ⚠ 页面加载异常: {e}")
    finally:
        page.remove_listener("response", on_response)

    # 检查 IP 封禁
    title = page.title()
    if "不见了" in title or "404" in title:
        print(f"  × 页面不可访问（IP 被限流）")
        return []

    return captured


def download_images_in_context(context, note_id: str, img_urls: list[str], out_dir: Path,
                                 batch_size: int = 10, delay: float = 3.0) -> list[str]:
    """在同一 context 内新建 page 下载图片（关键：同 context 才能绕过 CDN 鉴权）"""
    out_dir.mkdir(parents=True, exist_ok=True)
    saved = []
    img_page = context.new_page()

    for i, url in enumerate(img_urls[:batch_size]):
        out_path = out_dir / f"img_{i:02d}.jpg"
        if out_path.exists():
            saved.append(str(out_path))
            continue
        try:
            resp = img_page.goto(url, timeout=15000)
            if resp and resp.status == 200:
                body = resp.body()
                if len(body) > 1024:
                    out_path.write_bytes(body)
                    saved.append(str(out_path))
                    print(f"    ✓ img_{i:02d}: {len(body)//1024} KB")
                else:
                    print(f"    × img_{i:02d}: 文件过小，跳过")
            else:
                print(f"    × img_{i:02d}: HTTP {resp.status if resp else 'None'}")
        except Exception as e:
            print(f"    × img_{i:02d}: {e}")
        time.sleep(delay)

    img_page.close()
    return saved


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="XHS 图片下载器（Playwright）")
    parser.add_argument("--source-dir", required=True, help="标准化 JSON 目录（含 note_id.json）")
    parser.add_argument("--output-dir", required=True, help="图片输出目录")
    parser.add_argument("--tier", default="S,A", help="筛选评级（逗号分隔，默认 S,A）")
    parser.add_argument("--max", type=int, default=20, help="最多处理笔记数（默认 20）")
    parser.add_argument("--wait-sec", type=int, default=5, help="每条笔记页面等待秒数（默认 5）")
    parser.add_argument("--delay", type=float, default=3.0, help="图片间延迟（默认 3s）")
    parser.add_argument("--cookie", default=None, help="Cookie 文件路径")
    args = parser.parse_args()

    from playwright.sync_api import sync_playwright

    source_dir = Path(args.source_dir).expanduser()
    output_dir = Path(args.output_dir).expanduser()
    tiers = tuple(t.strip() for t in args.tier.split(","))

    cookies = load_cookie_list(args.cookie)
    print(f"✓ 加载 {len(cookies)} 个 Cookie")

    # 收集目标笔记
    targets = []
    for f in sorted(source_dir.glob("*.json")):
        try:
            meta = json.loads(f.read_text())
        except Exception:
            continue
        if meta.get("material_tier") in tiers:
            out_dir = output_dir / f.stem
            if not out_dir.exists() or not list(out_dir.glob("*.jpg")):
                targets.append((f.stem, meta))

    print(f"待下载: {len(targets)} 条（评级 {tiers}）")
    targets = targets[:args.max]

    results = {"ok": 0, "blocked": 0, "failed": 0}

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(
            user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
            viewport={"width": 1920, "height": 1080},
        )
        context.add_init_script(
            "Object.defineProperty(navigator, 'webdriver', { get: () => undefined });"
        )
        context.add_cookies(cookies)
        page = context.new_page()

        # 先建立 session
        print("→ 建立 session...")
        page.goto("https://www.xiaohongshu.com/explore", timeout=20000)
        time.sleep(3)

        for i, (note_id, meta) in enumerate(targets):
            title = meta.get("title", meta.get("post_id", note_id))[:40]
            print(f"\n[{i+1}/{len(targets)}] [{meta.get('material_tier','?')}] {title}")

            img_urls = get_live_img_urls(page, note_id, args.wait_sec)
            if not img_urls:
                results["blocked"] += 1
                print("  → IP 被限流，停止本批次")
                break

            saved = download_images_in_context(
                context, note_id, img_urls,
                out_dir=output_dir / note_id,
                delay=args.delay,
            )
            if saved:
                results["ok"] += 1
                print(f"  ✓ 保存 {len(saved)} 张")
            else:
                results["failed"] += 1

            time.sleep(5)  # 笔记间隔

        browser.close()

    print(f"\n完成: 成功={results['ok']} 限流={results['blocked']} 失败={results['failed']}")


if __name__ == "__main__":
    main()
