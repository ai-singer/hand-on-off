#!/usr/bin/env python3
"""
download_video_playwright.py
小红书视频下载器（Playwright 实时 CDN 拦截 + ffmpeg）

重要：视频 CDN URL 含时效签名，Stage 2 存入后很快过期（403）。
必须通过 Playwright 打开笔记页面，实时拦截浏览器发出的视频媒体请求。

用法:
  # 单条
  python3 download_video_playwright.py --note-id <note_id> --out-dir ./output/video/

  # 批量（按评级）
  python3 download_video_playwright.py --meta-dir ./source_material/{category}/video/ --tier S,A

依赖:
  pip install playwright
  playwright install chromium
  apt install ffmpeg  (或对应系统包管理器)

失败方案（不要重试）:
  - 直接使用 Stage 2 meta.json 中的 CDN URL → 403（签名过期）
  - yt-dlp + Cookie → No video formats found
  - media_v2.stream 中的 URL → 403（同样过期）
"""

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).resolve().parent))
from human_pacing import human_delay, batch_rest  # noqa: E402  真人化节奏控制


VIDEO_CDN_HOSTS = [
    "sns-video-bd.xhscdn.com",
    "sns-video-hw.xhscdn.com",
    "sns-video-qc.xhscdn.com",
    "sns-video-al.xhscdn.com",
]


# ── Cookie 加载 ────────────────────────────────────────────────────────────────

def _skill_dir_cookie_candidates() -> list[Path]:
    """随包分发的 cookie（v1.1.0）。"""
    dirs = []
    env_dir = os.environ.get("XHS_SKILL_DIR")
    if env_dir:
        dirs.append(Path(env_dir))
    try:
        dirs.append(Path(__file__).resolve().parent.parent)
    except NameError:
        pass
    return [d / "xiaohongshu_cookies.txt" for d in dirs]


def load_cookie_list(cookie_path: Optional[str] = None) -> list[dict]:
    candidates = []
    if cookie_path:
        candidates.append(Path(cookie_path))
    for p in _skill_dir_cookie_candidates() + [
        Path.home() / "workspace" / "xiaohongshu_cookies.txt",
        Path.home() / ".openclaw" / "workspace" / "xiaohongshu_cookies.txt",
        Path("xiaohongshu_cookies.txt"),
    ]:
        candidates.append(p)

    for p in candidates:
        if not p.exists():
            continue
        content = p.read_text(encoding="utf-8").strip()
        if not content:
            continue
        if "\t" in content:
            cookies = []
            for line in content.splitlines():
                if line.strip() and not line.startswith("#"):
                    parts = line.split("\t")
                    if len(parts) >= 7:
                        cookies.append({
                            "name": parts[5], "value": parts[6],
                            "domain": ".xiaohongshu.com", "path": "/",
                        })
            if cookies:
                return cookies
        else:
            cookies = []
            for pair in content.split(";"):
                pair = pair.strip()
                if "=" in pair:
                    k, v = pair.split("=", 1)
                    cookies.append({
                        "name": k.strip(), "value": v.strip(),
                        "domain": ".xiaohongshu.com", "path": "/",
                    })
            if cookies:
                return cookies

    raise FileNotFoundError("Cookie file not found")


# ── Playwright 拦截 ────────────────────────────────────────────────────────────

def intercept_video_url(note_id: str, cookies: list[dict], wait_sec: int = 8) -> Optional[str]:
    """打开笔记页，实时拦截视频 CDN 请求，返回带有效签名的 URL"""
    from playwright.sync_api import sync_playwright

    captured = []

    def on_response(response):
        url = response.url
        if any(h in url for h in VIDEO_CDN_HOSTS):
            if any(x in url for x in ["/stream/", ".mp4", "video"]):
                if "thumbnail" not in url and "thumb" not in url:
                    if url not in captured:
                        captured.append(url)
                        print(f"  ✓ 拦截: {url[:80]}")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(
            user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                       "AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
        )
        context.add_cookies(cookies)
        page = context.new_page()
        page.on("response", on_response)

        try:
            page.goto(
                f"https://www.xiaohongshu.com/explore/{note_id}",
                timeout=30000,
            )
            page.wait_for_timeout(wait_sec * 1000)
        except Exception as e:
            print(f"  ⚠ 页面加载异常: {e}")

        browser.close()

    if not captured:
        return None
    return max(captured, key=len)  # 优先最长 URL（通常最高画质）


# ── ffmpeg 下载 ────────────────────────────────────────────────────────────────

def download_with_ffmpeg(video_url: str, out_path: Path) -> bool:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    cmd = ["ffmpeg", "-y", "-i", video_url, "-c", "copy", str(out_path)]
    print(f"  → ffmpeg 下载...")
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if result.returncode == 0:
            size = out_path.stat().st_size // 1024
            print(f"  ✓ 完成: {size} KB → {out_path.name}")
            return True
        else:
            print(f"  × 失败: {result.stderr[-200:]}")
            return False
    except subprocess.TimeoutExpired:
        print("  × 超时（120s）")
        return False


# ── 单条处理 ───────────────────────────────────────────────────────────────────

def process_note(note_id: str, out_base: Path, cookies: list[dict]) -> dict:
    video_path = out_base / note_id / "video.mp4"
    if video_path.exists() and video_path.stat().st_size > 1024:
        return {"note_id": note_id, "status": "skip"}

    print(f"\n[{note_id}]")
    video_url = intercept_video_url(note_id, cookies)
    if not video_url:
        print("  × 未拦截到视频 URL（可能页面被限流）")
        return {"note_id": note_id, "status": "no_url"}

    ok = download_with_ffmpeg(video_url, video_path)
    return {
        "note_id": note_id,
        "status": "ok" if ok else "failed",
        "video_path": str(video_path) if ok else None,
    }


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="XHS 视频下载器（Playwright 实时拦截）")
    parser.add_argument("--note-id", help="单条笔记 note_id")
    parser.add_argument("--meta-dir", help="批量处理：video/{note_id}/ 目录")
    parser.add_argument("--tier", default="S,A", help="批量评级过滤（默认 S,A）")
    parser.add_argument("--out-dir", default="./output/video/", help="单条模式输出目录")
    parser.add_argument("--delay", type=int, default=5, help="批量笔记间延迟秒数（默认 5）")
    parser.add_argument("--wait-sec", type=int, default=8, help="每条页面等待秒数（默认 8）")
    parser.add_argument("--cookie", default=None, help="Cookie 文件路径")
    parser.add_argument("--enforce-window", action="store_true",
                        help="非活跃时段（08:00–23:00 之外）直接退出")
    args = parser.parse_args()

    if not warn_off_hours(enforce=args.enforce_window):
        sys.exit(0)
    session_startup()

    cookies = load_cookie_list(args.cookie)
    print(f"✓ 加载 {len(cookies)} 个 Cookie")

    if args.note_id:
        budget_guard("playwright_note")
        out_base = Path(args.out_dir).expanduser()
        result = process_note(args.note_id, out_base, cookies)
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif args.meta_dir:
        meta_dir = Path(args.meta_dir).expanduser()
        tiers = [t.strip() for t in args.tier.split(",")]
        results = []

        for note_dir in sorted(meta_dir.iterdir()):
            meta_path = note_dir / "meta.json"
            if not meta_path.exists():
                continue
            meta = json.loads(meta_path.read_text())
            if meta.get("material_tier") not in tiers:
                continue
            budget_guard("playwright_note")
            result = process_note(note_dir.name, meta_dir, cookies)
            results.append(result)
            human_delay(args.delay, kind="playwright_note")
            batch_rest()

        ok = sum(1 for r in results if r["status"] == "ok")
        skip = sum(1 for r in results if r["status"] == "skip")
        failed = sum(1 for r in results if r["status"] not in ("ok", "skip"))
        print(f"\n✓ 完成: 成功={ok} 跳过={skip} 失败={failed}")

    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
