#!/usr/bin/env python3
"""
extract_asr.py
从视频文件提取 ASR 字幕（faster-whisper）

用法:
  python3 extract_asr.py \
    --video-dir ./source_material/{category}/video/ \
    --tier S,A \
    --language zh

依赖:
  pip install faster-whisper

网络配置（HuggingFace 不可达时）:
  export HF_ENDPOINT=https://hf-mirror.com
"""

import argparse
import json
import os
from datetime import datetime, timezone
from pathlib import Path


def extract_asr(video_path: Path, language: str = "zh") -> dict:
    """从视频提取 ASR 字幕，返回结构化结果"""
    from faster_whisper import WhisperModel

    model = WhisperModel("base", device="cpu", compute_type="int8")
    segments_gen, info = model.transcribe(str(video_path), language=language)

    segments = []
    full_text_parts = []
    for seg in segments_gen:
        segments.append({
            "start": round(seg.start, 2),
            "end": round(seg.end, 2),
            "text": seg.text.strip(),
        })
        full_text_parts.append(seg.text.strip())

    return {
        "language": info.language,
        "duration": round(info.duration, 2) if hasattr(info, "duration") else None,
        "segments": segments,
        "full_text": "".join(full_text_parts),
        "extracted_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


def process_video_dir(video_dir: Path, tiers: list[str], language: str = "zh"):
    results = {"ok": 0, "skip": 0, "failed": 0}

    for note_dir in sorted(video_dir.iterdir()):
        if not note_dir.is_dir():
            continue
        meta_path = note_dir / "meta.json"
        video_path = note_dir / "video.mp4"
        transcript_path = note_dir / "transcript.json"

        if not meta_path.exists() or not video_path.exists():
            continue
        if transcript_path.exists():
            results["skip"] += 1
            continue

        meta = json.loads(meta_path.read_text())
        if meta.get("material_tier") not in tiers:
            continue

        note_id = note_dir.name
        title = meta.get("title", note_id)[:40]
        print(f"[{note_id}] {title}")

        try:
            transcript = extract_asr(video_path, language=language)
            transcript["note_id"] = note_id
            transcript_path.write_text(
                json.dumps(transcript, ensure_ascii=False, indent=2)
            )
            print(f"  ✓ {len(transcript['segments'])} 段, {len(transcript['full_text'])} 字")
            results["ok"] += 1
        except Exception as e:
            print(f"  × 失败: {e}")
            results["failed"] += 1

    print(f"\n完成: 成功={results['ok']} 跳过={results['skip']} 失败={results['failed']}")
    return results


def main():
    parser = argparse.ArgumentParser(description="视频 ASR 字幕提取（faster-whisper）")
    parser.add_argument("--video-dir", required=True, help="video/{note_id}/ 目录")
    parser.add_argument("--tier", default="S,A", help="评级过滤（默认 S,A）")
    parser.add_argument("--language", default="zh", help="语言（默认 zh）")
    args = parser.parse_args()

    # HuggingFace 镜像提示
    if not os.environ.get("HF_ENDPOINT"):
        print("提示: 如 HuggingFace 不可达，请设置 HF_ENDPOINT=https://hf-mirror.com")

    video_dir = Path(args.video_dir).expanduser()
    tiers = [t.strip() for t in args.tier.split(",")]

    process_video_dir(video_dir, tiers, args.language)


if __name__ == "__main__":
    main()
