#!/usr/bin/env python3
"""
human_pacing.py — 真人化访问节奏控制（v1.2.0）

目的：让采集请求的时间分布接近真人操作，而不是机器式的等间隔轮询，
降低被平台风控识别并封禁的概率。

四层保护：
  1. 抖动间隔   —— 固定间隔是最强的机器特征。基础间隔上叠加随机抖动。
  2. 长尾停顿   —— 小概率插入"走神/思考"式长停顿，模拟真人节奏不均匀。
  3. 批次休息   —— 连续 N 次请求后强制长休息，模拟"看完一批去干别的"。
  4. 日额度     —— 硬上限，超出直接停止，避免单日过度采集。

另含活跃时段检查（默认只告警，不阻断）。

用法（同步）:
    from human_pacing import human_delay, batch_rest, budget_guard
    human_delay(3.0, kind="stage2")
    batch_rest()

用法（异步）:
    from human_pacing import ahuman_delay
    await ahuman_delay(3.0, kind="stage1")
"""

import asyncio
import json
import os
import random
import sys
import time
from datetime import datetime
from pathlib import Path

# ── 参数 ───────────────────────────────────────────────────────────────────────

JITTER_MAX = 0.9          # 上浮比例：实际间隔 = base × [1.0, 1.0+JITTER_MAX]
JITTER_MIN = 0.0          # 下浮比例（0 = 不低于基础间隔，保证速率下限）
LONG_TAIL_P = 0.07        # 长尾停顿触发概率
LONG_TAIL_MIN_MULT = 2.0  # 长尾下限（× base）
LONG_TAIL_MAX_MULT = 6.0  # 长尾上限（× base）

BATCH_SIZE = 12           # 连续多少次请求后强休
BATCH_REST_MIN = 60.0     # 强休下限（秒）
BATCH_REST_MAX = 240.0    # 强休上限（秒）

SESSION_STARTUP_MIN = 1.5  # 会话启动前的随机延迟
SESSION_STARTUP_MAX = 6.0

# 日额度（见 docs/rate_limit_guide.md）
DAILY_LIMITS = {
    "stage1": 60,
    "stage2": 300,
    "playwright_note": 50,
    "image": 400,
    "search": 60,
}

ACTIVE_HOUR_START = 8     # 活跃时段（本地时区）
ACTIVE_HOUR_END = 23

# ── 状态 ───────────────────────────────────────────────────────────────────────


def _state_path() -> Path:
    env = os.environ.get("XHS_PACING_STATE")
    if env:
        return Path(env)
    for cand in [
        Path.home() / ".openclaw" / "workspace" / ".xhs_pacing_state.json",
        Path.home() / "workspace" / ".xhs_pacing_state.json",
        Path("/tmp/.xhs_pacing_state.json"),
    ]:
        try:
            cand.parent.mkdir(parents=True, exist_ok=True)
            if cand.exists() or os.access(cand.parent, os.W_OK):
                return cand
        except Exception:
            continue
    return Path("/tmp/.xhs_pacing_state.json")


def _load_state() -> dict:
    p = _state_path()
    today = datetime.now().strftime("%Y-%m-%d")
    try:
        st = json.loads(p.read_text())
    except Exception:
        st = {}
    if st.get("date") != today:
        st = {"date": today, "counts": {}, "since_rest": 0, "ops": 0}
    st.setdefault("counts", {})
    st.setdefault("since_rest", 0)
    st.setdefault("ops", 0)
    return st


def _save_state(st: dict):
    try:
        _state_path().write_text(json.dumps(st, ensure_ascii=False, indent=2))
    except Exception:
        pass


def note(msg: str):
    print(f"  ⏱  {msg}", file=sys.stderr, flush=True)


# ── 核心延迟 ───────────────────────────────────────────────────────────────────


def _compute_delay(base: float) -> tuple[float, str]:
    """返回 (秒数, 说明)"""
    lo = base * (1.0 - JITTER_MIN)
    hi = base * (1.0 + JITTER_MAX)
    d = random.uniform(lo, hi)
    reason = ""
    if random.random() < LONG_TAIL_P:
        d = base * random.uniform(LONG_TAIL_MIN_MULT, LONG_TAIL_MAX_MULT)
        reason = "长尾停顿"
    return d, reason


def human_delay(base: float = 3.0, kind: str = "", quiet: bool = False):
    """同步真人化延迟。base 为速率限制表里的最小间隔。"""
    d, reason = _compute_delay(base)
    if not quiet and reason:
        note(f"{reason} {d:.1f}s")
    time.sleep(d)
    _tick()


def async_human_delay_impl(base: float = 3.0, kind: str = "", quiet: bool = False):
    return _compute_delay(base)


async def ahuman_delay(base: float = 3.0, kind: str = "", quiet: bool = False):
    """异步真人化延迟。"""
    d, reason = _compute_delay(base)
    if not quiet and reason:
        note(f"{reason} {d:.1f}s")
    await asyncio.sleep(d)
    _tick()


def _tick():
    st = _load_state()
    st["since_rest"] = st.get("since_rest", 0) + 1
    st["ops"] = st.get("ops", 0) + 1
    _save_state(st)


# ── 批次休息 ───────────────────────────────────────────────────────────────────


def batch_rest(force: bool = False):
    """连续请求达到 BATCH_SIZE 后强制长休息。"""
    st = _load_state()
    if not force and st.get("since_rest", 0) < BATCH_SIZE:
        return
    secs = random.uniform(BATCH_REST_MIN, BATCH_REST_MAX)
    note(f"批次休息 {secs:.0f}s（已连续 {st.get('since_rest', 0)} 次请求）")
    time.sleep(secs)
    st = _load_state()
    st["since_rest"] = 0
    _save_state(st)


async def abatch_rest(force: bool = False):
    st = _load_state()
    if not force and st.get("since_rest", 0) < BATCH_SIZE:
        return
    secs = random.uniform(BATCH_REST_MIN, BATCH_REST_MAX)
    note(f"批次休息 {secs:.0f}s（已连续 {st.get('since_rest', 0)} 次请求）")
    await asyncio.sleep(secs)
    st = _load_state()
    st["since_rest"] = 0
    _save_state(st)


# ── 日额度 ─────────────────────────────────────────────────────────────────────


def budget_guard(kind: str, n: int = 1, raise_on_exceed: bool = True) -> bool:
    """检查并预占日额度。超限返回 False（或抛异常）。"""
    limit = DAILY_LIMITS.get(kind)
    if limit is None:
        return True
    st = _load_state()
    used = st["counts"].get(kind, 0)
    if used + n > limit:
        msg = f"日额度超限：{kind} 已用 {used}/{limit}，本次需 {n}"
        note(msg)
        if raise_on_exceed:
            raise RuntimeError(msg)
        return False
    st["counts"][kind] = used + n
    _save_state(st)
    return True


def budget_report() -> str:
    st = _load_state()
    lines = [f"日期 {st.get('date')}｜累计请求 {st.get('ops', 0)}｜距上次休息 {st.get('since_rest', 0)}"]
    for k, lim in DAILY_LIMITS.items():
        lines.append(f"  {k}: {st['counts'].get(k, 0)}/{lim}")
    return "\n".join(lines)


# ── 活跃时段 ───────────────────────────────────────────────────────────────────


def active_hours_ok(now: datetime | None = None) -> bool:
    h = (now or datetime.now()).hour
    return ACTIVE_HOUR_START <= h < ACTIVE_HOUR_END


def warn_off_hours(enforce: bool = False) -> bool:
    """活跃时段检查。enforce=True 时非活跃时段直接退出。"""
    if active_hours_ok():
        return True
    msg = (f"当前处于非活跃时段（{datetime.now():%H:%M}），"
           f"建议作业窗口 {ACTIVE_HOUR_START}:00–{ACTIVE_HOUR_END}:00")
    note(msg)
    if enforce:
        note("--enforce-window 已启用，停止执行")
        return False
    return True


def session_startup():
    """会话开始前的随机延迟，避免每次都在整点/固定间隔启动。"""
    d = random.uniform(SESSION_STARTUP_MIN, SESSION_STARTUP_MAX)
    time.sleep(d)


# ── CLI ────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="真人化节奏控制：状态查看与自检")
    ap.add_argument("--report", action="store_true", help="打印当日额度与请求统计")
    ap.add_argument("--reset", action="store_true", help="重置当日状态")
    ap.add_argument("--window", action="store_true", help="检查活跃时段")
    args = ap.parse_args()

    if args.reset:
        _save_state({"date": datetime.now().strftime("%Y-%m-%d"),
                     "counts": {}, "since_rest": 0, "ops": 0})
        print("状态已重置")
    elif args.window:
        print("活跃时段内" if active_hours_ok() else "非活跃时段")
    else:
        print(budget_report())
