#!/usr/bin/env python3
"""
normalize.py
XHS 原始 JSON → 标准化格式转换器 v2.0

将 scrape_two_stage.py 输出的原始 JSON 转换为标准化格式，
按垂类和内容格式分目录存储：
  output/{category}/video/{note_id}/meta.json
  output/{category}/image_text/{note_id}.json

Content Signal Score 公式（依据 source_strategy）:
  score = log1p(collected)*0.35 + log1p(share)*0.30
        + log1p(comment)*0.25  + log1p(liked)*0.10
  归一化：score / log1p(10000) × 100 → 0–100

分级（绝对值模式，无 Benchmark 时使用）:
  S ≥ 75 | A ≥ 50 | B ≥ 25 | C < 25

用法:
  python3 normalize.py <raw_file.json> <category> [--output-base ./output/]
"""

import argparse
import json
import math
from datetime import datetime, timezone
from pathlib import Path


# ── 评分与分级 ─────────────────────────────────────────────────────────────────

def _to_int(val) -> int:
    try:
        return int(str(val).replace(",", "").replace("+", "").strip())
    except (ValueError, TypeError):
        return 0


def compute_signal_score(metrics: dict) -> float:
    """
    Content Signal Score，基于 log1p 压缩后加权求和，归一化到 0–100。
    权重: collected×0.35, share×0.30, comment×0.25, liked×0.10
    基准: log1p(10000) ≈ 9.21
    """
    collected = _to_int(metrics.get("collected_count", 0))
    share     = _to_int(metrics.get("share_count", 0))
    comment   = _to_int(metrics.get("comment_count", 0))
    liked     = _to_int(metrics.get("liked_count", 0))

    raw = (
        math.log1p(collected) * 0.35 +
        math.log1p(share)     * 0.30 +
        math.log1p(comment)   * 0.25 +
        math.log1p(liked)     * 0.10
    )
    return round(min(raw / 9.21 * 100, 100.0), 2)


def score_to_tier(score: float) -> str:
    if score >= 75: return "S"
    if score >= 50: return "A"
    if score >= 25: return "B"
    return "C"


# ── 内容类型判断 ───────────────────────────────────────────────────────────────

def detect_content_type(note_card: dict) -> str:
    if note_card.get("video") or note_card.get("type") == "video":
        return "video"
    return "image_text"


# ── 单条标准化 ─────────────────────────────────────────────────────────────────

def normalize_note(note_card: dict, category: str, raw_ref: str = "") -> dict:
    images = []
    for img in note_card.get("image_list", []):
        url = img.get("url_default") or img.get("url_pre") or ""
        if not url:
            for info in img.get("info_list", []):
                if info.get("image_scene") in ("WB_DFT", "WB_PRV"):
                    url = info.get("url", "")
                    break
        if url:
            images.append({
                "url": url,
                "width": img.get("width"),
                "height": img.get("height"),
                "file_id": img.get("file_id", ""),
            })

    post_id      = note_card.get("note_id", "")
    interact     = note_card.get("interact_info", {})
    user         = note_card.get("user", {})
    content_type = detect_content_type(note_card)
    discovery_role = "topic_discovery" if content_type == "video" else "knowledge_distillation"

    metrics = {
        "liked_count":     interact.get("liked_count", "0"),
        "collected_count": interact.get("collected_count", "0"),
        "comment_count":   interact.get("comment_count", "0"),
        "share_count":     interact.get("share_count", "0"),
    }

    score = compute_signal_score(metrics)
    tier  = score_to_tier(score)

    return {
        "platform":             "xiaohongshu",
        "category":             category,
        "content_type":         content_type,
        "discovery_role":       discovery_role,
        "creator": {
            "id":     user.get("user_id", ""),
            "name":   user.get("nickname", ""),
            "avatar": user.get("avatar", ""),
        },
        "post_id":              post_id,
        "title":                note_card.get("title", ""),
        "text":                 note_card.get("desc", ""),
        "images":               images,
        "tags":                 [t.get("name", "") for t in note_card.get("tag_list", []) if t.get("name")],
        "metrics":              metrics,
        "content_signal_score": score,
        "material_tier":        tier,
        "topic_candidate":      None,
        "source_url":           f"https://www.xiaohongshu.com/explore/{post_id}",
        "collected_at":         datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "raw_ref":              raw_ref,
    }


# ── 批量处理 ───────────────────────────────────────────────────────────────────

def normalize_batch(raw_file: Path, output_base: Path, category: str) -> dict:
    raw_notes = json.loads(raw_file.read_text(encoding="utf-8"))
    stats = {"total": 0, "video": 0, "image_text": 0, "tiers": {"S": 0, "A": 0, "B": 0, "C": 0}}

    for note_card in raw_notes:
        normalized = normalize_note(
            note_card,
            category=category,
            raw_ref=f"raw/{raw_file.name}",
        )
        content_type = normalized["content_type"]
        post_id      = normalized["post_id"]
        tier         = normalized["material_tier"]

        if content_type == "video":
            out_dir = output_base / category / "video" / post_id
            out_dir.mkdir(parents=True, exist_ok=True)
            out_file = out_dir / "meta.json"
        else:
            out_dir = output_base / category / "image_text"
            out_dir.mkdir(parents=True, exist_ok=True)
            out_file = out_dir / f"{post_id}.json"

        out_file.write_text(json.dumps(normalized, ensure_ascii=False, indent=2))
        stats["total"]       += 1
        stats[content_type]  += 1
        stats["tiers"][tier] += 1

    return stats


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="XHS 笔记标准化工具 v2.0")
    parser.add_argument("raw_file", help="原始 JSON 文件路径（scrape_two_stage 输出）")
    parser.add_argument("category", help="垂类标签，如 finance / travel / general")
    parser.add_argument("--output-base", default="./output/", help="输出根目录（默认 ./output/）")
    args = parser.parse_args()

    raw_file    = Path(args.raw_file).expanduser()
    output_base = Path(args.output_base).expanduser()

    print(f"原始文件: {raw_file}")
    print(f"垂类: {args.category}")
    print(f"输出根目录: {output_base}")

    stats = normalize_batch(raw_file, output_base, args.category)

    print(f"\n✓ 标准化完成")
    print(f"  总计: {stats['total']} 条")
    print(f"  video: {stats['video']} 条 → topic_discovery")
    print(f"  image_text: {stats['image_text']} 条 → knowledge_distillation")
    print(f"  评级: S={stats['tiers']['S']} A={stats['tiers']['A']} B={stats['tiers']['B']} C={stats['tiers']['C']}")


if __name__ == "__main__":
    main()
