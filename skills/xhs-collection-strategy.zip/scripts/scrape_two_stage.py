#!/usr/bin/env python3
"""
scrape_two_stage.py
小红书两阶段笔记采集器

Stage 1: GET /api/sns/web/v1/user_posted → note_id + xsec_token 列表
Stage 2: POST /api/sns/web/v1/feed       → 完整笔记详情

用法:
  python3 scrape_two_stage.py --user-id <user_id> --creator-name <name> --max-notes 100 --output-dir ./output/

依赖:
  pip install aiohttp xhshow

Cookie 加载顺序（自动）:
  1. ~/workspace/xiaohongshu_cookies.txt  (Netscape 格式)
  2. .env 中 XHS_COOKIE=...
  3. ~/xhs-auto-bot/.env 中 XHS_COOKIE=...
"""

import argparse
import asyncio
import hashlib
import json
import sys
import time
from datetime import date
from pathlib import Path
from typing import Optional
from urllib.parse import quote

import aiohttp


# ── Cookie 加载 ────────────────────────────────────────────────────────────────

def _parse_netscape_cookies(content: str) -> str:
    cookies = []
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) >= 7:
            cookies.append(f"{parts[5]}={parts[6]}")
    return "; ".join(cookies)


def _load_cookie(cookie_path: Optional[str] = None) -> tuple[str, str]:
    """
    返回 (cookie_string, source_description)
    cookie_string 为空表示加载失败。
    """
    candidates = []
    if cookie_path:
        candidates.append(Path(cookie_path))
    # 通用搜索路径（不含硬编码生产路径）
    for p in [
        Path.home() / "workspace" / "xiaohongshu_cookies.txt",
        Path.home() / ".openclaw" / "workspace" / "xiaohongshu_cookies.txt",
        Path("xiaohongshu_cookies.txt"),
    ]:
        candidates.append(p)

    for p in candidates:
        if not p.exists():
            continue
        content = p.read_text(encoding="utf-8").strip()
        if not content:
            continue
        if "# Netscape HTTP Cookie File" in content or "\t" in content:
            converted = _parse_netscape_cookies(content)
            if converted:
                return converted, str(p) + " (Netscape)"
        else:
            return content, str(p)

    # 从 .env 文件读取
    for env_path in [
        Path(".env"),
        Path.home() / ".openclaw" / "workspace" / ".env",
        Path.home() / "xhs-auto-bot" / ".env",
    ]:
        if env_path.exists():
            for line in env_path.read_text(encoding="utf-8").splitlines():
                if line.startswith("XHS_COOKIE="):
                    val = line.split("=", 1)[1].strip().strip('"')
                    if val:
                        return val, str(env_path)

    return "", ""


# ── xhshow 签名补丁 ────────────────────────────────────────────────────────────

def _patch_xhshow_a3_hash():
    """修复 xhshow GET 请求 a3_hash 计算错误（body 为空时 md5 应对 path 计算）"""
    try:
        from xhshow.core.crypto import CryptoProcessor
        _original_build = CryptoProcessor.build_payload_array

        def _patched_build(self, hex_parameter, hex_md5_path, a1_value,
                           app_identifier="xhs-pc-web", string_param="",
                           timestamp=None, sign_state=None):
            payload = _original_build(
                self, hex_parameter, hex_md5_path, a1_value,
                app_identifier, string_param, timestamp, sign_state
            )
            if "{" not in string_param:
                correct_md5_hex = hashlib.md5(string_param.encode("utf-8")).hexdigest()
                correct_md5_bytes = [int(correct_md5_hex[i:i+2], 16) for i in range(0, 32, 2)]
                seed_byte = payload[4]
                ts_bytes = payload[8:16]
                correct_a3_hash = self._custom_hash_v2(list(ts_bytes) + correct_md5_bytes)
                for i in range(16):
                    payload[128 + i] = correct_a3_hash[i] ^ seed_byte
            return payload

        CryptoProcessor.build_payload_array = _patched_build
    except ImportError:
        pass  # xhshow 未安装时跳过


_patch_xhshow_a3_hash()


# ── 请求签名 ───────────────────────────────────────────────────────────────────

def sign_with_xhshow(uri: str, data=None, cookie_str: str = "", method: str = "POST") -> dict:
    from xhshow import Xhshow
    client = Xhshow()

    if method.upper() == "POST":
        headers = client.sign_headers_post(
            uri=uri,
            cookies=cookie_str,
            payload=data if isinstance(data, dict) else {},
        )
    else:
        # GET：对 uri?params 字符串计算签名
        if data and isinstance(data, dict):
            params_str = "&".join(
                f"{k}={quote(str(v), safe=',')}" for k, v in data.items()
            )
            content_string = f"{uri}?{params_str}"
        else:
            content_string = uri

        cookie_dict = client._parse_cookies(cookie_str)
        a1_value = cookie_dict.get("a1", "")
        ts = time.time()
        d_value = hashlib.md5(content_string.encode("utf-8")).hexdigest()
        payload_array = client.crypto_processor.build_payload_array(
            d_value, d_value, a1_value, "xhs-pc-web", content_string, ts
        )
        xor_result = client.crypto_processor.bit_ops.xor_transform_array(payload_array)
        config = client.config
        x3_b64 = client.crypto_processor.b64encoder.encode_x3(
            xor_result[:config.PAYLOAD_LENGTH]
        )
        sig_data = config.SIGNATURE_DATA_TEMPLATE.copy()
        sig_data["x3"] = config.X3_PREFIX + x3_b64
        x_s = config.XYS_PREFIX + client.crypto_processor.b64encoder.encode(
            json.dumps(sig_data, separators=(",", ":"), ensure_ascii=False)
        )
        headers = {
            "x-s": x_s,
            "x-s-common": client.sign_xs_common(cookie_dict),
            "x-t": str(client.get_x_t(ts)),
            "x-b3-traceid": client.get_b3_trace_id(),
        }

    return {
        "x-s": headers.get("x-s", ""),
        "x-t": headers.get("x-t", ""),
        "x-s-common": headers.get("x-s-common", ""),
        "x-b3-traceid": headers.get("x-b3-traceid", ""),
    }


# ── Stage 1：笔记列表 ──────────────────────────────────────────────────────────

async def get_note_list(user_id: str, cookie_str: str, max_notes: int = 100) -> list[dict]:
    """
    分页获取博主全部笔记的 note_id + xsec_token。
    返回列表，每条含: note_id, xsec_token, display_title, type
    """
    print(f"Stage 1: 获取笔记列表 (user_id={user_id}, max={max_notes})")
    all_notes = []
    cursor = ""
    base_url = "https://edith.xiaohongshu.com"
    uri = "/api/sns/web/v1/user_posted"
    page = 0

    while len(all_notes) < max_notes:
        page += 1
        fetch_num = min(30, max_notes - len(all_notes))
        params = {
            "num": fetch_num,
            "cursor": cursor,
            "user_id": user_id,
            "image_formats": "jpg,webp,avif",
        }
        signs = sign_with_xhshow(uri=uri, data=params, cookie_str=cookie_str, method="GET")
        headers = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
            "Referer": "https://www.xiaohongshu.com/",
            "Origin": "https://www.xiaohongshu.com",
            "Accept": "application/json, text/plain, */*",
            "Cookie": cookie_str,
            "X-S": signs["x-s"],
            "X-T": signs["x-t"],
            "x-S-Common": signs["x-s-common"],
            "X-B3-Traceid": signs["x-b3-traceid"],
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{base_url}{uri}",
                    params=params,
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=30),
                ) as resp:
                    if resp.status != 200:
                        print(f"  × HTTP {resp.status}")
                        break
                    result = await resp.json()
                    if not result.get("success"):
                        code = result.get("code")
                        print(f"  × API 失败 code={code}")
                        if code == -101:
                            print("  Cookie 已过期，请重新导出")
                        break
                    data = result.get("data", {})
                    notes = data.get("notes", [])
                    if not notes:
                        print(f"  [页{page}] 无更多笔记")
                        break
                    all_notes.extend(notes)
                    print(f"  [页{page}] +{len(notes)} 条，累计 {len(all_notes)}")
                    if not data.get("has_more") or not data.get("cursor"):
                        break
                    cursor = data["cursor"]
        except Exception as e:
            print(f"  × 异常: {e}")
            break

        if len(all_notes) < max_notes:
            await asyncio.sleep(3)

    print(f"✓ Stage 1 完成，共 {len(all_notes)} 条")
    return all_notes[:max_notes]


# ── Stage 2：笔记详情 ──────────────────────────────────────────────────────────

async def get_note_detail(note_id: str, xsec_token: str, cookie_str: str) -> Optional[dict]:
    """获取单条笔记完整详情（note_card）"""
    base_url = "https://edith.xiaohongshu.com"
    uri = "/api/sns/web/v1/feed"
    data = {
        "source_note_id": note_id,
        "image_formats": ["jpg", "webp", "avif"],
        "extra": {"need_body_topic": 1},
        "xsec_source": "pc_user",
        "xsec_token": xsec_token,
    }
    signs = sign_with_xhshow(uri=uri, data=data, cookie_str=cookie_str, method="POST")
    headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
        "Referer": "https://www.xiaohongshu.com/",
        "Origin": "https://www.xiaohongshu.com",
        "Accept": "application/json, text/plain, */*",
        "Content-Type": "application/json;charset=UTF-8",
        "Cookie": cookie_str,
        "X-S": signs["x-s"],
        "X-T": signs["x-t"],
        "x-S-Common": signs["x-s-common"],
        "X-B3-Traceid": signs["x-b3-traceid"],
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{base_url}{uri}",
                json=data,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                if resp.status != 200:
                    return None
                result = await resp.json()
                if not result.get("success"):
                    return None
                items = result.get("data", {}).get("items", [])
                return items[0].get("note_card", {}) if items else None
    except Exception as e:
        print(f"    × {e}")
        return None


# ── Main ───────────────────────────────────────────────────────────────────────

async def main():
    parser = argparse.ArgumentParser(description="XHS 两阶段笔记采集器")
    parser.add_argument("--user-id", required=True, help="博主 user_id（主页 URL 末尾）")
    parser.add_argument("--creator-name", default="", help="博主名称，用于输出文件命名")
    parser.add_argument("--max-notes", type=int, default=100, help="最大采集数（默认 100）")
    parser.add_argument("--output-dir", default="./output/raw/", help="输出目录")
    parser.add_argument("--cookie", default=None, help="Cookie 文件路径（可选，会自动搜索）")
    args = parser.parse_args()

    output_dir = Path(args.output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)
    creator_name = args.creator_name or args.user_id

    cookie, cookie_source = _load_cookie(args.cookie)
    if not cookie:
        print("× Cookie 未找到，请检查 Cookie 配置")
        sys.exit(1)
    print(f"✓ Cookie 来源: {cookie_source}")

    # Stage 1
    note_list = await get_note_list(args.user_id, cookie, args.max_notes)
    if not note_list:
        print("× Stage 1 失败")
        sys.exit(1)

    s1_path = output_dir / "stage1_note_list.json"
    s1_path.write_text(json.dumps(note_list, ensure_ascii=False, indent=2))
    print(f"  Stage 1 保存: {s1_path}")

    # Stage 2
    print(f"\nStage 2: 获取详情 ({len(note_list)} 条)")
    full_notes = []
    for i, note in enumerate(note_list, 1):
        note_id = note.get("note_id", "")
        xsec_token = note.get("xsec_token", "")
        print(f"  [{i}/{len(note_list)}] {note.get('display_title','')[:25]}...")
        detail = await get_note_detail(note_id, xsec_token, cookie)
        if detail:
            full_notes.append(detail)
            print(f"    ✓ {len(detail.get('image_list',[]))}张图 {len(detail.get('desc',''))}字")
        else:
            print(f"    × 失败")
        if i < len(note_list):
            await asyncio.sleep(3)

    date_str = date.today().strftime("%Y%m%d")
    out_path = output_dir / f"xhs_{creator_name}_{date_str}.json"
    out_path.write_text(json.dumps(full_notes, ensure_ascii=False, indent=2))
    print(f"\n✓ Stage 2 完成: {len(full_notes)}/{len(note_list)} 条")
    print(f"  输出: {out_path}")


if __name__ == "__main__":
    asyncio.run(main())
