#!/usr/bin/env python3
"""
search_playwright.py
通过 Playwright 拦截 XHR 获取小红书关键词搜索结果

重要：/api/sns/web/v1/search/notes 直接调用返回 404，
必须通过 Playwright 打开搜索页面，拦截页面发出的 XHR 响应。

用法:
  python3 search_playwright.py \
    --keywords "关键词1,关键词2,关键词3" \
    --output-dir ./output/raw/ \
    --category finance \
    --wait-sec 6

依赖:
  pip install playwright
  playwright install chromium
  （或 PLAYWRIGHT_BROWSERS_PATH=/path playwright install chromium）
"""

import argparse
import asyncio
import json
import sys
import time
import urllib.parse
from datetime import date
from pathlib import Path
from typing import Optional


# ── Cookie 加载 ────────────────────────────────────────────────────────────────

def load_cookie_list(cookie_path: Optional[str] = None) -> list[dict]:
    """加载 Cookie 为 Playwright 格式（list of dict）"""
    candidates = []
    if cookie_path:
        candidates.append(Path(cookie_path))
    for p in [
        Path.home() / "workspace" / "xiaohongshu_cookies.txt",
        Path.home() / ".openclaw" / "workspace" / "xiaohongshu_cookies.txt",
        Path("xiaohongshu_cookies.txt"),
    ]:
        candidates.append(p)

    for p in candidates:
        if not p.exists():
            continue
        content = p.read_text(encoding="utf-8").strip()
        if not content:
            continue
        # Netscape 格式
        if "\t" in content:
            cookies = []
            for line in content.splitlines():
                if line.strip() and not line.startswith("#"):
                    parts = line.split("\t")
                    if len(parts) >= 7:
                        cookies.append({
                            "name": parts[5],
                            "value": parts[6],
                            "domain": ".xiaohongshu.com",
                            "path": "/",
                        })
            if cookies:
                return cookies
        # key=value; key=value 格式
        else:
            cookies = []
            for pair in content.split(";"):
                pair = pair.strip()
                if "=" in pair:
                    k, v = pair.split("=", 1)
                    cookies.append({
                        "name": k.strip(),
                        "value": v.strip(),
                        "domain": ".xiaohongshu.com",
                        "path": "/",
                    })
            if cookies:
                return cookies

    # 从 .env 读取
    for env_path in [Path(".env"), Path.home() / ".openclaw" / "workspace" / ".env"]:
        if env_path.exists():
            for line in env_path.read_text(encoding="utf-8").splitlines():
                if line.startswith("XHS_COOKIE="):
                    val = line.split("=", 1)[1].strip().strip('"')
                    cookies = []
                    for pair in val.split(";"):
                        pair = pair.strip()
                        if "=" in pair:
                            k, v = pair.split("=", 1)
                            cookies.append({
                                "name": k.strip(),
                                "value": v.strip(),
                                "domain": ".xiaohongshu.com",
                                "path": "/",
                            })
                    if cookies:
                        return cookies

    raise FileNotFoundError("Cookie file not found. 请配置 xiaohongshu_cookies.txt 或 .env 中的 XHS_COOKIE")


# ── Playwright 搜索拦截 ────────────────────────────────────────────────────────

async def search_notes_playwright(
    keywords: list[str],
    cookies: list[dict],
    wait_sec: int = 6,
    video_only: bool = False,
) -> list[dict]:
    """
    对每个关键词打开搜索页，拦截 search/notes XHR，收集候选笔记。
    默认只收集图文笔记（type != "video"）。
    """
    from playwright.async_api import async_playwright

    all_candidates = []
    seen_ids: set[str] = set()

    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=True,
            args=["--no-sandbox", "--disable-dev-shm-usage"],
        )
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                       "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            viewport={"width": 1280, "height": 800},
        )
        await context.add_cookies(cookies)

        # 先建立 session（访问主页）
        print("  → 建立 XHS session...")
        page = await context.new_page()
        try:
            await page.goto("https://www.xiaohongshu.com/explore", timeout=20000)
            await page.wait_for_timeout(3000)
        except Exception as e:
            print(f"  ⚠ 主页加载异常（可能正常）: {e}")
        await page.close()

        for kw in keywords:
            candidates: list[dict] = []

            async def on_response(resp):
                try:
                    if "search/notes" in resp.url and resp.status == 200:
                        data = await resp.json()
                        items = data.get("data", {}).get("items", [])
                        for item in items:
                            note_card = item.get("note_card", {})
                            note_id = item.get("id") or note_card.get("note_id")
                            xsec_token = item.get("xsec_token") or note_card.get("xsec_token", "")
                            title = note_card.get("display_title") or note_card.get("title", "")
                            note_type = note_card.get("type", "")

                            if not note_id or note_id in seen_ids:
                                continue
                            if not video_only and note_type == "video":
                                continue  # 默认仅图文
                            if video_only and note_type != "video":
                                continue

                            candidates.append({
                                "note_id": note_id,
                                "xsec_token": xsec_token,
                                "display_title": title,
                                "type": note_type,
                            })
                            seen_ids.add(note_id)
                except Exception:
                    pass

            search_page = await context.new_page()
            search_page.on("response", on_response)
            encoded_kw = urllib.parse.quote(kw)
            url = f"https://www.xiaohongshu.com/search_result?keyword={encoded_kw}&type=51"
            print(f"  → 搜索: {kw} ...")
            try:
                await search_page.goto(url, timeout=20000)
                await search_page.wait_for_timeout(wait_sec * 1000)
            except Exception as e:
                print(f"    ⚠ 搜索页异常: {e}")
            await search_page.close()

            print(f"    ✓ 捕获候选: {len(candidates)} 条")
            all_candidates.extend(candidates)
            await asyncio.sleep(3)

        await browser.close()

    print(f"\n✓ 搜索完成，共 {len(all_candidates)} 条候选（去重）")
    return all_candidates


# ── Main ───────────────────────────────────────────────────────────────────────

async def main():
    parser = argparse.ArgumentParser(description="XHS 关键词搜索（Playwright XHR 拦截）")
    parser.add_argument("--keywords", required=True, help="搜索关键词，逗号分隔")
    parser.add_argument("--output-dir", default="./output/raw/", help="输出目录")
    parser.add_argument("--category", default="general", help="垂类标签（用于文件命名）")
    parser.add_argument("--wait-sec", type=int, default=6, help="每页等待秒数（默认 6）")
    parser.add_argument("--video-only", action="store_true", help="仅采集视频笔记")
    parser.add_argument("--cookie", default=None, help="Cookie 文件路径")
    args = parser.parse_args()

    output_dir = Path(args.output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)

    keywords = [k.strip() for k in args.keywords.split(",") if k.strip()]
    print(f"关键词: {keywords}")

    cookies = load_cookie_list(args.cookie)
    print(f"✓ 加载 {len(cookies)} 个 Cookie")

    candidates = await search_notes_playwright(
        keywords=keywords,
        cookies=cookies,
        wait_sec=args.wait_sec,
        video_only=args.video_only,
    )

    date_str = date.today().strftime("%Y%m%d")
    out_path = output_dir / f"xhs_{args.category}_candidates_{date_str}.json"
    out_path.write_text(json.dumps(candidates, ensure_ascii=False, indent=2))
    print(f"✓ 候选列表保存: {out_path}")
    print(f"  共 {len(candidates)} 条，可直接用于 Stage 2 采集")


if __name__ == "__main__":
    asyncio.run(main())
