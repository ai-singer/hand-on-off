---
name: xhs-collection-strategy
version: 1.0.0
description: 小红书内容采集完整策略。涵盖双层素材架构、博主发现、两阶段采集、评分分级、风险过滤、图片下载、视频处理的端到端执行规则。适用于商业财经垂类内容生产。
allowed-tools: Bash, Read
---

# XHS Collection Strategy Skill

小红书内容采集完整策略，覆盖从博主发现到素材入库的端到端流程。

---

# 核心架构

## 双层素材架构（不可混用）

```
Layer 1: Discovery Layer（发现层）
  └── 小红书、微博、短视频平台
  └── 用途：发现话题、用户问题、流量信号
  └── 禁止：作为事实来源、直接复写、引用数据

Layer 2: Evidence Layer（证据层）
  └── 官方数据：企业年报、政府公告、统计局数据
  └── 用途：提供可核实的事实、数据、机制解释
  └── 禁止：用社交平台内容代替
```

规则：Discovery Layer 输出 topic_candidate，Evidence Layer 输出 source_material。两者不得互相替代。

---

# 禁止采集内容

以下内容一律不得进入素材库，触发后立即移至 blocked 目录：

| 类别 | 关键词示例 |
|------|-----------|
| 股票/证券操作 | 股票、炒股、A股、选股、个股、持仓、仓位 |
| 投资建议 | 投资建议、投资推荐、交易策略、买卖信号 |
| 金融产品推销 | 理财产品、基金推荐、证券、期货操作 |
| 暴富/速成类 | 暴富、一夜暴富、躺赚、被动收入 |
| 敏感财务目标 | 财务自由、财富自由 |
| 政治/社会敏感 | 敏感政治评论、社会争议、宗教、民族议题 |

---

# 博主发现流程（Creator Discovery）

## 触发条件
用户提供垂类方向而非具体博主。

## Step 1：生成搜索关键词
根据垂类生成 3–5 个关键词，Finance 垂类示例：
- 商业分析、财务知识、企业经营、商业逻辑、公司案例

## Step 2：Baidu 搜索
```
小红书 {关键词} 博主 知识 商业
site:xiaohongshu.com {关键词}
```

## Step 3：质量筛选维度
| 维度 | 要求 |
|------|------|
| 内容方向 | 垂类强相关，机制解释优先 |
| 内容类型 | 知识型 > 娱乐型 |
| 原创性 | 有独立分析，非纯搬运 |
| 风险规避 | 不涉及投资建议、敏感话题 |

## Step 4：user_id 验证（必须）
从主页 URL 提取 user_id：
```
https://www.xiaohongshu.com/user/profile/{user_id}
```

调用 API 验证：
```
GET /api/sns/web/v1/user/otherinfo?target_user_id={user_id}
```

确认返回 `basic_info.nickname` 与博主名称匹配。

**规则：未经 API 验证的 user_id 不得写入 registry，不得执行采集。**

## Step 5：写入 candidate_registry.json
```json
{
  "creator_name": "小Lin说",
  "user_id": "5abf90244eacab2c32c7c5e6",
  "category": "finance",
  "red_id": "636461303",
  "followers": "220万",
  "discovery_keywords": ["商业分析", "财务知识"],
  "risk_check": "passed",
  "identity_verified": true,
  "verified_at": "2026-09-18T00:00:00Z",
  "status": "active"
}
```

---

# 两阶段采集流程

## 依赖
```bash
pip install aiohttp xhshow playwright
PLAYWRIGHT_BROWSERS_PATH=/home/node/.playwright playwright install chromium
```

## Cookie 配置
- 路径：`~/workspace/xiaohongshu_cookies.txt`（Netscape 格式）
- 有效期：约 30 天
- 失效特征：API 返回 `code=-101`

## Stage 1：获取笔记列表
```
GET /api/sns/web/v1/user_posted
参数：num=30, cursor={cursor}, user_id={user_id}
```
- 每页 30 条，自动翻页
- 获取：note_id + xsec_token
- 页间延迟：≥ 3 秒
- 输出：`raw/xhs_{博主名}_stage1_{date}.json`

## Stage 2：获取笔记详情
```
POST /api/sns/web/v1/feed
body：source_note_id, xsec_token, xsec_source=pc_feed
```
- 每条延迟：≥ 3 秒
- 获取：title, desc, image_list, tag_list, interact_info
- 输出：`raw/xhs_{博主名}_stage2_{date}.json`

## 速率限制（必须遵守）
| 操作 | 间隔 | 单次上限 |
|------|------|---------|
| Stage 1 翻页 | ≥ 3s | — |
| Stage 2 每条 | ≥ 3s | — |
| Playwright 访问笔记页 | ≥ 5s | ≤ 20 条/session |
| 图片下载（批量） | ≥ 3s/张 | ≤ 10 张/批 |
| Stage 1+2 完成后 Playwright | 间隔 ≥ 30min | — |

---

# 标准化与分级

## 存储结构
```
source_material/xhs/
  raw/                          # 原始 JSON（不修改）
  finance/
    video/{note_id}/
      meta.json                 # 标准化元数据
      transcript.json           # ASR 字幕（如已处理）
      frames/                   # 关键帧（如已提取）
    image_text/
      {note_id}.json            # 标准化元数据
    image_text_blocked/         # 风险过滤移出（不删除，留审计）
    image_text_imgs/{note_id}/  # 下载的图片文件
```

## Account Benchmark（账号基准）
采集 100 条后先建立账号基准：
```
P50/P75/P90/P95 × {liked, collected, comment, share}
```
存入：`creator_registry/{creator}_benchmark.json`

## 分级阈值（以小Lin说为例）
| 级别 | 收藏数阈值 |
|------|-----------|
| S | ≥ P95（≥ 6260） |
| A | ≥ P90（≥ 5746） |
| B | ≥ P75 |
| C | < P75 |

## Content Signal Score（快速排序用）
```
score = log1p(collected)×0.35 + log1p(share)×0.30
      + log1p(comment)×0.25 + log1p(liked)×0.10
```
对 9.21 归一化到 0–100 分。

## 跨账号归一化
```
Account Factor = 其他账号均值 / 小Lin说均值
Adjusted Performance = Raw ÷ Account Factor
```
大账号（Factor > 1）降权，避免被粉丝基数虚高干扰。

---

# 风险过滤

## 触发关键词（任意命中即移出）
```
股票/炒股/A股/选股/个股/持仓/仓位/
投资建议/投资推荐/交易策略/买卖信号/
理财产品/基金推荐/证券/期货操作/
暴富/一夜暴富/躺赚/被动收入/
财务自由/财富自由
```

## 处理规则
- 命中 → 移至 `finance/image_text_blocked/`（不删除）
- 仅检查 title + desc（不检查 tag）
- 过滤后更新 meta.json 中 `material_tier = "blocked"`

---

# 图片下载

## ✅ 唯一有效方案：Playwright 同一 Context 内请求

原理：CDN 只对浏览器 session 开放，curl/requests 直接请求一律 403。

```python
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    context = browser.new_context(...)
    context.add_cookies(cookies)

    page = context.new_page()
    img_urls = []
    page.on("response", lambda r: img_urls.append(r.url)
            if "sns-webpic" in r.url and r.status == 200 else None)

    page.goto("https://www.xiaohongshu.com/explore")  # 先建立 session
    page.goto(f"https://www.xiaohongshu.com/explore/{note_id}")
    time.sleep(5)  # 等待图片加载

    # ✅ 在同一 context 新建 page 下载
    img_page = context.new_page()
    resp = img_page.goto(img_urls[0])
    body = resp.body()  # 200 OK，图片字节
```

## ❌ 已验证失败方案（不要重试）
| 方案 | 结果 |
|------|------|
| curl 直接请求 CDN URL | 403（IP 白名单） |
| curl + Cookie | 403（CDN 不验证 Cookie） |
| curl + Referer | 403 |
| Stage 2 存储的 URL 延迟请求 | 403（签名过期） |

## IP 限流恢复
- 触发特征：所有 `/explore/{note_id}` 返回「页面不见了」
- 恢复方法：等待 12–24h / 更换 Cookie / 更换 IP

---

# 视频处理

## 下载：Playwright 实时拦截
Stage 2 存储的视频 URL 有时效签名，采集后即过期，必须实时拦截。

```python
def handle_response(response):
    url = response.url
    if any(cdn in url for cdn in ["sns-video-bd", "sns-video-hw", "sns-video-qc"]) \
       and response.request.resource_type in ("media", "xhr", "fetch"):
        captured_urls.append(url)

page.on("response", handle_response)
page.goto(f"https://www.xiaohongshu.com/explore/{note_id}")
page.wait_for_timeout(5000)
# 用 ffmpeg 下载拦截到的 URL
```

## 静态帧提取（ffmpeg）
```bash
ffmpeg -i video.mp4 \
  -vf "select='gt(scene,0.02)',setpts=N/FRAME_RATE/TB" \
  -vsync vfr frames/%06d.jpg
```
阈值：连续相同帧 ≥ 1 秒判定为静态帧。

## ASR 字幕（faster-whisper base）
```python
# 模型下载需设置镜像（huggingface.co 不可达）
export HF_ENDPOINT=https://hf-mirror.com

from faster_whisper import WhisperModel
model = WhisperModel('base', device='cpu', compute_type='int8')
segments, _ = model.transcribe('audio.wav', language='zh')
```
输出：`video/{note_id}/transcript.json`

## 视频内容角色
- 视频 = **话题发现**，不做知识蒸馏
- 从 title + tags + transcript 提取 topic_candidate
- 存入 `creator_registry/topic_pool.json`

---

# 话题池管理

## topic_pool.json 结构
```json
[
  {
    "topic": "IPO 发行机制",
    "angle": "普通投资者视角",
    "mechanism": "承销商定价博弈",
    "content_hook": "你以为抢到新股就赚了，其实...",
    "source_note_id": "6a...",
    "material_tier": "S",
    "content_type": "video",
    "added_at": "2026-09-22T00:00:00Z"
  }
]
```

## 入池规则
- 仅 A 级及以上进入话题池
- S/A 同步至 GitHub（`topic_pool.json`）
- 每个话题需包含：topic / angle / mechanism / content_hook

---

# 知识蒸馏入口（图文）

图文 S/A 级素材完成采集后，进入蒸馏流程：

1. 读取 `agent_config/distillation_framework.md`
2. 对图文提取：结构层 + 认知层 + 表达层
3. 输出模板至 `agent_config/distilled/content_templates_{垂类}_{来源}.md`
4. 视觉 prompt 输出至 `agent_config/distilled/visual_prompt_templates_{垂类}_{来源}.md`

**视频素材仅提取话题，不做内容蒸馏。**

---

# 已验证环境参数

| 项目 | 值 |
|------|----|
| Playwright 安装路径 | `/home/node/.playwright` |
| Chromium binary | `/home/node/.playwright/chromium-1243/chrome-linux64/chrome` |
| faster-whisper 版本 | 1.2.1 |
| HF 镜像 | `https://hf-mirror.com`（可达） |
| 小Lin说 user_id | `5abf90224eacab2c32c7c5e6` |
| Cookie 路径 | `~/workspace/xiaohongshu_cookies.txt` |
| Scraper 脚本 | `~/.openclaw/skills/xhs-scraper-skill/scripts/scrape_two_stage.py` |
| 图片下载脚本 | `~/workspace/source_material/xhs/scripts/xhs_download_images.py` |

---

# 完整采集执行顺序

```
1. 验证 Cookie（curl edith.xiaohongshu.com 测试）
2. 博主发现 + user_id API 验证（如新博主）
3. Stage 1：获取笔记列表（100条，≥3s/页）
4. Stage 2：获取笔记详情（≥3s/条）
5. 建立 Account Benchmark（P50/P75/P90/P95）
6. normalize.py 标准化 + 分级
7. 风险关键词过滤（blocked → image_text_blocked/）
8. Playwright 图片下载（S/A 级，≥5s/笔记）
9. 话题提取 → topic_pool.json（视频 S/A）
10. 蒸馏 → content_templates（图文 S/A）
11. 同步 GitHub（S/A 元数据 + topic_pool + templates）
```

---

# 版本

v1.0.0 — 2026-09-22

基于：xhs-scraper-skill v1.x + source_strategy v2.0 + 实际采集经验整合
